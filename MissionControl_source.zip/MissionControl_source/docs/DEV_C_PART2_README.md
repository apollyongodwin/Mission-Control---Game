# Dev C, Part 2: Mission Control "wow" layer

All files are NEW. Nothing in SimEngine, Data or any other dev's file was changed.

## Files (copy into the repo keeping these paths)
ui/broadcast/BCTheme.gd, HealthStrip.gd, ShipSchematic.gd(+.tscn), OrbitView.gd(+.tscn), Ticker.gd(+.tscn),
Announcer.gd, CrisisOverlay.gd, LaunchSequence.gd, DemoMode.gd, BroadcastLayer.gd(+.tscn)
tests/broadcast_part2_test.gd(+.tscn)

## Test it alone (no other modules needed)
Open tests/broadcast_part2_test.tscn and press F6. Keys are printed at the top-left.
Quick tour: press 1, then B P A M N S O I (parts change and the ship updates), 4 (orbit view),
C then X X X X (crisis, radio silence), V (resolved), 3 (launch countdown), D or F9 (full Demo Mode).

## Hook it into Part 1 (ONE line)
File: ui/broadcast/BroadcastMain.gd. At the END of its _ready() function add:
    add_child(preload("res://ui/broadcast/BroadcastLayer.tscn").instantiate())
(The root of BroadcastMain must be a plain Control, not a VBox/HBox container.)
If the new pieces overlap Part 1 content, edit the LAYOUT numbers at the top of BroadcastLayer.gd only.

## For the Lead (MissionState and Net hookup)
BroadcastLayer reads these from the autoload /root/MissionState IF it exists, and ignores them if not:
  property `design` (Dictionary), property `phase` (String like "DESIGN" OR int index in spec order
  LOBBY=0 ... DEBRIEF=6), optional property `difficulty`; signals `design_changed`, `phase_changed`
  (any argument list works).
Everything else is driven by calls. From anywhere:
  get_tree().call_group("broadcast_layer", "show_crisis", event_dict, timer_s, radio_silence_bool)
  ... "crisis_acted", role   ... "add_ping", role, card_id   ... "crisis_resolved", {"residual": 0.0..1.0, "line": "why text"}
  ... "announce_poll", role, go_bool   ... "start_launch", reliability_pct, seconds, success_bool
  ... "show_report", report_dict   ... "set_radio_silence", bool
Signals on the layer: launch_finished(success) (use it to move on to FLIGHT), sfx_requested(name).
Set `layer.auto_launch = false` if you want to call start_launch() yourself with the real roll result.
Audio: if an autoload `Audio` has a method play_sfx(name), it is called with
  snap, chime, buzz, alarm, tick, liftoff, success.

## Contracts I assumed (tell me if different)
- crisis_resolved result: "residual" (float, 0 = fully saved) and "line" (plain-language what happened and why).
- Ping card ids look like "need_power" (underscores become spaces on screen).
- Roles are lowercase: flight, systems, payload, ground.

## Credits / notes
Everything is drawn in code (no art files). TTS uses DisplayServer.tts_speak and silently does nothing when unavailable.
