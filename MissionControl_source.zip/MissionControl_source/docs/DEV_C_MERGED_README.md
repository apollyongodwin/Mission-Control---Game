# Dev C: Part 1 + Part 2 merged

Copy this folder's contents over your repo (paths are res:// paths).

## Run it
- Open ui/broadcast/BroadcastMain.tscn and press F6 (uses the built-in fake MissionState if the real one is missing).
- Keys: Right/Left = phase, 1-4 seats, Q W E R poll, D design, S scenario (Part 1)
        F9 = full Demo Mode (deterministic), C = crisis, X = next role acts, G = ping, V = resolve (Part 2)
- Part 2 alone: tests/broadcast_part2_test.tscn (F6).

## What changed in Part 1 files (ui/broadcast/BroadcastMain.gd only)
- new vars (_layer, _ship_slot, _orbit_slot ...), new funcs _make_layer, _sync_slots, _lights_row
- _ready calls _make_layer() before _refresh()
- DESIGN: right column = empty ship slot + a compact row of the 6 lights (old tall lights panel unused)
- FLIGHT: left = event, clock, small ship slot; right = orbit view slot
- LAUNCH: Part 1's own countdown is skipped (Part 2's countdown overlay replaces it)
- bottom margin 110 so content stays above the ticker
- test keys C X G V (fake state only)
BroadcastLayer got bind_state(), place_slot(), clear_slots(), drive_phase/design/poll() for this merge.

## For the Lead
Real MissionState: BroadcastMain binds to /root/MissionState automatically. Other calls and contracts are in DEV_C_PART2_README.md.
