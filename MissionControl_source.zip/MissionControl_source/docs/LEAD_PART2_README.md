# LEAD Part 2: what is in this folder

New files (copy into the project, nothing to merge):
- `net/PhaseMachine.gd`            the phase machine (host only; also runs offline so you can test alone)
- `sim/FlightDirectorStub.gd`      TEMPORARY stand-in for Dev A's FlightDirector; delete when theirs passes the test
- `tests/phase_test.tscn/.gd`      offline test, 55 checks (F6)
- `tests/net_e2e.tscn/.gd`         real two-process test (host window + client window)

Files you must PATCH (yours differ from the zip I was given, so merge by hand):
- `patches/Net.diff`               against the Part 1 Net.gd
- `patches/MissionState.diff`      against the Part 1 MissionState.gd
- `reference_zip_versions/`        the fully patched files, ONLY safe to copy over if your copy matches the zip

## What to change in Net.gd
1. `var phase_machine: PhaseMachine` and create it as the FIRST lines of `_ready()` (before Net connects its own
   phase listener; the machine sets `phase_payload` for LAUNCH and Net must send it afterwards).
2. `_on_peer_connected`: also send `phase_changed.rpc_id(id, MissionState.phase, MissionState.phase_payload)`.
3. `_on_peer_disconnected`: call `phase_machine.on_peer_disconnected(id)` instead of `MissionState.release_peer(id)`.
4. New RPC `hello(key)`, sent from `_on_connected_ok`. `_client_key` is random per app run, so the host can
   give the same player their seat back after a drop.
5. `_flush_broadcast` (your `broadcast_state`): add `private_view["tokens"] = MissionState.tokens_for_role(role)`.
6. `debrief` RPC: set `MissionState.last_report = report` before emitting.
7. New helpers: `host_set_phase(p, payload := {})`, `host_again()`, `host_new_mission()`, `say_to(peer, code, text)`,
   `say_all(code, text)`, `resend_to(peer)`. If you already have `host_set_phase`, keep yours but make sure it accepts
   `(phase, payload)`; `PhaseMachine._go()` is the only line that calls it. `say_to` / `say_all` should use your
   `notify_rejected(kind, reason)`; mine use the zip's `server_message`.
Also: `join_game` sets `MissionState.eval_result = {}` (a client must never hold a result).
The stubs for `call_review`, `poll_answer`, `play_action`, `give_token`, `ping`, `event_choice` must emit the host-side
signals that exist in the zip (`review_requested`, `poll_answered`, `action_requested`, `token_give_requested`,
`ping_received`, `event_choice_made`); PhaseMachine connects to those.

## What to change in MissionState.gd
Signals `poll_changed`, `flight_status_changed`; vars `poll`, `flight_status`, `last_report`; clear them in `reset_all`;
`set_poll`, `set_flight_status`, `tokens_for_role`; add `poll` and `flight_status` to `public_state()`;
`apply_sync` splits `tokens` off the private view (so a token change is not a "design change") and emits the new signals.

## Seat values (tell Dev D)
`MissionState.seats[role]`: 0 = empty, -1 = bot, -2 = held for a dropped player (`PhaseMachine.SEAT_HELD`), > 0 = peer id.
Anything non-zero should look "taken" in the lobby.
