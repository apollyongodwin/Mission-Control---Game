# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name NetInfo
extends RefCounted
## LEAD (LAN fix). Which address should the crew type?
## A laptop often has several IPv4 addresses: the real Wi-Fi/Ethernet one, plus VIRTUAL adapters that other
## laptops can never reach (WSL / Hyper-V "vEthernet" 172.x, VirtualBox 192.168.56.x, VMware, Docker, VPNs).
## The old lobby showed the first private address it found, which was often a virtual one.
## This ranks every address so the real Wi-Fi/Ethernet one comes first.

const VIRTUAL_WORDS := ["vethernet", "virtualbox", "vbox", "vmware", "hyper-v", "wsl", "docker", "loopback",
	"bluetooth", "vpn", "tap-", "tun", "utun", "npcap", "zerotier", "hamachi", "radmin", "teredo", "isatap", "bridge"]
const REAL_WORDS := ["wi-fi", "wifi", "wlan", "wireless", "ethernet", "en0", "en1", "eth0", "wlp", "enp", "local area connection"]


static func _is_private(ip: String) -> bool:
	var p := ip.split(".")
	if p.size() != 4:
		return false
	if p[0] == "10" or (p[0] == "192" and p[1] == "168"):
		return true
	return p[0] == "172" and int(p[1]) >= 16 and int(p[1]) <= 31


## [{ip, name, score}] best first. Only IPv4, never loopback or link-local.
static func candidates() -> Array:
	var out: Array = []
	var seen := {}
	for iface in IP.get_local_interfaces():
		var label: String = (str(iface.get("friendly", "")) + " " + str(iface.get("name", ""))).to_lower()
		for a in iface.get("addresses", []):
			var ip := str(a)
			if ip.count(".") != 3 or ip.begins_with("127.") or ip.begins_with("169.254.") or seen.has(ip):
				continue
			seen[ip] = true
			var score := 0
			if _is_private(ip):
				score += 5
			for w in REAL_WORDS:
				if label.contains(w):
					score += 4
					break
			for w in VIRTUAL_WORDS:
				if label.contains(w):
					score -= 12
					break
			if ip.begins_with("192.168.56.") or ip.begins_with("192.168.99."):
				score -= 8    # VirtualBox / docker-machine host-only networks
			if ip.begins_with("172.") and not label.contains("wi"):
				score -= 2    # 172.17-31 is very often WSL / Docker
			if ip.ends_with(".1"):
				score -= 1    # usually a router or a virtual switch, rarely a laptop
			out.append({"ip": ip, "name": str(iface.get("friendly", iface.get("name", ""))), "score": score})
	out.sort_custom(func(x, y): return int(x["score"]) > int(y["score"]))
	return out


static func best_ip() -> String:
	var c := candidates()
	return str(c[0]["ip"]) if not c.is_empty() else "127.0.0.1"


## Every address except the best one, for the "or try" line.
static func other_ips() -> Array:
	var c := candidates()
	var out: Array = []
	for i in range(1, c.size()):
		out.append(str(c[i]["ip"]))
	return out


## Broadcast targets for the LAN beacon: the global broadcast plus each interface's /24 broadcast.
static func broadcast_targets() -> Array:
	var t: Array = ["255.255.255.255"]
	for c in candidates():
		var p := str(c["ip"]).split(".")
		var b := "%s.%s.%s.255" % [p[0], p[1], p[2]]
		if not t.has(b):
			t.append(b)
	return t


const HELP := """CREW CAN'T CONNECT? Check these, in order:
1. Every laptop is on the SAME Wi-Fi (or the same phone hotspot).
2. Windows asked "Allow access?" the first time: it must be allowed on PRIVATE networks.
   Fix: Windows Security > Firewall > Allow an app > tick Godot / Mission Control (Private AND Public).
3. Set the Wi-Fi to "Private network" in Windows Wi-Fi settings (Public blocks other laptops).
4. School / event / cafe Wi-Fi often blocks laptop-to-laptop traffic ("client isolation").
   Fix: use a phone hotspot or a cheap travel router.
5. Type one of the OTHER addresses shown below if the big one does not work.
6. Everyone must run the SAME copy of the game (the lobby now says so if they differ)."""
