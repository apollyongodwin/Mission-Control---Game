# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name PhaseMachine
extends Node
## HOST-SIDE phase machine (spec section 2). Created by Net as a child node; it only acts on the host
## (and offline, so a whole mission can be tested in one process). On clients it does nothing.
##
## LOBBY -> BRIEFING -> DESIGN -> REVIEW -> LAUNCH -> FLIGHT -> DEBRIEF
##                         ^_______|  (any NO-GO, with the reason)
##
## Entry logic runs when MissionState.phase_changed fires, so it does not matter WHO changed the phase
## (Dev D's START button, a test, or this class): Net.host_set_phase("BRIEFING") is enough to start a mission.
##
## ---------------------------------------------------------------------------------------------
## FLIGHT DIRECTOR CONTRACT (what Dev A's sim/FlightDirector.gd must provide; sim/FlightDirectorStub.gd
## follows it). If res://sim/FlightDirector.gd exists it is used, otherwise the stub.
##   var tokens: Dictionary                      role -> {token: int}   (host-side truth)
##   setup(design, eval_result, seed, difficulty, length)
##   beat_count() -> int                         (optional; used for the timeline strip)
##   next_beat() -> Dictionary                   {} when finished, else
##                                               {"index","total","kind":"crisis|opportunity|decision","event":{...},"timer_s"}
##   play_action(role, action_id) -> Dictionary  {"ok": bool, "reason": String}
##   give_token(from_role, to_role, token) -> bool
##   event_choice(role, option_id) -> Dictionary {"ok": bool, "reason": String, "complete": bool}
##                                               opportunity: option "capture" (this role pays what it can toward "needs")
##                                               decision:    option = the option id (e.g. "accept")
##   resolve_current() -> Dictionary             result dict for the finished beat (give it a "line" = what happened and why)
##   final_report() -> Dictionary
##   auto_play(role) -> Dictionary               OPTIONAL: bot/empty seat plays its best affordable action
##   record_ping(role, card_id)                  OPTIONAL
##   tick(delta)                                 OPTIONAL bookkeeping ONLY. This class owns the crisis timer and calls
##                                               resolve_current() itself, so tick() must NOT resolve anything.
## ---------------------------------------------------------------------------------------------

const SEAT_HELD := -2            # MissionState.seats[role] value while a dropped player's seat is held
const HOLD_SECONDS := 60.0
const BRIEFING_SECONDS := 15.0
const POLL_STAGGER_SECONDS := 0.9
const LAUNCH_COUNTDOWN_SECONDS := 6.0
const FIRST_BEAT_DELAY := 3.0
const BEAT_GAP_SECONDS := 7.0    # the mission "time-lapses" between beats (MERGE: 7 s so players can read the result + quip)
const UNTIMED_FAILSAFE_SECONDS := 90.0
const SOLO_BEAT_SECONDS := 4.0   # nobody connected: do not wait a full timer
const MAX_PINGS := 12
## LEAD (round 7/8) BUILD CLOCK: the lobby picks the time (data meta.build_clock, default 3:00). After 0:00 the investors
## take C$6M every 15 s (up to 30% of the budget) AND every step costs FLIGHT 1 time token at launch: lost time hurts.
const OVERTIME_STEP_SECONDS := 15.0
const OVERTIME_CUT := 6.0
const MAX_CUT_FRACTION := 0.3
## LEAD (round 8) MINI-TASKS. One per role (ui/common/MiniTask.gd draws them).
const TASKS := {"flight": "asteroids", "systems": "wires", "payload": "binary", "ground": "trace"}
const TASK_REWARD := {"flight": "fuel", "systems": "power", "payload": "data", "ground": "budget"}

var director = null              # Dev A's FlightDirector (or the stub); untyped on purpose
var _clock := 0.0
var _epoch := 0                  # bumps on every phase change: stale scheduled jobs are dropped
var _beat_serial := 0            # bumps on every beat start/resolve: stale bot actions are dropped
var _sched: Array = []
var _rng := RandomNumberGenerator.new()

var _briefing_left := 0.0
var _poll: Dictionary = {}
var _launch_success := true

var _beat: Dictionary = {}       # the current beat from the director
var _event: Dictionary = {}      # event copy that was sent to clients
var _active := false             # a beat with a running timer
var _resolving := false
var _time_left := 0.0
var _acted: Dictionary = {}
var _pings: Array = []
var _status: Dictionary = {}

var _bots: BotCrew = null        # MERGE: Dev A's AutoCrew fills the parts for every seat without a human
var _bot_design_done := false
var _bot_review_called := false
var _design_left: float = 0.0
var _overtime: float = 0.0
var _clock_on: bool = false
var _gifts: int = 0              # round 6: tokens handed over this mission (Helping Paws medal)
var _forced: Dictionary = {}     # round 4: category -> the value the Commander rejected (a bot's own plan must not put it back)
var _overtime_steps: int = 0     # round 8: each overtime step costs 1 time token at launch
var _tasks: Dictionary = {}      # round 8: role -> {"task", "kind": "random"|"chip", "state": "running"|"done"|"failed"}
var _task_round: bool = false    # round 8: a random task round is running between two beats
var _lost_this_beat: bool = false
const SEAT_BOT := -1

var _keys: Dictionary = {}       # peer id -> client key (from the hello RPC)
var _held: Dictionary = {}       # role -> {"key": String, "left": float}


func _ready() -> void:
	MissionState.phase_changed.connect(_on_phase_changed)
	MissionState.seats_changed.connect(_on_seats_changed)
	# Net's host-side signals (a validated request from a seated player)
	Net.review_requested.connect(on_call_review)
	Net.poll_answered.connect(on_poll_answer)
	Net.action_requested.connect(on_play_action)
	Net.token_give_requested.connect(on_give_token)
	Net.ping_received.connect(on_ping)
	Net.event_choice_made.connect(on_event_choice)


func _process(delta: float) -> void:
	tick(delta)


## Public so tests can drive time without waiting.
func tick(delta: float) -> void:
	if not Net.is_authority():
		return
	_clock += delta
	_run_scheduled()
	_tick_holds(delta)
	match MissionState.phase:
		"BRIEFING":
			_briefing_left -= delta
			if _briefing_left <= 0.0:
				_go("DESIGN")
		"DESIGN":
			_tick_bot_design(delta)   # MERGE: AutoCrew bots pick their parts
			_tick_build_clock(delta)
		"FLIGHT":
			if _active:
				_time_left -= delta
				if director != null and director.has_method("tick"):
					director.tick(delta)
				if _time_left <= 0.0:
					_resolve_beat()


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------

## The ONE place a phase is changed. If your Net.host_set_phase has a different shape, edit this line only.
func _go(p: String, payload: Dictionary = {}) -> void:
	Net.host_set_phase(p, payload)


func _later(delay: float, fn: Callable) -> void:
	_sched.append({"due": _clock + delay, "fn": fn, "epoch": _epoch, "beat": _beat_serial})


func _run_scheduled() -> void:
	var pending: Array = _sched
	_sched = []
	for s in pending:
		if int(s["epoch"]) != _epoch or int(s["beat"]) != _beat_serial:
			continue
		if _clock >= float(s["due"]):
			(s["fn"] as Callable).call()
		else:
			_sched.append(s)


func _is_human(role: String) -> bool:
	## a player we wait for: connected, or a dropped player whose seat is being held
	var s: int = int(MissionState.seats.get(role, 0))
	return s > 0 or s == SEAT_HELD


func _is_connected(role: String) -> bool:
	return int(MissionState.seats.get(role, 0)) > 0


func _tell(role: String, code: String, text: String) -> void:
	var peer: int = int(MissionState.seats.get(role, 0))
	if peer > 0:
		Net.say_to(peer, code, text)


func _tell_all(code: String, text: String) -> void:
	Net.say_all(code, text)


func _role_name(role: String) -> String:
	return str(Data.db["meta"]["roles"][role]["name"])


func _difficulty_cfg() -> Dictionary:
	return Data.db["meta"]["difficulty"][MissionState.difficulty]


func _make_director():
	# MERGE: Dev A's FlightDirector is wrapped so it fits the contract above (see sim/FlightDirectorAdapter.gd).
	if ResourceLoader.exists("res://sim/FlightDirector.gd"):
		return FlightDirectorAdapter.new()
	return FlightDirectorStub.new()


func _sync_tokens() -> void:
	if director != null:
		MissionState.set_tokens(director.tokens)


# ----------------------------------------------------------------------
# Phase entry
# ----------------------------------------------------------------------

func _on_phase_changed(p: String) -> void:
	if not Net.is_authority():
		return
	_epoch += 1
	_sched = []
	match p:
		"LOBBY":
			_reset_flight()
			_free_bot_seats()
			if not MissionState.twists.is_empty():
				MissionState.set_twists([])
		"BRIEFING":
			_briefing_left = BRIEFING_SECONDS
			for r in Protocol.ROLES:
				MissionState.set_ready(r, false)
			_rng.seed = MissionState.mission_seed + 7
			_fill_empty_seats_with_bots()
			_bot_design_done = false
			_forced = {}
			_roll_twists()
			_start_build_clock()
		"DESIGN":
			_poll = {}
			MissionState.set_poll({})
			MissionState.set_commander_go(false)
			_bot_review_called = false
			if MissionState.design_left < 0 and not MissionState.demo_mode:
				_start_build_clock()   # "Again!" skips the briefing
			_start_bot_design()
			_later(1.0, _bots_obey_pending_swaps)   # round 4: swaps marked during REVIEW get fixed once DESIGN is back
		"REVIEW":
			_enter_review()
		"LAUNCH":
			_enter_launch()
		"FLIGHT":
			_enter_flight()


func _on_seats_changed() -> void:
	if not Net.is_authority() or MissionState.phase != "BRIEFING":
		return
	if MissionState.filled_seat_count() > 0 and MissionState.all_seated_ready():
		_go("DESIGN")


func _reset_flight() -> void:
	director = null
	_gifts = 0
	_tasks = {}
	_task_round = false
	MissionState.set_lives(-1, -1)
	_bots = null
	_active = false
	_resolving = false
	_beat = {}
	_event = {}
	_acted = {}
	_pings = []
	_poll = {}
	_status = {}
	MissionState.set_tokens({})
	MissionState.set_poll({})
	MissionState.set_flight_status({})


## "Again!" with the same crew and the same design (UX guide section 6). Host only.
func again() -> void:
	if not Net.is_authority():
		return
	_reset_flight()
	for r in Protocol.ROLES:
		MissionState.tokens[r] = {}
	MissionState.mission_seed = MissionState.DEMO_SEED if MissionState.demo_mode else (randi() % 999999) + 1
	_go("DESIGN")


# ----------------------------------------------------------------------
# MERGE: AutoCrew bots in DESIGN (Dev A's sim/BotCrew.gd). Spec section 2: empty seats are filled by bots.
# ----------------------------------------------------------------------

func _fill_empty_seats_with_bots() -> void:
	var changed := false
	for r in Protocol.ROLES:
		if int(MissionState.seats.get(r, 0)) == 0:
			MissionState.seats[r] = SEAT_BOT
			MissionState.seat_ready[r] = true
			changed = true
	if changed:
		MissionState.seats_changed.emit.call_deferred()   # deferred: never change phase from inside a phase change


func _any_human() -> bool:
	for r in Protocol.ROLES:
		if _is_human(r):
			return true
	return false


func _free_bot_seats() -> void:
	var changed := false
	for r in Protocol.ROLES:
		if int(MissionState.seats.get(r, 0)) == SEAT_BOT:
			MissionState.seats[r] = 0
			MissionState.seat_ready[r] = false
			changed = true
	if changed:
		MissionState.seats_changed.emit()


func _start_bot_design() -> void:
	if _bot_design_done:
		return   # after a NO-GO the bots keep their choices; humans fix the rest
	_bot_design_done = true
	var roles: Array = []
	for r in Protocol.ROLES:
		if not _is_human(r):
			roles.append(r)
	if roles.is_empty():
		_bots = null
		return
	_bots = BotCrew.new()
	_bots.setup(Data.db, MissionState.scenario_id, roles, MissionState.mission_seed + 3)
	_bots.begin_design()
	var names: Array = []
	for r in roles:
		names.append(_role_name(r))
	_tell_all("bot_chatter", "AutoCrew bots are flying %s." % ", ".join(names))


func _tick_bot_design(delta: float) -> void:
	# Nobody human on board (attract / demo mode): when the bots finish, they call the review themselves.
	if not _any_human() and not _bot_review_called and (_bots == null or not _bots.design_pending()):
		_bot_review_called = true
		_later(2.0, func() -> void: on_call_review("flight"))
	if _bots == null:
		return
	for c in _bots.tick_design(delta):
		var role: String = str(c["role"])
		if _is_human(role):
			continue   # a human took the seat back
		if _forced.has(str(c["category"])) and str(_forced[str(c["category"])]) == str(c["value"]):
			continue   # the Commander rejected exactly this one
		var err: String = Net.apply_choice_as(role, str(c["category"]), c["value"])
		if err == "":
			_tell_all("bot_chatter", str(c.get("chatter", "")))


# ----------------------------------------------------------------------
# DESIGN -> REVIEW (launch poll)
# ----------------------------------------------------------------------

func on_call_review(role: String) -> void:
	if not Net.is_authority() or MissionState.phase != "DESIGN":
		return
	var res: Dictionary = MissionState.eval_result
	if not bool(res.get("valid", false)):
		var msgs: Array = SimEngine.review_messages(res)
		var text := "The design is not ready yet."
		if not msgs.is_empty():
			var who: Array = []
			for r in msgs[0].get("roles", []):
				who.append(_role_name(str(r)))
			text = "%s (%s)" % [str(msgs[0]["text"]), ", ".join(who)]
		if MissionState.commander_mode:   # round 4: the crew cannot see the problem; the Commander can
			text = "Not ready yet! Ask the Commander what is wrong."
		_tell_all("review_blocked", text)
		return
	_go("REVIEW", {"called_by": role})


func _enter_review() -> void:
	MissionState.set_commander_go(false)
	_poll = {}
	for r in Protocol.ROLES:
		_poll[r] = {"state": "pending", "reason": ""}
	MissionState.set_poll(_poll)
	_auto_go_for_non_humans()


## Empty seats and bots answer GO by themselves, one after another, so the broadcast lights up one by one.
func _auto_go_for_non_humans() -> void:
	var n := 0
	for r in Protocol.ROLES:
		if _poll.get(r, {}).get("state", "") == "pending" and not _is_human(r):
			n += 1
			var role: String = r
			_later(POLL_STAGGER_SECONDS * n, func(): _answer(role, true, "Bot crew: all systems look good."))


func on_poll_answer(role: String, go: bool, reason: String) -> void:
	if not Net.is_authority() or MissionState.phase != "REVIEW":
		return
	if _poll.get(role, {}).get("state", "") != "pending":
		return
	_answer(role, go, reason)


func _answer(role: String, go: bool, reason: String) -> void:
	if MissionState.phase != "REVIEW" or _poll.get(role, {}).get("state", "") != "pending":
		return
	if go and not MissionState.swaps_for_role(role).is_empty():   # round 4: fix the Commander's SWAP first
		_tell(role, "poll_rejected", "The Commander wants you to swap a part first. Say NO-GO, then fix it.")
		return
	var why := reason.strip_edges()
	if not go and why == "":
		why = "No reason given."
	_poll[role] = {"state": "go" if go else "nogo", "reason": why}
	MissionState.set_poll(_poll)
	if not go:
		_tell_all("nogo", "%s says NO-GO: %s" % [_role_name(role), why])
		_go("DESIGN", {"nogo_role": role, "reason": why})
		return
	_check_launch()


## LEAD (round 7): the build clock. Not in Demo Mode (stays repeatable) and not when nobody human is playing.
func _start_build_clock() -> void:
	_clock_on = not MissionState.demo_mode
	var bc: Dictionary = Data.db["meta"].get("build_clock", {})
	_design_left = float(MissionState.build_seconds)
	if MissionState.mission_length == "full":
		_design_left += 60.0   # a full mission has more to talk about
	if MissionState.difficulty == "cadet":
		_design_left += float(bc.get("cadet_extra_s", 60))
	_overtime = 0.0
	_overtime_steps = 0
	MissionState.budget_penalty = 0.0
	MissionState.set_design_clock(int(ceil(_design_left)) if _clock_on else -1)


func _tick_build_clock(delta: float) -> void:
	if not _clock_on:
		return
	if _design_left > 0.0:
		_design_left -= delta
		MissionState.set_design_clock(maxi(0, int(ceil(_design_left))))
		if _design_left <= 60.0 and _design_left + delta > 60.0:
			_tell_all("build_clock", "One minute left to build! Call the design review soon.")
		if _design_left <= 0.0:
			_tell_all("build_clock", "Time's up! Investors are getting nervous. Every 20 seconds they take back C$5M!")
		return
	_overtime += delta
	var bc: Dictionary = Data.db["meta"].get("build_clock", {})
	var step: float = float(bc.get("overtime_step_s", OVERTIME_STEP_SECONDS))
	if _overtime >= step:
		_overtime -= step
		_overtime_steps += 1
		var cut_step: float = float(bc.get("overtime_cut", OVERTIME_CUT))
		var cap: float = float(MissionState.eval_result.get("cost", {}).get("cap", 0.0)) + MissionState.budget_penalty
		var cut: float = minf(MissionState.budget_penalty + cut_step, cap * float(bc.get("max_cut_frac", MAX_CUT_FRACTION)))
		if cut > MissionState.budget_penalty:
			MissionState.set_budget_penalty(cut)
			_tell_all("investors", "Investors pulled C$%d M and the launch slipped (FLIGHT loses 1 time token)! Hurry!" % int(cut_step))
		else:
			_tell_all("investors", "Still building! FLIGHT loses another time token at launch.")


## LEAD (round 4): launch needs all four crew GO, no open SWAP, and (with a human Commander) the Commander's GO.
func _check_launch() -> void:
	if MissionState.phase != "REVIEW":
		return
	for r in Protocol.ROLES:
		if str(_poll.get(r, {}).get("state", "")) != "go":
			return
	if MissionState.commander_mode:
		if MissionState.any_swaps():
			return
		if MissionState.commander_present and not MissionState.commander_go:
			_tell_all("waiting_commander", "Crew is GO! Waiting for the Commander...")
			return
	var serial := _epoch
	_later(1.5, func():
		if serial == _epoch:
			_go("LAUNCH"))   # short beat so the fourth light is seen


## The Commander's answer in the launch poll (host screen only).
func on_commander_decision(go: bool, reason: String) -> String:
	if MissionState.phase != "REVIEW":
		return "The launch poll is not open."
	if not go:
		var why := reason.strip_edges() if reason.strip_edges() != "" else "Fix the parts I marked."
		_tell_all("nogo", "COMMANDER says NO-GO: %s" % why)
		_go("DESIGN", {"nogo_role": "commander", "reason": why})
		return ""
	if MissionState.any_swaps():
		return "You still have parts marked SWAP. Say NO-GO so the crew can fix them."
	MissionState.set_commander_go(true)
	_tell_all("commander_go", "The Commander is GO for launch!")
	_check_launch()
	return ""


## The Commander marks one design category. Bots obey a SWAP by themselves (humans have to listen).
func on_commander_mark(category: String, state: String) -> void:
	MissionState.set_mark(category, state)
	if state == "swap":
		var role: String = SimEngine._owner_of(Data.db, category.get_slice(":", 0))
		if role != "" and not _is_human(role):
			var serial := _epoch
			_later(1.4, func():
				if serial == _epoch:
					_bot_obey(category))
		elif role != "":
			_tell(role, "commander_swap", "Commander: swap your %s!" % MissionState.mark_label(category).to_lower())


func _bots_obey_pending_swaps() -> void:
	for c in MissionState.commander_marks.keys():
		if str(MissionState.commander_marks[c]) == "swap":
			var role: String = SimEngine._owner_of(Data.db, str(c).get_slice(":", 0))
			if role != "" and not _is_human(role):
				_bot_obey(str(c))


## A bot tries every other option for that category and takes the one that leaves the ship healthiest.
func _bot_obey(key: String) -> void:
	if MissionState.phase != "DESIGN" or str(MissionState.commander_marks.get(key, "")) != "swap":
		return
	var category: String = key.get_slice(":", 0)
	var item: String = key.get_slice(":", 1) if key.contains(":") else ""
	var role: String = SimEngine._owner_of(Data.db, category)
	var cur = MissionState.design.get(category)
	var scored: Array = []
	for v in _candidates(category):
		if item != "" and (v as Array).has(item):
			continue   # round 7: a flagged instrument / station must go
		if v == cur:
			continue
		var d: Dictionary = MissionState.design.duplicate(true)
		d[category] = v
		scored.append({"v": v, "bad": SimEngine._badness(SimEngine.evaluate(Data.db, d, MissionState.difficulty))})
	scored.sort_custom(func(a, b): return float(a["bad"]) < float(b["bad"]))
	for s in scored:
		if Net.apply_choice_as(role, category, s["v"]) == "":
			_forced[category] = cur
			_tell_all("bot_swap", "AutoCrew %s swapped the %s, as the Commander ordered." % [_role_name(role),
				MissionState.mark_label(key).to_lower()])
			return


func _candidates(category: String) -> Array:
	var out: Array = []
	match category:
		"orbit":
			out = Data.scenario(MissionState.scenario_id).get("orbits", {}).keys()
		"rocket":
			for r in Data.db["rockets"]:
				out.append(r["id"])
		"rtg_count":
			for i in int(Data.db["rtg"].get("max_count", 3)) + 1:
				out.append(i)
		"stations", "instruments":
			var cur: Array = (MissionState.design.get(category, []) as Array)
			var pool: Array = []
			if category == "stations":
				for s in Data.db["stations"]:
					pool.append(s["id"])
			else:
				for i in Data.db["instruments"]:
					if str(i.get("scenario", "")) == MissionState.scenario_id:
						pool.append(i["id"])
			for x in cur:   # drop one
				var l: Array = cur.duplicate()
				l.erase(x)
				out.append(l)
			for x in pool:  # add one
				if not cur.has(x):
					var l2: Array = cur.duplicate()
					l2.append(x)
					out.append(l2)
		_:
			for p in Data.db["parts"].get(category, []):
				out.append(p["id"])
	return out


# ----------------------------------------------------------------------
# LEAD (round 8) MISSION TWISTS: one random twist per mission so no two games feel the same.
# ----------------------------------------------------------------------

func _roll_twists() -> void:
	if MissionState.demo_mode or not MissionState.twists_on:
		MissionState.set_twists([])
		return
	var pool: Array = Data.db["meta"].get("twists", [])
	if pool.is_empty():
		return
	var pick: Dictionary = pool[_rng.randi_range(0, pool.size() - 1)]
	# a forced crisis that cannot happen in this mission is skipped
	var forced: String = str(pick.get("effect", {}).get("force_event", ""))
	if forced != "":
		var ok := false
		for e in Data.db["events"]:
			if str(e["id"]) == forced and (e.get("scenarios", []) as Array).has(MissionState.scenario_id):
				ok = true
		if not ok:
			pick = pool[(pool.find(pick) + 1) % pool.size()]
	MissionState.set_twists([str(pick["id"])])
	_tell_all("twist", "Mission twist: %s! %s" % [str(pick.get("name", "")), str(pick.get("blurb", ""))])


func _apply_flight_twists() -> void:
	if director == null or not director.has_method("apply_twists"):
		return
	var forced: String = ""
	for t in MissionState.twist_names():
		forced = str(t.get("effect", {}).get("force_event", forced))
	director.apply_twists(forced, int(MissionState.twist_effect("extra_crises", 0.0)))
	var bonus: int = int(MissionState.twist_effect("bonus_tokens", 0.0))
	for r in Protocol.ROLES:
		var owned: Array = Data.db["meta"]["roles"][r]["owns_tokens"]
		if bonus > 0 and not owned.is_empty():
			var tk: String = str(owned[0])
			director.tokens[r][tk] = int(director.tokens[r].get(tk, 0)) + bonus
	# round 8: time lost in overtime is time FLIGHT does not have in space
	if _overtime_steps > 0:
		var t_now: int = int(director.tokens["flight"].get("time", 0))
		director.tokens["flight"]["time"] = maxi(0, t_now - _overtime_steps)


# ----------------------------------------------------------------------
# LAUNCH
# ----------------------------------------------------------------------

## Deterministic launch roll for a seed (public so tests can pick a failing seed).
static func launch_roll(seed_value: int) -> float:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value ^ 0x1A7C
	return r.randf()


func _enter_launch() -> void:
	if not bool(MissionState.eval_result.get("valid", false)):
		_go("DESIGN", {"reason": "The design is no longer valid."})
		return
	var prob: float = float(MissionState.eval_result.get("launch_success_prob", 1.0))
	var can_fail: bool = bool(_difficulty_cfg().get("launch_can_fail", true)) and not MissionState.demo_mode
	_launch_success = (not can_fail) or launch_roll(MissionState.mission_seed) < prob
	# the outcome is NOT in the payload: only the host knows until the countdown ends
	MissionState.phase_payload = {"reliability": prob, "countdown_s": LAUNCH_COUNTDOWN_SECONDS, "can_fail": can_fail}
	_later(LAUNCH_COUNTDOWN_SECONDS, _finish_launch)


func _finish_launch() -> void:
	if MissionState.phase != "LAUNCH":
		return
	if _launch_success:
		_go("FLIGHT")
		return
	_send_debrief(_lost_report())
	_go("DEBRIEF", {"mission_lost": true})


func _lost_report() -> Dictionary:
	var ev: Dictionary = MissionState.eval_result
	var rocket: Dictionary = Data.rocket(str(MissionState.design.get("rocket", "")))
	var pct := int(round(float(ev.get("launch_success_prob", 0.0)) * 100.0))
	var zero := {"science": 0.0, "lifetime": 0.0, "budget": 0.0, "margins": 0.0, "crisis": 0.0, "teamwork": 0.0}
	return {
		"mission_lost": true, "grade": "LOST", "total": 0, "TOTAL": 0, "score": zero, "medals": [],
		"science_final": 0.0, "lifetime_final": 0.0, "total_cost": float(ev.get("cost", {}).get("total", 0.0)),
		"crisis_score": 0.0, "teamwork_score": 0.0,
		"limiting": ev.get("lifetime", {}).get("limiting", ""),
		"lines": [
			"Anomaly investigation: the %s rocket has a %d%% chance of success, and this time the launch failed." % [str(rocket.get("name", rocket.get("id", "rocket"))), pct],
			"Real launches fail sometimes. That is why teams pick reliable rockets and keep spare budget for a second try.",
		],
	}


# ----------------------------------------------------------------------
# FLIGHT
# ----------------------------------------------------------------------

func _enter_flight() -> void:
	director = _make_director()
	director.setup(MissionState.design, MissionState.eval_result, MissionState.mission_seed, MissionState.difficulty, MissionState.mission_length)
	_apply_flight_twists()
	_sync_tokens()
	var n_lives: int = int(_difficulty_cfg().get("lives", 2)) + int(MissionState.twist_effect("bonus_lives", 0.0))
	MissionState.set_lives(n_lives, n_lives)
	_tasks = {}
	_task_round = false
	_active = false
	_resolving = false
	_acted = {}
	_pings = []
	var total: int = int(director.beat_count()) if director.has_method("beat_count") else -1
	_status = {"active": false, "beat": -1, "total": total, "kind": "", "event_id": "", "title": "",
		"acted": {}, "pings": [], "radio_silence": false, "untimed": false}
	_push_status()
	_later(FIRST_BEAT_DELAY, _next_beat)


func _push_status() -> void:
	var acted_public := {}
	for r in Protocol.ROLES:
		if _is_human(r):
			acted_public[r] = bool(_acted.get(r, false))
	_status["acted"] = acted_public
	_status["pings"] = _pings.duplicate(true)
	MissionState.set_flight_status(_status)


func _next_beat() -> void:
	if MissionState.phase != "FLIGHT" or director == null:
		return
	_beat_serial += 1
	var beat: Dictionary = director.next_beat()
	if beat.is_empty():
		_finish_flight()
		return
	_beat = beat
	_event = (beat["event"] as Dictionary).duplicate(true)
	_tasks = {}            # round 8: last round's finished tasks are history now
	_task_round = false
	_status["tasks"] = {}
	var cfg := _difficulty_cfg()
	var kind: String = str(beat.get("kind", _event.get("kind", "crisis")))
	# round 7: the crew ALWAYS has a clock (players asked for it); Cadet just gets 50% more time.
	var untimed: bool = false
	var rs: bool = bool(cfg.get("radio_silence", false)) and kind == "crisis"
	var timer_s: float = float(beat.get("timer_s", _event.get("timer_s", 25.0)))
	if MissionState.difficulty == "cadet":
		timer_s = roundf(timer_s * 1.5)
	timer_s = roundf(timer_s * MissionState.twist_effect("crisis_time_mult", 1.0))   # round 8 twist
	_event["untimed"] = untimed
	_event["radio_silence"] = rs
	_event["index"] = int(beat.get("index", 0))
	_event["total"] = int(beat.get("total", -1))
	_time_left = UNTIMED_FAILSAFE_SECONDS if untimed else timer_s
	_acted = {}
	_pings = []
	_active = true
	_resolving = false
	var any_connected := false
	for r in Protocol.ROLES:
		if _is_connected(r):
			any_connected = true
	if not any_connected:
		_time_left = minf(_time_left, SOLO_BEAT_SECONDS)
	_status["active"] = true
	_status["beat"] = int(beat.get("index", 0))
	_status["total"] = int(beat.get("total", _status.get("total", -1)))
	_status["kind"] = kind
	_status["event_id"] = str(_event.get("id", ""))
	_status["title"] = str(_event.get("title", ""))
	_status["radio_silence"] = rs
	_status["untimed"] = untimed
	_push_status()
	var shown_timer: float = 0.0 if untimed else timer_s
	if Net.is_host():
		Net.crisis_started.rpc(_event, shown_timer)
	Net.crisis_event.emit(_event, shown_timer)
	_schedule_bots(kind)


func _schedule_bots(kind: String) -> void:
	if kind != "crisis" or director == null or not director.has_method("auto_play"):
		return
	var serial := _beat_serial
	for r in Protocol.ROLES:
		if _is_human(r):
			continue
		var role: String = r
		_later(_rng.randf_range(1.0, 3.0), func():
			if _active and serial == _beat_serial:
				director.auto_play(role)
				_sync_tokens())


func _resolve_beat() -> void:
	if not _active or director == null:
		return
	# LEAD (round 8) BUG FIX: when every human tapped "I'm done" quickly, the crisis resolved 1.2 s later, but the
	# bots were scheduled 1-3 s in, and their jobs were thrown away as stale. The crew "did everything" and still lost.
	# Every seat without a human now plays its card BEFORE the crisis is scored.
	if str(_beat.get("kind", "")) == "crisis" and director.has_method("auto_play"):
		for r in Protocol.ROLES:
			if not _is_human(r):
				director.auto_play(r)
	_active = false
	_resolving = false
	_beat_serial += 1
	var result: Dictionary = director.resolve_current()
	_cancel_chip_tasks()
	var out_of_lives: bool = _judge_mistake(result)
	if Net.is_host():
		Net.crisis_resolved.rpc(result)
	Net.crisis_result.emit(result)
	_sync_tokens()
	_acted = {}
	_status["active"] = false
	_push_status()
	if out_of_lives:
		_later(4.0, _out_of_lives)
		return
	# round 8: sometimes a surprise mini-task round happens before the next beat (not after the last one)
	var more: bool = director.has_method("beats_left") and int(director.beats_left()) > 0
	var chance: float = float(Data.db["meta"].get("mini_tasks", {}).get("random_chance", 0.35))
	var tc: float = MissionState.twist_effect("task_chance", 0.0)
	if tc > 0.0:
		chance = tc
	if more and not MissionState.demo_mode and _rng.randf() < chance:
		_later(BEAT_GAP_SECONDS - 2.0, _start_task_round)
		return
	_later(BEAT_GAP_SECONDS, _next_beat)


# ----------------------------------------------------------------------
# LEAD (round 8) LIVES. A crisis is a MISTAKE when the crew blocks less than half of it, or someone plays a card
# that does not help at all. One mistake = one life (at most one per crisis). 0 lives = the mission is lost.
# ----------------------------------------------------------------------

func _judge_mistake(result: Dictionary) -> bool:
	if str(result.get("kind", "")) != "crisis" or MissionState.lives < 0:
		return false
	var m: float = float(result.get("mitigation", 1.0))
	var wrong: Array = []
	for p in result.get("played", []):
		if RoleGuide.blocked(_event, [str(p.get("action", ""))]) <= 0.001:
			wrong.append("%s played '%s', which does not help with this one" % [_role_name(str(p.get("role", ""))), str(p.get("label", ""))])
	var reason := ""
	if m < 0.5:
		reason = "the crew blocked only %d%% of it (you need at least half)" % int(round(m * 100.0))
	elif not wrong.is_empty():
		reason = wrong[0]
	result["mistake"] = reason != ""
	if reason == "":
		result["lives_left"] = MissionState.lives
		return false
	var left: int = maxi(0, MissionState.lives - 1)
	MissionState.set_lives(left)
	result["mistake_reason"] = reason
	result["lives_left"] = left
	result["line"] = "MISTAKE (-1 life): %s. %s" % [reason, str(result.get("line", ""))]
	_tell_all("life_lost", "-1 LIFE! %s. Lives left: %d" % [reason.substr(0, 1).to_upper() + reason.substr(1), left])
	return left <= 0


func _out_of_lives() -> void:
	if MissionState.phase != "FLIGHT" or director == null:
		return
	_tasks = {}
	_task_round = false
	var report: Dictionary = director.final_report()
	report["mission_lost"] = true
	report["out_of_lives"] = true
	report["grade"] = "LOST"
	var lines: Array = (report.get("what_happened", []) as Array).duplicate()
	lines.push_front("OUT OF LIVES: the crew made %d mistakes, so Mission Control called the mission off. Next time: read the gauges out loud, let the Commander find the crisis, and only play the cards the Commander names." % MissionState.lives_max)
	report["what_happened"] = lines
	_send_debrief(report)
	_go("DEBRIEF", {"mission_lost": true, "out_of_lives": true})


# ----------------------------------------------------------------------
# LEAD (round 8) MINI-TASKS
#   random task: between two beats, by chance. EVERY crew member gets their own task at the same time.
#   chip-in task: when someone taps CHIP IN on an opportunity, ONLY they get a task; finishing it pays the chip-in.
#   Each finished task gives that crew member 1 token of their own kind (GROUND gets money).
# Host -> crew: say_to(peer, "task_start", "<task>|<kind>|<seconds>")   crew -> host: ping("@task:ok" / "@task:fail")
# ----------------------------------------------------------------------

func _task_seconds() -> float:
	return float(Data.db["meta"].get("mini_tasks", {}).get("task_seconds", 20))


func _start_task(role: String, kind: String) -> void:
	_tasks[role] = {"task": str(TASKS[role]), "kind": kind, "state": "running"}
	if _is_connected(role):
		_tell(role, "task_start", "%s|%s|%d" % [str(TASKS[role]), kind, int(_task_seconds())])
	else:   # bots (and held seats) do theirs by themselves
		var serial := _beat_serial
		var ok: bool = _rng.randf() < float(Data.db["meta"].get("mini_tasks", {}).get("bot_success", 0.7))
		_later(_rng.randf_range(4.0, 10.0), func():
			if serial == _beat_serial:
				_on_task_report(role, ok))
	_push_task_status()


func _start_task_round() -> void:
	if MissionState.phase != "FLIGHT" or director == null:
		return
	_task_round = true
	_tasks = {}
	_tell_all("task_round", "Surprise maintenance! Everyone has a quick task. Finish it to earn a token!")
	for r in Protocol.ROLES:
		_start_task(r, "random")
	var serial := _beat_serial
	_later(_task_seconds() + 3.0, func():
		if serial == _beat_serial:
			_end_task_round())


func _end_task_round() -> void:
	if not _task_round:
		return
	_task_round = false
	for r in _tasks.keys():
		if str(_tasks[r]["state"]) == "running":
			_tasks[r]["state"] = "failed"
			_tell(str(r), "task_stop", "Time's up!")
	var done := 0
	for r in _tasks:
		if str(_tasks[r]["state"]) == "done":
			done += 1
	_tell_all("task_round_done", "Maintenance over: %d of %d tasks done." % [done, _tasks.size()])
	_push_task_status()
	_later(2.5, _next_beat)


func _cancel_chip_tasks() -> void:
	for r in _tasks.keys():
		if str(_tasks[r]["kind"]) == "chip" and str(_tasks[r]["state"]) == "running":
			_tasks[r]["state"] = "failed"
			_tell(str(r), "task_stop", "The chance passed.")
	_push_task_status()


func _on_task_report(role: String, ok: bool) -> void:
	if not _tasks.has(role) or str(_tasks[role]["state"]) != "running":
		return
	var kind: String = str(_tasks[role]["kind"])
	_tasks[role]["state"] = "done" if ok else "failed"
	if ok:
		_reward(role)
	if kind == "chip":
		if ok and _active and director != null:
			var res: Dictionary = director.event_choice(role, "capture")
			if bool(res.get("ok", false)):
				_sync_tokens()
				_mark_acted(role)
				_tell_all("chip_ok", "%s finished the task and chipped in! Chance captured!" % _role_name(role))
				_resolve_soon()
			else:
				_tell(role, "choice_rejected", str(res.get("reason", "Could not chip in.")))
		elif not ok:
			_tell_all("chip_fail", "%s's task failed. Someone can try to CHIP IN again!" % _role_name(role))
	_push_task_status()
	if _task_round:
		var running := false
		for r in _tasks:
			if str(_tasks[r]["state"]) == "running":
				running = true
		if not running:
			_end_task_round()


func _reward(role: String) -> void:
	if director == null:
		return
	var cfg: Dictionary = Data.db["meta"].get("mini_tasks", {})
	var tk: String = str(TASK_REWARD.get(role, "power"))
	var have: int = int(director.tokens[role].get(tk, 0))
	var add: int = int(cfg.get("reward_tokens", 1))
	director.tokens[role][tk] = mini(have + add, int(cfg.get("max_tokens", 5)))
	_sync_tokens()
	_tell(role, "task_reward", "Task done! +%d %s" % [add, CrisisPanel.token_word(tk)])


func _push_task_status() -> void:
	var t := {}
	for r in _tasks:
		t[r] = {"task": str(_tasks[r]["task"]), "kind": str(_tasks[r]["kind"]), "state": str(_tasks[r]["state"])}
	_status["tasks"] = t
	_push_status()


func _finish_flight() -> void:
	var report: Dictionary = director.final_report()
	_send_debrief(report)
	_go("DEBRIEF", {"mission_lost": false})


func _send_debrief(report_in: Dictionary) -> void:
	var report: Dictionary = ReportFormat.normalize(report_in)   # MERGE: one report shape for every screen
	report["team_name"] = MissionState.team_name
	report["scenario"] = MissionState.scenario_id
	report["difficulty"] = MissionState.difficulty
	report["mission_length"] = MissionState.mission_length
	report["design"] = MissionState.design.duplicate(true)
	if not report.has("limiting"):
		report["limiting"] = MissionState.eval_result.get("lifetime", {}).get("limiting", "")
	# MERGE (debrief "three little users", UX guide section 10): how far each objective got after the flight.
	# Shared only after the mission, so it does not break the design-time privacy rules.
	var sci: Dictionary = MissionState.eval_result.get("science", {})
	var pre: float = float(sci.get("points", 0.0))
	var post: float = float(report.get("science_final", pre))
	var k: float = (post / pre) if pre > 0.0 else 0.0
	var objs: Array = []
	for o in sci.get("objectives", []):
		objs.append({"tag": str(o["tag"]), "achieved": float(o["achieved"]) * k, "max": float(o["max"])})
	report["objectives"] = objs
	report["launch_reliability"] = float(MissionState.eval_result.get("launch_success_prob", 1.0))
	# round 8: why the science came out as it did (after the mission, so no privacy rule is broken)
	var doc: Dictionary = ShipDoctor.science(Data.db, MissionState.design, MissionState.eval_result)
	report["science_leaks"] = (doc.get("leaks", []) as Array).slice(0, 4)
	report["science_planned"] = float(doc.get("points", 0.0))
	report["lives_left"] = MissionState.lives
	report["lives_max"] = MissionState.lives_max
	report["twists"] = MissionState.twists.duplicate()
	if _gifts >= 2 and not (report.get("medal_ids", []) as Array).has("helping_paws"):   # round 6: teamwork with tokens
		report["medals"] = (report.get("medals", []) as Array) + ["Helping Paws"]
		report["medal_ids"] = (report.get("medal_ids", []) as Array) + ["helping_paws"]
	report["token_gifts"] = _gifts
	MissionState.last_report = report
	if Net.is_host():
		Net.debrief.rpc(report)
	Net.debrief_report.emit(report)


# ----------------------------------------------------------------------
# FLIGHT: player requests (already checked by Net for "has a seat")
# ----------------------------------------------------------------------

func on_play_action(role: String, action_id: String) -> void:
	if not Net.is_authority():
		return
	if MissionState.phase != "FLIGHT" or not _active or director == null:
		_tell(role, "action_rejected", "There is no crisis right now.")
		return
	if _acted.get(role, false):
		_tell(role, "action_rejected", "You already acted in this crisis.")
		return
	if action_id == "pass":           # "Done / nothing to play": works in any beat, lets it end early (Cadet has no timer)
		_mark_acted(role)
		return
	if str(_beat.get("kind", "")) != "crisis":
		_tell(role, "action_rejected", "There is no crisis right now.")
		return
	var res: Dictionary = director.play_action(role, action_id)
	if not bool(res.get("ok", false)):
		_tell(role, "action_rejected", str(res.get("reason", "You cannot play that.")))
		return
	_sync_tokens()
	_mark_acted(role)


func on_event_choice(role: String, option_id: String) -> void:
	if not Net.is_authority():
		return
	if MissionState.phase != "FLIGHT" or not _active or director == null:
		_tell(role, "choice_rejected", "Nothing to choose right now.")
		return
	var kind := str(_beat.get("kind", ""))
	if kind == "crisis":
		_tell(role, "choice_rejected", "That is for opportunities and decisions.")
		return
	if option_id == "pass":
		_mark_acted(role)
		return
	# round 8: CHIP IN starts a mini-task for a human; finishing it pays the chip-in (see _on_task_report)
	if kind == "opportunity" and option_id == "capture" and _is_connected(role):
		for r in _tasks:
			if str(_tasks[r]["kind"]) == "chip" and str(_tasks[r]["state"]) == "running":
				_tell(role, "choice_rejected", "%s is already chipping in. Cheer them on!" % _role_name(str(r)))
				return
		if director.has_method("team_can_pay") and not bool(director.team_can_pay()):
			_tell(role, "choice_rejected", "The team does not hold enough tokens to chip in.")
			return
		_start_task(role, "chip")
		_time_left = maxf(_time_left, _task_seconds() + 3.0)
		_tell_all("chip_start", "%s is chipping in: finish the task to capture the chance!" % _role_name(role))
		return
	var res: Dictionary = director.event_choice(role, option_id)
	if not bool(res.get("ok", false)):
		_tell(role, "choice_rejected", str(res.get("reason", "You cannot do that.")))
		return
	_sync_tokens()
	_mark_acted(role)
	if bool(res.get("complete", false)) or kind == "decision":
		_resolve_soon()


func on_give_token(from_role: String, to_role: String, token: String) -> void:
	if not Net.is_authority():
		return
	if MissionState.phase != "FLIGHT" or not _active or director == null:
		_tell(from_role, "give_rejected", "You can only hand over tokens while a crisis is running.")
		return
	if from_role == to_role or not bool(director.give_token(from_role, to_role, token)):
		_tell(from_role, "give_rejected", "You cannot hand that over.")
		return
	_gifts += 1
	_sync_tokens()
	_tell(to_role, "token_given", "%s gave you 1 %s! Now you can play your card." % [_role_name(from_role), CrisisPanel.token_word(token)])


## round 6: a crew member asks for a token. A bot holder gives it at once; a human holder gets a GIVE button.
func _on_token_ask(role: String, token: String) -> void:
	if MissionState.phase != "FLIGHT" or not _active or director == null:
		return
	var holders: Array = []
	var owner: String = CrisisPanel.owner_role(token)
	if owner != "" and owner != role:
		holders.append(owner)
	for r in Protocol.ROLES:
		if r != role and not holders.has(r):
			holders.append(r)
	for r in holders:
		if int(MissionState.tokens.get(r, {}).get(token, 0)) <= 0:
			continue
		if not _is_human(r):
			on_give_token(r, role, token)
		else:
			_tell(r, "token_ask", "%s|%s" % [role, token])
		return
	_tell(role, "give_rejected", "Nobody has any %s left. Pick another card!" % CrisisPanel.token_word(token))


func on_ping(role: String, card_id: String) -> void:
	if card_id.begins_with("@task:"):
		_on_task_report(role, card_id == "@task:ok")   # round 8: a crew member finished (or failed) a mini-task
		return
	if card_id.begins_with("@ask:"):
		_on_token_ask(role, card_id.substr(5))   # round 6: "I need 1 power" -> whoever holds one
		return
	if card_id.begins_with("@"):
		return   # round 4: "@commander" pings go straight to the Commander screen, not to the flight log
	if not Net.is_authority() or MissionState.phase != "FLIGHT" or not _active:
		return
	_pings.append({"role": role, "card": card_id.substr(0, 24)})
	while _pings.size() > MAX_PINGS:
		_pings.pop_front()
	if director != null and director.has_method("record_ping"):
		director.record_ping(role, card_id)
	_push_status()


func _mark_acted(role: String) -> void:
	_acted[role] = true
	_push_status()
	var all_done := true
	var any := false
	for r in Protocol.ROLES:
		if _is_connected(r):
			any = true
			if not _acted.get(r, false):
				all_done = false
	if any and all_done:
		_resolve_soon()


func _resolve_soon() -> void:
	if _resolving or not _active:
		return
	_resolving = true
	_later(1.2, _resolve_beat)


# ----------------------------------------------------------------------
# Disconnects: hold the seat for 60 seconds (spec: Part 2 item 5)
# ----------------------------------------------------------------------

func on_hello(peer: int, key: String) -> void:
	if not Net.is_authority() or key == "":
		return
	_keys[peer] = key
	for role in _held.keys():
		if _held[role]["key"] != key:
			continue
		_held.erase(role)
		MissionState.seats[role] = peer
		MissionState.seat_ready[role] = true
		MissionState.seats_changed.emit()
		Net.say_to(peer, "rejoined", "Welcome back! You are %s again." % _role_name(role))
		Net.resend_to(peer)
		if _active and Net.is_host():
			Net.crisis_started.rpc_id(peer, _event, 0.0 if bool(_event.get("untimed", false)) else maxf(_time_left, 1.0))
		return


func on_peer_disconnected(peer: int) -> void:
	var role := MissionState.role_of_peer(peer)
	var key: String = str(_keys.get(peer, ""))
	_keys.erase(peer)
	if role == "":
		return
	if MissionState.phase == "LOBBY" or key == "":
		MissionState.release_peer(peer)     # nothing to protect yet, or no way to recognise them later
		return
	MissionState.seats[role] = SEAT_HELD
	MissionState.seat_ready[role] = false
	_held[role] = {"key": key, "left": HOLD_SECONDS}
	MissionState.seats_changed.emit()
	_tell_all("seat_held", "%s lost connection. Their seat is held for %d seconds." % [_role_name(role), int(HOLD_SECONDS)])


func _tick_holds(delta: float) -> void:
	for role in _held.keys():
		_held[role]["left"] = float(_held[role]["left"]) - delta
		if float(_held[role]["left"]) <= 0.0:
			_held.erase(role)
			MissionState.seats[role] = 0
			MissionState.seat_ready[role] = false
			MissionState.seats_changed.emit()
			_tell_all("seat_freed", "%s is open again." % _role_name(role))
			if MissionState.phase == "REVIEW":
				_auto_go_for_non_humans()


func is_held(role: String) -> bool:
	return _held.has(role)
