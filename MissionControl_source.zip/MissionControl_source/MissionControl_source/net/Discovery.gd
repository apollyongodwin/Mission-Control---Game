# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Discovery
extends Node
## Dev D, Part 2. LAN host finder.
## HOST: start_beacon(name, ip) sends "COUNTDOWN|<name>|<ip>|7777" to UDP port 7778 every second.
## CLIENT: start_listen() collects beacons into `hosts`; emits hosts_changed when the list changes.
## Add it as a child node (Lobby does this). It cleans up after itself when freed.

signal hosts_changed

const BEACON_PORT := 7778
const GAME_PORT := 7777
const MAGIC := "MISSIONCONTROL"   # renamed from COUNTDOWN (the game is now called Mission Control)
const EXPIRE_S := 4.0   # a host disappears from the list if silent this long

var hosts: Dictionary = {}   # ip -> {"name", "ip", "port", "seen"}
var _tx: PacketPeerUDP
var _rx: PacketPeerUDP
var _timer: Timer
var _targets: Array[String] = []
var _b_name := "Mission Control"
var _b_ip := ""
var _b_port := GAME_PORT
var _text := ""


func _ready() -> void:
	set_process(false)


# ---------------------------------------------------------------- HOST
func start_beacon(host_name: String, ip: String, port: int = GAME_PORT) -> void:
	stop()
	_b_ip = ip
	_b_port = port
	set_beacon_name(host_name)
	_tx = PacketPeerUDP.new()
	_tx.set_broadcast_enabled(true)
	# MERGE (LAN fix): broadcast on EVERY network this laptop is on (Wi-Fi, Ethernet, hotspot...), not only the
	# subnet of one address (which was sometimes a virtual adapter nobody else can see).
	_targets = []
	for t in NetInfo.broadcast_targets():
		_targets.append(str(t))
	_timer = Timer.new()
	_timer.wait_time = 1.0
	_timer.autostart = true
	_timer.timeout.connect(_send_beacon)
	add_child(_timer)
	_send_beacon()


func set_beacon_name(host_name: String) -> void:
	var clean := host_name.replace("|", " ").strip_edges()
	_b_name = clean if clean != "" else "Mission Control"
	_text = "%s|%s|%s|%d" % [MAGIC, _b_name, _b_ip, _b_port]


func _send_beacon() -> void:
	if _tx == null:
		return
	for t in _targets:
		_tx.set_dest_address(t, BEACON_PORT)
		_tx.put_packet(_text.to_utf8_buffer())


# ---------------------------------------------------------------- CLIENT
func start_listen() -> Error:
	stop()
	_rx = PacketPeerUDP.new()
	var err := _rx.bind(BEACON_PORT)
	if err != OK:
		_rx = null
		return err
	set_process(true)
	return OK


func get_sorted() -> Array:
	var out: Array = hosts.values()
	out.sort_custom(func(a, b): return str(a["name"]) < str(b["name"]))
	return out


func _process(_d: float) -> void:
	if _rx == null:
		return
	var changed := false
	while _rx.get_available_packet_count() > 0:
		var pkt := _rx.get_packet()
		if _rx.get_packet_error() != OK:
			continue
		var parts := pkt.get_string_from_utf8().split("|")
		if parts.size() != 4 or parts[0] != MAGIC:
			continue
		# MERGE (LAN fix): use the address the beacon really CAME FROM; the address written inside it can be a
		# virtual adapter the host picked by mistake.
		var host_ip := _rx.get_packet_ip()
		if not host_ip.is_valid_ip_address() or host_ip.begins_with("127."):
			host_ip = parts[2].strip_edges()
		if not host_ip.is_valid_ip_address() or not parts[3].is_valid_int():
			continue
		var is_new: bool = not hosts.has(host_ip) or hosts[host_ip]["name"] != parts[1]
		hosts[host_ip] = {"name": parts[1], "ip": host_ip, "port": int(parts[3]),
			"seen": Time.get_ticks_msec() / 1000.0}
		if is_new:
			changed = true
	var now := Time.get_ticks_msec() / 1000.0
	for k in hosts.keys():
		if now - float(hosts[k]["seen"]) > EXPIRE_S:
			hosts.erase(k)
			changed = true
	if changed:
		hosts_changed.emit()


func stop() -> void:
	set_process(false)
	if _tx != null:
		_tx.close()
		_tx = null
	if _rx != null:
		_rx.close()
		_rx = null
	if _timer != null:
		_timer.queue_free()
		_timer = null
	hosts.clear()


func _exit_tree() -> void:
	stop()
