# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Protocol
extends RefCounted
## Shared constants and PURE validation helpers for networking (no nodes, no state).
## The host uses validate_choice() on every submit_choice. Never trust a client.

## LAN fix: every laptop must run the SAME copy. Different copies number their network functions differently,
## which silently mixes up requests (for example a seat request landing as something else).
## BUMP THIS whenever any @rpc function is added, removed or renamed, and hand everyone the new zip.
const GAME_VERSION := "MC-9.0"   # round 9: team info, science rebalance, crew layout, AI notices
const PORT := 7777
const DISCOVERY_PORT := 7778
const MAX_CLIENTS := 8   # 4 seats plus a few spare/spectator connections

const ROLES: Array = ["flight", "systems", "payload", "ground"]
const PHASES: Array = ["LOBBY", "BRIEFING", "DESIGN", "REVIEW", "LAUNCH", "FLIGHT", "DEBRIEF"]

## Design keys that hold ONE id (string).
const PART_CATEGORIES: Array = ["bus", "panel", "battery", "comm", "adcs", "obc", "shield", "prop"]
## Every design key a player may submit (everything in the design except "scenario").
const CHOICE_KEYS: Array = ["orbit", "bus", "panel", "rtg_count", "battery", "comm", "adcs", "obc", "shield",
	"prop", "rocket", "stations", "instruments"]

const MAX_LIST := 12   # sanity cap for instruments / stations lists


static func _has_id(arr: Array, id: Variant) -> bool:
	if typeof(id) != TYPE_STRING:
		return false
	for x in arr:
		if x["id"] == id:
			return true
	return false


## Which role owns this design key? ("" if none). Source: data meta.roles[role].owns_choices.
static func owner_of(db: Dictionary, category: String) -> String:
	for role in ROLES:
		if category in db["meta"]["roles"][role]["owns_choices"]:
			return role
	return ""


static func role_may_submit(db: Dictionary, role: String, category: String) -> bool:
	if not db["meta"]["roles"].has(role):
		return false
	return category in db["meta"]["roles"][role]["owns_choices"]


## Returns "" if the value is acceptable, otherwise a short plain-language reason (no secret numbers).
static func validate_choice(db: Dictionary, category: String, value: Variant) -> String:
	if not (category in CHOICE_KEYS):
		return "Unknown choice."
	if category == "orbit":
		return "" if _has_id(db["orbits"], value) else "That orbit does not exist."
	if category == "rocket":
		return "" if _has_id(db["rockets"], value) else "That rocket does not exist."
	if category in PART_CATEGORIES:
		return "" if _has_id(db["parts"][category], value) else "That part does not exist."
	if category == "rtg_count":
		var t := typeof(value)
		if t != TYPE_INT and t != TYPE_FLOAT:
			return "Nuclear battery count must be a number."
		if float(value) != floor(float(value)):
			return "Nuclear battery count must be a whole number."
		if int(value) < 0 or int(value) > int(db["rtg"]["max_count"]):
			return "That many nuclear batteries is not possible."
		return ""
	if category == "stations" or category == "instruments":
		if typeof(value) != TYPE_ARRAY:
			return "Expected a list."
		var arr: Array = value
		if arr.size() > MAX_LIST:
			return "That list is too long."
		var pool: Array = db["stations"] if category == "stations" else db["instruments"]
		var seen := {}
		for id in arr:
			if not _has_id(pool, id):
				return "One of those items does not exist."
			if seen.has(id):
				return "The same item was chosen twice."
			seen[id] = true
		return ""
	return "Unknown choice."


## Makes a value safe to store in the design (ints are ints, lists are plain String arrays).
static func normalize_choice(category: String, value: Variant) -> Variant:
	if category == "rtg_count":
		return int(value)
	if category == "stations" or category == "instruments":
		var out: Array = []
		for id in value:
			out.append(str(id))
		return out
	return str(value)
