# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## LEAD (round 8) helper: shows each mini-task (or one: --task=wires) and saves a screenshot of each.
##   xvfb-run godot --path . res://tests/minitask_shot.tscn -- --out=/tmp/tasks
func _ready() -> void:
	var out := "/tmp/tasks"
	var only := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="):
			out = a.substr(6)
		if a.begins_with("--task="):
			only = a.substr(7)
	DirAccess.make_dir_recursive_absolute(out)
	get_window().size = Vector2i(1280, 720)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for t in ["asteroids", "wires", "binary", "trace"]:
		if only != "" and t != only:
			continue
		var m := MiniTask.new()
		m.report_to_host = false
		m.setup(t, "chip" if t == "binary" else "random", 20.0, "engineer")
		add_child(m)
		for i in 50:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("%s/%s.png" % [out, t])
		m.queue_free()
		await get_tree().process_frame
	get_tree().quit()
