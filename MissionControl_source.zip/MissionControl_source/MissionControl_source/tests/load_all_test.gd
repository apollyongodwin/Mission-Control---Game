# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends SceneTree
## MERGE CHECK (Lead). Loads every script and scene in the project and instantiates every scene once,
## so a broken merge shows up as an error here instead of in front of the judges.
## Run:  godot --headless -s res://tests/load_all_test.gd

var _fails: int = 0
var _count: int = 0


func _initialize() -> void:
	# Autoloads are not running in a -s script, so only LOAD scenes here (no instantiate) to avoid
	# false errors from _ready() code that needs Data / MissionState / Net.
	var files: Array = []
	_walk("res://", files)
	files.sort()
	for f in files:
		if f.begins_with("res://tests/") and f.ends_with("load_all_test.gd"):
			continue
		_count += 1
		var res: Resource = load(f)
		if res == null:
			_fails += 1
			print("FAIL  ", f)
		elif res is GDScript and not (res as GDScript).can_instantiate():
			_fails += 1
			print("FAIL  (does not compile) ", f)
	print("")
	if _fails == 0:
		print("ALL %d FILES LOAD" % _count)
	else:
		print("%d of %d FILES FAILED" % [_fails, _count])
	quit(1 if _fails > 0 else 0)


func _walk(dir_path: String, out: Array) -> void:
	var d := DirAccess.open(dir_path)
	if d == null:
		return
	for sub in d.get_directories():
		if sub.begins_with("."):
			continue
		_walk(dir_path.path_join(sub), out)
	for f in d.get_files():
		if f.ends_with(".gd") or f.ends_with(".tscn"):
			out.append(dir_path.path_join(f))
