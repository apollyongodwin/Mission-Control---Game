# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## Standalone test for Dev C Part 2. Open tests/broadcast_part2_test.tscn and press F6.
## No MissionState needed: this scene fakes the design and drives BroadcastLayer directly.
## Keys are listed in the help label.

const HELP := "0 lobby  1 design  2 review  3 launch  4 flight  5 debrief\nB bus  P panel  A battery  M antenna  N engines  S shield  O orbit  I add instrument  U clear instruments\nC crisis  X next role acts  R radio silence  V resolve  G ping  D/F9 demo  T voice on/off"

var layer: BroadcastLayer
var design: Dictionary = {
	"scenario": "bagyo_watch", "orbit": "leo_tropical_600", "bus": "bus_mini", "panel": "si_6", "rtg_count": 0,
	"battery": "bat_800", "comm": "x_band_steer", "adcs": "adcs_wheels", "obc": "obc_basic", "shield": "shield_none",
	"prop": "prop_none", "rocket": "swift", "stations": ["iligan_gs"], "instruments": ["rain_gauge_relay"],
}
var _acted: int = 0


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = BCTheme.NAVY
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var help := Label.new()
	help.text = HELP
	help.add_theme_font_size_override("font_size", 16)
	help.position = Vector2(10, 4)
	add_child(help)
	layer = preload("res://ui/broadcast/BroadcastLayer.tscn").instantiate() as BroadcastLayer
	add_child(layer)
	layer.set_design(design)
	layer.set_phase("DESIGN")


func _cycle(cat: String) -> void:
	var arr: Array = Data.db["parts"][cat]
	var i: int = 0
	for k in arr.size():
		if arr[k]["id"] == design[cat]:
			i = k
	design[cat] = arr[(i + 1) % arr.size()]["id"]
	layer.set_design(design)


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed and not event.echo):
		return
	match event.keycode:
		KEY_0: layer.set_phase("LOBBY")
		KEY_1: layer.set_phase("DESIGN")
		KEY_2: layer.set_phase("REVIEW")
		KEY_3: layer.set_phase("LAUNCH")
		KEY_4: layer.set_phase("FLIGHT")
		KEY_5:
			layer.set_phase("DEBRIEF")
			layer.show_report({"grade": "B"})
		KEY_B: _cycle("bus")
		KEY_P: _cycle("panel")
		KEY_A: _cycle("battery")
		KEY_M: _cycle("comm")
		KEY_N: _cycle("prop")
		KEY_S: _cycle("shield")
		KEY_O:
			var sc: Dictionary = Data.scenario(str(design["scenario"]))
			var ids: Array = sc["orbits"].keys()
			design["orbit"] = ids[(ids.find(design["orbit"]) + 1) % ids.size()]
			layer.set_design(design)
		KEY_I:
			for ins in Data.db["instruments"]:
				if ins["scenario"] == design["scenario"] and not design["instruments"].has(ins["id"]):
					design["instruments"].append(ins["id"])
					break
			layer.set_design(design)
		KEY_U:
			design["instruments"] = ["rain_gauge_relay"]
			layer.set_design(design)
		KEY_C:
			_acted = 0
			layer.set_phase("FLIGHT")
			layer.show_crisis(Data.by_id(Data.db["events"], "solar_flare"), 25.0, true)
		KEY_X:
			layer.crisis_acted(BCTheme.ROLES[_acted % 4])
			_acted += 1
		KEY_R: layer.set_radio_silence(true)
		KEY_G: layer.add_ping("payload", "have_spare_data")
		KEY_V: layer.crisis_resolved({"residual": 0.0, "line": "You had power and shielding to spare, so the flare did no harm."})
		KEY_D: layer.play_demo()
		KEY_T: layer.announcer.voice_enabled = not layer.announcer.voice_enabled
