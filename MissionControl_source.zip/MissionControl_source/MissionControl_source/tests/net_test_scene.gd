# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## Bare-bones network test (LEAD, Part 1). No real UI.
##
## HOW TO TEST (Godot editor): Debug > Customize Run Instances > 2 instances, with this scene
## as the main scene (or open it and use Run Current Scene twice).
##   Window 1: click "Host".      (the host goes straight to the DESIGN phase for this test)
##   Window 2: click "Join" (127.0.0.1), click the SYSTEMS seat, then click a battery.
##   Window 1: the DESIGN label shows the battery.
##   Window 3 (or the same window, after taking the GROUND seat): click the "pebble" rocket.
##   The MASS light turns red (XX) on the host and on every client.
## Try clicking a battery as FLIGHT or with no seat: the host says no (see the message line).
##
## Optional launch arguments (after "--"), used by automated tests:
##   --host   --auto-join=127.0.0.1   --role=systems   --submit=battery:bat_2000  (or rocket:pebble)
##   --difficulty=engineer   --quit-after=6

const LIGHT_ORDER := ["mass", "power", "budget", "data", "comms", "time", "lifetime"]

var _args := {}
var _status: Label
var _design: RichTextLabel
var _lights: RichTextLabel
var _private: RichTextLabel
var _msg: Label
var _ip: LineEdit
var _submitted := false


func _ready() -> void:
	_args = _parse_args()
	_build_ui()
	MissionState.design_changed.connect(_refresh)
	MissionState.seats_changed.connect(_refresh)
	MissionState.phase_changed.connect(func(_p): _refresh())
	MissionState.settings_changed.connect(_refresh)
	Net.server_message_received.connect(_on_server_message)
	Net.joined_server.connect(_on_joined)
	Net.join_failed.connect(func(): _say("Could not connect."))
	Net.left_network.connect(func(): _say("Disconnected."))
	Net.peer_joined.connect(func(id): _say("Peer %d joined." % id))
	_refresh()

	if _args.has("difficulty"):
		MissionState.set_difficulty(str(_args["difficulty"]))
	if _args.has("host"):
		_on_host()
	elif _args.has("auto-join"):
		_on_join(str(_args["auto-join"]))
	if _args.has("quit-after"):
		get_tree().create_timer(float(_args["quit-after"])).timeout.connect(func(): get_tree().quit())


func _parse_args() -> Dictionary:
	var out := {}
	for a in OS.get_cmdline_user_args():
		var s := str(a).trim_prefix("--")
		var kv := s.split("=", true, 1)
		out[kv[0]] = kv[1] if kv.size() > 1 else true
	return out


func _build_ui() -> void:
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 8)
	add_child(root)

	var row1 := HBoxContainer.new()
	root.add_child(row1)
	var host_btn := Button.new()
	host_btn.text = "Host"
	host_btn.pressed.connect(_on_host)
	row1.add_child(host_btn)
	_ip = LineEdit.new()
	_ip.text = "127.0.0.1"
	_ip.custom_minimum_size.x = 160
	row1.add_child(_ip)
	var join_btn := Button.new()
	join_btn.text = "Join"
	join_btn.pressed.connect(func(): _on_join(_ip.text))
	row1.add_child(join_btn)
	var leave_btn := Button.new()
	leave_btn.text = "Leave"
	leave_btn.pressed.connect(func(): Net.leave(); _say("Left."))
	row1.add_child(leave_btn)

	var row2 := HBoxContainer.new()
	root.add_child(row2)
	var l2 := Label.new()
	l2.text = "Seat: "
	row2.add_child(l2)
	for r in Protocol.ROLES:
		var b := Button.new()
		b.text = str(r).to_upper()
		b.pressed.connect(func(): Net.request_seat(r))
		row2.add_child(b)

	var row3 := HBoxContainer.new()
	root.add_child(row3)
	var l3 := Label.new()
	l3.text = "Battery: "
	row3.add_child(l3)
	for item in Data.db["parts"]["battery"]:
		var b := Button.new()
		b.text = str(item["id"])
		var id: String = item["id"]
		b.pressed.connect(func(): Net.submit_choice("battery", id))
		row3.add_child(b)

	var row4 := HBoxContainer.new()
	root.add_child(row4)
	var l4 := Label.new()
	l4.text = "Rocket (GROUND only): "
	row4.add_child(l4)
	for item in Data.db["rockets"]:
		var b := Button.new()
		b.text = str(item["id"])
		var rid: String = item["id"]
		b.pressed.connect(func(): Net.submit_choice("rocket", rid))
		row4.add_child(b)

	_status = Label.new()
	root.add_child(_status)
	_msg = Label.new()
	_msg.modulate = Color(1.0, 0.8, 0.3)
	root.add_child(_msg)
	_design = _rich(root, 150)
	_lights = _rich(root, 40)
	_private = _rich(root, 120)


func _rich(parent: Node, h: int) -> RichTextLabel:
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = false
	r.custom_minimum_size.y = h
	r.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.add_child(r)
	return r


func _on_host() -> void:
	var err := Net.host_game()
	if err != OK:
		_say("Host failed: error %d (is port 7777 already in use?)" % err)
		return
	# For this test only: skip the lobby so clients can edit right away.
	# (The real phase machine is Part 2.)
	MissionState.set_phase("DESIGN")
	_say("Hosting on %s:%d" % [Net.local_ip(), Protocol.PORT])
	print("NETTEST host started")


func _on_join(ip: String) -> void:
	var err := Net.join_game(ip)
	if err != OK:
		_say("Join failed: error %d" % err)


func _on_joined() -> void:
	_say("Connected.")
	print("NETTEST joined")
	if _args.has("role"):
		Net.request_seat(str(_args["role"]))


func _on_server_message(code: String, text: String) -> void:
	_say("HOST SAYS NO (%s): %s" % [code, text])
	print("NETTEST message ", code, ": ", text)


func _say(t: String) -> void:
	_msg.text = t


func _refresh() -> void:
	var mode_name: String = ["OFFLINE", "HOST", "CLIENT"][Net.mode]
	var seat_txt := ""
	for r in Protocol.ROLES:
		seat_txt += "%s=%s  " % [str(r).to_upper(), str(MissionState.seats[r])]
	_status.text = "%s | my role: %s | phase: %s | difficulty: %s | seats: %s" % [
		mode_name, MissionState.local_role if MissionState.local_role != "" else "(none)",
		MissionState.phase, MissionState.difficulty, seat_txt]

	var d := MissionState.design
	_design.text = "[b]DESIGN[/b]  battery = [color=yellow]%s[/color]   panel = %s   bus = %s\norbit = %s   rocket = %s\ninstruments = %s   stations = %s" % [
		d.get("battery", "?"), d.get("panel", "?"), d.get("bus", "?"),
		d.get("orbit", "?"), d.get("rocket", "?"), str(d.get("instruments", [])), str(d.get("stations", []))]

	var lt: Dictionary = MissionState.view.get("lights", {})
	var lt_txt := "[b]LIGHTS[/b]  "
	for k in LIGHT_ORDER:
		var c: String = str(lt.get(k, "?"))
		var color := "green" if c == "green" else ("yellow" if c == "amber" else ("red" if c == "red" else "gray"))
		var mark := "OK" if c == "green" else ("!!" if c == "amber" else ("XX" if c == "red" else "??"))
		lt_txt += "[color=%s]%s %s[/color]   " % [color, str(k), mark]
	_lights.text = lt_txt

	var priv: Dictionary = MissionState.view.get("private", {})
	_private.text = "[b]PRIVATE NUMBERS I MAY SEE[/b]: %s" % str(priv.keys())

	# one parseable line per change, for the automated test
	var light_str := ""
	for k in LIGHT_ORDER:
		light_str += "%s=%s," % [k, lt.get(k, "?")]
	print("NETTEST state mode=%s role=%s phase=%s battery=%s lights=%s private=%s" % [
		mode_name, MissionState.local_role, MissionState.phase, d.get("battery", "?"), light_str, str(priv.keys())])

	# auto-submit once we hold our seat (automated test only)
	if _args.has("submit") and not _submitted and Net.is_client() and MissionState.local_role != "":
		_submitted = true
		var kv := str(_args["submit"]).split(":", true, 1)
		Net.submit_choice(kv[0], kv[1])
