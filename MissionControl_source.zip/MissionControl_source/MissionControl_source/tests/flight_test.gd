# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends SceneTree
## Terminal:  godot --headless --path . -s res://tests/flight_test.gd
## Exit code 0 = everything passed.
## Checks, for every bot_presets design in all 3 scenarios:
##  - Short mission with a fixed seed gives a total between 0 and 1000
##  - the same seed gives the same total twice (deterministic)
##  - a Full mission also stays between 0 and 1000
##  - tokens never go negative
##  - "rookie" scores lower than "cautious" in each scenario

const SEED: int = 12345


func _init() -> void:
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json"))
	if typeof(data) != TYPE_DICTIONARY:
		printerr("Could not read res://data/countdown_data.json")
		quit(2)
		return
	var failures: int = 0
	for sc in data["scenarios"]:
		var sid: String = sc["id"]
		print("")
		print("=== %s ===" % sid)
		var totals: Dictionary = {}
		for preset in data["bot_presets"][sid]:
			var pname: String = preset["name"]
			var design: Dictionary = preset["design"]
			var res: Dictionary = SimEngine.evaluate(data, design, "engineer")
			var rep: Dictionary = _fly(data, design, res, SEED, "short")
			var rep2: Dictionary = _fly(data, design, res, SEED, "short")
			var rep_full: Dictionary = _fly(data, design, res, SEED, "full")
			var b: Dictionary = rep["breakdown"]
			print("%s total %6.1f  grade %s  [sci %.1f life %.1f budget %.1f margins %.1f crisis %.1f team %.1f]  launchable=%s" % [
				pname.rpad(9), rep["total"], rep["grade"], b["science"], b["lifetime"], b["budget"], b["margins"], b["crisis"], b["teamwork"], str(res["valid"])])
			totals[pname] = rep["total"]
			if rep["total"] < 0.0 or rep["total"] > 1000.0:
				failures += 1
				printerr("FAIL  %s/%s short total out of range: %s" % [sid, pname, rep["total"]])
			if rep_full["total"] < 0.0 or rep_full["total"] > 1000.0:
				failures += 1
				printerr("FAIL  %s/%s full total out of range: %s" % [sid, pname, rep_full["total"]])
			if rep["total"] != rep2["total"]:
				failures += 1
				printerr("FAIL  %s/%s same seed gave two different totals" % [sid, pname])
			if rep["events"].size() != 4:
				failures += 1
				printerr("FAIL  %s/%s short mission should have 4 events, got %d" % [sid, pname, rep["events"].size()])
			if rep_full["events"].size() != 7:
				failures += 1
				printerr("FAIL  %s/%s full mission should have 7 events, got %d" % [sid, pname, rep_full["events"].size()])
		if totals.has("rookie") and totals.has("cautious"):
			if totals["rookie"] < totals["cautious"]:
				print("PASS  rookie (%.1f) < cautious (%.1f)" % [totals["rookie"], totals["cautious"]])
			else:
				failures += 1
				printerr("FAIL  %s: rookie (%.1f) is not lower than cautious (%.1f)" % [sid, totals["rookie"], totals["cautious"]])
		else:
			failures += 1
			printerr("FAIL  %s: missing rookie or cautious preset" % sid)

	# print one sample report so Dev D can see the exact shape
	var sample_design: Dictionary = data["bot_presets"]["bagyo_watch"][0]["design"]
	var sample_res: Dictionary = SimEngine.evaluate(data, sample_design, "engineer")
	var sample: Dictionary = _fly(data, sample_design, sample_res, SEED, "short")
	print("")
	print("--- sample final_report (bagyo_watch / cautious / short) ---")
	print(JSON.stringify(sample, "  "))
	print("")
	failures += _interactive_tests(data)

	if failures == 0:
		print("ALL FLIGHT TESTS PASSED")
	else:
		printerr("%d FLIGHT TEST(S) FAILED" % failures)
	quit(failures)


func _fly(data: Dictionary, design: Dictionary, res: Dictionary, seed_value: int, length: String) -> Dictionary:
	var fd: FlightDirector = FlightDirector.new()
	fd.db = data
	fd.setup(design, res, seed_value, "engineer", length)
	var rep: Dictionary = fd.run_auto()
	for role in fd.tokens:
		for tk in fd.tokens[role]:
			if int(fd.tokens[role][tk]) < 0:
				printerr("FAIL  negative token %s/%s" % [role, tk])
	return rep


# ================================================================ PART 2 tests (interactive + bots)

func _check(cond: bool, label: String) -> int:
	if cond:
		print("PASS  " + label)
		return 0
	printerr("FAIL  " + label)
	return 1


func _total_tokens(fd: FlightDirector) -> int:
	var n: int = 0
	for role in fd.tokens:
		for tk in fd.tokens[role]:
			n += int(fd.tokens[role][tk])
	return n


func _interactive_tests(data: Dictionary) -> int:
	var f: int = 0
	print("")
	print("=== Part 2: interactive play ===")
	var design: Dictionary = data["bot_presets"]["bagyo_watch"][0]["design"]
	var res: Dictionary = SimEngine.evaluate(data, design, "engineer")
	var fd: FlightDirector = FlightDirector.new()
	fd.db = data
	fd.setup(design, res, SEED, "engineer", "short")

	f += _check(not fd.play_action("flight", "override")["ok"], "play_action with no event is refused")
	var ev: Dictionary = fd.next_beat()
	f += _check(ev["kind"] == "crisis", "first beat is a crisis")
	f += _check(is_equal_approx(fd.deadline_left, float(ev["timer_s"])), "deadline_left starts at timer_s")
	f += _check(not fd.play_action("flight", "reboot")["ok"], "an action from another role's hand is refused")
	var saved: int = int(fd.tokens["systems"]["power"])
	fd.tokens["systems"]["power"] = 0
	f += _check(not fd.play_action("systems", "reboot")["ok"], "an unaffordable action is refused")
	fd.tokens["systems"]["power"] = saved

	var r1: Dictionary = fd.play_action("flight", "override")
	f += _check(bool(r1["ok"]), "flight plays override (costs nothing)")
	f += _check(not fd.play_action("flight", "override")["ok"], "second action by the same role is refused")
	f += _check(is_equal_approx(fd.sum_lifetime_loss_days, 90.0), "override side effect (-90 days) applied immediately")

	var legal: Array = fd.legal_actions("systems")
	if legal.size() > 0:
		var a: Dictionary = legal[0]
		var before: int = _total_tokens(fd)
		var spend: int = 0
		for tk in a["cost"]:
			spend += int(a["cost"][tk])
		f += _check(bool(fd.play_action("systems", str(a["id"]))["ok"]), "systems plays '%s'" % a["id"])
		f += _check(_total_tokens(fd) == before - spend, "tokens were deducted by the action's cost")

	# hand a token over
	var giver: String = ""
	var tok: String = ""
	for role in fd.tokens:
		for tk in fd.tokens[role]:
			if giver == "" and int(fd.tokens[role][tk]) >= 1:
				giver = role
				tok = tk
	if giver != "":
		var taker: String = "payload" if giver != "payload" else "ground"
		var pool_before: int = _total_tokens(fd)
		var gv: int = int(fd.tokens[giver][tok])
		f += _check(fd.give_token(giver, taker, tok), "give_token works during a crisis")
		f += _check(int(fd.tokens[giver][tok]) == gv - 1, "giver has one fewer token")
		f += _check(_total_tokens(fd) == pool_before, "no tokens were created or lost")
		f += _check(not fd.give_token(giver, giver, tok), "cannot give a token to yourself")

	# pings
	f += _check(fd.ping("payload", "on_it"), "ping is logged")
	f += _check(not fd.ping("payload", ""), "empty ping is refused")
	f += _check(fd.ping_log.size() == 1, "ping_log has one entry")

	# finish the crisis early: everyone acted or passed
	f += _check(not fd.everyone_done(), "crisis is not done while roles are waiting")
	for role in FlightDirector.ROLE_ORDER:
		fd.pass_turn(role)
	f += _check(fd.everyone_done(), "crisis is done when everyone acted or passed")
	var rec: Dictionary = fd.tick(0.0)
	f += _check(not rec.is_empty() and rec["kind"] == "crisis", "tick() resolves the crisis once everyone has acted")
	f += _check(fd.history.size() == 1 and fd.current.is_empty(), "history has 1 record and no event is active")
	f += _check(not fd.give_token("systems", "ground", "power"), "give_token is refused when no crisis is active")

	# timer: second crisis ends by the clock
	ev = fd.next_beat()
	f += _check(ev["kind"] == "crisis", "second beat is a crisis")
	var t0: Dictionary = fd.tick(1.0)
	f += _check(t0.is_empty(), "tick(1s) does not resolve a 25-30s crisis")
	var t1: Dictionary = fd.tick(1000.0)
	f += _check(not t1.is_empty(), "tick() resolves the crisis when the timer runs out")

	# opportunity
	ev = fd.next_beat()
	f += _check(ev["kind"] == "opportunity", "third beat is the opportunity")
	var pool_o: int = _total_tokens(fd)
	var oc: Dictionary = fd.event_choice("flight", "capture")
	var orec: Dictionary
	if bool(oc["ok"]):
		f += _check(not fd.event_choice("ground", "capture")["ok"], "an opportunity cannot be paid twice")
		f += _check(fd.everyone_done(), "paid opportunity is done")
		orec = fd.tick(0.0)
	else:
		orec = fd.tick(1000.0)
	f += _check(bool(orec["captured"]) == bool(oc["ok"]), "opportunity record matches what the team did")
	f += _check(_total_tokens(fd) >= 0 and (_total_tokens(fd) <= pool_o), "opportunity never creates tokens")

	ev = fd.next_beat()
	fd.tick(1000.0)
	f += _check(fd.next_beat().is_empty(), "deck ends after 4 events (short)")
	var rep: Dictionary = fd.final_report()
	f += _check(rep["total"] >= 0.0 and rep["total"] <= 1000.0, "interactive final total is 0..1000 (%.1f)" % rep["total"])

	# decision (full mission)
	var fd2: FlightDirector = FlightDirector.new()
	fd2.db = data
	fd2.setup(design, res, SEED, "engineer", "full")
	var saw_decision: bool = false
	while true:
		var e2: Dictionary = fd2.next_beat()
		if e2.is_empty():
			break
		if e2["kind"] == "decision":
			saw_decision = true
			f += _check(not fd2.event_choice("flight", "nonsense")["ok"], "decision: an unknown option is refused")
			var d1: Dictionary = fd2.event_choice("flight", "decline")
			f += _check(bool(d1["ok"]), "decision: decline is accepted")
			f += _check(not fd2.event_choice("ground", "accept")["ok"], "decision: the team cannot choose twice")
		fd2.tick(1000.0)
	f += _check(saw_decision, "a full mission contains a decision")
	f += _check(fd2.history.size() == 7, "full interactive mission has 7 records")

	# Cadet has no timer
	var res_c: Dictionary = SimEngine.evaluate(data, design, "cadet")
	var fd3: FlightDirector = FlightDirector.new()
	fd3.db = data
	fd3.setup(design, res_c, SEED, "cadet", "short")
	fd3.next_beat()
	f += _check(not fd3.timer_enabled, "Cadet has no timer")
	f += _check(fd3.tick(1000.0).is_empty(), "Cadet: the clock never resolves a crisis")
	f += _check(not fd3.resolve_current().is_empty(), "Cadet: the host can still resolve by hand")

	f += _bot_tests(data)
	return f


func _bot_tests(data: Dictionary) -> int:
	var f: int = 0
	print("")
	print("=== Part 2: BotCrew ===")
	for sc in data["scenarios"]:
		var sid: String = sc["id"]
		var bots: BotCrew = BotCrew.new()
		bots.setup(data, sid, ["flight", "systems", "payload", "ground"], SEED)
		bots.begin_design()
		var built: Dictionary = {"scenario": sid}
		var chatter_ok: bool = true
		var guard: int = 0
		while bots.design_pending() and guard < 200:
			guard += 1
			for item in bots.tick_design(0.5):
				built[item["category"]] = item["value"]
				if str(item["chatter"]) == "":
					chatter_ok = false
		var preset: Dictionary = data["bot_presets"][sid][0]["design"]
		var same: bool = true
		for k in preset:
			if not built.has(k) or built[k] != preset[k]:
				same = false
		f += _check(same, "%s: four bots rebuild the 'cautious' preset exactly" % sid)
		f += _check(chatter_ok, "%s: every bot choice comes with a chatter line" % sid)

		# a full short mission flown only by bots, twice with the same seed
		var totals: Array = []
		for run in range(2):
			var res: Dictionary = SimEngine.evaluate(data, preset, "engineer")
			var fd: FlightDirector = FlightDirector.new()
			fd.db = data
			fd.setup(preset, res, SEED, "engineer", "short")
			var crew: BotCrew = BotCrew.new()
			crew.setup(data, sid, ["flight", "systems", "payload", "ground"], SEED)
			var beats: int = 0
			while true:
				var ev: Dictionary = fd.next_beat()
				if ev.is_empty():
					break
				beats += 1
				crew.begin_event(fd)
				var loops: int = 0
				while not fd.current.is_empty() and loops < 300:
					loops += 1
					crew.tick_flight(1.0, fd)
					fd.tick(1.0)
				if loops >= 300:
					printerr("FAIL  %s: event never ended" % sid)
					f += 1
			var rep: Dictionary = fd.final_report()
			totals.append(rep["total"])
			if run == 0:
				f += _check(beats == 4 and fd.history.size() == 4, "%s: bots finish a short mission (4 events)" % sid)
				f += _check(rep["total"] >= 0.0 and rep["total"] <= 1000.0, "%s: bot-flown total in range (%.1f)" % [sid, rep["total"]])
		f += _check(totals[0] == totals[1], "%s: same seed gives the same bot-flown total" % sid)

	# about 70% of bot decisions are 'play'
	var crew2: BotCrew = BotCrew.new()
	crew2.setup(data, "bagyo_watch", ["systems"], 99)
	var plays: int = 0
	var fdx: FlightDirector = FlightDirector.new()
	fdx.db = data
	var dsg: Dictionary = data["bot_presets"]["bagyo_watch"][0]["design"]
	var rx: Dictionary = SimEngine.evaluate(data, dsg, "engineer")
	var trials: int = 300
	for i in range(trials):
		fdx.setup(dsg, rx, i, "engineer", "short")
		fdx.next_beat()
		crew2.begin_event(fdx)
		if bool(crew2._plan["systems"]["plays"]):
			plays += 1
	var pct: float = float(plays) / float(trials)
	f += _check(pct > 0.62 and pct < 0.78, "bots decide to play about 70%% of the time (got %.0f%%)" % (pct * 100.0))
	return f
