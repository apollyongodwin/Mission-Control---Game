# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## LEAD (round 8) helper: draws every orbit at three moments and saves one sheet per orbit.
##   xvfb-run godot --path . res://tests/orbit_shot.tscn -- --out=/tmp/orbits
func _ready() -> void:
	var out := "/tmp/orbits"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="):
			out = a.substr(6)
	DirAccess.make_dir_recursive_absolute(out)
	get_window().size = Vector2i(1500, 420)
	for o in Data.db["orbits"]:
		for c in get_children():
			c.queue_free()
		await get_tree().process_frame
		var stations: Array = ["iligan_gs", "svalbard_gs", "perth_gs", "dsn_like"]
		for k in 3:
			var ov := OrbitView.new()
			ov.position = Vector2(k * 500, 0)
			ov.size = Vector2(495, 420)
			add_child(ov)
			ov.set_design({"orbit": o["id"], "stations": stations})
			ov._t = float(k) * ov._cycle_seconds() / 3.0 + 0.3
			ov.set_process(false)
			ov._process(0.0)
		for i in 3:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("%s/%s.png" % [out, o["id"]])
	get_tree().quit()
