# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## Offline logic test for MissionState + Net + Protocol (no network needed).
## Editor: open tests/net_offline_test.tscn and press F6. Terminal:
##   godot --headless --path . res://tests/net_offline_test.tscn
## Expect every line to say PASS.

var _lines: Array = []
var _fails := 0
var _design_signals := 0


func check(name: String, cond: bool) -> void:
	_lines.append(("PASS  " if cond else "FAIL  ") + name)
	if not cond:
		_fails += 1


func _ready() -> void:
	Net.leave()
	MissionState.reset_all()
	MissionState.design_changed.connect(func(): _design_signals += 1)
	var D: Dictionary = Data.db

	check("starts offline", Net.is_offline())
	check("default design has the scenario", MissionState.design["scenario"] == "bagyo_watch")
	check("default orbit is offered in the scenario", D["scenarios"][0]["orbits"].has(MissionState.design["orbit"]))
	check("lights exist at start", MissionState.view.has("lights"))
	check("offline with no role sees private numbers", MissionState.view["private"].has("mass_dry"))

	# offline submit works with no network
	_design_signals = 0
	Net.submit_choice("battery", "bat_2000")
	check("offline submit_choice applies", MissionState.design["battery"] == "bat_2000")
	check("design_changed fired", _design_signals >= 1)
	Net.submit_choice("rocket", "pebble")
	check("small rocket turns mass light red", MissionState.view["lights"]["mass"] == "red")
	check("host-only eval_result is kept offline", MissionState.eval_result.has("mass"))

	# validation
	var rejected := []
	Net.server_message_received.connect(func(code, _t): rejected.append(code))
	Net.submit_choice("battery", "bat_9999")
	check("unknown part id rejected", MissionState.design["battery"] == "bat_2000" and rejected.size() == 1)
	Net.submit_choice("scenario", "moon_relay")
	check("scenario key cannot be submitted", MissionState.design["scenario"] == "bagyo_watch")
	Net.submit_choice("rtg_count", -1)
	check("negative rtg_count rejected", MissionState.design["rtg_count"] == 0)
	Net.submit_choice("rtg_count", 99)
	check("huge rtg_count rejected", MissionState.design["rtg_count"] == 0)
	Net.submit_choice("rtg_count", "two")
	check("non-number rtg_count rejected", MissionState.design["rtg_count"] == 0)
	Net.submit_choice("instruments", ["sar_c", "sar_c"])
	check("duplicate instruments rejected", MissionState.design["instruments"].is_empty())
	Net.submit_choice("instruments", ["nope"])
	check("unknown instrument rejected", MissionState.design["instruments"].is_empty())
	var long_list := []
	for i in 30:
		long_list.append("sar_c")
	Net.submit_choice("instruments", long_list)
	check("oversized list rejected", MissionState.design["instruments"].is_empty())
	Net.submit_choice("instruments", ["sar_c", "thermal_ir"])
	check("valid instrument list accepted", MissionState.design["instruments"] == ["sar_c", "thermal_ir"])
	Net.submit_choice("stations", ["iligan_gs", "iligan_gs"])
	check("duplicate stations rejected", MissionState.design["stations"].is_empty())
	Net.submit_choice("stations", ["iligan_gs"])
	check("valid stations accepted", MissionState.design["stations"] == ["iligan_gs"])
	Net.submit_choice("orbit", "leo_tropical_600")
	check("valid orbit accepted", MissionState.design["orbit"] == "leo_tropical_600")

	# ownership once a seat is taken (Engineer: private numbers)
	MissionState.set_difficulty("engineer")
	Net.request_seat("systems")
	check("offline seat assigned", MissionState.local_role == "systems")
	check("systems sees mass_dry but not cost", MissionState.view["private"].has("mass_dry") and not MissionState.view["private"].has("cost"))
	rejected.clear()
	Net.submit_choice("rocket", "swift")
	check("systems cannot change the rocket", MissionState.design["rocket"] == "pebble" and rejected == ["choice_rejected"])
	Net.submit_choice("panel", "si_12")
	check("systems can change the panel", MissionState.design["panel"] == "si_12")
	check("seat taken by someone else is refused", not MissionState.assign_seat("systems", 12345))

	# what a client would receive
	var pub := MissionState.public_state()
	check("public state has no numbers / seed / tokens", not pub.has("mass") and not pub.has("mission_seed") and not pub.has("tokens") and not pub.has("eval_result"))
	var ground_view: Dictionary = MissionState.view_for_role("ground")
	check("ground view has cost, not mass_dry", ground_view["private"].has("cost") and not ground_view["private"].has("mass_dry"))
	var public_view: Dictionary = MissionState.view_for_role("")
	check("spectator view has lights only", public_view["private"].is_empty() and public_view.has("lights"))

	# settings
	MissionState.set_scenario("moon_relay")
	check("changing scenario resets the design", MissionState.design["scenario"] == "moon_relay" and MissionState.design["instruments"].is_empty())
	MissionState.set_scenario("not_a_scenario")
	check("unknown scenario ignored", MissionState.scenario_id == "moon_relay")
	MissionState.set_demo_mode(true)
	check("demo mode uses the fixed seed", MissionState.mission_seed == MissionState.DEMO_SEED)
	MissionState.set_phase("DESIGN")
	check("phase can be set", MissionState.phase == "DESIGN")
	MissionState.set_phase("NONSENSE")
	check("unknown phase ignored", MissionState.phase == "DESIGN")

	# cleanup so other tests start clean
	MissionState.set_demo_mode(false)
	MissionState.set_scenario("bagyo_watch")
	MissionState.set_difficulty("cadet")

	var text := ""
	for l in _lines:
		print(l)
		text += l + "\n"
	text += "\n%s" % ("ALL GOOD" if _fails == 0 else "%d FAILED" % _fails)
	print(text.split("\n")[-1])
	var label := RichTextLabel.new()
	label.set_anchors_preset(Control.PRESET_FULL_RECT)
	label.add_theme_font_size_override("normal_font_size", 20)
	label.text = text
	add_child(label)
	if DisplayServer.get_name() == "headless":
		get_tree().quit(0 if _fails == 0 else 1)
