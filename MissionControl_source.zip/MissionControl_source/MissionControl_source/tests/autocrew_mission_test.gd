# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## MERGE TEST (Lead). One whole mission with every seat flown by Dev A's AutoCrew bots, through the Lead's
## PhaseMachine and Dev A's FlightDirector (via the adapter), for every scenario. Offline, one process.
## Run: open tests/autocrew_mission_test.tscn and press F6, or
##      godot --headless res://tests/autocrew_mission_test.tscn

var fails := 0


func check(name: String, cond: bool) -> void:
	print(("PASS  " if cond else "FAIL  ") + name)
	if not cond:
		fails += 1


func _ready() -> void:
	await get_tree().process_frame
	for sid in ["bagyo_watch", "moon_relay", "deep_probe"]:
		for diff in ["cadet", "engineer"]:
			await _run(sid, diff)
	print("ALL GOOD" if fails == 0 else "%d FAILED" % fails)
	get_tree().quit(1 if fails > 0 else 0)


func _run(sid: String, diff: String) -> void:
	MissionState.reset_all()
	MissionState.set_scenario(sid)
	MissionState.set_difficulty(diff)
	MissionState.set_demo_mode(true)
	var phases: Array = []
	var cb := func(p: String) -> void: phases.append(p)
	MissionState.phase_changed.connect(cb)
	Net.host_set_phase("BRIEFING")
	var pm: PhaseMachine = Net.phase_machine
	for i in 3000:
		pm.tick(0.1)
		if MissionState.phase == "DEBRIEF":
			break
		if i % 50 == 0:
			await get_tree().process_frame   # let deferred calls run
	MissionState.phase_changed.disconnect(cb)
	var tag := "%s/%s: " % [sid, diff]
	check(tag + "reaches DEBRIEF", MissionState.phase == "DEBRIEF")
	check(tag + "phases in order", phases.slice(0, 6) == ["BRIEFING", "DESIGN", "REVIEW", "LAUNCH", "FLIGHT", "DEBRIEF"])
	var rep: Dictionary = MissionState.last_report
	check(tag + "report has total and grade", rep.has("total") and str(rep.get("grade", "")) != "")
	check(tag + "report has why lines", (rep.get("why", []) as Array).size() >= 4)
	check(tag + "medals are names", (rep.get("medals", []) as Array).all(func(m): return m is String))
	check(tag + "score in range (%.1f)" % float(rep.get("total", -1)), float(rep.get("total", -1)) >= 0.0 and float(rep.get("total", 2000)) <= 1000.0)
