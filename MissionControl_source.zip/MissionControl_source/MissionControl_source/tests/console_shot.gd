# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Screenshot helper (Lead): the Commander screen in a phase.
##   xvfb-run godot --path . res://tests/console_shot.tscn -- --out=/tmp/c.png --phase=FLIGHT|DESIGN|BRIEFING

func _ready() -> void:
	var out := "/tmp/console.png"
	var phase := "FLIGHT"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="):
			out = a.substr(6)
		if a.begins_with("--phase="):
			phase = a.substr(8)
	MissionState.set_difficulty("engineer")
	if phase == "DESIGN":
		MissionState.design["instruments"] = ["sar_c", "vis_imager_mid"]
		MissionState.design["stations"] = ["perth_like"] if false else []
		MissionState.reevaluate()
		MissionState.set_mark("bus", "swap")
		MissionState.set_mark("instruments:sar_c", "swap")
	var c := CommanderConsole.new()
	add_child(c)
	await get_tree().process_frame
	MissionState.set_phase(phase)
	c._on_phase(phase)
	if phase == "FLIGHT":
		var ev: Dictionary = {}
		for e in Data.db["events"]:
			if e["id"] == "solar_flare":
				ev = e.duplicate(true)
		c._on_crisis(ev, 10.0)
		c._finder.set_alarms(["radiation", "power"])
		c._on_ping("payload", "@commander")
	for i in 20:
		await get_tree().process_frame
	await get_tree().create_timer(0.3).timeout
	get_viewport().get_texture().get_image().save_png(out)
	get_tree().quit()
