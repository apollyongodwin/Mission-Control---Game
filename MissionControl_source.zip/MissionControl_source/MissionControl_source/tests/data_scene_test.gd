# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
func _ready() -> void:
	print("Data autoload ok: ", Data.db["orbits"].size(), " orbits; kid on sar_c: ", Data.instrument("sar_c").get("kid", "MISSING"))
	get_tree().quit()
