# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Two-process chat test (localhost). Run BOTH, host first:
##   godot --headless --path . res://tests/chat_e2e.tscn -- --host
##   godot --headless --path . res://tests/chat_e2e.tscn -- --client

var is_host := false
var fails := 0
var got: Array = []


func check(name: String, cond: bool) -> void:
	print(("PASS  " if cond else "FAIL  ") + name)
	if not cond:
		fails += 1


func _ready() -> void:
	is_host = "--host" in OS.get_cmdline_user_args()
	Net.chat_received.connect(func(r, t): got.append([r, t]))
	if is_host:
		check("host starts", Net.host_game() == OK)
		await _wait_for(func(): return got.size() >= 2, 20.0)
		check("host got the quick phrase", got.size() > 0 and got[0] == ["payload", "Ready!"])
		check("host got the typed line", got.size() > 1 and got[1] == ["payload", "radar needs power (lots)"])
		Net.typed_chat_allowed = false
		Net.send_chat("Quick phrases only now!")
		await _wait_for(func(): return got.size() >= 4, 15.0)
		check("quick phrase still allowed", got.size() >= 4 and got[3] == ["payload", "Help!"])
		check("typed line blocked", not got.any(func(m): return m[1] == "this should be blocked"))
		await get_tree().create_timer(2.0).timeout
	else:
		var rejected: Array = []
		Net.server_message_received.connect(func(c, t): if c == "chat_rejected": rejected.append(t))
		var joined := [false]
		Net.joined_server.connect(func(): joined[0] = true)
		Net.join_game("127.0.0.1")
		await _wait_for(func(): return joined[0], 10.0)
		await get_tree().create_timer(0.5).timeout
		Net.send_chat("nobody hears me")   # no seat yet: dropped
		Net.request_seat("payload")
		await _wait_for(func(): return MissionState.local_role == "payload", 10.0)
		Net.send_chat("Ready!")
		await get_tree().create_timer(1.0).timeout
		Net.send_chat("radar needs [lots] of power".replace("[lots] of power", "power [lots]"))   # brackets get neutralised
		await _wait_for(func(): return got.size() >= 3, 15.0)
		check("client sees its own lines relayed", got.size() >= 2 and got[0][1] == "Ready!")
		check("client sees Mission Control", got.any(func(m): return m[0] == "mission_control"))
		check("seatless line was dropped", not got.any(func(m): return m[1] == "nobody hears me"))
		await get_tree().create_timer(1.0).timeout
		Net.send_chat("this should be blocked")
		await get_tree().create_timer(1.0).timeout
		check("typed line rejected with a reason", rejected.size() == 1)
		Net.send_chat("Help!")
		await get_tree().create_timer(2.0).timeout
	print(("host" if is_host else "client") + (": ALL GOOD" if fails == 0 else ": %d FAILED" % fails))
	get_tree().quit(1 if fails > 0 else 0)


func _wait_for(cond: Callable, secs: float) -> void:
	var t := 0.0
	while t < secs and not cond.call():
		await get_tree().create_timer(0.1).timeout
		t += 0.1
