# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## LEAD TEST (round 4): Commander mode. Offline, one process, all seats AutoCrew bots, a human Commander present.
## Run: godot --headless res://tests/commander_test.tscn

var fails := 0


func check(name: String, cond: bool) -> void:
	print(("PASS  " if cond else "FAIL  ") + name)
	if not cond:
		fails += 1


func _ticks(pm: PhaseMachine, seconds: float) -> void:
	for i in int(seconds * 10.0):
		pm.tick(0.1)
		if i % 20 == 0:
			await get_tree().process_frame


func _ready() -> void:
	await get_tree().process_frame
	var pm: PhaseMachine = Net.phase_machine
	MissionState.reset_all()
	MissionState.set_scenario("bagyo_watch")
	MissionState.set_difficulty("engineer")
	MissionState.set_demo_mode(true)
	MissionState.set_commander_mode(true)
	MissionState.commander_present = true
	Net.host_set_phase("BRIEFING")
	for i in 400:
		pm.tick(0.1)
		if MissionState.phase == "DESIGN":
			break
	check("reaches DESIGN", MissionState.phase == "DESIGN")
	MissionState.commander_present = true
	# let the bots finish their own design first (the Commander checks a finished ship)
	pm._bot_review_called = true   # keep the bots from calling the review while we test marks
	for i in 600:
		pm.tick(0.1)
		if pm._bots == null or not pm._bots.design_pending():
			break
		if i % 40 == 0:
			await get_tree().process_frame

	# a bot obeys a SWAP by itself
	var before = MissionState.design["battery"]
	pm.on_commander_mark("battery", "swap")
	check("swap is public", MissionState.commander_marks.get("battery") == "swap")
	check("systems has an open swap", MissionState.swaps_for_role("systems") == ["battery"])
	await _ticks(pm, 2.0)
	check("bot swapped the battery (%s -> %s)" % [before, MissionState.design["battery"]], MissionState.design["battery"] != before)
	check("flag cleared after the swap", not MissionState.commander_marks.has("battery"))

	# an OK mark turns into 'changed' when the pick changes
	pm.on_commander_mark("battery", "")
	var keep = MissionState.design["comm"]
	MissionState.set_mark("comm", "swap")   # as if a human owned it
	var other: String = "uhf_basic"
	for p in Data.db["parts"]["comm"]:
		if p["id"] != keep:
			other = p["id"]
	MissionState.set_choice("comm", other)
	check("a flag clears when the crew changes that part", not MissionState.commander_marks.has("comm"))
	MissionState.set_choice("comm", keep)
	MissionState.set_mark("comm", "swap")
	MissionState.set_mark("comm", "")
	check("the Commander can take a flag back", not MissionState.commander_marks.has("comm"))
	print("   design valid before review: ", MissionState.eval_result.get("valid"), " ", MissionState.eval_result.get("errors"))
	pm._bot_review_called = false

	# bots finish, call review, say GO... but the Commander has not said GO yet
	for i in 1200:
		pm.tick(0.1)
		if MissionState.phase == "REVIEW":
			break
		if i % 40 == 0:
			await get_tree().process_frame
	check("reaches REVIEW", MissionState.phase == "REVIEW")
	await _ticks(pm, 8.0)
	var all_go := true
	for r in Protocol.ROLES:
		if str(MissionState.poll.get(r, {}).get("state", "")) != "go":
			all_go = false
	check("crew all GO", all_go)
	check("waits for the Commander", MissionState.phase == "REVIEW")

	pm.on_commander_mark("rocket", "swap")
	check("GO refused while a SWAP is open", pm.on_commander_decision(true, "") != "")
	pm.on_commander_mark("rocket", "")
	check("Commander GO accepted", pm.on_commander_decision(true, "") == "")
	await _ticks(pm, 3.0)
	check("launches after the Commander's GO", MissionState.phase in ["LAUNCH", "FLIGHT"])

	# HURRY pings go to the Commander screen, not into the flight log
	await _ticks(pm, 15.0)
	var n0: int = (MissionState.flight_status.get("pings", []) as Array).size()
	pm.on_ping("flight", "@commander")
	check("@commander ping not logged as a card ping", (MissionState.flight_status.get("pings", []) as Array).size() == n0)
	# round 6: ASK -> a bot holder gives the token at once
	for i in 300:
		if pm._active and str(pm._beat.get("kind", "")) == "crisis":
			break
		pm.tick(0.1)
	if pm._active:
		var sys_power: int = int(MissionState.tokens["systems"].get("power", 0))
		var fl_power: int = int(MissionState.tokens["flight"].get("power", 0))
		pm.on_ping("flight", "@ask:power")
		if sys_power > 0:
			check("ASK: bot SYSTEMS gave FLIGHT 1 power", int(MissionState.tokens["flight"].get("power", 0)) == fl_power + 1 \
				and int(MissionState.tokens["systems"]["power"]) == sys_power - 1)
			check("gift counted for Helping Paws", pm._gifts >= 1)
		else:
			print("   (systems had no power tokens; ask check skipped)")
	var cross := 0
	for a in Data.db["actions"]:
		if RoleGuide.cost_note(str(a["id"])) != "":
			cross += 1
	check("each crew role has a card that needs a teammate's token (%d)" % cross, cross >= 4)

	# Commander NO-GO sends the crew back to DESIGN
	MissionState.reset_all(false)
	MissionState.set_demo_mode(true)
	Net.host_set_phase("BRIEFING")
	for i in 2000:
		pm.tick(0.1)
		if MissionState.phase == "REVIEW":
			break
		if i % 40 == 0:
			await get_tree().process_frame
	check("second run reaches REVIEW", MissionState.phase == "REVIEW")
	check("Commander NO-GO accepted", pm.on_commander_decision(false, "Too heavy") == "")
	check("back to DESIGN", MissionState.phase == "DESIGN")

	# the handbook: every crisis has a unique gauge pattern and at least one card to play
	var seen: Dictionary = {}
	var unique := true
	var playable := true
	for e in Data.db["events"]:
		if str(e["kind"]) != "crisis":
			continue
		var pat: Array = []
		for t in (e["threat"] as Dictionary):
			pat.append("%s=%s" % [t, RoleGuide.level(float(e["threat"][t]))])
		pat.sort()
		var key := ",".join(pat)
		if seen.has(key):
			unique = false
			print("   same pattern: %s and %s" % [seen[key], e["id"]])
		seen[key] = e["id"]
		if RoleGuide.best_cards(e).is_empty():
			playable = false
			print("   no card for " + str(e["id"]))
	check("every crisis has a unique gauge pattern", unique)
	check("every crisis has a card that helps", playable)
	var gauges := 0
	for r in Protocol.ROLES:
		gauges += RoleGuide.gauges_for(r).size()
		check("%s reads 2 gauges" % r, RoleGuide.gauges_for(r).size() == 2)
	var hb: Dictionary = CommanderHandbook.as_json()
	check("printable handbook has 11 crises and the parts", (hb["crises"] as Array).size() == 11 and (hb["parts"] as Array).size() >= 8)
	var max_calls := 0
	for c in hb["crises"]:
		max_calls = maxi(max_calls, (c["calls"] as Array).size())
	check("the Commander calls at most 2 cards per crisis", max_calls <= 2 and max_calls >= 1)
	# the gauge finder answers a solar flare
	var f := GaugeFinder.new()
	add_child(f)
	f.set_alarms(["radiation", "power"])
	var said := ""
	for n in f.find_children("*", "Label", true, false):
		said += (n as Label).text + " "
	check("gauge finder: radiation + power = SOLAR FLARE", said.contains("SOLAR FLARE"))
	f.set_alarms(["radiation"])
	said = ""
	for n in f.find_children("*", "Label", true, false):
		said += (n as Label).text + " "
	check("gauge finder: radiation only = RADIATION BELT", said.contains("RADIATION"))
	f.queue_free()

	# the crew's gauges show the same ALARMs the handbook lists (round 6 regression check)
	var cp := CrisisPanel.new()
	cp.setup("systems", Color.ORANGE)
	add_child(cp)
	for eid in ["battery_cell", "software_glitch"]:
		var ev: Dictionary = Data.by_id(Data.db["events"], eid).duplicate(true)
		cp.show_event(ev, 25.0)
		var txt := ""
		for n in cp._gauge_box.find_children("*", "Label", true, false):
			txt += (n as Label).text + " | "
		print("   ", eid, ": ", txt)
		var want_batt: bool = eid == "battery_cell"
		check("%s: SYSTEMS gauges right" % eid, txt.contains("BATTERY VOLTAGE | %s" % ("!!! ALARM" if want_batt else "OK")) \
			and txt.contains("COMPUTER HEALTH | %s" % ("OK" if want_batt else "!!! ALARM")))
	cp.queue_free()

	# round 7: per-instrument flags
	var ins: Array = []
	for i in Data.db["instruments"]:
		if i["scenario"] == "bagyo_watch" and ins.size() < 2:
			ins.append(i["id"])
	MissionState.set_choice("instruments", ins)
	MissionState.set_mark("instruments:" + ins[0], "swap")
	check("PAYLOAD sees one flagged instrument", MissionState.swaps_for_role("payload") == ["instruments:" + ins[0]])
	check("flag label is the instrument's name", MissionState.mark_label("instruments:" + ins[0]) == SimEngine._item_name(Data.db, "instruments", ins[0]))
	MissionState.set_choice("instruments", [ins[1]])
	check("taking that instrument out clears its flag", not MissionState.commander_marks.has("instruments:" + ins[0]))
	MissionState.set_mark("instruments:" + ins[1], "swap")
	MissionState.set_choice("instruments", [ins[1], ins[0]])
	check("adding another instrument keeps the other flag", MissionState.commander_marks.has("instruments:" + ins[1]))
	MissionState.set_mark("instruments:" + ins[1], "")

	# round 7: balance - FLIGHT now picks orbit + engines + pointing
	check("FLIGHT owns orbit, engines, pointing", Data.db["meta"]["roles"]["flight"]["owns_choices"] == ["orbit", "adcs", "prop"])
	check("tokens start at 3 or less", FlightDirector.MAX_START_TOKENS == 3)

	# round 7: the build clock (not in Demo Mode)
	MissionState.reset_all(false)
	MissionState.set_demo_mode(false)
	MissionState.set_difficulty("engineer")
	MissionState.set_mission_length("short")
	Net.host_set_phase("BRIEFING")
	for i in 400:
		pm.tick(0.1)
		if MissionState.phase == "DESIGN":
			break
	pm._bot_review_called = true   # bots wait: we want to see overtime
	check("build clock starts at the lobby's build time (%d s)" % MissionState.build_seconds,
		MissionState.design_left >= MissionState.build_seconds - 5 and MissionState.design_left <= MissionState.build_seconds)
	var cap0: float = float(MissionState.eval_result["cost"]["cap"])
	for i in 2850:   # 4:45
		pm.tick(0.1)
		if i % 200 == 0:
			await get_tree().process_frame
	check("clock reached zero", MissionState.design_left == 0)
	check("investors pulled money in overtime (C$%d M)" % int(MissionState.budget_penalty), MissionState.budget_penalty >= 10.0)
	var c: Dictionary = MissionState.eval_result["cost"]
	var expect: float = float(c.get("base_cap", cap0)) * MissionState.orbit_budget_mult() * MissionState.twist_effect("budget_mult", 1.0) - MissionState.budget_penalty
	check("the budget cap shrank by that much (orbit and twist budgets included)", absf(float(c["cap"]) - expect) < 0.2)
	MissionState.set_demo_mode(true)

	MissionState.commander_present = false
	print("ALL GOOD" if fails == 0 else "%d FAILED" % fails)
	get_tree().quit(1 if fails > 0 else 0)
