# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## LEAD (round 8) tests: crisis fixes, lives, mini-tasks, twists, orbit budgets, mods. Offline, fake time.
## Terminal: godot --headless --path . res://tests/round8_test.tscn -- --no-mods
## Expect every line to say PASS and "ALL GOOD" at the end.

var _fails := 0
var _msgs: Array = []
var _results: Array = []
var _reports: Array = []
var pm: PhaseMachine


func check(label: String, cond: bool) -> void:
	print(("PASS  " if cond else "FAIL  ") + label)
	if not cond:
		_fails += 1


func run(seconds: float, step: float = 0.25) -> void:
	var t := 0.0
	while t < seconds:
		pm.tick(step)
		t += step


func _fresh(diff: String, demo: bool = true) -> void:
	Net.leave()
	MissionState.reset_all()
	MissionState.set_difficulty(diff)
	MissionState.set_demo_mode(demo)
	MissionState.set_scenario("bagyo_watch")
	Net.request_seat("flight")
	_msgs.clear()
	_results.clear()
	_reports.clear()


func _load_preset(preset_name: String) -> void:
	for p in Data.db["bot_presets"]["bagyo_watch"]:
		if p["name"] == preset_name:
			for k in p["design"]:
				if k != "scenario":
					Net.apply_choice_as("", k, p["design"][k])


## BRIEFING -> DESIGN -> REVIEW -> LAUNCH -> FLIGHT with the cautious design.
func _to_flight() -> void:
	Net.host_set_phase("BRIEFING")
	Net.set_seat_ready(true)
	_load_preset("cautious")
	Net.call_review()
	Net.poll_answer(true, "")
	run(6.0)
	run(LAUNCH_WAIT)


const LAUNCH_WAIT := 8.0


func _event(id: String) -> Dictionary:
	for e in Data.db["events"]:
		if str(e["id"]) == id:
			return e
	return {}


func _ready() -> void:
	pm = Net.phase_machine
	Net.server_message_received.connect(func(code, text): _msgs.append([code, text]))
	Net.crisis_result.connect(func(r): _results.append(r))
	Net.debrief_report.connect(func(r): _reports.append(r))

	# ---- 1. the handbook's cards block EVERY crisis completely ----
	for e in Data.db["events"]:
		if str(e["kind"]) != "crisis":
			continue
		var ids: Array = []
		for c in RoleGuide.calls(e):
			ids.append(str(c["action"]))
		check("handbook fix for %s blocks 100%% (%s)" % [e["id"], ", ".join(ids)], RoleGuide.blocked(e, ids) >= 0.999 and ids.size() <= 2)

	# ---- 2. "I'm done" right away: the bots still play before the crisis is scored ----
	_fresh("engineer")
	_to_flight()
	check("reached FLIGHT", MissionState.phase == "FLIGHT")
	check("Engineer starts with 2 lives", MissionState.lives == 2 and MissionState.lives_max == 2)
	run(4.0)   # first beat
	check("a beat is running", pm._active)
	Net.play_action("pass")   # the only human is done at once
	run(1.5)
	var res: Dictionary = _results.back() if not _results.is_empty() else {}
	var bot_plays := 0
	for p in res.get("played", []):
		if str(p.get("role", "")) != "flight":
			bot_plays += 1
	check("bots played their cards even though the human finished instantly (%d bot cards)" % bot_plays, str(res.get("kind", "")) != "crisis" or bot_plays >= 1)

	# ---- 3. lives: a crisis with nothing played is a mistake; out of lives ends the mission ----
	_fresh("flight_director")   # 1 life
	_to_flight()
	check("Flight Director starts with 1 life", MissionState.lives == 1)
	# take every seat away from the bots so nobody blocks anything
	for r in ["systems", "payload", "ground"]:
		MissionState.seats[r] = 99   # a "human" that never answers
	var guard := 0
	while MissionState.phase == "FLIGHT" and guard < 400:
		if pm._active and str(pm._beat.get("kind", "")) == "crisis":
			Net.play_action("pass")
		run(1.0)
		guard += 1
	check("out of lives -> DEBRIEF", MissionState.phase == "DEBRIEF")
	var rep: Dictionary = _reports.back() if not _reports.is_empty() else {}
	check("report says mission lost, out of lives", bool(rep.get("mission_lost", false)) and bool(rep.get("out_of_lives", false)))
	check("the mistake line is in the report", str(rep.get("why", [])).contains("OUT OF LIVES"))

	# ---- 4. mini-tasks ----
	_fresh("cadet")
	_to_flight()
	check("Cadet starts with 3 lives", MissionState.lives == 3)
	var before: int = int(pm.director.tokens["flight"].get("fuel", 0))
	pm._start_task_round()
	var started := false
	for m in _msgs:
		if m[0] == "task_start" and str(m[1]).begins_with("asteroids|random|"):
			started = true
	check("random task round: FLIGHT gets the asteroid task", started)
	check("every crew member has a task", pm._tasks.size() == 4)
	Net.ping("@task:ok")
	check("finished task pays 1 fuel", int(pm.director.tokens["flight"].get("fuel", 0)) == mini(before + 1, 5))
	run(12.0)   # bots finish theirs, the round ends
	check("task round ended", not pm._task_round)

	# chip-in: run to an opportunity
	var opp_seen := false
	guard = 0
	while MissionState.phase == "FLIGHT" and guard < 300:
		if pm._active and str(pm._beat.get("kind", "")) == "opportunity" and not opp_seen:
			opp_seen = true
			_msgs.clear()
			# give the team what it needs so the chip-in is affordable
			for tk in (pm._event.get("needs", {}) as Dictionary):
				var owner: String = CrisisPanel.owner_role(str(tk))
				pm.director.tokens[owner][tk] = 3
			Net.event_choice("capture")
			var chip_started := false
			for m in _msgs:
				if m[0] == "task_start" and str(m[1]).contains("|chip|"):
					chip_started = true
			check("CHIP IN starts a task for ONLY that player", chip_started and pm._tasks.size() == 1)
			check("nothing is paid before the task is done", not pm.director.fd._paid)
			Net.ping("@task:ok")
			check("task done -> the chance is captured", pm.director.fd._paid)
		elif pm._active and str(pm._beat.get("kind", "")) == "crisis":
			Net.play_action("pass")
		run(1.0)
		guard += 1
	check("an opportunity came up", opp_seen)

	# ---- 5. twists ----
	_fresh("engineer", false)
	Net.host_set_phase("BRIEFING")
	check("a twist was rolled", MissionState.twists.size() == 1)
	MissionState.set_twists(["solar_max"])
	Net.set_seat_ready(true)
	_load_preset("cautious")
	Net.call_review()
	Net.poll_answer(true, "")
	run(6.0)
	run(LAUNCH_WAIT)
	if MissionState.phase == "FLIGHT":
		var ids2: Array = []
		for e in pm.director.fd.deck:
			ids2.append(str(e["id"]))
		check("Solar maximum puts a solar flare in the deck", ids2.has("solar_flare"))
	else:
		check("launch worked for the twist test (launch can fail outside demo mode)", MissionState.phase == "DEBRIEF")
	_fresh("engineer")
	var cap1: float = float(MissionState.eval_result["cost"]["cap"])
	MissionState.set_twists(["tight_funding"])
	check("Tight funding cuts the budget by 10%", absf(float(MissionState.eval_result["cost"]["cap"]) - cap1 * 0.9) < 0.2)
	MissionState.set_twists([])

	# ---- 6. the budget depends on the orbit ----
	Net.apply_choice_as("", "orbit", "leo_sso_700")
	var cap_sso: float = float(MissionState.eval_result["cost"]["cap"])
	Net.apply_choice_as("", "orbit", "geo_35786")
	var cap_geo: float = float(MissionState.eval_result["cost"]["cap"])
	check("geostationary comes with a bigger budget (C$%d M vs C$%d M)" % [int(cap_geo), int(cap_sso)], cap_geo > cap_sso * 1.3)

	# ---- 7. build time setting ----
	MissionState.set_build_seconds(120)
	MissionState.set_difficulty("engineer")
	Net.host_set_phase("LOBBY")
	Net.host_set_phase("BRIEFING")
	check("build clock uses the lobby setting (2:00)", MissionState.design_left == 120 or MissionState.demo_mode)
	MissionState.set_build_seconds(180)

	# ---- 8. mods ----
	var base: Dictionary = (JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json")) as Dictionary)
	var good_inst: Dictionary = (base["instruments"][0] as Dictionary).duplicate(true)
	good_inst["id"] = "mod_camera"
	good_inst["name"] = "Mod camera"
	var r1: Dictionary = Data.apply_mod(base, {"instruments": [good_inst], "parts": {"battery": [{"id": "broken"}]}}, "test.json")
	check("a complete modded instrument is added", int(r1["added"]) == 1 and not Data.by_id(base["instruments"], "mod_camera").is_empty())
	check("an incomplete modded part is refused with a reason", (r1["problems"] as Array).size() == 1 and str(r1["problems"][0]).contains("missing"))
	check("the game still evaluates with the mod", SimEngine.evaluate(base, MissionState.design, "engineer").has("cost"))
	var ex = JSON.parse_string(FileAccess.get_file_as_string("res://modding/example_mod.json"))
	var base2: Dictionary = (JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json")) as Dictionary)
	var r2: Dictionary = Data.apply_mod(base2, ex, "example_mod.json")
	check("modding/example_mod.json loads with no problems (%s)" % str(r2["problems"]), (r2["problems"] as Array).is_empty() and int(r2["added"]) == 4)
	var mm: Dictionary = Data.by_id(base2["events"], "mod_micrometeoroid")
	var mm_ids: Array = []
	for c in RoleGuide.calls(mm):
		mm_ids.append(str(c["action"]))
	check("the example crisis can be fully blocked by the handbook's cards", RoleGuide.blocked(mm, mm_ids) >= 0.999)

	# ---- 9. round 9: team info on crew screens matches the real science maths; credits load ----
	for sc in Data.db["scenarios"]:
		for pr in Data.db["bot_presets"][sc["id"]]:
			var d: Dictionary = pr["design"]
			var r: Dictionary = SimEngine.evaluate(Data.db, d, "engineer")
			if not r.has("science"):
				continue
			var ok := true
			var gf: Array = ShipDoctor.goal_fill(Data.db, d)
			for i in gf.size():
				var want: float = float(r["science"]["objectives"][i]["achieved"])
				if absf(float(gf[i]["fill"]) * float(gf[i]["weight"]) - want) > 0.05:
					ok = false
			check("crew goal meter = SimEngine objectives (%s/%s)" % [sc["id"], pr["name"]], ok)
	check("team box lists all four crew", ShipDoctor.team_lines(Data.db, MissionState.design).size() == 4)
	check("credits file loads and says AI", Credits.short_line().contains("AI") and (Credits.data().get("items", []) as Array).size() >= 5)

	print("")
	print("ALL GOOD" if _fails == 0 else "%d FAILED" % _fails)
	get_tree().quit(1 if _fails > 0 else 0)
