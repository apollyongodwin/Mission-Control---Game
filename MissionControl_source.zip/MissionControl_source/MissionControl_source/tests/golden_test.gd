# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends SceneTree
## Terminal version:  godot --headless --path . -s res://tests/golden_test.gd
## Exit code 0 = all golden tests pass.


func _init() -> void:
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json"))
	if typeof(data) != TYPE_DICTIONARY:
		printerr("Could not read res://data/countdown_data.json")
		quit(2)
		return
	var result: Dictionary = GoldenRunner.run(data)
	for l in result["lines"]:
		print(l)
	quit(result["failures"])
