# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## No terminal needed: open tests/golden_test_scene.tscn in the editor and press F6.
## Results appear on screen and in the Output panel.


func _ready() -> void:
	var label := RichTextLabel.new()
	label.set_anchors_preset(Control.PRESET_FULL_RECT)
	label.bbcode_enabled = true
	label.add_theme_font_size_override("normal_font_size", 22)
	add_child(label)
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json"))
	if typeof(data) != TYPE_DICTIONARY:
		label.text = "Could not read res://data/countdown_data.json"
		return
	var result: Dictionary = GoldenRunner.run(data)
	var text := ""
	for l in result["lines"]:
		print(l)
		if str(l).begins_with("PASS"):
			text += "[color=lightgreen]%s[/color]\n" % l
		elif str(l).begins_with("FAIL"):
			text += "[color=tomato]%s[/color]\n" % l
		else:
			text += str(l) + "\n"
	if result["failures"] == 0:
		text += "\n[color=lightgreen][b]ALL GOOD. The sim is correct.[/b][/color]"
	else:
		text += "\n[color=tomato][b]%d FAILED. Copy this screen and send it to the lead.[/b][/color]" % result["failures"]
	label.text = text
