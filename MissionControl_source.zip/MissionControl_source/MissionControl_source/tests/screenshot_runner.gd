# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## LEAD tool: open any scene, optionally put the game into a phase, wait, and save a PNG.
## Used to check the merged UI without clicking through it by hand.
##   godot res://tests/screenshot_runner.tscn -- --scene=res://ui/menu/MainMenu.tscn --out=/tmp/menu.png
## Extra options:  --frames=N  --size=1280x720  --setup=<name>  (see _setup below)

var _args: Dictionary = {}


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		var kv: PackedStringArray = str(a).trim_prefix("--").split("=", true, 1)
		_args[kv[0]] = kv[1] if kv.size() > 1 else "1"
	var sz: PackedStringArray = str(_args.get("size", "1280x720")).split("x")
	get_window().size = Vector2i(int(sz[0]), int(sz[1]))
	await get_tree().process_frame
	_setup(str(_args.get("setup", "")))
	var scene_path: String = str(_args.get("scene", ""))
	if scene_path != "":
		var packed: PackedScene = load(scene_path)
		var inst: Node = packed.instantiate()
		get_tree().root.add_child.call_deferred(inst)
		await get_tree().process_frame
		_after(str(_args.get("setup", "")), inst)
	for i in int(_args.get("frames", "40")):
		await get_tree().process_frame
	var t: float = float(_args.get("wait", "0"))
	if t > 0.0:
		await get_tree().create_timer(t).timeout
	await RenderingServer.frame_post_draw
	var img: Image = get_viewport().get_texture().get_image()
	img.save_png(str(_args.get("out", "/tmp/shot.png")))
	print("SAVED ", _args.get("out", "/tmp/shot.png"))
	get_tree().quit()


## Puts MissionState into a state worth looking at (offline, single process).
func _setup(name: String) -> void:
	if name == "":
		return
	var ms: Node = get_node("/root/MissionState")
	var net: Node = get_node("/root/Net")
	var role: String = str(_args.get("role", "systems"))
	ms.set("difficulty", str(_args.get("difficulty", "cadet")))
	match name:
		"design", "review", "crisis", "flight", "briefing", "debrief", "launch":
			ms.call("set_scenario", "bagyo_watch")
			ms.set("local_role", role)
			ms.call("assign_seat", role, 1)
			if name != "briefing":
				net.call("host_set_phase", "DESIGN")
			else:
				net.call("host_set_phase", "BRIEFING")
			# a sensible design so the lights are not all red
			for kv in [["orbit", "leo_tropical_600"], ["instruments", ["sar_c", "thermal_ir", "rain_gauge_relay"]],
					["bus", "bus_mini"], ["panel", "si_12"], ["battery", "bat_2000"], ["stations", ["iligan_gs"]]]:
				net.call("apply_choice_as", "", kv[0], kv[1])


func _after(name: String, inst: Node) -> void:
	if _args.has("orbit") and inst.has_method("set_design"):
		if inst is Control:
			(inst as Control).set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		inst.call("set_design", {"scenario": "bagyo_watch", "orbit": str(_args["orbit"]), "bus": "bus_mini", "panel": "si_6",
			"comm": "x_band_steer", "stations": ["iligan_gs", "svalbard_gs"], "instruments": ["sar_c"]})
		if _args.has("t"):
			inst.set("_t", float(_args["t"]))
	var net: Node = get_node("/root/Net")
	var ms: Node = get_node("/root/MissionState")
	if _args.has("page"):   # round 9: show page N of a crew panel (CrewScreen or a role panel)
		await get_tree().create_timer(0.3).timeout
		var panel: Node = inst.get("_panel") if inst.get("_panel") != null else inst
		for i in int(_args["page"]):
			panel.call("_go_page", 1)
	if _args.has("myjob"):   # round 6: the MY JOB popup
		await get_tree().create_timer(0.3).timeout
		RoleGuide.popup(inst, str(_args.get("role", "systems")))
	match name:
		"review":
			net.call("host_set_phase", "REVIEW")
		"flight":
			net.call("host_set_phase", "REVIEW")
			net.call("host_set_phase", "LAUNCH")
			net.call("host_set_phase", "FLIGHT")
		"launch":
			net.call("host_set_phase", "REVIEW")
			net.call("host_set_phase", "LAUNCH")
		"crisis":
			await get_tree().process_frame
			var ev: Dictionary = Data.by_id(Data.db["events"], str(_args.get("event", "solar_flare")))
			ms.call("set_tokens", {"flight": {"fuel": 2, "time": 1}, "systems": {"power": 3}, "payload": {"data": 2}, "ground": {"budget": 2, "comms": 1}})
			net.call("host_set_phase", "FLIGHT")
			ms.call("set_flight_status", {"active": true, "title": str(ev.get("title", "")), "acted": {"systems": false}})
			net.emit_signal("crisis_event", ev, 25.0)
			if _args.has("resolve"):
				await get_tree().create_timer(0.5).timeout
				net.emit_signal("crisis_result", {"kind": "crisis", "id": ev["id"], "residual": float(_args["resolve"]),
					"line": "%s: SYSTEMS played 'Shed electrical load'. It cost 6%% of the science. %s" % [ev["title"], ev.get("learn", "")]})
		"debrief":
			var fd := FlightDirectorAdapter.new()
			var design: Dictionary = ms.get("design")
			for p in Data.db["bot_presets"]["bagyo_watch"]:
				if p["name"] == str(_args.get("preset", "cautious")):
					design = p["design"].duplicate(true)
			ms.set("design", design)
			var res: Dictionary = SimEngine.evaluate(Data.db, design, "cadet")
			fd.setup(design, res, 7, "cadet", "short")
			while true:
				var b: Dictionary = fd.next_beat()
				if b.is_empty():
					break
				fd.fd.auto_play_current()
				fd.resolve_current()
			var rep: Dictionary = ReportFormat.normalize(fd.final_report())
			if _args.has("lost"):
				ms.set("eval_result", res)
				rep = ReportFormat.normalize(net.get("phase_machine").call("_lost_report"))
			rep["team_name"] = "Pawstronauts"
			rep["scenario"] = "bagyo_watch"
			rep["design"] = design
			var objs: Array = []
			var k: float = float(rep.get("science_final", 0.0)) / maxf(0.001, float(res["science"]["points"]))
			for o in res["science"]["objectives"]:
				objs.append({"tag": o["tag"], "achieved": float(o["achieved"]) * k, "max": o["max"]})
			rep["objectives"] = objs
			ms.set("last_report", rep)
			net.call("host_set_phase", "DEBRIEF")
			if inst.has_method("show_report"):
				inst.set("save_on_show", false)
				inst.call("show_report", rep, {}, {})
