# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Real two-process network test (localhost). Run BOTH, host first:
##   godot --headless --path . res://tests/net_e2e.tscn -- --host
##   godot --headless --path . res://tests/net_e2e.tscn -- --client
## Each prints PASS/FAIL lines and exits 0 when all is well. The client plays GROUND; the host plays
## Mission Control and applies the other three roles' choices itself (as if AutoCrew bots had picked them).

var is_host := false
var fails := 0
var did := {}
var t_start := 0.0


func check(name: String, cond: bool) -> void:
	print(("PASS  " if cond else "FAIL  ") + name)
	if not cond:
		fails += 1


func _ready() -> void:
	is_host = "--host" in OS.get_cmdline_user_args()
	t_start = Time.get_ticks_msec() / 1000.0
	if is_host:
		MissionState.set_difficulty("engineer")
		MissionState.set_demo_mode(true)
		check("host starts", Net.host_game() == OK)
		Net.peer_joined.connect(func(id): print("host: peer joined ", id))
		MissionState.seats_changed.connect(_host_seats)
		MissionState.phase_changed.connect(_host_phase)
		Net.crisis_event.connect(func(e, t): print("host: crisis ", e["id"], " timer ", t))
	else:
		await get_tree().create_timer(1.5).timeout    # let the host come up
		Net.joined_server.connect(_client_joined)
		Net.phase_started.connect(_client_phase)
		Net.crisis_event.connect(_client_crisis)
		Net.debrief_report.connect(_client_debrief)
		Net.server_message_received.connect(func(c, t): print("client: msg ", c, " ", t))
		check("client joins", Net.join_game("127.0.0.1") == OK)


func _process(_d: float) -> void:
	if Time.get_ticks_msec() / 1000.0 - t_start > 120.0:
		print("FAIL  timeout")
		get_tree().quit(1)


# ------------------------- host -------------------------
func _host_seats() -> void:
	if MissionState.phase == "LOBBY" and MissionState.seats["ground"] > 0 and not did.has("start"):
		did["start"] = true
		Net.host_set_phase("BRIEFING")


func _host_phase(p: String) -> void:
	print("host: phase ", p)
	if p == "DESIGN" and not did.has("design"):
		did["design"] = true
		for pr in Data.db["bot_presets"]["bagyo_watch"]:
			if pr["name"] == "cautious":
				for k in pr["design"]:
					if k == "scenario":
						continue
					var owner := Protocol.owner_of(Data.db, k)
					if owner != "ground":
						var err := Net.apply_choice_as(owner, k, pr["design"][k])
						check("host applies %s for %s" % [k, owner], err == "")
	if p == "DEBRIEF":
		await get_tree().create_timer(1.0).timeout
		check("host saw a report", not MissionState.last_report.is_empty())
		print("host: ", "ALL GOOD" if fails == 0 else "%d FAILED" % fails)
		get_tree().quit(0 if fails == 0 else 1)


# ------------------------- client -------------------------
func _client_joined() -> void:
	Net.request_seat("ground")
	await get_tree().create_timer(0.3).timeout
	check("client got the GROUND seat", MissionState.local_role == "ground")
	Net.set_seat_ready(true)


func _client_phase(p: String, payload: Dictionary) -> void:
	print("client: phase ", p)
	if p == "DESIGN" and not did.has("design"):
		did["design"] = true
		for pr in Data.db["bot_presets"]["bagyo_watch"]:
			if pr["name"] == "cautious":
				for k in ["rocket", "comm", "stations"]:
					Net.submit_choice(k, pr["design"][k])
		await get_tree().create_timer(0.5).timeout
		# drop the connection and come back: the seat must still be ours
		Net.leave()
		await get_tree().create_timer(0.5).timeout
		Net.join_game("127.0.0.1")
		await get_tree().create_timer(1.0).timeout
		check("seat held and returned after a dropped connection", MissionState.local_role == "ground")
		check("design survived the reconnect", MissionState.design.get("rocket", "") != "")
		check("client lights valid after rejoin", MissionState.view.get("valid", false) == true)
		Net.call_review()
	if p == "REVIEW":
		await get_tree().create_timer(0.3).timeout
		check("client sees the poll", MissionState.poll.size() == 4)
		Net.poll_answer(true, "")
	if p == "LAUNCH":
		check("client got the launch reliability", payload.has("reliability"))
	if p == "FLIGHT":
		await get_tree().create_timer(0.6).timeout   # the state sync arrives just after the phase message
		check("client holds only its own tokens", MissionState.tokens.keys() == ["ground"])
		check("client has budget tokens, not fuel", MissionState.role_tokens("ground").has("budget") and not MissionState.tokens.has("flight"))
		check("client never receives the full result", MissionState.eval_result.is_empty())


func _client_crisis(e: Dictionary, timer: float) -> void:
	print("client: crisis ", e["id"], " timer ", timer)
	await get_tree().create_timer(0.3).timeout
	Net.ping("ON_IT")
	Net.play_action("pass")


func _client_debrief(r: Dictionary) -> void:
	check("client received the report", r.has("lines") and r.has("grade"))
	check("client sees the flight status", MissionState.flight_status.has("beat"))
	print("client: ", "ALL GOOD" if fails == 0 else "%d FAILED" % fails)
	await get_tree().create_timer(0.5).timeout
	get_tree().quit(0 if fails == 0 else 1)
