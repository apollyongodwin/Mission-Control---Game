# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends SceneTree
## godot --headless --path . -s res://tests/autofill_test.gd


func _init() -> void:
	var D = JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json"))
	var fails := 0
	var power_total := 0
	var power_ok := 0
	for t in D["golden_tests"]:
		var name: String = t["name"]
		var d: Dictionary = t["design"].duplicate(true)
		var orb := SimEngine._find(D["orbits"], d["orbit"])
		# 1. autopilot for adcs + prop on a design with those blanked out
		d["adcs"] = "adcs_basic"
		d["prop"] = "prop_none"
		var res: Dictionary = SimEngine.autofill(D, d, ["adcs", "prop"])
		var f: Dictionary = res["design"]
		var prop := SimEngine._find(D["parts"]["prop"], f["prop"])
		if int(prop["tier"]) < int(orb["requires_prop_tier"]):
			print("FAIL ", name, ": prop tier too low")
			fails += 1
		var adcs := SimEngine._find(D["parts"]["adcs"], f["adcs"])
		var need := 1000.0
		for iid in f["instruments"]:
			need = minf(need, float(SimEngine._find(D["instruments"], iid)["point_req_deg"]))
		need = minf(need, float(SimEngine._find(D["parts"]["comm"], f["comm"])["point_req_deg"]))
		if float(adcs["pointing_deg"]) > need and f["adcs"] != "adcs_precision":
			print("FAIL ", name, ": pointing not good enough")
			fails += 1
		var after: Dictionary = SimEngine.evaluate(D, f, "engineer")
		for e in after["errors"]:
			if e == "orbit needs more propulsion":
				print("FAIL ", name, ": still needs propulsion")
				fails += 1
		print("  %-22s adcs=%-15s prop=%-14s notes=%d" % [name, f["adcs"], f["prop"], res["notes"].size()])
		# 2. autopilot for power: how often does it find a green power pack?
		var d2: Dictionary = t["design"].duplicate(true)
		var pr: Dictionary = SimEngine.autofill(D, d2, ["adcs", "prop", "power"])
		var r2: Dictionary = SimEngine.evaluate(D, pr["design"], "engineer")
		power_total += 1
		if r2["lights"]["power"] == "green":
			power_ok += 1
		else:
			print("  (power not green for %s: %s)" % [name, r2["lights"]["power"]])
	print("power autopilot gave green power in %d of %d presets" % [power_ok, power_total])
	# 3. Fix it for me on the three rookie designs
	for t in D["golden_tests"]:
		if not str(t["name"]).ends_with("rookie"):
			continue
		var fx: Dictionary = SimEngine.suggest_fix(D, t["design"], "engineer")
		if fx.is_empty():
			print("FAIL ", t["name"], ": no fix suggested")
			fails += 1
			continue
		var before: Dictionary = SimEngine.evaluate(D, t["design"], "engineer")
		var fixed: Dictionary = SimEngine.evaluate(D, SimEngine.apply_fix(t["design"], fx), "engineer")
		var improved: bool = SimEngine._badness(fixed) < SimEngine._badness(before)
		print("  FIX %-22s -> %s  [owner: %s]  improved=%s" % [t["name"], fx["label"], fx["owner_role"], improved])
		print("      why: ", fx["why"])
		if not improved:
			fails += 1
	# 4. a perfect design needs no fix
	var good: Dictionary = SimEngine.suggest_fix(D, D["golden_tests"][0]["design"], "engineer")
	print("  fix on a healthy design: ", "none (good)" if good.is_empty() else good["label"])
	print("")
	print("autofill test: %d problems" % fails)
	quit(fails)
