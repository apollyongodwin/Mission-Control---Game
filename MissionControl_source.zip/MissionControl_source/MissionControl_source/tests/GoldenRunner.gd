# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name GoldenRunner
extends RefCounted
## Shared by the terminal test and the click-to-run scene. Returns {"lines": Array, "failures": int, "total": int}.

const TOL := 0.05
const TOL_COARSE := 0.11  ## values the data file rounds to 0.1


static func _near(a, b, tol: float = TOL) -> bool:
	return absf(float(a) - float(b)) <= tol


static func run(data: Dictionary) -> Dictionary:
	var lines: Array = []
	var failures := 0
	for t in data["golden_tests"]:
		var r: Dictionary = SimEngine.evaluate(data, t["design"], "engineer")
		var e: Dictionary = t["expect"]
		var checks := {
			"valid": [r["valid"], e["valid"]],
			"launch_mass": [r["mass"]["launch"], e["launch_mass"], TOL_COARSE],
			"mass_margin": [r["mass"]["margin"], e["mass_margin"]],
			"power_margin": [r["power"]["margin"], e["power_margin"]],
			"data_ratio": [r["data"]["ratio"], e["data_ratio"]],
			"downlink_gb_day": [r["data"]["downlink_gb_day"], e["downlink_gb_day"]],
			"lifetime_days": [r["lifetime"]["days"], e["lifetime_days"]],
			"total_cost": [r["cost"]["total"], e["total_cost"], TOL_COARSE],
			"dev_months": [r["schedule"]["dev_months"], e["dev_months"]],
			"science": [r["science"]["points"], e["science"]],
			"pre_total": [r["score"]["pre_total"], e["pre_total"], TOL_COARSE],
		}
		var bad: Array = []
		for k in checks:
			var pair: Array = checks[k]
			if typeof(pair[0]) == TYPE_BOOL:
				if pair[0] != pair[1]:
					bad.append("%s got %s want %s" % [k, pair[0], pair[1]])
			elif not _near(pair[0], pair[1], pair[2] if pair.size() > 2 else TOL):
				bad.append("%s got %s want %s" % [k, pair[0], pair[1]])
		if r["lifetime"]["limiting"] != e["lifetime_limit"]:
			bad.append("lifetime_limit got %s want %s" % [r["lifetime"]["limiting"], e["lifetime_limit"]])
		var got_err: Array = r["errors"].duplicate()
		var want_err: Array = e["errors"].duplicate()
		got_err.sort()
		want_err.sort()
		if got_err != want_err:
			bad.append("errors got %s want %s" % [got_err, want_err])
		for tk in e["tokens"]:
			if int(r["tokens"][tk]) != int(e["tokens"][tk]):
				bad.append("token %s got %s want %s" % [tk, r["tokens"][tk], e["tokens"][tk]])
		if bad.is_empty():
			lines.append("PASS  " + str(t["name"]))
		else:
			failures += 1
			lines.append("FAIL  " + str(t["name"]))
			for b in bad:
				lines.append("      " + str(b))
	var total: int = data["golden_tests"].size()
	lines.append("")
	lines.append("%d of %d golden tests passed" % [total - failures, total])
	return {"lines": lines, "failures": failures, "total": total}
