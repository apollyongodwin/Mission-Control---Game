# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## Offline test of the phase machine (single process, fake time). Editor: open tests/phase_test.tscn, F6.
## Terminal: godot --headless --path . res://tests/phase_test.tscn --quit-after 600
## Expect every line to say PASS. Run it against the stub director AND against Dev A's real FlightDirector.

var _fails := 0
var _msgs: Array = []
var _crises: Array = []
var _results: Array = []
var _reports: Array = []
var pm: PhaseMachine


func check(label: String, cond: bool) -> void:
	print(("PASS  " if cond else "FAIL  ") + label)
	if not cond:
		_fails += 1


func run(seconds: float, step: float = 0.5) -> void:
	var t := 0.0
	while t < seconds:
		pm.tick(step)
		t += step


func _fresh(diff: String, demo: bool) -> void:
	Net.leave()
	MissionState.reset_all()
	MissionState.set_difficulty(diff)
	MissionState.set_demo_mode(demo)
	MissionState.set_scenario("bagyo_watch")
	Net.request_seat("flight")        # offline: this process plays FLIGHT; the other three seats are empty (bots)
	_msgs.clear()
	_crises.clear()
	_results.clear()
	_reports.clear()


func _load_preset(preset_name: String) -> void:
	for p in Data.db["bot_presets"]["bagyo_watch"]:
		if p["name"] == preset_name:
			for k in p["design"]:
				if k != "scenario":
					var err: String = Net.apply_choice_as("", k, p["design"][k])
					assert(err == "", "preset " + k + ": " + err)


func _ready() -> void:
	pm = Net.phase_machine
	Net.server_message_received.connect(func(code, _text): _msgs.append(code))
	Net.crisis_event.connect(func(e, t): _crises.append({"event": e, "timer": t}))
	Net.crisis_result.connect(func(r): _results.append(r))
	Net.debrief_report.connect(func(r): _reports.append(r))

	# ---- BRIEFING ends by timer, or when every seated player is READY ----
	_fresh("engineer", true)
	Net.host_set_phase("BRIEFING")
	check("BRIEFING entered", MissionState.phase == "BRIEFING")
	run(14.0)
	check("still BRIEFING before 15 s", MissionState.phase == "BRIEFING")
	run(2.0)
	check("BRIEFING -> DESIGN after 15 s", MissionState.phase == "DESIGN")
	Net.host_set_phase("LOBBY")
	Net.host_set_phase("BRIEFING")
	Net.set_seat_ready(true)
	check("all seated players READY ends BRIEFING early", MissionState.phase == "DESIGN")

	# ---- DESIGN: an invalid design cannot go to review ----
	_msgs.clear()
	Net.call_review()
	check("incomplete design blocked with a message", MissionState.phase == "DESIGN" and "review_blocked" in _msgs)

	# ---- REVIEW: NO-GO returns to DESIGN, then all GO launches ----
	_load_preset("cautious")
	check("cautious preset is valid", MissionState.eval_result["valid"])
	Net.call_review()
	check("valid design -> REVIEW", MissionState.phase == "REVIEW")
	check("poll lists all four roles pending", MissionState.poll.size() == 4 and MissionState.poll["flight"]["state"] == "pending")
	run(0.5)
	check("bots have not answered yet (staggered)", MissionState.poll["systems"]["state"] == "pending")
	run(5.0)
	check("empty seats answered GO by themselves", MissionState.poll["systems"]["state"] == "go" and MissionState.poll["ground"]["state"] == "go")
	check("human still pending, so still REVIEW", MissionState.phase == "REVIEW" and MissionState.poll["flight"]["state"] == "pending")
	_msgs.clear()
	Net.poll_answer(false, "Orbit feels risky")
	check("any NO-GO returns to DESIGN", MissionState.phase == "DESIGN")
	check("NO-GO reason is announced", "nogo" in _msgs and MissionState.phase_payload.get("reason", "") == "Orbit feels risky")
	check("poll cleared in DESIGN", MissionState.poll.is_empty())
	Net.call_review()
	Net.apply_choice_as("", "battery", "bat_2000")   # offline allows it; on a HOST the phase check would refuse
	check("second review works", MissionState.phase == "REVIEW")
	run(5.0)
	Net.poll_answer(true, "")
	run(0.5)
	check("four GO still in REVIEW for a moment", MissionState.phase == "REVIEW")
	run(1.5)
	check("four GO -> LAUNCH", MissionState.phase == "LAUNCH")
	check("launch payload shows reliability, hides outcome", MissionState.phase_payload.has("reliability") and not MissionState.phase_payload.has("success"))
	check("demo mode: launch cannot fail", MissionState.phase_payload["can_fail"] == false)
	run(5.0)
	check("still counting down", MissionState.phase == "LAUNCH")
	run(2.0)
	check("LAUNCH -> FLIGHT", MissionState.phase == "FLIGHT")

	# ---- FLIGHT ----
	check("tokens exist after launch", MissionState.tokens["flight"].has("fuel") and MissionState.tokens["systems"].has("power"))
	check("engineer: client would only get its own tokens", MissionState.tokens_for_role("flight").size() == 1)
	check("public state has no tokens, has poll + flight status", not MissionState.public_state().has("tokens") and MissionState.public_state().has("flight_status"))
	_msgs.clear()
	Net.give_token("fuel", "systems")
	check("tokens cannot be handed over outside a crisis", "give_rejected" in _msgs)
	run(3.5)
	check("first beat started", _crises.size() == 1 and MissionState.flight_status["active"] == true)
	check("crisis event has flags", _crises[0]["event"].has("untimed") and _crises[0]["event"].has("radio_silence"))
	check("engineer crisis is timed", _crises[0]["timer"] > 0.0)
	var fuel_before: int = MissionState.tokens["flight"]["fuel"]
	Net.give_token("fuel", "systems")
	var gave_ok: bool = (fuel_before == 0) or MissionState.tokens["flight"]["fuel"] == fuel_before - 1
	check("hand-over during a crisis moves one token", gave_ok)
	_msgs.clear()
	Net.play_action("not_a_real_action")
	check("unknown action rejected", "action_rejected" in _msgs)
	Net.ping("HELP")
	check("ping is logged for everyone", MissionState.flight_status["pings"].size() == 1)
	var n0 := _results.size()
	run(31.0)
	check("crisis ends when its timer runs out", _results.size() == n0 + 1)

	# play every remaining beat; FLIGHT answers "pass" so crises end early
	var guard := 0
	while MissionState.phase == "FLIGHT" and guard < 400:
		guard += 1
		if MissionState.flight_status.get("active", false) and not MissionState.flight_status["acted"].get("flight", false):
			Net.play_action("pass")
		pm.tick(0.5)
	check("mission reaches DEBRIEF", MissionState.phase == "DEBRIEF")
	check("short mission: 3 crises + 1 opportunity = 4 beats", _crises.size() == 4)
	check("debrief report delivered once", _reports.size() == 1 and MissionState.last_report.has("lines"))
	var rep: Dictionary = MissionState.last_report
	check("report is tagged with team, scenario, design", rep["team_name"] == "Pawstronauts" and rep["scenario"] == "bagyo_watch" and rep["design"]["rocket"] == MissionState.design["rocket"])
	check("report has a limiting factor", str(rep["limiting"]) != "")

	# ---- AGAIN keeps crew and design ----
	var design_before: Dictionary = MissionState.design.duplicate(true)
	Net.host_again()
	check("Again -> DESIGN with same design", MissionState.phase == "DESIGN" and MissionState.design == design_before)
	check("Again keeps the seat", MissionState.seats["flight"] == multiplayer.get_unique_id())
	check("Again clears tokens and flight status", MissionState.tokens["flight"].is_empty() and MissionState.flight_status.is_empty())

	# ---- Cadet: open book + untimed crises ----
	_fresh("cadet", false)
	_load_preset("cautious")
	Net.host_set_phase("REVIEW")
	run(6.0)
	Net.poll_answer(true, "")
	run(3.0)
	run(7.5)
	check("cadet launch reaches FLIGHT (cannot fail)", MissionState.phase == "FLIGHT")
	check("cadet clients get everyone's tokens", MissionState.tokens_for_role("flight").size() == 4)
	run(3.5)
	# Lead round 7: players asked for a clock on every difficulty; Cadet's is 50% longer than the data's timer
	var base_t: float = float(_crises[0]["event"].get("timer_s", 25.0)) if _crises.size() == 1 else 25.0
	check("cadet crisis has a longer clock (%.0f s)" % (_crises[0]["timer"] if _crises.size() == 1 else -1.0),
		_crises.size() == 1 and absf(float(_crises[0]["timer"]) - roundf(base_t * 1.5)) < 0.01 and _crises[0]["event"]["untimed"] == false)
	var n1 := _results.size()
	run(5.0)
	check("cadet crisis does not end early by itself", _results.size() == n1)
	Net.play_action("pass")
	run(1.5)
	check("PASS from every connected player ends it", _results.size() == n1 + 1)

	# ---- launch failure -> MISSION LOST ----
	_fresh("engineer", false)
	_load_preset("cautious")
	var prob: float = MissionState.eval_result["launch_success_prob"]
	var bad_seed := 1
	while PhaseMachine.launch_roll(bad_seed) < prob:
		bad_seed += 1
	MissionState.mission_seed = bad_seed
	Net.host_set_phase("LAUNCH")
	check("engineer launch can fail", MissionState.phase_payload["can_fail"] == true)
	run(7.0)
	check("failed launch -> DEBRIEF, MISSION LOST", MissionState.phase == "DEBRIEF" and MissionState.last_report.get("mission_lost", false) == true)
	check("lost report has grade and an anomaly line", MissionState.last_report["grade"] == "LOST" and MissionState.last_report["lines"].size() >= 1)
	var good_seed := 1
	while PhaseMachine.launch_roll(good_seed) >= prob:
		good_seed += 1
	MissionState.reset_all()
	MissionState.set_difficulty("engineer")
	_load_preset("cautious")
	MissionState.mission_seed = good_seed
	Net.host_set_phase("LAUNCH")
	run(7.0)
	check("a lucky seed launches", MissionState.phase == "FLIGHT")
	Net.host_set_phase("DEBRIEF")

	# ---- seat hold and rejoin ----
	MissionState.reset_all()
	MissionState.assign_seat("systems", 7)
	pm.on_hello(7, "key-abc")
	pm.on_peer_disconnected(7)
	check("LOBBY drop frees the seat at once", MissionState.seats["systems"] == 0)
	MissionState.assign_seat("systems", 7)
	pm.on_hello(7, "key-abc")
	Net.host_set_phase("DESIGN")
	pm.on_peer_disconnected(7)
	check("DESIGN drop holds the seat", MissionState.seats["systems"] == PhaseMachine.SEAT_HELD and pm.is_held("systems"))
	check("held seat cannot be taken by someone else", not MissionState.assign_seat("systems", 9))
	run(30.0)
	pm.on_hello(9, "key-abc")
	check("same key gets the seat back", MissionState.seats["systems"] == 9 and not pm.is_held("systems"))
	pm.on_hello(11, "key-xyz")
	pm.on_peer_disconnected(9)
	run(61.0, 1.0)
	check("held seat is freed after 60 s", MissionState.seats["systems"] == 0)

	# ---- clients: tokens ride in the private view, not the public state ----
	var pub := MissionState.public_state()
	var tok_signals: Array = []
	MissionState.tokens_changed.connect(func(): tok_signals.append(1))
	MissionState.apply_sync(pub, {"valid": true, "errors": [], "tokens": {"flight": {"fuel": 2, "time": 1}}})
	check("client stores its tokens from the private view", MissionState.role_tokens("flight").get("fuel", -1) == 2 and tok_signals.size() == 1)

	print("")
	print("ALL GOOD" if _fails == 0 else "%d FAILED" % _fails)
	get_tree().quit(0 if _fails == 0 else 1)
