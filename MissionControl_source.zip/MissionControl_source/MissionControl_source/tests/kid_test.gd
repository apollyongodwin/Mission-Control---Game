# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends SceneTree
## godot --headless --path . -s res://tests/kid_test.gd   (every item must have a kid line of 10 words or fewer)
func _init() -> void:
	var db = JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json"))
	var kid = JSON.parse_string(FileAccess.get_file_as_string("res://data/kid_text.json"))
	var n: int = KidText.apply(db, kid)
	var problems := 0
	for k in kid:
		if str(kid[k]).split(" ", false).size() > 10:
			print("TOO LONG: ", k)
			problems += 1
	var sample: Dictionary = db["instruments"][3]
	print("merged ", n, " lines. sample: ", sample["name"], " -> ", KidText.kid_or_blurb(sample))
	print("kid test: %d problems" % problems)
	quit(problems)
