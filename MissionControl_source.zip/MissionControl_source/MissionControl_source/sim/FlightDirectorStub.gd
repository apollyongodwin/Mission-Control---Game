# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name FlightDirectorStub
extends RefCounted
## TEMPORARY stand-in for Dev A's sim/FlightDirector.gd, so the phase machine can be built and tested.
## It follows the SAME contract (see PhaseMachine.gd header). Delete it once Dev A's file passes the
## contract test (tests/phase_test.gd). Math follows spec 5.3 / 5.7 loosely; it is NOT the real scoring.

var tokens: Dictionary = {}          # role -> {token: int}
var _D: Dictionary = {}
var _difficulty: String = "engineer"
var _beats: Array = []
var _i: int = -1
var _current: Dictionary = {}
var _played: Array = []              # action ids played in the current crisis
var _paid: Dictionary = {}           # opportunity: token -> amount paid
var _sci_loss := 0.0
var _life_loss := 0.0
var _gain_sci := 0.0
var _points_lost := 0.0
var _gain_points := 0.0
var _lines: Array = []
var _eval: Dictionary = {}
var _design: Dictionary = {}
var pings: Array = []


func setup(design: Dictionary, eval_result: Dictionary, seed_value: int, difficulty: String, length: String) -> void:
	_D = Data.db
	_design = design.duplicate(true)
	_eval = eval_result
	_difficulty = difficulty
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var sid: String = design["scenario"]
	var crises: Array = []
	var opps: Array = []
	var decs: Array = []
	for e in _D["events"]:
		if not (sid in e.get("scenarios", [])):
			continue
		if str(design["orbit"]) in e.get("exclude_orbits", []):
			continue
		match e["kind"]:
			"crisis": crises.append(e)
			"opportunity": opps.append(e)
			"decision": decs.append(e)
	_shuffle(crises, rng)
	_shuffle(opps, rng)
	var n_crisis := 3 if length == "short" else 5
	_beats = []
	for k in mini(n_crisis, crises.size()):
		_beats.append(crises[k])
	if not opps.is_empty():
		_beats.insert(mini(2, _beats.size()), opps[0])
	if length == "full" and not decs.is_empty():
		_beats.append(decs[0])
	# tokens: eval tokens assigned to the role that owns them
	tokens = {}
	for r in Protocol.ROLES:
		tokens[r] = {}
		for t in _D["meta"]["roles"][r]["owns_tokens"]:
			tokens[r][t] = int(eval_result.get("tokens", {}).get(t, 0))


func _shuffle(a: Array, rng: RandomNumberGenerator) -> void:
	for k in range(a.size() - 1, 0, -1):
		var j := rng.randi_range(0, k)
		var tmp = a[k]
		a[k] = a[j]
		a[j] = tmp


func beat_count() -> int:
	return _beats.size()


## Returns {} when the mission has no more beats.
func next_beat() -> Dictionary:
	_i += 1
	if _i >= _beats.size():
		return {}
	_current = _beats[_i].duplicate(true)
	_played = []
	_paid = {}
	return {"index": _i, "total": _beats.size(), "kind": _current["kind"], "event": _current,
		"timer_s": float(_current.get("timer_s", 25.0))}


func play_action(role: String, action_id: String) -> Dictionary:
	if _current.is_empty() or _current["kind"] != "crisis":
		return {"ok": false, "reason": "There is no crisis right now."}
	var act: Dictionary = Data.by_id(_D["actions"], action_id)
	if act.is_empty() or act["role"] != role:
		return {"ok": false, "reason": "That action is not in your hand."}
	for a in _played:
		if a["role"] == role:
			return {"ok": false, "reason": "You already acted in this crisis."}
	for t in act["cost"]:
		if int(tokens[role].get(t, 0)) < int(act["cost"][t]):
			return {"ok": false, "reason": "You need more %s tokens." % t}
	for t in act["cost"]:
		tokens[role][t] = int(tokens[role].get(t, 0)) - int(act["cost"][t])
	_played.append({"role": role, "id": action_id})
	var se: Dictionary = act.get("side_effect", {})
	_sci_loss += -float(se.get("science_pct", 0.0))
	_life_loss += -float(se.get("lifetime_days", 0.0))
	return {"ok": true, "action": act}


## Optional: bots/empty seats. Plays the cheapest-in-tokens useful action this role can afford.
func auto_play(role: String) -> Dictionary:
	if _current.is_empty() or _current["kind"] != "crisis":
		return {"ok": false, "reason": "no crisis"}
	var best := ""
	var best_score := 0.0
	for act in _D["actions"]:
		if act["role"] != role:
			continue
		var afford := true
		for t in act["cost"]:
			if int(tokens[role].get(t, 0)) < int(act["cost"][t]):
				afford = false
		if not afford:
			continue
		var s := 0.0
		for tag in _current.get("threat", {}):
			s += float(_current["threat"][tag]) * float(act["mitigates"].get(tag, 0.0))
		if s > best_score:
			best_score = s
			best = act["id"]
	if best == "":
		return {"ok": false, "reason": "nothing useful"}
	return play_action(role, best)


func give_token(from_role: String, to_role: String, token: String) -> bool:
	if not tokens.has(from_role) or not tokens.has(to_role) or from_role == to_role:
		return false
	if int(tokens[from_role].get(token, 0)) < 1:
		return false
	tokens[from_role][token] = int(tokens[from_role][token]) - 1
	tokens[to_role][token] = int(tokens[to_role].get(token, 0)) + 1
	return true


## Opportunity: option "capture" pays what this role can toward needs. Decision: pays the option cost.
func event_choice(role: String, option_id: String) -> Dictionary:
	if _current.is_empty():
		return {"ok": false, "reason": "Nothing to choose right now."}
	if _current["kind"] == "opportunity":
		if option_id != "capture":
			return {"ok": false, "reason": "Unknown choice."}
		var needs: Dictionary = _current.get("needs", {})
		for t in needs:
			var still := int(needs[t]) - int(_paid.get(t, 0))
			var have := int(tokens[role].get(t, 0))
			var pay := mini(still, have)
			if pay > 0:
				tokens[role][t] = have - pay
				_paid[t] = int(_paid.get(t, 0)) + pay
		var done := true
		for t in needs:
			if int(_paid.get(t, 0)) < int(needs[t]):
				done = false
		return {"ok": true, "complete": done}
	if _current["kind"] == "decision":
		for o in _current.get("options", []):
			if o["id"] == option_id:
				var cost: Dictionary = o.get("cost", {})
				for t in cost:
					var owner := ""
					for r in Protocol.ROLES:
						if tokens[r].has(t):
							owner = r
					if owner == "" or int(tokens[owner][t]) < int(cost[t]):
						return {"ok": false, "reason": "The team cannot afford that."}
				for t in cost:
					for r in Protocol.ROLES:
						if tokens[r].has(t):
							tokens[r][t] = int(tokens[r][t]) - int(cost[t])
				if o.get("effect", {}).has("crisis_score"):
					_gain_points += float(o["effect"]["crisis_score"])
				_lines.append("Decision: %s." % str(o.get("label", option_id)))
				return {"ok": true, "complete": true}
	return {"ok": false, "reason": "Unknown choice."}


func record_ping(role: String, card_id: String) -> void:
	pings.append({"role": role, "card": card_id})


func resolve_current() -> Dictionary:
	if _current.is_empty():
		return {}
	var ev := _current
	var out := {"event_id": ev["id"], "kind": ev["kind"], "title": ev.get("title", ev["id"])}
	var sev_mult: float = float(_D["meta"]["difficulty"][_difficulty]["event_severity_mult"])
	if ev["kind"] == "crisis":
		var m := 0.0
		var mitig := {}
		for p in _played:
			var act: Dictionary = Data.by_id(_D["actions"], p["id"])
			for tag in act["mitigates"]:
				mitig[tag] = float(mitig.get(tag, 0.0)) + float(act["mitigates"][tag])
		for tag in ev.get("threat", {}):
			m += float(ev["threat"][tag]) * minf(1.0, float(mitig.get(tag, 0.0)))
		m = minf(1.0, m)
		var residual := 1.0 - m
		var sci := float(ev.get("base_loss", {}).get("science_pct", 0.0)) * residual * sev_mult
		var life := float(ev.get("base_loss", {}).get("lifetime_days", 0.0)) * residual * sev_mult
		var pts := float(ev.get("severity", 1)) * 25.0 * residual * sev_mult
		_sci_loss += sci
		_life_loss += life
		_points_lost += pts
		out["mitigated"] = m
		out["science_loss_pct"] = sci
		out["lifetime_loss_days"] = life
		out["points_lost"] = pts
		out["line"] = "%s: %s" % [ev.get("title", ""), str(ev.get("learn", ""))]
	elif ev["kind"] == "opportunity":
		var needs: Dictionary = ev.get("needs", {})
		var ok := true
		for t in needs:
			if int(_paid.get(t, 0)) < int(needs[t]):
				ok = false
		out["captured"] = ok
		if ok:
			_gain_sci += float(ev.get("gain", {}).get("science_pct", 0.0))
			_gain_points += 12.0
		out["line"] = "%s: %s" % [ev.get("title", ""), ("captured!" if ok else "missed this time.")]
	else:
		out["line"] = "%s: decided." % ev.get("title", "")
	_lines.append(out["line"])
	_current = {}
	return out


func final_report() -> Dictionary:
	var sci := clampf(float(_eval.get("science", {}).get("points", 0.0)) * (1.0 - _sci_loss / 100.0 + _gain_sci / 100.0), 0.0, 100.0)
	var crisis := clampf(150.0 - _points_lost + _gain_points, 0.0, 150.0)
	var total := sci * 4.0 + crisis
	return {"science_final": sci, "lifetime_final": float(_eval.get("lifetime", {}).get("days", 0.0)) - _life_loss,
		"crisis_score": crisis, "TOTAL": clampf(total, 0.0, 1000.0), "grade": "C", "medals": [], "lines": _lines.duplicate()}
