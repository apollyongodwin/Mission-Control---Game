# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name FlightDirector
extends RefCounted
## Host-only flight logic (Dev A). No UI, no networking. Never changes SimEngine.
## PART 1: seeded event deck, AUTO-RESOLVE mode, final report.
##
## Usage:
##   var fd := FlightDirector.new()
##   fd.setup(design, eval_result, seed, "engineer", "short")
##   var report: Dictionary = fd.run_auto()
##
## Roles own tokens (data meta.roles[role].owns_tokens). Every token type has exactly one
## owner role, so "the team pays" simply means "the owner role pays".

const ROLE_ORDER: Array = ["flight", "systems", "payload", "ground"]
const OPPORTUNITY_POINTS: float = 12.0
const CRISIS_POINTS_PER_SEVERITY: float = 25.0

## Data base. Left empty, it is read from the Data autoload. Tests can set fd.db = data first.
var db: Dictionary = {}
var design: Dictionary = {}
var result: Dictionary = {}
var difficulty: String = "engineer"
var length: String = "short"
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var ready_ok: bool = false

## MERGE (Lead, round 7): players said tokens were too strong. A great design still starts with at most 3 of each.
const MAX_START_TOKENS := 3
var tokens: Dictionary = {}        ## role -> {token: int}
var start_tokens: Dictionary = {}  ## copy at launch
var deck: Array = []               ## event Dictionaries in play order
var deck_index: int = 0
var current: Dictionary = {}       ## the event being played now ({} if none)
var played: Dictionary = {}        ## role -> action Dictionary, for the current crisis
var history: Array = []            ## one record per resolved event

var sum_science_loss_pct: float = 0.0
var sum_science_gain_pct: float = 0.0
var sum_lifetime_loss_days: float = 0.0
var sum_budget_loss: float = 0.0
var sum_points_lost: float = 0.0
var sum_points_gained: float = 0.0

var _sev_mult: float = 1.0
var _cap: float = 0.0
var _autonomy: int = 1
var _paid: bool = false      ## opportunity: the team has paid "needs"
var _choice: String = ""     ## decision: chosen option id

## ---- Part 2 (interactive mode)
var timer_enabled: bool = true     ## false in Cadet (no timer). The host may override it.
var radio_silence: bool = false    ## set from the difficulty in setup(); the host may set true for other levels
var deadline_left: float = 0.0     ## seconds left for the current event
var event_clock: float = 0.0       ## seconds since the current event began
var passed: Dictionary = {}        ## role -> true when that role chose to do nothing this crisis
var ping_log: Array = []           ## [{event, role, card, t}] Radio Silence pings (no effect on the maths)
const MAX_PING_LEN: int = 32


# ---------------------------------------------------------------- setup

func setup(p_design: Dictionary, p_result: Dictionary, p_seed: int, p_difficulty: String = "engineer", p_length: String = "short") -> void:
	ready_ok = false
	if db.is_empty():
		db = _load_db()
	if db.is_empty():
		push_error("FlightDirector: no data. Set fd.db = Data.db before setup().")
		return
	if not p_result.has("cost"):
		push_error("FlightDirector: eval result has no cost block (design was not evaluable).")
		return
	design = p_design.duplicate(true)
	result = p_result
	difficulty = p_difficulty
	length = p_length
	rng.seed = p_seed
	deck = []
	deck_index = 0
	current = {}
	played = {}
	history = []
	sum_science_loss_pct = 0.0
	sum_science_gain_pct = 0.0
	sum_lifetime_loss_days = 0.0
	sum_budget_loss = 0.0
	sum_points_lost = 0.0
	sum_points_gained = 0.0
	_paid = false
	_choice = ""
	var diff: Dictionary = db["meta"]["difficulty"][difficulty]
	_sev_mult = float(diff["event_severity_mult"])
	_cap = float(result["cost"]["cap"])
	_autonomy = 1
	for o in db["parts"]["obc"]:
		if o["id"] == design.get("obc", ""):
			_autonomy = int(o.get("autonomy", 1))
	_build_tokens()
	_build_deck()
	timer_enabled = difficulty != "cadet"
	radio_silence = bool(diff.get("radio_silence", false))
	passed = {}
	ping_log = []
	deadline_left = 0.0
	event_clock = 0.0
	ready_ok = true


func _load_db() -> Dictionary:
	var loop: MainLoop = Engine.get_main_loop()
	if loop is SceneTree:
		var n: Node = (loop as SceneTree).root.get_node_or_null("Data")
		if n != null:
			var d = n.get("db")
			if typeof(d) == TYPE_DICTIONARY:
				return d
	return {}


func _build_tokens() -> void:
	tokens = {}
	for role in ROLE_ORDER:
		tokens[role] = {}
		for tk in db["meta"]["roles"][role]["owns_tokens"]:
			tokens[role][tk] = mini(int(result["tokens"].get(tk, 0)), MAX_START_TOKENS)   # MERGE (Lead, round 7): token nerf
	start_tokens = tokens.duplicate(true)


func _shuffle(arr: Array) -> Array:
	var a: Array = arr.duplicate()
	for i in range(a.size() - 1, 0, -1):
		var j: int = rng.randi_range(0, i)
		var t = a[i]
		a[i] = a[j]
		a[j] = t
	return a


func _build_deck() -> void:
	var crises: Array = []
	var opps: Array = []
	var decisions: Array = []
	for e in db["events"]:
		if not (design["scenario"] in e["scenarios"]):
			continue
		if e.has("exclude_orbits") and (design["orbit"] in e["exclude_orbits"]):
			continue
		var kind: String = e["kind"]
		if kind == "crisis":
			crises.append(e)
		elif kind == "opportunity":
			opps.append(e)
		elif kind == "decision":
			decisions.append(e)
	crises = _shuffle(crises)
	opps = _shuffle(opps)
	decisions = _shuffle(decisions)
	var want_crises: int = 5 if length == "full" else 3
	var picked: Array = crises.slice(0, want_crises)
	var opp: Dictionary = opps[0] if opps.size() > 0 else {}
	var dec: Dictionary = decisions[0] if (length == "full" and decisions.size() > 0) else {}
	var opp_in: bool = false
	var dec_in: bool = false
	for i in range(picked.size()):
		deck.append(picked[i])
		if i == 1 and not opp.is_empty():
			deck.append(opp)
			opp_in = true
		if i == 3 and not dec.is_empty():
			deck.append(dec)
			dec_in = true
	if not opp.is_empty() and not opp_in:
		deck.append(opp)
	if not dec.is_empty() and not dec_in:
		deck.append(dec)


# ---------------------------------------------------------------- beats

## Moves to the next event. Returns {} when the deck is finished.
func next_beat() -> Dictionary:
	if deck_index >= deck.size():
		current = {}
		return {}
	current = deck[deck_index]
	deck_index += 1
	played = {}
	_paid = false
	_choice = ""
	passed = {}
	event_clock = 0.0
	deadline_left = float(current.get("timer_s", 30))
	return current


## Resolves the current event and records it. Returns the record (see _resolve_*).
func resolve_current() -> Dictionary:
	if current.is_empty():
		return {}
	var rec: Dictionary = {}
	var kind: String = current["kind"]
	if kind == "crisis":
		rec = _resolve_crisis(current)
	elif kind == "opportunity":
		rec = _resolve_opportunity(current)
	elif kind == "decision":
		rec = _resolve_decision(current)
	history.append(rec)
	current = {}
	return rec


# ---------------------------------------------------------------- tokens

func _can_afford(role: String, cost: Dictionary) -> bool:
	for tk in cost:
		if int(tokens[role].get(tk, 0)) < int(cost[tk]):
			return false
	return true


## The role that OWNS a token type (from the data), not whoever happens to hold it now.
func _owner_of_token(tk: String) -> String:
	for role in ROLE_ORDER:
		if tk in db["meta"]["roles"][role]["owns_tokens"]:
			return role
	return ""


## How many of one token type the whole team holds right now (tokens can be handed over).
func _pool(tk: String) -> int:
	var n: int = 0
	for role in ROLE_ORDER:
		n += int(tokens[role].get(tk, 0))
	return n


func _team_can_pay(cost: Dictionary) -> bool:
	for tk in cost:
		if _pool(tk) < int(cost[tk]):
			return false
	return true


func _team_pay(cost: Dictionary) -> void:
	for tk in cost:
		var left: int = int(cost[tk])
		var order: Array = [_owner_of_token(tk)]
		for r in ROLE_ORDER:
			if not (r in order):
				order.append(r)
		for r2 in order:
			if left <= 0:
				break
			var have: int = int(tokens[r2].get(tk, 0))
			var take: int = mini(have, left)
			if take > 0:
				tokens[r2][tk] = have - take
				left -= take


func _cost_count(cost: Dictionary) -> int:
	var n: int = 0
	for tk in cost:
		n += int(cost[tk])
	return n


# ---------------------------------------------------------------- actions

## Total of a role's action mitigation, weighted by the event's threat (the same maths as 5.3).
func _mitigation(e: Dictionary, acts: Array) -> float:
	var m: float = 0.0
	var threat: Dictionary = e.get("threat", {})
	for tag in threat:
		var total: float = 0.0
		for a in acts:
			total += float(a["mitigates"].get(tag, 0.0))
		m += float(threat[tag]) * minf(1.0, total)
	return m


func _gain_of(e: Dictionary, a: Dictionary) -> float:
	var before: float = _mitigation(e, played.values())
	var after: float = _mitigation(e, played.values() + [a])
	return after - before


## The best affordable action for a role right now ({} if nothing helps).
func best_action_for(role: String, e: Dictionary) -> Dictionary:
	var best: Dictionary = {}
	var best_gain: float = 0.0
	var best_cost: int = 0
	var best_side: float = 0.0
	for a in db["actions"]:
		if a["role"] != role:
			continue
		if not _can_afford(role, a["cost"]):
			continue
		var gain: float = _gain_of(e, a)
		if gain <= 0.001:
			continue
		var cost_n: int = _cost_count(a["cost"])
		var side: float = absf(float(a["side_effect"].get("science_pct", 0.0))) + absf(float(a["side_effect"].get("lifetime_days", 0.0)))
		var better: bool = false
		if best.is_empty():
			better = true
		elif gain > best_gain + 0.0001:
			better = true
		elif absf(gain - best_gain) <= 0.0001:
			if cost_n < best_cost or (cost_n == best_cost and side < best_side):
				better = true
		if better:
			best = a
			best_gain = gain
			best_cost = cost_n
			best_side = side
	return best


## Pays the cost and applies the side effect. Used by auto mode now, and by play_action() in Part 2.
func _apply_action(role: String, a: Dictionary) -> void:
	for tk in a["cost"]:
		tokens[role][tk] = int(tokens[role][tk]) - int(a["cost"][tk])
	played[role] = a
	var se: Dictionary = a["side_effect"]
	# negative numbers are losses; they count as losses in the final report
	sum_science_loss_pct -= float(se.get("science_pct", 0.0))
	sum_lifetime_loss_days -= float(se.get("lifetime_days", 0.0))


## AUTO-RESOLVE for the current event.
func auto_play_current() -> void:
	if current.is_empty():
		return
	var kind: String = current["kind"]
	if kind == "crisis":
		for role in ROLE_ORDER:
			var a: Dictionary = best_action_for(role, current)
			if not a.is_empty():
				_apply_action(role, a)
	elif kind == "opportunity":
		var needs: Dictionary = current.get("needs", {})
		if _team_can_pay(needs):
			_team_pay(needs)
			_paid = true
	elif kind == "decision":
		_choice = "decline"
		for opt in current["options"]:
			if opt["id"] == "accept" and _team_can_pay(opt["cost"]):
				_team_pay(opt["cost"])
				_choice = "accept"


## Plays every beat on auto and returns final_report().
func run_auto() -> Dictionary:
	while true:
		var ev: Dictionary = next_beat()
		if ev.is_empty():
			break
		auto_play_current()
		resolve_current()
	return final_report()


# ================================================================ PART 2: interactive mode

func is_role(role: String) -> bool:
	return role in ROLE_ORDER


## The actions this role may play right now: its own hand, affordable, and it has not acted yet.
func legal_actions(role: String) -> Array:
	var out: Array = []
	if current.is_empty() or str(current["kind"]) != "crisis" or not is_role(role):
		return out
	if played.has(role) or passed.has(role):
		return out
	for a in db["actions"]:
		if a["role"] == role and _can_afford(role, a["cost"]):
			out.append(a)
	return out


## One action per role per crisis. Returns {ok, reason} (and details when ok).
func play_action(role: String, action_id: String) -> Dictionary:
	if current.is_empty() or str(current["kind"]) != "crisis":
		return {"ok": false, "reason": "There is no crisis right now."}
	if not is_role(role):
		return {"ok": false, "reason": "Unknown role."}
	if timer_enabled and deadline_left <= 0.0:
		return {"ok": false, "reason": "Time is up."}
	if played.has(role) or passed.has(role):
		return {"ok": false, "reason": "You already acted in this crisis."}
	var action: Dictionary = {}
	for a in db["actions"]:
		if a["id"] == action_id:
			action = a
	if action.is_empty():
		return {"ok": false, "reason": "Unknown action."}
	if action["role"] != role:
		return {"ok": false, "reason": "That action is not in your hand."}
	if not _can_afford(role, action["cost"]):
		return {"ok": false, "reason": "You do not have the tokens for that."}
	_apply_action(role, action)
	return {"ok": true, "role": role, "action": action_id, "label": action["label"],
		"side_effect": action["side_effect"], "tokens": tokens[role].duplicate()}


## "I choose to do nothing this crisis." Lets the crisis end early when everyone has acted or passed.
func pass_turn(role: String) -> bool:
	if current.is_empty() or str(current["kind"]) != "crisis" or not is_role(role):
		return false
	if played.has(role) or passed.has(role):
		return false
	passed[role] = true
	return true


## Hand ONE token to another role. Allowed only while a crisis is active.
func give_token(from_role: String, to_role: String, token: String) -> bool:
	if current.is_empty() or str(current["kind"]) != "crisis":
		return false
	if not is_role(from_role) or not is_role(to_role) or from_role == to_role:
		return false
	if _owner_of_token(token) == "":
		return false
	if int(tokens[from_role].get(token, 0)) < 1:
		return false
	tokens[from_role][token] = int(tokens[from_role][token]) - 1
	tokens[to_role][token] = int(tokens[to_role].get(token, 0)) + 1
	return true


## Opportunity: option_id "capture" (the team pays "needs"). Decision: "accept" or "decline".
## Any role may send it. Returns {ok, reason, choice}.
func event_choice(role: String, option_id: String) -> Dictionary:
	if current.is_empty():
		return {"ok": false, "reason": "There is no event right now."}
	if not is_role(role):
		return {"ok": false, "reason": "Unknown role."}
	var kind: String = str(current["kind"])
	if kind == "opportunity":
		if option_id != "capture":
			return {"ok": false, "reason": "Use 'capture' for an opportunity."}
		if _paid:
			return {"ok": false, "reason": "Already captured."}
		var needs: Dictionary = current.get("needs", {})
		if not _team_can_pay(needs):
			return {"ok": false, "reason": "The team does not hold enough tokens."}
		_team_pay(needs)
		_paid = true
		return {"ok": true, "choice": "capture"}
	if kind == "decision":
		if _choice != "":
			return {"ok": false, "reason": "The team already chose."}
		for opt in current["options"]:
			if opt["id"] == option_id:
				if not _team_can_pay(opt["cost"]):
					return {"ok": false, "reason": "The team does not hold enough tokens."}
				_team_pay(opt["cost"])
				_choice = option_id
				return {"ok": true, "choice": option_id}
		return {"ok": false, "reason": "Unknown option."}
	return {"ok": false, "reason": "Crises use play_action()."}


## Radio Silence: log a Ping Wheel card. It has no effect on the maths.
func ping(role: String, card_id: String) -> bool:
	if current.is_empty() or not is_role(role):
		return false
	if card_id == "" or card_id.length() > MAX_PING_LEN:
		return false
	ping_log.append({"event": str(current["id"]), "role": role, "card": card_id, "t": snappedf(event_clock, 0.1)})
	return true


## True when the current event has nothing left to wait for.
func everyone_done() -> bool:
	if current.is_empty():
		return false
	var kind: String = str(current["kind"])
	if kind == "crisis":
		for role in ROLE_ORDER:
			if not (played.has(role) or passed.has(role)):
				return false
		return true
	if kind == "opportunity":
		return _paid
	return _choice != ""


## For the broadcast "who has acted" display: role -> "played" | "passed" | "waiting".
func acted_status() -> Dictionary:
	var out: Dictionary = {}
	for role in ROLE_ORDER:
		if played.has(role):
			out[role] = "played"
		elif passed.has(role):
			out[role] = "passed"
		else:
			out[role] = "waiting"
	return out


## The host calls this every frame from its _process(delta).
## Returns {} while the event is still running. When the timer runs out (or everyone has acted)
## it resolves the event and returns that event's record (the same Dictionary resolve_current() gives).
func tick(delta: float) -> Dictionary:
	if current.is_empty():
		return {}
	event_clock += delta
	if timer_enabled:
		deadline_left = maxf(0.0, deadline_left - delta)
		if deadline_left <= 0.0:
			return resolve_current()
	if everyone_done():
		return resolve_current()
	return {}


# ---------------------------------------------------------------- resolution

func _resolve_crisis(e: Dictionary) -> Dictionary:
	var acts: Array = played.values()
	var m: float = _mitigation(e, acts)
	if e.has("autonomy_reduces"):
		m = minf(1.0, m + float(e["autonomy_reduces"]) * float(_autonomy - 1))
	m = clampf(m, 0.0, 1.0)
	var residual: float = 1.0 - m
	var base: Dictionary = e.get("base_loss", {})
	var sci: float = float(base.get("science_pct", 0.0)) * residual * _sev_mult
	var life: float = float(base.get("lifetime_days", 0.0)) * residual * _sev_mult
	var bloss: float = float(base.get("budget_pct_of_cap", 0.0)) / 100.0 * _cap * residual
	var pts: float = float(e["severity"]) * CRISIS_POINTS_PER_SEVERITY * residual * _sev_mult
	sum_science_loss_pct += sci
	sum_lifetime_loss_days += life
	sum_budget_loss += bloss
	sum_points_lost += pts

	var who: Array = []
	var played_list: Array = []
	for role in ROLE_ORDER:
		if played.has(role):
			who.append("%s played '%s'" % [str(role).to_upper(), played[role]["label"]])
			played_list.append({"role": role, "action": played[role]["id"], "label": played[role]["label"]})
	var who_text: String = "Nobody played an action." if who.is_empty() else (", ".join(PackedStringArray(who)) + ".")
	var bits: Array = []
	if sci > 0.05:
		bits.append("%.1f%% of the science" % sci)
	if life > 0.5:
		bits.append("%d days of life" % int(round(life)))
	if bloss > 0.05:
		bits.append("C$%.1fM" % bloss)
	var outcome: String
	if bits.is_empty():
		outcome = "The threat was fully handled: no damage."
	else:
		outcome = "It cost %s (%d%% of the threat was blocked)." % [" and ".join(PackedStringArray(bits)), int(round(m * 100.0))]
	var line: String = "%s: %s %s %s" % [e["title"], who_text, outcome, e.get("learn", "")]
	return {
		"id": e["id"], "kind": "crisis", "title": e["title"], "played": played_list,
		"mitigation": m, "residual": residual,
		"science_loss_pct": sci, "lifetime_loss_days": life, "budget_loss": bloss, "points_lost": pts,
		"line": line,
	}


func _resolve_opportunity(e: Dictionary) -> Dictionary:
	var gain_pct: float = 0.0
	var gain_pts: float = 0.0
	var line: String
	var needs: Dictionary = e.get("needs", {})
	var needs_text: Array = []
	for tk in needs:
		needs_text.append("%s x%d" % [tk, int(needs[tk])])
	if _paid:
		gain_pct = float(e["gain"].get("science_pct", 0.0))
		gain_pts = OPPORTUNITY_POINTS
		sum_science_gain_pct += gain_pct
		sum_points_gained += gain_pts
		line = "%s: the team paid %s and captured +%d%% science. %s" % [e["title"], ", ".join(PackedStringArray(needs_text)), int(round(gain_pct)), e.get("learn", "")]
	else:
		line = "%s: the team could not pay %s, so the chance passed. %s" % [e["title"], ", ".join(PackedStringArray(needs_text)), e.get("learn", "")]
	return {
		"id": e["id"], "kind": "opportunity", "title": e["title"], "captured": _paid,
		"gain_science_pct": gain_pct, "gain_points": gain_pts, "line": line,
	}


func _resolve_decision(e: Dictionary) -> Dictionary:
	var gain_pts: float = 0.0
	var label: String = "no choice"
	for opt in e["options"]:
		if opt["id"] == _choice:
			label = opt["label"]
			gain_pts = float(opt["effect"].get("crisis_score", 0.0))
	sum_points_gained += gain_pts
	var line: String = "%s: the team chose '%s'%s. %s" % [e["title"], label, (" (+%d crisis points)" % int(round(gain_pts))) if gain_pts > 0.0 else "", e.get("learn", "")]
	return {
		"id": e["id"], "kind": "decision", "title": e["title"], "choice": _choice,
		"gain_points": gain_pts, "line": line,
	}


# ---------------------------------------------------------------- final report

func _clamp01(x: float) -> float:
	return clampf(x, 0.0, 1.0)


func _grade_for(total: float) -> String:
	if total >= 850.0:
		return "S"
	if total >= 700.0:
		return "A"
	if total >= 550.0:
		return "B"
	if total >= 400.0:
		return "C"
	return "D"


func _scenario() -> Dictionary:
	for s in db["scenarios"]:
		if s["id"] == design["scenario"]:
			return s
	return {}


func final_report() -> Dictionary:
	var C: Dictionary = db["meta"]["constants"]
	var S: Dictionary = C["score_max"]
	var T: Dictionary = C["targets"]

	# flight-adjusted numbers (spec 5.7)
	var science_final: float = clampf(float(result["science"]["points"]) * (1.0 - sum_science_loss_pct / 100.0 + sum_science_gain_pct / 100.0), 0.0, 100.0)
	var lifetime_final: float = maxf(0.0, float(result["lifetime"]["days"]) - sum_lifetime_loss_days)
	var total_cost: float = float(result["cost"]["total"]) + sum_budget_loss
	var crisis_score: float = clampf(float(S["crisis"]) - sum_points_lost + sum_points_gained, 0.0, float(S["crisis"]))

	# science and lifetime
	var life_req: float = float(result["lifetime"]["required"])
	var life_target: float = float(result["lifetime"]["target"])
	var s_sci: float = float(S["science"]) * science_final / 100.0
	var s_life: float = 0.0
	if lifetime_final >= life_req:
		s_life = float(S["lifetime"]) * _clamp01((minf(lifetime_final, life_target) - life_req) / maxf(1.0, life_target - life_req))

	# budget
	var s_budget: float = 0.0
	if total_cost <= _cap:
		s_budget = float(S["budget"]) * _clamp01((_cap - total_cost) / (0.25 * _cap))

	# margins (same five checks as evaluate, with the final cost)
	var margin_parts: Array = [
		_clamp01(float(result["power"]["margin"]) / float(T["power_margin"])),
		_clamp01(float(result["mass"]["margin"]) / float(T["mass_margin"])),
		_clamp01(float(result["data"]["margin"]) / float(T["comms_margin"])),
		_clamp01(float(result["schedule"]["float"]) / float(T["schedule_float_months"])),
		_clamp01((_cap - total_cost) / (float(T["cost_reserve_frac"]) * _cap)),
	]
	var margin_sum: float = 0.0
	var all_margins_full: bool = true
	for p in margin_parts:
		margin_sum += float(p)
		if float(p) < 0.9999:
			all_margins_full = false
	var s_margin: float = float(S["margins"]) * margin_sum / float(margin_parts.size())

	# teamwork: the four private goals
	var sc: Dictionary = _scenario()
	var covered: Dictionary = {}
	for o in sc["objectives"]:
		for iid in design["instruments"]:
			for inst in db["instruments"]:
				if inst["id"] == iid and float(inst["values"].get(o["tag"], 0)) > 0.0:
					covered[o["tag"]] = true
	var goals: Dictionary = {
		"flight": lifetime_final >= life_target,
		"systems": float(result["power"]["margin"]) >= 0.15 and float(result["mass"]["margin"]) >= 0.10,
		"payload": design["instruments"].size() >= 3 and covered.size() >= 2,
		"ground": total_cost <= 0.9 * _cap,
	}
	var goals_met: int = 0
	for r in goals:
		if goals[r]:
			goals_met += 1
	var teamwork: float = 12.5 * float(goals_met)

	var total: float = s_sci + s_life + s_budget + s_margin + crisis_score + teamwork

	# crisis bookkeeping for medals
	var crisis_count: int = 0
	var perfect: bool = true
	for h in history:
		if h["kind"] == "crisis":
			crisis_count += 1
			if float(h["residual"]) > 0.001:
				perfect = false
	perfect = perfect and crisis_count > 0

	var medals: Array = []
	if total_cost <= 0.75 * _cap:
		medals.append({"id": "frugal_flyer", "name": "Frugal Flyer"})
	if all_margins_full:
		medals.append({"id": "margin_master", "name": "Margin Master"})
	if result["science"]["synergy_hits"].size() >= 2:
		medals.append({"id": "great_minds", "name": "Great Minds"})
	if perfect:
		medals.append({"id": "perfect_pass", "name": "Perfect Pass"})
	# Part 1 has no talking in auto mode, so a perfect run on a Radio Silence difficulty counts.
	if perfect and radio_silence:
		medals.append({"id": "silent_running", "name": "Silent Running"})
	if design["scenario"] == "bagyo_watch" and design["orbit"] == "leo_tropical_600" and ("rain_gauge_relay" in design["instruments"]):
		medals.append({"id": "local_hero", "name": "Local Hero"})

	var lines: Array = []
	for h in history:
		lines.append(h["line"])

	return {
		"science_final": snappedf(science_final, 0.1),
		"lifetime_final": snappedf(lifetime_final, 1.0),
		"total_cost": snappedf(total_cost, 0.1),
		"crisis_score": snappedf(crisis_score, 0.1),
		"teamwork_score": teamwork,
		"goals_met": goals,
		"breakdown": {
			"science": snappedf(s_sci, 0.1),
			"lifetime": snappedf(s_life, 0.1),
			"budget": snappedf(s_budget, 0.1),
			"margins": snappedf(s_margin, 0.1),
			"crisis": snappedf(crisis_score, 0.1),
			"teamwork": teamwork,
		},
		"max": S,
		"total": snappedf(total, 0.1),
		"grade": _grade_for(total),
		"medals": medals,
		"what_happened": lines,
		"limiting": result["lifetime"]["limiting"],
		"events": history,
	}
