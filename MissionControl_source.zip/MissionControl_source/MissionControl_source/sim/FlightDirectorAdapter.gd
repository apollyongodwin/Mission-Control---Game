# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name FlightDirectorAdapter
extends RefCounted
## LEAD (merge glue). Wraps Dev A's sim/FlightDirector.gd so it fits the PhaseMachine contract
## (see the FLIGHT DIRECTOR CONTRACT at the top of net/PhaseMachine.gd) WITHOUT changing Dev A's file,
## so Dev A's own tests/flight_test.gd keeps passing.
##
## What it translates:
##   next_beat()      Dev A returns the bare event; PhaseMachine wants {index, total, kind, event, timer_s}
##   tick()           Dev A's tick() resolves events itself; PhaseMachine owns the timer, so it is NOT forwarded
##   auto_play(role)  bots / empty seats play their best affordable action (Dev A: best_action_for)
##   record_ping()    -> Dev A's ping()
##   event_choice()   adds "complete": true so an opportunity resolves as soon as the team pays
##   final_report()   adds the keys the debrief, broadcast and mission store read (see ReportFormat)

var fd: FlightDirector = FlightDirector.new()

## PhaseMachine reads and writes `director.tokens` (role -> {token: int}). Same Dictionary as Dev A's.
var tokens: Dictionary:
	get:
		return fd.tokens
	set(value):
		fd.tokens = value


func setup(design: Dictionary, eval_result: Dictionary, seed_value: int, difficulty: String, length: String) -> void:
	fd.db = Data.db
	fd.setup(design, eval_result, seed_value, difficulty, length)
	# PhaseMachine owns the countdown. With Dev A's own timer on, play_action() would say "Time is up"
	# because nobody calls fd.tick() (that would resolve the event a second time).
	fd.timer_enabled = false


func beat_count() -> int:
	return fd.deck.size()


func next_beat() -> Dictionary:
	var ev: Dictionary = fd.next_beat()
	if ev.is_empty():
		return {}
	return {
		"index": fd.deck_index - 1,
		"total": fd.deck.size(),
		"kind": str(ev.get("kind", "crisis")),
		"event": ev,
		"timer_s": float(ev.get("timer_s", 30.0)),
	}


func play_action(role: String, action_id: String) -> Dictionary:
	return fd.play_action(role, action_id)


func give_token(from_role: String, to_role: String, token: String) -> bool:
	return fd.give_token(from_role, to_role, token)


func event_choice(role: String, option_id: String) -> Dictionary:
	var res: Dictionary = fd.event_choice(role, option_id)
	if bool(res.get("ok", false)):
		res["complete"] = true
	return res


func resolve_current() -> Dictionary:
	return fd.resolve_current()


## A bot (or an empty seat) plays its best affordable action, like Dev A's AUTO-RESOLVE mode.
func auto_play(role: String) -> Dictionary:
	if fd.current.is_empty() or str(fd.current.get("kind", "")) != "crisis":
		return {}
	var a: Dictionary = fd.best_action_for(role, fd.current)
	if a.is_empty():
		fd.pass_turn(role)
		return {}
	return fd.play_action(role, str(a["id"]))


## LEAD (round 8): how many beats are still to come (0 = the one just resolved was the last).
func beats_left() -> int:
	return fd.deck.size() - fd.deck_index


## LEAD (round 8): can the team pay the current opportunity right now? (CHIP IN checks this before the mini-task)
func team_can_pay() -> bool:
	if fd.current.is_empty():
		return false
	return fd._team_can_pay(fd.current.get("needs", {}))


## LEAD (round 8) MISSION TWISTS. forced_id: make sure this crisis is in the deck (it replaces a random crisis).
## extra: add that many more crises from the ones not drawn. Uses Dev A's seeded rng, so Demo Mode stays repeatable.
func apply_twists(forced_id: String, extra: int) -> void:
	var pool: Array = []
	for e in fd.db["events"]:
		if str(e["kind"]) != "crisis" or not (fd.design["scenario"] in e["scenarios"]):
			continue
		if e.has("exclude_orbits") and (fd.design["orbit"] in e["exclude_orbits"]):
			continue
		pool.append(e)
	var in_deck: Array = []
	for e in fd.deck:
		in_deck.append(str(e["id"]))
	if forced_id != "" and not in_deck.has(forced_id):
		var forced: Dictionary = {}
		for e in pool:
			if str(e["id"]) == forced_id:
				forced = e
		if not forced.is_empty():
			var slots: Array = []
			for i in fd.deck.size():
				if str(fd.deck[i]["kind"]) == "crisis":
					slots.append(i)
			if not slots.is_empty():
				var at: int = slots[fd.rng.randi_range(0, slots.size() - 1)]
				in_deck.erase(str(fd.deck[at]["id"]))
				fd.deck[at] = forced
				in_deck.append(forced_id)
	for n in extra:
		var left: Array = []
		for e in pool:
			if not in_deck.has(str(e["id"])):
				left.append(e)
		if left.is_empty():
			break
		var pick: Dictionary = left[fd.rng.randi_range(0, left.size() - 1)]
		fd.deck.insert(maxi(1, fd.deck.size() - 1), pick)
		in_deck.append(str(pick["id"]))


func record_ping(role: String, card_id: String) -> void:
	fd.ping(role, card_id)


func final_report() -> Dictionary:
	return fd.final_report()
