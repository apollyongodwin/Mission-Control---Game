# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name BotCrew
extends RefCounted
## Host-only AutoCrew bots (Dev A, Part 2). No UI, no networking. Never changes SimEngine.
##
## The host (Lead) owns the clock. Each frame it calls:
##   DESIGN phase:  var out: Array = bots.tick_design(delta)   -> submit each result for that role
##   FLIGHT phase:  var out: Array = bots.tick_flight(delta, fd) -> already applied to fd; just show chatter
##
## Setup:
##   var bots := BotCrew.new()
##   bots.setup(Data.db, "bagyo_watch", ["systems", "payload", "ground"], seed)   # empty seats
##   bots.begin_design()                       # when the DESIGN phase starts
##   bots.begin_event(fd)                      # right after fd.next_beat() in FLIGHT

const ROLE_ORDER: Array = ["flight", "systems", "payload", "ground"]
const PLAY_CHANCE: float = 0.7        ## in flight a bot plays an action 70% of the time
const DESIGN_DELAY_MIN: float = 1.5   ## seconds between a bot's design choices
const DESIGN_DELAY_MAX: float = 4.0

const DESIGN_CHATTER: Dictionary = {
	"flight": ["FLIGHT bot: I will pick us an orbit.", "FLIGHT bot: this orbit should work.", "FLIGHT bot: orbit locked in."],
	"systems": ["SYSTEMS bot: choosing the hardware.", "SYSTEMS bot: watch the mass, please!", "SYSTEMS bot: power looks fine on my side."],
	"payload": ["PAYLOAD bot: science first!", "PAYLOAD bot: adding instruments.", "PAYLOAD bot: these will cover our goals."],
	"ground": ["GROUND bot: checking the budget.", "GROUND bot: rocket and antenna chosen.", "GROUND bot: stations are booked."],
}
const PASS_CHATTER: Array = ["Holding steady.", "Waiting to see how it goes.", "Nothing I can do right now."]

var db: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var scenario: String = ""
var seats: Array = []               ## roles filled by bots
var personality: Dictionary = {}    ## role -> bot_presets name (cautious, greedy, frugal, rookie)

var _design_queue: Array = []       ## [{role, category, value, at}]
var _design_clock: float = 0.0
var _plan: Dictionary = {}          ## role -> {at, plays, pick, done}
var _plan_event: String = ""
var _flight_clock: float = 0.0


## empty_roles = the seats with no human. All bots use p_personality unless you call set_personality().
func setup(p_db: Dictionary, p_scenario: String, empty_roles: Array, p_seed: int, p_personality: String = "cautious") -> void:
	db = p_db
	scenario = p_scenario
	rng.seed = p_seed
	seats = []
	personality = {}
	for r in empty_roles:
		if r in ROLE_ORDER and not (r in seats):
			seats.append(r)
			personality[r] = p_personality
	_design_queue = []
	_plan = {}


func set_personality(role: String, preset_name: String) -> void:
	if role in seats:
		personality[role] = preset_name


func has_bot(role: String) -> bool:
	return role in seats


## The preset design this bot copies from ({} if the preset does not exist).
func preset_design(role: String) -> Dictionary:
	var wanted: String = str(personality.get(role, "cautious"))
	var list: Array = db["bot_presets"].get(scenario, [])
	for p in list:
		if p["name"] == wanted:
			return p["design"]
	return {}


# ---------------------------------------------------------------- design phase

## Queues every design choice each bot owns, with short random delays.
func begin_design() -> void:
	_design_queue = []
	_design_clock = 0.0
	for role in seats:
		var d: Dictionary = preset_design(role)
		if d.is_empty():
			continue
		var t: float = 0.0
		for category in db["meta"]["roles"][role]["owns_choices"]:
			if not d.has(category):
				continue
			t += rng.randf_range(DESIGN_DELAY_MIN, DESIGN_DELAY_MAX)
			var v: Variant = d[category]
			if v is Array:
				v = (v as Array).duplicate()
			_design_queue.append({"role": role, "category": category, "value": v, "at": t})


## Returns the choices that are due now:
## [{type:"choice", role, category, value, chatter}]. The host submits each one as that role
## (same validation as a human, e.g. Net's host-side submit path).
func tick_design(delta: float) -> Array:
	_design_clock += delta
	var out: Array = []
	var keep: Array = []
	for item in _design_queue:
		if float(item["at"]) <= _design_clock:
			out.append({
				"type": "choice", "role": item["role"], "category": item["category"],
				"value": item["value"], "chatter": _pick(DESIGN_CHATTER[item["role"]]),
			})
		else:
			keep.append(item)
	_design_queue = keep
	return out


func design_pending() -> bool:
	return _design_queue.size() > 0


# ---------------------------------------------------------------- flight phase

## Call right after fd.next_beat(). Each bot decides now (seeded) when to act and whether to act at all.
func begin_event(fd: FlightDirector) -> void:
	_plan = {}
	_flight_clock = 0.0
	if fd.current.is_empty():
		return
	_plan_event = str(fd.current["id"])
	var timer: float = float(fd.current.get("timer_s", 30))
	for role in seats:
		_plan[role] = {
			"at": rng.randf_range(2.0, maxf(3.0, timer * 0.6)),
			"plays": rng.randf() < PLAY_CHANCE,
			"pick": rng.randf(),
			"done": false,
		}


## Acts for the bots whose time has come. The action is ALREADY applied to fd.
## Returns [{type:"action"|"pass"|"event_choice", role, chatter, ...}].
func tick_flight(delta: float, fd: FlightDirector) -> Array:
	var out: Array = []
	if fd.current.is_empty() or str(fd.current["id"]) != _plan_event:
		return out
	_flight_clock += delta
	for role in seats:
		if not _plan.has(role):
			continue
		var plan: Dictionary = _plan[role]
		if bool(plan["done"]) or float(plan["at"]) > _flight_clock:
			continue
		plan["done"] = true
		var kind: String = str(fd.current["kind"])
		if kind == "crisis":
			out.append(_act_crisis(role, plan, fd))
		elif kind == "opportunity":
			if bool(plan["plays"]):
				var r: Dictionary = fd.event_choice(role, "capture")
				if bool(r["ok"]):
					out.append({"type": "event_choice", "role": role, "choice": "capture",
						"chatter": "%s bot: we can afford it, going for it!" % role.to_upper()})
		else:  # decision
			var choice: String = "accept" if bool(plan["plays"]) else "decline"
			var r2: Dictionary = fd.event_choice(role, choice)
			if not bool(r2["ok"]) and choice == "accept":
				r2 = fd.event_choice(role, "decline")
				choice = "decline"
			if bool(r2["ok"]):
				out.append({"type": "event_choice", "role": role, "choice": choice,
					"chatter": "%s bot: we choose to %s." % [role.to_upper(), choice]})
	return out


func _act_crisis(role: String, plan: Dictionary, fd: FlightDirector) -> Dictionary:
	if bool(plan["plays"]):
		var legal: Array = fd.legal_actions(role)
		if legal.size() > 0:
			var idx: int = clampi(int(float(plan["pick"]) * legal.size()), 0, legal.size() - 1)
			var a: Dictionary = legal[idx]
			var res: Dictionary = fd.play_action(role, str(a["id"]))
			if bool(res["ok"]):
				return {"type": "action", "role": role, "action_id": a["id"], "label": a["label"],
					"chatter": "%s bot: %s!" % [role.to_upper(), a["label"]]}
	fd.pass_turn(role)
	return {"type": "pass", "role": role, "chatter": "%s bot: %s" % [role.to_upper(), _pick(PASS_CHATTER)]}


func _pick(lines: Array) -> String:
	return str(lines[rng.randi_range(0, lines.size() - 1)])
