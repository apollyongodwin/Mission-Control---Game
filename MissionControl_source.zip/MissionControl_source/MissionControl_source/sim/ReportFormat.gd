# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name ReportFormat
extends RefCounted
## LEAD (merge glue). One report shape for every screen.
## Dev A's final_report() and PhaseMachine's "mission lost" report use slightly different keys from what
## Dev D's Debrief / MissionStore and Dev C's broadcast read. This adds the missing keys; it never removes any.
##
##   why, lines  <- what_happened (Dev A) or lines (lost report)    Debrief "what happened and why"
##   breakdown   <- score (lost report)                             Debrief score bars
##   medals      [String] names (Debrief prints them)                Dev A sends [{id, name}]
##   medal_ids   [String] ids (MissionPatch emblems, stickers)
##   eval        {lifetime: {limiting, days}}                         Debrief "what limited your mission"
##   total       float                                                everyone


static func normalize(report: Dictionary) -> Dictionary:
	var r: Dictionary = report.duplicate(true)
	if not r.has("why"):
		r["why"] = r.get("what_happened", r.get("lines", []))
	if not r.has("lines"):
		r["lines"] = r["why"]
	if not r.has("breakdown") and r.has("score"):
		r["breakdown"] = r["score"]
	if not r.has("total"):
		r["total"] = float(r.get("TOTAL", 0.0))
	var names: Array = []
	var ids: Array = []
	for m in r.get("medals", []):
		if m is Dictionary:
			names.append(str(m.get("name", m.get("id", ""))))
			ids.append(str(m.get("id", "")))
		else:
			names.append(str(m))
			ids.append(str(m).to_snake_case())
	r["medals"] = names
	r["medal_ids"] = ids
	if not r.has("eval"):
		r["eval"] = {"lifetime": {"limiting": str(r.get("limiting", "")), "days": float(r.get("lifetime_final", 0.0))}}
	return r
