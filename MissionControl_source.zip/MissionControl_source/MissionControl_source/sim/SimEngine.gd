# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name SimEngine
extends RefCounted
## COUNTDOWN design-time math. Pure static functions: no nodes, no autoloads.
## This is a line-for-line port of reference_sim.py. If this and reference_sim.py
## disagree, reference_sim.py is right. Pass the whole data dictionary in as `D`
## (in the game: SimEngine.evaluate(Data.db, design)).


static func _find(arr: Array, id: String) -> Dictionary:
	for x in arr:
		if x["id"] == id:
			return x
	push_error("SimEngine: id not found: " + id)
	return {}


static func _light(val: float, red_below: float, amber_below: float) -> String:
	if val < red_below:
		return "red"
	if val < amber_below:
		return "amber"
	return "green"


static func evaluate(D: Dictionary, design: Dictionary, difficulty: String = "engineer") -> Dictionary:
	var C: Dictionary = D["meta"]["constants"]
	var diff: Dictionary = D["meta"]["difficulty"][difficulty]
	var sc: Dictionary = _find(D["scenarios"], design["scenario"])
	var orb: Dictionary = _find(D["orbits"], design["orbit"])
	var errors: Array = []
	if not sc["orbits"].has(design["orbit"]):
		return {"errors": ["orbit not offered in this scenario"], "valid": false}
	var oc: Dictionary = sc["orbits"][design["orbit"]]

	var P: Dictionary = D["parts"]
	var bus: Dictionary = _find(P["bus"], design["bus"])
	var panel: Dictionary = _find(P["panel"], design["panel"])
	var bat: Dictionary = _find(P["battery"], design["battery"])
	var comm: Dictionary = _find(P["comm"], design["comm"])
	var adcs: Dictionary = _find(P["adcs"], design["adcs"])
	var obc: Dictionary = _find(P["obc"], design["obc"])
	var shield: Dictionary = _find(P["shield"], design["shield"])
	var prop: Dictionary = _find(P["prop"], design["prop"])
	var rocket: Dictionary = _find(D["rockets"], design["rocket"])
	var stations: Array = []
	for sid in design["stations"]:
		stations.append(_find(D["stations"], sid))
	var instr: Array = []
	for iid in design["instruments"]:
		instr.append(_find(D["instruments"], iid))
	var rtg_n: int = int(design.get("rtg_count", 0))
	var rtg: Dictionary = D["rtg"]

	# ---- validity checks (ORDER MATTERS: it matches reference_sim.py)
	for i in instr:
		if i["scenario"] != sc["id"]:
			errors.append("instrument %s not for this scenario" % i["id"])
	var seen := {}
	var has_dup := false
	for iid in design["instruments"]:
		if seen.has(iid):
			has_dup = true
		seen[iid] = true
	if has_dup:
		errors.append("duplicate instrument")
	if instr.size() > int(bus["slots"]):
		errors.append("too many instruments for bus slots")
	var instr_mass := 0.0
	for i in instr:
		instr_mass += float(i["mass"])
	if instr_mass > float(bus["payload_capacity_kg"]):
		errors.append("instrument mass exceeds bus payload capacity")
	if int(prop["tier"]) < int(orb["requires_prop_tier"]):
		errors.append("orbit needs more propulsion")
	if rtg_n > 0 and not sc["rtg_allowed"]:
		errors.append("RTGs not allowed in this scenario")
	if rtg_n > int(rtg["max_count"]):
		errors.append("too many RTGs")
	if instr.size() == 0:
		errors.append("no instruments")
	if stations.size() == 0:
		errors.append("no ground station")

	# ---- mass
	var dry: float = float(bus["mass"]) + instr_mass + float(panel["mass"]) + rtg_n * float(rtg["mass"]) \
		+ float(bat["mass"]) + float(comm["mass"]) + float(adcs["mass"]) + float(obc["mass"]) \
		+ float(shield["mass"]) + float(prop["mass"])
	var launch_mass: float = dry * float(orb["wet_mass_factor"])
	var capacity: float = float(rocket["capacity_kg"][orb["launch_class"]])
	var mass_margin: float = (capacity - launch_mass) / capacity if capacity > 0.0 else -1.0
	if capacity <= 0.0:
		errors.append("rocket cannot reach this orbit")
	elif launch_mass > capacity:
		errors.append("spacecraft too heavy for rocket")

	# ---- power
	var load_w: float = float(bus["base_power_w"]) + float(comm["power_w"]) + float(adcs["power_w"]) + float(obc["power_w"])
	for i in instr:
		load_w += float(i["power_w"])
	var d2: float = float(orb["sun_au"]) * float(orb["sun_au"])
	var panel_bol: float = float(panel["area_m2"]) * float(panel["w_per_m2_1au"]) / d2 * float(adcs["sun_eff"])
	var rtg_bol: float = rtg_n * float(rtg["w_bol"])
	var yrs: float = float(oc["min_life_days"]) / 365.0
	var panel_eol: float = panel_bol * pow(1.0 - float(panel["deg_per_year"]), yrs)
	var rtg_eol: float = rtg_bol * pow(1.0 - float(C["rtg_deg_per_year"]), yrs)
	var sunlit_frac: float = 1.0 - float(orb["eclipse_avg_frac"])
	var gen_bol: float = panel_bol * sunlit_frac + rtg_bol
	var gen_eol: float = panel_eol * sunlit_frac + rtg_eol
	var gen_mid: float = (gen_bol + gen_eol) / 2.0
	var power_margin: float = gen_eol / load_w - 1.0
	var ecl_energy: float = maxf(0.0, load_w - rtg_eol) * float(orb["eclipse_min_worst"]) / 60.0
	var usable: float = float(bat["capacity_wh"]) * float(C["battery_dod"])
	var batt_ratio: float = 1.0 if ecl_energy == 0.0 else minf(1.0, usable / ecl_energy)
	var period: float = float(orb["period_min"])
	var sunlit_min: float = period * sunlit_frac
	var surplus_wh: float = maxf(0.0, panel_eol + rtg_eol - load_w) * sunlit_min / 60.0
	var recharge_ratio: float = 1.0 if ecl_energy == 0.0 else minf(1.0, surplus_wh / ecl_energy)
	var power_uptime: float = minf(1.0, gen_mid / load_w) * minf(batt_ratio, recharge_ratio)

	# ---- data and comms
	var gen_gb := 0.0
	for i in instr:
		gen_gb += float(i["data_gb_day"])
	gen_gb /= float(obc["compression"])
	var contact := 0.0
	for s in stations:
		if s["ranges"].has(orb["range_class"]) and s["bands"].has(comm["band"]):
			contact += float(s["contact_min_day"][orb["contact_class"]]) * float(s["weather_factor"])
	contact = minf(contact, float(orb["max_contact_min_day"]))
	var rate: float = float(comm["rates_mbps"][orb["range_class"]])
	var point_ok_comm: bool = float(adcs["pointing_deg"]) <= float(comm["point_req_deg"])
	var rate_eff: float = rate * (1.0 if point_ok_comm else float(C["comm_pointing_fail_factor"]))
	var down_gb: float = rate_eff * contact * float(C["mbps_min_to_gb"])
	var data_ratio: float
	var comms_margin: float
	var buffer_days: float
	if sc["data_model"] == "burst":
		var burst_gb: float = gen_gb * float(oc["burst_days"])
		var stored_ratio: float = minf(1.0, float(obc["storage_gb"]) / burst_gb) if burst_gb > 0.0 else 1.0
		var time_ratio: float
		if down_gb <= 0.0:
			time_ratio = 0.0
		else:
			var need_days: float = burst_gb * stored_ratio / down_gb
			time_ratio = minf(1.0, float(oc["window_days"]) / need_days) if need_days > 0.0 else 1.0
		data_ratio = stored_ratio * time_ratio
		comms_margin = (down_gb * float(oc["window_days"])) / burst_gb - 1.0 if burst_gb > 0.0 else 9.0
		buffer_days = float(obc["storage_gb"]) / maxf(gen_gb, 1e-9)
	else:
		data_ratio = 1.0 if gen_gb == 0.0 else minf(1.0, down_gb / gen_gb)
		comms_margin = (down_gb / gen_gb - 1.0) if gen_gb > 0.0 else 9.0
		buffer_days = float(obc["storage_gb"]) / maxf(gen_gb, 1e-9)

	# ---- lifetime
	var drag_life: float = 99999.0 if float(orb["natural_life_days"]) >= 99999.0 else float(orb["natural_life_days"]) * float(prop["life_mult"])
	var rad_tol: float = float(obc["rad_tol_krad"]) + float(shield["rad_bonus_krad"])
	var rad_life: float = 99999.0 if float(orb["dose_krad_yr"]) <= 0.0 else rad_tol / float(orb["dose_krad_yr"]) * 365.0
	var deg_eff := 0.0
	var tot: float = panel_bol * sunlit_frac + rtg_bol
	if tot > 0.0:
		deg_eff = (panel_bol * sunlit_frac * float(panel["deg_per_year"]) + rtg_bol * float(C["rtg_deg_per_year"])) / tot
	var power_life: float
	if gen_bol > load_w and deg_eff > 0.0:
		power_life = log(load_w / gen_bol) / log(1.0 - deg_eff) * 365.0
	else:
		power_life = 99999.0
	var dod: float = ecl_energy / float(bat["capacity_wh"])
	var bat_life: float = 99999.0 if dod <= 0.35 else (2500.0 if dod <= 0.5 else 900.0)
	var lifetime: float = minf(minf(drag_life, rad_life), minf(power_life, bat_life))
	# limiting factor: first minimum in this order, strict "<" like Python's min()
	var limiting := "drag"
	var lim_val := drag_life
	if rad_life < lim_val:
		limiting = "radiation"
		lim_val = rad_life
	if power_life < lim_val:
		limiting = "solar_fade"
		lim_val = power_life
	if bat_life < lim_val:
		limiting = "battery"
		lim_val = bat_life
	var life_factor: float = minf(1.0, lifetime / float(oc["min_life_days"]))

	# ---- science
	var present := {}
	for iid in design["instruments"]:
		present[iid] = true
	var obj_results: Array = []
	var sci_raw := 0.0
	for o in sc["objectives"]:
		var raw := 0.0
		for i in instr:
			var v: float = float(i["values"].get(o["tag"], 0))
			if v == 0.0:
				continue
			var f := 1.0
			if i["weather_blocked_tags"].has(o["tag"]):
				f *= float(sc["cloud_factor"])
			if i["sun_dependent"]:
				f *= float(orb["lighting"])
			if float(adcs["pointing_deg"]) > float(i["point_req_deg"]):
				f *= float(C["pointing_fail_factor"])
			if i["requires_deep_rate_mbps"] != null and rate < float(i["requires_deep_rate_mbps"]):
				f *= 0.0
			raw += v * f
		var cov: float = float(oc["coverage"].get(o["tag"], 0))
		var ach: float = float(o["weight"]) * minf(1.0, raw * cov / float(o["sat"]))
		obj_results.append({"tag": o["tag"], "achieved": ach, "max": o["weight"]})
		sci_raw += ach
	var bonus := 0.0
	var hits: Array = []
	for s in sc["synergies"]:
		if present.has(s["a"]) and present.has(s["b"]):
			bonus += float(s["bonus"])
			hits.append(str(s["a"]) + "+" + str(s["b"]))
	bonus = minf(bonus, float(C["synergy_bonus_cap"]))
	var science: float = minf(100.0, (sci_raw + bonus) * power_uptime * data_ratio * life_factor)

	# ---- cost
	var hw: float = float(bus["cost"]) + float(panel["cost"]) + rtg_n * float(rtg["cost"]) + float(bat["cost"]) \
		+ float(comm["cost"]) + float(adcs["cost"]) + float(obc["cost"]) + float(shield["cost"]) + float(prop["cost"])
	for i in instr:
		hw += float(i["cost"])
	var hw_total: float = hw * (1.0 + float(C["integration_overhead"]))
	var gs_setup := 0.0
	var gs_ops := 0.0
	for s in stations:
		gs_setup += float(s["setup_cost"])
		gs_ops += float(s["ops_cost_per_year"])
	var ops: float = (float(bus["ops_cost_per_year"]) + gs_ops) * yrs
	var total: float = hw_total + float(rocket["cost"]) + gs_setup + ops
	var cap: float = float(sc["budget_cap"]) * float(diff["budget_mult"])
	if total > cap:
		errors.append("over budget")

	# ---- schedule
	var dev_max: float = maxf(float(bus["dev_months"]), float(panel["dev_months"]))
	for v in [comm["dev_months"], adcs["dev_months"], obc["dev_months"], shield["dev_months"], prop["dev_months"], rocket["lead_time_months"]]:
		dev_max = maxf(dev_max, float(v))
	for i in instr:
		dev_max = maxf(dev_max, float(i["dev_months"]))
	if rtg_n > 0:
		dev_max = maxf(dev_max, float(rtg["dev_months"]))
	var dev_months: int = int(dev_max) + int(C["integration_months_base"]) + ceili(instr.size() / 2.0)
	var float_months: int = int(sc["deadline_months"]) - dev_months
	if float_months < 0:
		errors.append("misses the launch window")

	# ---- scoring (pre-flight)
	var S: Dictionary = C["score_max"]
	var T: Dictionary = C["targets"]
	var life_capped: float = minf(lifetime, float(oc["target_life_days"]))
	var s_sci: float = float(S["science"]) * science / 100.0
	var s_life := 0.0
	if lifetime >= float(oc["min_life_days"]):
		s_life = float(S["life" + "time"]) * clampf((life_capped - float(oc["min_life_days"])) / maxf(1.0, float(oc["target_life_days"]) - float(oc["min_life_days"])), 0.0, 1.0)
	var s_budget := 0.0
	if total <= cap:
		s_budget = float(S["budget"]) * clampf((cap - total) / (0.25 * cap), 0.0, 1.0)
	var margins: Array = [
		clampf(power_margin / float(T["power_margin"]), 0.0, 1.0),
		clampf(mass_margin / float(T["mass_margin"]), 0.0, 1.0),
		clampf(comms_margin / float(T["comms_margin"]), 0.0, 1.0),
		clampf(float_months / float(T["schedule_float_months"]), 0.0, 1.0),
		clampf((cap - total) / (float(T["cost_reserve_frac"]) * cap), 0.0, 1.0),
	]
	var msum := 0.0
	for m in margins:
		msum += float(m)
	var s_margin: float = float(S["margins"]) * msum / float(margins.size())
	var pre_score: float = s_sci + s_life + s_budget + s_margin

	# ---- tokens for flight
	var tokens := {
		"power": int(minf(5.0, maxf(0.0, floorf(power_margin / 0.10)))),
		"data": int(minf(5.0, maxf(0.0, floorf(buffer_days / 2.0)))),
		"budget": int(minf(5.0, maxf(0.0, floorf((cap - total) / (0.05 * cap))))),
		"comms": int(minf(5.0, maxf(0.0, floorf(comms_margin / 0.25)))),
		"fuel": int(minf(5.0, float(int(prop["tier"])) + maxf(0.0, floorf(mass_margin / 0.10)))),
		"time": int(minf(5.0, maxf(0.0, floorf(float_months / 2.0)))),
	}

	# ---- review lights
	var lights := {
		"mass": _light(mass_margin, 0.0, float(T["mass_margin"])),
		"power": "red",
		"budget": _light((cap - total) / cap, 0.0, float(T["cost_reserve_frac"])),
		"data": _light(comms_margin, 0.0, float(T["comms_margin"])),
		"comms": _light(comms_margin, 0.0, float(T["comms_margin"])),
		"time": _light(float_months, 0.0, float(T["schedule_float_months"])),
		"lifetime": "red" if lifetime < float(oc["min_life_days"]) else ("amber" if lifetime < float(oc["target_life_days"]) else "green"),
	}
	if power_uptime >= 0.999 or power_margin >= 0.0:
		lights["power"] = _light(power_margin, 0.0, float(T["power_margin"]))
	if batt_ratio < 1.0:
		lights["power"] = "red"

	return {
		"valid": errors.size() == 0, "errors": errors, "lights": lights, "tokens": tokens,
		"mass": {"dry": snappedf(dry, 0.1), "launch": snappedf(launch_mass, 0.1), "capacity": capacity, "margin": snappedf(mass_margin, 0.001)},
		"power": {"load_w": snappedf(load_w, 0.1), "gen_bol_w": snappedf(gen_bol, 0.1), "gen_eol_w": snappedf(gen_eol, 0.1),
			"margin": snappedf(power_margin, 0.001), "eclipse_wh_needed": snappedf(ecl_energy, 0.1), "battery_usable_wh": usable,
			"battery_ratio": snappedf(batt_ratio, 0.001), "recharge_ratio": snappedf(recharge_ratio, 0.001), "uptime": snappedf(power_uptime, 0.001)},
		"data": {"generated_gb_day": snappedf(gen_gb, 0.01), "downlink_gb_day": snappedf(down_gb, 0.01), "contact_min_day": snappedf(contact, 0.1),
			"rate_mbps_eff": snappedf(rate_eff, 0.001), "ratio": snappedf(data_ratio, 0.001), "margin": snappedf(comms_margin, 0.001), "buffer_days": snappedf(buffer_days, 0.1)},
		"lifetime": {"days": snappedf(minf(lifetime, 99999.0), 1.0), "limiting": limiting, "required": oc["min_life_days"], "target": oc["target_life_days"]},
		"cost": {"hardware": snappedf(hw_total, 0.1), "launch": rocket["cost"], "ground_setup": gs_setup, "ops": snappedf(ops, 0.1),
			"total": snappedf(total, 0.1), "cap": snappedf(cap, 0.1)},
		"schedule": {"dev_months": dev_months, "deadline": sc["deadline_months"], "float": float_months},
		"science": {"points": snappedf(science, 0.01), "raw": snappedf(sci_raw, 0.01), "synergy": bonus, "objectives": obj_results, "synergy_hits": hits},
		"score": {"science": snappedf(s_sci, 0.1), "lifetime": snappedf(s_life, 0.1), "budget": snappedf(s_budget, 0.1),
			"margins": snappedf(s_margin, 0.1), "pre_total": snappedf(pre_score, 0.1), "pre_max": 800},
		"launch_success_prob": rocket["reliability"],
	}


## Filters an evaluate() result down to what one role is allowed to see.
## Cadet difficulty (private_info = false) shows everyone everything.
## Send ONLY this to a client, never the full result (privacy is enforced on the host).
static func role_view(D: Dictionary, result: Dictionary, role: String, difficulty: String = "engineer") -> Dictionary:
	var view := {"valid": result["valid"], "errors": result["errors"]}
	if not result.has("lights"):
		return view
	view["lights"] = result["lights"]
	var open_book: bool = not D["meta"]["difficulty"][difficulty]["private_info"]
	var priv := {}
	if open_book or role == "flight":
		priv["lifetime"] = result["lifetime"]
		priv["schedule"] = result["schedule"]
		priv["objectives"] = result["science"]["objectives"]
	if open_book or role == "systems":
		priv["mass_dry"] = result["mass"]["dry"]
		priv["power"] = result["power"]
	if open_book or role == "payload":
		priv["data_generated_gb_day"] = result["data"]["generated_gb_day"]
		priv["science"] = result["science"]
	if open_book or role == "ground":
		priv["cost"] = result["cost"]
		priv["rocket_capacity"] = result["mass"]["capacity"]
		priv["launch_mass_margin"] = result["mass"]["margin"]
		priv["downlink_gb_day"] = result["data"]["downlink_gb_day"]
		priv["contact_min_day"] = result["data"]["contact_min_day"]
	view["private"] = priv
	return view


## Turns evaluate()["errors"] into friendly lines plus the roles who should fix them.
## Returns [{"text": String, "roles": Array}]. Text contains no secret numbers.
static func review_messages(result: Dictionary) -> Array:
	var out: Array = []
	for e in result.get("errors", []):
		var text := str(e).capitalize()
		var roles: Array = ["flight", "systems", "payload", "ground"]
		var s := str(e)
		if s.begins_with("instrument ") and s.ends_with("not for this scenario"):
			text = "An instrument you picked does not belong to this mission."
			roles = ["payload"]
		elif s == "duplicate instrument":
			text = "The same instrument was chosen twice."
			roles = ["payload"]
		elif s == "too many instruments for bus slots":
			text = "Too many instruments for this spacecraft bus."
			roles = ["payload", "systems"]
		elif s == "instrument mass exceeds bus payload capacity":
			text = "The instruments are too heavy for this bus."
			roles = ["payload", "systems"]
		elif s == "orbit needs more propulsion":
			text = "This orbit needs a stronger propulsion system."
			roles = ["systems", "flight"]
		elif s == "rocket cannot reach this orbit":
			text = "This rocket cannot reach that orbit."
			roles = ["ground", "flight"]
		elif s == "spacecraft too heavy for rocket":
			text = "The spacecraft is too heavy for the rocket."
			roles = ["ground", "systems"]
		elif s == "over budget":
			text = "The mission is over budget."
			roles = ["ground", "flight", "systems", "payload"]
		elif s == "misses the launch window":
			text = "The spacecraft cannot be built in time for the launch window."
			roles = ["ground", "systems"]
		elif s == "RTGs not allowed in this scenario" or s == "too many RTGs":
			text = "The nuclear power choice is not allowed here."
			roles = ["systems"]
		elif s == "no instruments":
			text = "The spacecraft has no instruments."
			roles = ["payload"]
		elif s == "no ground station":
			text = "Nobody is listening: pick a ground station."
			roles = ["ground"]
		elif s == "orbit not offered in this scenario":
			text = "That orbit is not offered in this mission."
			roles = ["flight"]
		out.append({"text": text, "roles": roles})
	return out


# ======================================================================
# AUTOPILOT and "FIX IT FOR ME" (UX_GUIDE.md sections 3 and 4)
# ======================================================================

const CATEGORY_LABELS := {
	"bus": "Body", "panel": "Solar wings", "battery": "Battery", "comm": "Antenna", "adcs": "Pointing",
	"obc": "Computer", "shield": "Shield", "prop": "Engines", "rocket": "Rocket", "stations": "Ground station",
	"instruments": "Instrument", "rtg_count": "Nuclear battery",
}


static func _sorted_by_cost(arr: Array) -> Array:
	var out: Array = arr.duplicate()
	out.sort_custom(func(a, b): return float(a["cost"]) < float(b["cost"]))
	return out


## Fills any missing design keys with plain defaults so evaluate() can run on a half-finished design.
static func _with_defaults(d: Dictionary) -> Dictionary:
	var out: Dictionary = d.duplicate(true)
	var defaults := {"bus": "bus_mini", "panel": "si_6", "battery": "bat_800", "comm": "x_band_steer", "adcs": "adcs_basic",
		"obc": "obc_basic", "shield": "shield_none", "prop": "prop_none", "rocket": "workhorse"}
	for k in defaults:
		if not out.has(k) or str(out[k]) == "":
			out[k] = defaults[k]
	if not out.has("rtg_count"):
		out["rtg_count"] = 0
	if not out.has("stations") or out["stations"].is_empty():
		out["stations"] = ["iligan_gs"]
	if not out.has("instruments"):
		out["instruments"] = []
	return out


## Autopilot. `keys` chooses what to fill: any of "adcs", "prop", "power" (power = panel + battery + rtg_count).
## Returns {"design": Dictionary, "notes": [{"key", "id", "text"}]}; notes become the small "Autopilot chose..." chips.
## Order matters: pointing and engines first, because power depends on them.
static func autofill(D: Dictionary, design: Dictionary, keys: Array = ["adcs", "prop"]) -> Dictionary:
	var d: Dictionary = _with_defaults(design)
	var notes: Array = []
	var P: Dictionary = D["parts"]
	var sc: Dictionary = _find(D["scenarios"], d["scenario"])
	var orb: Dictionary = _find(D["orbits"], d["orbit"])
	var oc: Dictionary = sc["orbits"].get(d["orbit"], {})
	var T: Dictionary = D["meta"]["constants"]["targets"]

	if keys.has("adcs"):
		var need_deg := 1000.0
		var who := ""
		for iid in d["instruments"]:
			var ins: Dictionary = _find(D["instruments"], iid)
			if float(ins["point_req_deg"]) < need_deg:
				need_deg = float(ins["point_req_deg"])
				who = str(ins["name"])
		var comm: Dictionary = _find(P["comm"], d["comm"])
		if float(comm["point_req_deg"]) < need_deg:
			need_deg = float(comm["point_req_deg"])
			who = str(comm["name"])
		var pick: Dictionary = {}
		for a in _sorted_by_cost(P["adcs"]):
			if float(a["pointing_deg"]) <= need_deg:
				pick = a
				break
		if pick.is_empty():
			pick = P["adcs"][0]
			for a in P["adcs"]:
				if float(a["pointing_deg"]) < float(pick["pointing_deg"]):
					pick = a
		d["adcs"] = pick["id"]
		var why := "Cheap pointing is enough for your gadgets."
		if who != "" and float(pick["pointing_deg"]) <= 0.1:
			why = "%s needs steady aim." % who
		elif who != "" and float(pick["pointing_deg"]) < 5.0:
			why = "%s needs steadier aim than basic pointing." % who
		notes.append({"key": "adcs", "id": pick["id"], "text": "Autopilot chose %s. %s" % [pick["name"], why]})

	if keys.has("prop"):
		var natural: float = float(orb["natural_life_days"])
		var min_life: float = float(oc.get("min_life_days", 0))
		var pick_p: Dictionary = {}
		for p in _sorted_by_cost(P["prop"]):
			if int(p["tier"]) < int(orb["requires_prop_tier"]):
				continue
			if natural < 99999.0 and natural * float(p["life_mult"]) < min_life:
				continue
			pick_p = p
			break
		if pick_p.is_empty():
			pick_p = P["prop"][P["prop"].size() - 1]
		d["prop"] = pick_p["id"]
		var why_p := "No engines needed in this orbit."
		if int(orb["requires_prop_tier"]) > 0:
			why_p = "This orbit needs engines to get in and stay put."
		elif natural < 99999.0:
			why_p = "Air drag would pull you down in about %d months, so thrusters keep you up." % int(natural / 30.4)
		notes.append({"key": "prop", "id": pick_p["id"], "text": "Autopilot chose %s. %s" % [pick_p["name"], why_p]})

	if keys.has("power"):
		var rtg: Dictionary = D["rtg"]
		var rtg_opts: Array = [0]
		if sc["rtg_allowed"]:
			rtg_opts = [0, 1, 2, 3]
		var best: Dictionary = {}
		var best_cost := INF
		var best_mass := INF
		var fallback: Dictionary = {}
		var fb_uptime := -1.0
		for n in rtg_opts:
			for pnl in P["panel"]:
				if float(pnl["area_m2"]) == 0.0 and n == 0:
					continue
				for bat in P["battery"]:
					var t: Dictionary = d.duplicate(true)
					t["panel"] = pnl["id"]
					t["battery"] = bat["id"]
					t["rtg_count"] = n
					var r: Dictionary = evaluate(D, t, "engineer")
					if not r.has("power"):
						continue
					var cost: float = float(pnl["cost"]) + float(bat["cost"]) + n * float(rtg["cost"])
					var mass: float = float(pnl["mass"]) + float(bat["mass"]) + n * float(rtg["mass"])
					var up: float = float(r["power"]["uptime"])
					if float(r["power"]["margin"]) >= float(T["power_margin"]) and float(r["power"]["battery_ratio"]) >= 1.0 and float(r["power"]["recharge_ratio"]) >= 1.0:
						if cost < best_cost or (is_equal_approx(cost, best_cost) and mass < best_mass):
							best = t
							best_cost = cost
							best_mass = mass
					elif up > fb_uptime:
						fb_uptime = up
						fallback = t
		var chosen: Dictionary = best if not best.is_empty() else fallback
		if not chosen.is_empty():
			d["panel"] = chosen["panel"]
			d["battery"] = chosen["battery"]
			d["rtg_count"] = chosen["rtg_count"]
			var why_w := "Sun power for your gadgets, plus a battery for the shadows."
			if int(chosen["rtg_count"]) > 0:
				why_w = "Far from the Sun, a nuclear battery beats solar wings."
			if best.is_empty():
				why_w = "This is the most power we can offer. You may need fewer gadgets."
			notes.append({"key": "power", "id": str(chosen["panel"]) + "+" + str(chosen["battery"]), "text": "Autopilot chose %s with %s. %s" % [
				_find(P["panel"], chosen["panel"])["name"], _find(P["battery"], chosen["battery"])["name"], why_w]})
	return {"design": d, "notes": notes}


static func _badness(r: Dictionary) -> float:
	if not r.has("lights"):
		return 1000.0
	var b := float(r["errors"].size()) * 10.0
	for k in r["lights"]:
		var l: String = r["lights"][k]
		if l == "red":
			b += 3.0
		elif l == "amber":
			b += 1.0
	return b


static func _item_name(D: Dictionary, key: String, value) -> String:
	if key == "rocket":
		return str(_find(D["rockets"], str(value)).get("name", value))
	if key == "stations":
		return str(_find(D["stations"], str(value)).get("name", value))
	if key == "instruments":
		return str(_find(D["instruments"], str(value)).get("name", value))
	if key == "rtg_count":
		return "%d nuclear batter%s" % [int(value), "y" if int(value) == 1 else "ies"]
	if D["parts"].has(key):
		return str(_find(D["parts"][key], str(value)).get("name", value))
	return str(value)


static func _owner_of(D: Dictionary, key: String) -> String:
	for role in D["meta"]["roles"]:
		if D["meta"]["roles"][role]["owns_choices"].has(key):
			return role
	return ""


## Applies a fix returned by suggest_fix() and returns the new design (keep the old one for Undo).
static func apply_fix(design: Dictionary, fix: Dictionary) -> Dictionary:
	var d: Dictionary = design.duplicate(true)
	var key: String = fix["key"]
	match str(fix["op"]):
		"set":
			d[key] = fix["value"]
		"add":
			if not d[key].has(fix["value"]):
				d[key].append(fix["value"])
		"remove":
			d[key].erase(fix["value"])
	return d


## "Fix it for me": tries every single-step change (one swap, one added station, one removed station or instrument)
## and returns the one that most improves the design, or {} if nothing helps. FLIGHT's orbit is never changed.
## Returns {"key","op","value","label","why","owner_role"}.
static func suggest_fix(D: Dictionary, design: Dictionary, difficulty: String = "engineer") -> Dictionary:
	var current: Dictionary = evaluate(D, design, difficulty)
	var base_bad: float = _badness(current)
	if base_bad == 0.0 or not current.has("lights"):
		return {}
	var cands: Array = []
	var P: Dictionary = D["parts"]
	for key in ["bus", "panel", "battery", "comm", "adcs", "obc", "shield", "prop"]:
		for opt in P[key]:
			if opt["id"] != design[key]:
				cands.append({"key": key, "op": "set", "value": opt["id"]})
	for r in D["rockets"]:
		if r["id"] != design["rocket"] and r["id"] != "super_heavy":
			cands.append({"key": "rocket", "op": "set", "value": r["id"]})
	var sc: Dictionary = _find(D["scenarios"], design["scenario"])
	if sc["rtg_allowed"]:
		for n in [0, 1, 2, 3]:
			if n != int(design.get("rtg_count", 0)):
				cands.append({"key": "rtg_count", "op": "set", "value": n})
	for s in D["stations"]:
		if design["stations"].has(s["id"]):
			if design["stations"].size() > 1:
				cands.append({"key": "stations", "op": "remove", "value": s["id"]})
		else:
			cands.append({"key": "stations", "op": "add", "value": s["id"]})
	if design["instruments"].size() > 1:
		for iid in design["instruments"]:
			cands.append({"key": "instruments", "op": "remove", "value": iid})
	var best: Dictionary = {}
	var best_bad := base_bad
	var best_cost := INF
	for c in cands:
		var r: Dictionary = evaluate(D, apply_fix(design, c), difficulty)
		var b: float = _badness(r)
		var cost: float = float(r["cost"]["total"]) if r.has("cost") else 9999.0
		# prefer the biggest improvement; on a tie prefer the cheaper design (a fix should be modest, not a splurge)
		if b < best_bad or (is_equal_approx(b, best_bad) and b < base_bad and cost < best_cost):
			best = c
			best_bad = b
			best_cost = cost
	if best.is_empty():
		return {}
	var key: String = best["key"]
	var verb := "Change"
	if best["op"] == "add":
		verb = "Add"
	elif best["op"] == "remove":
		verb = "Remove"
	var reason := "That turns a warning light around."
	var msgs: Array = review_messages(current)
	if not msgs.is_empty():
		reason = str(msgs[0]["text"])
	var label: String = "%s %s: %s" % [verb, CATEGORY_LABELS.get(key, key), _item_name(D, key, best["value"])]
	best["label"] = label
	best["why"] = reason
	best["owner_role"] = _owner_of(D, key)
	return best
