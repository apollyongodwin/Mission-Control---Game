# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name KidText
extends RefCounted
## Merges data/kid_text.json (id -> short kid-friendly line) into the main data dictionary as item["kid"].
## Non-coders edit kid_text.json only. If an id has no kid line, UI code falls back to "blurb" (see kid_or_blurb).


static func apply(db: Dictionary, kid: Dictionary) -> int:
	var count := 0
	var lists: Array = []
	for k in ["orbits", "rockets", "stations", "instruments", "scenarios", "actions", "events"]:
		lists.append(db[k])
	for cat in db["parts"]:
		lists.append(db["parts"][cat])
	lists.append([db["rtg"]])
	for lst in lists:
		for item in lst:
			if kid.has(item["id"]):
				item["kid"] = kid[item["id"]]
				count += 1
	return count


## What to show in Cadet (kid text) vs Engineer (blurb). Safe if kid text is missing.
static func kid_or_blurb(item: Dictionary) -> String:
	if item.has("kid"):
		return str(item["kid"])
	return str(item.get("blurb", ""))
