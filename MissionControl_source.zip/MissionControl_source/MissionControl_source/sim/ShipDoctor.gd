# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name ShipDoctor
extends RefCounted
## LEAD (round 8). Turns the numbers into SPECIFIC advice for the Commander ("Tell GROUND: add the Perth station,
## Mindanao can't hear the Moon"), and explains the science score. Pure and static: reads SimEngine.evaluate's
## result (with the budget adjustments from MissionState) and the data. It never changes the design.
##
##   ShipDoctor.diagnose(D, design, result)  -> [{light, roles, say, why}]   most urgent first
##   ShipDoctor.science(D, design, result)   -> {points, objectives: [{label, got, max}], leaks: [String]}
##   ShipDoctor.station_status(D, design)    -> [{id, name, ok, why}]  can each ground station hear the ship?


static func _find(arr: Array, id: String) -> Dictionary:
	for x in arr:
		if str(x["id"]) == id:
			return x
	return {}


static func _part(D: Dictionary, cat: String, id) -> Dictionary:
	return _find(D["parts"][cat], str(id))


static func _role_name(D: Dictionary, role: String) -> String:
	return str(D["meta"]["roles"].get(role, {}).get("name", role.to_upper()))


static func _orbit_conf(D: Dictionary, design: Dictionary) -> Dictionary:
	var sc: Dictionary = _find(D["scenarios"], str(design["scenario"]))
	return sc.get("orbits", {}).get(str(design["orbit"]), {})


# ======================================================================
# Ground stations: who can hear the ship?
# ======================================================================

static func station_hears(D: Dictionary, design: Dictionary, st: Dictionary) -> String:
	## "" when this station can talk to the ship, otherwise the plain reason why not.
	var orb: Dictionary = _find(D["orbits"], str(design["orbit"]))
	var comm: Dictionary = _part(D, "comm", design["comm"])
	if orb.is_empty() or comm.is_empty():
		return "pick an orbit and an antenna first"
	var range_names := {"leo": "low orbits", "geo": "geostationary", "lunar": "the Moon", "deep": "deep space"}
	if not (st["ranges"] as Array).has(orb["range_class"]):
		return "too far: it can't reach %s" % str(range_names.get(orb["range_class"], orb["range_class"]))
	if not (st["bands"] as Array).has(comm["band"]):
		return "it has no %s receiver for your antenna" % str(comm["band"]).to_upper()
	if float(st["contact_min_day"].get(orb["contact_class"], 0)) <= 0.0:
		return "this orbit never passes over it"
	return ""


static func station_status(D: Dictionary, design: Dictionary) -> Array:
	var out: Array = []
	var orb: Dictionary = _find(D["orbits"], str(design.get("orbit", "")))
	for st in D["stations"]:
		var why: String = station_hears(D, design, st)
		var mins: float = 0.0
		if why == "" and not orb.is_empty():
			mins = float(st["contact_min_day"].get(orb["contact_class"], 0)) * float(st.get("weather_factor", 1.0))
		out.append({"id": str(st["id"]), "name": str(st["name"]), "ok": why == "", "why": why, "minutes": mins,
			"picked": (design.get("stations", []) as Array).has(st["id"])})
	return out


static func _good_stations(D: Dictionary, design: Dictionary) -> Array:
	var ok: Array = []
	for s in station_status(D, design):
		if bool(s["ok"]) and not bool(s["picked"]):
			ok.append(s)
	ok.sort_custom(func(a, b): return float(a["minutes"]) > float(b["minutes"]))
	return ok


# ======================================================================
# Diagnosis
# ======================================================================

static func diagnose(D: Dictionary, design: Dictionary, r: Dictionary) -> Array:
	var out: Array = []
	if not r.has("lights"):
		return [{"light": "orbit", "roles": ["flight"], "say": "FLIGHT: pick an orbit this mission offers.", "why": ""}]
	var errs: Array = r.get("errors", [])
	var lights: Dictionary = r["lights"]
	var bus: Dictionary = _part(D, "bus", design["bus"])
	var orb: Dictionary = _find(D["orbits"], str(design["orbit"]))
	var rocket: Dictionary = _find(D["rockets"], str(design["rocket"]))
	var comm: Dictionary = _part(D, "comm", design["comm"])
	var adcs: Dictionary = _part(D, "adcs", design["adcs"])

	# 1. nothing to fly / nobody listening
	if errs.has("no instruments"):
		out.append({"light": "data", "roles": ["payload"], "say": "Tell PAYLOAD: add instruments, one for each mission goal.",
			"why": "With no instruments the ship does no science at all."})
	if errs.has("no ground station"):
		var good: Array = _good_stations(D, design)
		var names: Array = []
		for g in good.slice(0, 2):
			names.append(str(g["name"]).get_slice(" (", 0))
		out.append({"light": "comms", "roles": ["ground"],
			"say": "Tell GROUND: add a ground station%s." % ((": " + " or ".join(names)) if not names.is_empty() else ""),
			"why": "Nobody on Earth is listening, so no data comes home."})

	# 2. the body is too small for the instruments
	if errs.has("too many instruments for bus slots") or errs.has("instrument mass exceeds bus payload capacity"):
		var imass := 0.0
		var heavy: Dictionary = {}
		for iid in design["instruments"]:
			var ins: Dictionary = _find(D["instruments"], str(iid))
			imass += float(ins.get("mass", 0))
			if heavy.is_empty() or float(ins.get("mass", 0)) > float(heavy["mass"]):
				heavy = ins
		out.append({"light": "mass", "roles": ["systems", "payload"],
			"say": "Tell SYSTEMS: a bigger body, OR tell PAYLOAD: drop the %s (%d kg)." % [str(heavy.get("name", "heaviest instrument")), int(heavy.get("mass", 0))],
			"why": "Instruments: %d of %d slots, %d kg of %d kg the body can carry." % [(design["instruments"] as Array).size(), int(bus.get("slots", 0)), int(imass), int(bus.get("payload_capacity_kg", 0))]})

	# 3. engines
	if errs.has("orbit needs more propulsion"):
		var need: int = int(orb.get("requires_prop_tier", 0))
		var pick: Dictionary = {}
		for p in D["parts"]["prop"]:
			if int(p["tier"]) >= need and (pick.is_empty() or float(p["cost"]) < float(pick["cost"])):
				pick = p
		out.append({"light": "lifetime", "roles": ["flight"], "say": "Tell FLIGHT: pick the %s." % str(pick.get("name", "a bigger engine")),
			"why": "%s needs a stronger engine to get there and stay there." % str(orb.get("name", "This orbit"))})

	# 4. rocket
	if errs.has("rocket cannot reach this orbit") or errs.has("spacecraft too heavy for rocket"):
		var lm: float = float(r["mass"]["launch"])
		var fits: Dictionary = {}
		for rk in D["rockets"]:
			if float(rk["capacity_kg"].get(orb["launch_class"], 0)) >= lm * 1.05 and (fits.is_empty() or float(rk["cost"]) < float(fits["cost"])):
				fits = rk
		var cap: float = float(rocket["capacity_kg"].get(orb["launch_class"], 0))
		out.append({"light": "mass", "roles": ["ground", "systems"],
			"say": "Tell GROUND: pick the %s." % str(fits.get("name", "a bigger rocket")) if not fits.is_empty() else "Tell SYSTEMS: make the ship lighter.",
			"why": ("The %s can't reach this orbit at all." % str(rocket["name"])) if cap <= 0.0 else
				("Ship weighs %d kg at launch, the %s lifts only %d kg to this orbit." % [int(lm), str(rocket["name"]), int(cap)])})

	# 5. money
	if errs.has("over budget"):
		var over: float = float(r["cost"]["total"]) - float(r["cost"]["cap"])
		var lm2: float = float(r["mass"]["launch"])
		var cheaper: Dictionary = {}
		for rk in D["rockets"]:
			if float(rk["cost"]) < float(rocket["cost"]) and float(rk["capacity_kg"].get(orb["launch_class"], 0)) >= lm2 * 1.05:
				if cheaper.is_empty() or float(rk["cost"]) < float(cheaper["cost"]):
					cheaper = rk
		var pricey: Dictionary = {}
		for iid in design["instruments"]:
			var ins2: Dictionary = _find(D["instruments"], str(iid))
			if pricey.is_empty() or float(ins2["cost"]) > float(pricey["cost"]):
				pricey = ins2
		var say := "Tell GROUND: switch to the %s (saves C$%d M)." % [str(cheaper["name"]), int(float(rocket["cost"]) - float(cheaper["cost"]))] if not cheaper.is_empty() \
			else "Tell PAYLOAD: drop the %s (C$%d M)." % [str(pricey.get("name", "priciest instrument")), int(float(pricey.get("cost", 0)) * 1.15)]
		out.append({"light": "budget", "roles": ["ground"] if not cheaper.is_empty() else ["payload"], "say": say,
			"why": "C$%d M over budget. The rocket alone costs C$%d M." % [int(ceil(over)), int(rocket["cost"])]})

	# 6. schedule
	if errs.has("misses the launch window") or str(lights.get("time", "")) == "red":
		var slow: Array = _slowest(D, design)
		out.append({"light": "time", "roles": [str(slow[2])],
			"say": "Tell %s: swap the %s for a quicker one." % [_role_name(D, str(slow[2])), str(slow[0])],
			"why": "Building takes %d months, the deadline is %d. The %s alone takes %d months." % [int(r["schedule"]["dev_months"]), int(r["schedule"]["deadline"]), str(slow[0]), int(slow[1])]})

	# 7. red lights that are not errors
	if str(lights.get("power", "")) == "red":
		var p: Dictionary = r["power"]
		var how := "Tell SYSTEMS: bigger solar wings."
		if float(p.get("battery_ratio", 1.0)) < 1.0:
			how = "Tell SYSTEMS: a bigger battery (it runs flat in the shadow)."
		out.append({"light": "power", "roles": ["systems"], "say": how,
			"why": "The ship needs %d W; the panels give %d W when old. The battery covers %d%% of the darkest shadow." % [int(p["load_w"]), int(p["gen_eol_w"]), int(round(float(p.get("battery_ratio", 1.0)) * 100.0))]})
	if str(lights.get("comms", "")) == "red" or str(lights.get("data", "")) == "red":
		out.append_array(_comms_advice(D, design, r, comm, adcs))
	if str(lights.get("lifetime", "")) == "red":
		out.append(_life_advice(D, design, r))
	if str(lights.get("mass", "")) == "red" and not errs.has("spacecraft too heavy for rocket"):
		out.append({"light": "mass", "roles": ["ground", "systems"], "say": "Tell GROUND: a rocket with more lift, or SYSTEMS: lighter parts.",
			"why": "There is no spare lift left on the rocket."})
	# one piece of advice per light (the first, most urgent one wins)
	var seen: Dictionary = {}
	var uniq: Array = []
	for a in out:
		if seen.has(str(a["light"])):
			continue
		seen[str(a["light"])] = true
		uniq.append(a)
	out = uniq
	# 8. amber: nice to fix
	if out.is_empty():
		for k in ["power", "mass", "comms", "budget", "time", "lifetime"]:
			if str(lights.get(k, "")) == "amber":
				out.append({"light": k, "roles": [], "say": "%s is yellow: it works, but there is little spare." % str(ResourceStrip.NAMES.get(k, k)),
					"why": "Spare margin turns into tokens for the crises. More spare = more tokens."})
				break
	return out


static func _comms_advice(D: Dictionary, design: Dictionary, r: Dictionary, comm: Dictionary, adcs: Dictionary) -> Array:
	var d: Dictionary = r["data"]
	var gen: float = float(d["generated_gb_day"])
	var down: float = float(d["downlink_gb_day"])
	var orb: Dictionary = _find(D["orbits"], str(design["orbit"]))
	var why := "The ship makes %d GB of data a day but can only send %d GB home (%d minutes of contact a day)." % [int(round(gen)), int(round(down)), int(d["contact_min_day"])]
	# no station can hear it?
	var hearing: Array = []
	var deaf: Array = []
	for s in station_status(D, design):
		if bool(s["picked"]):
			if bool(s["ok"]):
				hearing.append(s)
			else:
				deaf.append(s)
	if hearing.is_empty():
		var good: Array = _good_stations(D, design)
		var first_deaf: String = ("%s: %s." % [str(deaf[0]["name"]).get_slice(" (", 0).get_slice(" [", 0), str(deaf[0]["why"])]) if not deaf.is_empty() else ""
		if good.is_empty():
			return [{"light": "comms", "roles": ["ground"], "say": "Tell GROUND: change the antenna, no station can hear the %s." % str(comm.get("name", "antenna")),
				"why": first_deaf}]
		return [{"light": "comms", "roles": ["ground"], "say": "Tell GROUND: add the %s." % str(good[0]["name"]).get_slice(" (", 0).get_slice(" [", 0),
			"why": "None of your stations can hear the ship. " + first_deaf}]
	if float(adcs.get("pointing_deg", 0)) > float(comm.get("point_req_deg", 90)):
		return [{"light": "comms", "roles": ["flight"], "say": "Tell FLIGHT: steadier pointing (reaction wheels) so the antenna can aim.",
			"why": "The %s needs aiming to %s degrees; the ship only holds %s degrees." % [str(comm["name"]), str(comm["point_req_deg"]), str(adcs["pointing_deg"])]}]
	# faster antenna that some picked station can hear
	var faster: Dictionary = {}
	for c in D["parts"]["comm"]:
		if float(c["rates_mbps"].get(orb["range_class"], 0)) <= float(comm["rates_mbps"].get(orb["range_class"], 0)) * 1.5:
			continue
		for s in D["stations"]:
			if (design["stations"] as Array).has(s["id"]) and (s["bands"] as Array).has(c["band"]):
				if faster.is_empty() or float(c["cost"]) < float(faster["cost"]):
					faster = c
	var out: Array = []
	var good2: Array = _good_stations(D, design)
	if not faster.is_empty():
		out.append({"light": "comms", "roles": ["ground"], "say": "Tell GROUND: a faster antenna, the %s." % str(faster["name"]), "why": why})
	elif not good2.is_empty():
		out.append({"light": "comms", "roles": ["ground"], "say": "Tell GROUND: add the %s for more contact time." % str(good2[0]["name"]).get_slice(" (", 0).get_slice(" [", 0), "why": why})
	else:
		out.append({"light": "comms", "roles": ["systems", "payload"], "say": "Tell SYSTEMS: a computer that squeezes data, or PAYLOAD: fewer data-hungry instruments.", "why": why})
	return out


static func _life_advice(D: Dictionary, design: Dictionary, r: Dictionary) -> Dictionary:
	var lim: String = str(r["lifetime"]["limiting"])
	var days: int = int(r["lifetime"]["days"])
	var need: int = int(r["lifetime"]["required"])
	var why := "The ship lasts about %d days, the contract needs %d." % [days, need]
	match lim:
		"drag":
			return {"light": "lifetime", "roles": ["flight"], "say": "Tell FLIGHT: add engines (cold-gas thrusters are enough) or pick a higher orbit.", "why": why + " Air drag pulls it down."}
		"radiation":
			return {"light": "lifetime", "roles": ["systems"], "say": "Tell SYSTEMS: add shielding or a radiation-hardened computer.", "why": why + " Radiation wears out the computer."}
		"solar_fade":
			return {"light": "lifetime", "roles": ["systems"], "say": "Tell SYSTEMS: bigger (or multi-junction) solar wings.", "why": why + " The panels fade until they can't power the ship."}
		"battery":
			return {"light": "lifetime", "roles": ["systems"], "say": "Tell SYSTEMS: a bigger battery, so it isn't drained so deep every orbit.", "why": why + " Deep battery drains wear it out."}
	return {"light": "lifetime", "roles": ["flight", "systems"], "say": "Ask FLIGHT and SYSTEMS what wears the ship out.", "why": why}


static func _slowest(D: Dictionary, design: Dictionary) -> Array:
	## [name, months, owner role]
	var best: Array = ["", -1.0, "systems"]
	for cat in ["bus", "panel", "comm", "adcs", "obc", "shield", "prop"]:
		var p: Dictionary = _part(D, cat, design[cat])
		if float(p.get("dev_months", 0)) > float(best[1]):
			best = [str(p["name"]), float(p["dev_months"]), SimEngine._owner_of(D, cat)]
	var rk: Dictionary = _find(D["rockets"], str(design["rocket"]))
	if float(rk.get("lead_time_months", 0)) > float(best[1]):
		best = [str(rk["name"]), float(rk["lead_time_months"]), "ground"]
	for iid in design["instruments"]:
		var ins: Dictionary = _find(D["instruments"], str(iid))
		if float(ins.get("dev_months", 0)) > float(best[1]):
			best = [str(ins["name"]), float(ins["dev_months"]), "payload"]
	return best


# ======================================================================
# Science: why is it what it is?
# ======================================================================

static func science(D: Dictionary, design: Dictionary, r: Dictionary) -> Dictionary:
	if not r.has("science"):
		return {"points": 0.0, "objectives": [], "leaks": ["Pick the parts first."]}
	var sc: Dictionary = _find(D["scenarios"], str(design["scenario"]))
	var oc: Dictionary = _orbit_conf(D, design)
	var objs: Array = []
	var leaks: Array = []
	var by_tag := {}
	for o in sc["objectives"]:
		by_tag[str(o["tag"])] = o
	for res in r["science"]["objectives"]:
		var o: Dictionary = by_tag.get(str(res["tag"]), {})
		objs.append({"tag": str(res["tag"]), "label": str(o.get("label", res["tag"])), "got": float(res["achieved"]), "max": float(res["max"])})
		if float(res["achieved"]) <= 0.01:
			leaks.append("No instrument helps \"%s\" (%d points missing)." % [str(o.get("label", res["tag"])), int(res["max"])])
		elif float(res["achieved"]) < float(res["max"]) * 0.6:
			leaks.append("\"%s\" is only %d of %d: add another instrument for it." % [str(o.get("label", res["tag"])), int(round(float(res["achieved"]))), int(res["max"])])
	var raw: float = float(r["science"]["raw"]) + float(r["science"]["synergy"])
	var up: float = float(r["power"]["uptime"])
	var dr: float = float(r["data"]["ratio"])
	var lf: float = minf(1.0, float(r["lifetime"]["days"]) / maxf(1.0, float(r["lifetime"]["required"])))
	# the multipliers hurt the most, so they go first (worst first)
	var mult: Array = []
	if up < 0.99:
		mult.append([up, "Power runs short: only %d%% of the science happens (SYSTEMS: more power)." % int(round(up * 100.0))])
	if dr < 0.99:
		mult.append([dr, "Only %d%% of the data gets home (GROUND: faster antenna or more stations)." % int(round(dr * 100.0))])
	if lf < 0.99:
		mult.append([lf, "The ship dies early: only %d%% of the mission happens." % int(round(lf * 100.0))])
	mult.sort_custom(func(a, b): return float(a[0]) < float(b[0]))
	for i in mult.size():
		leaks.insert(i, str(mult[i][1]))
	# per-instrument penalties
	var orb: Dictionary = _find(D["orbits"], str(design["orbit"]))
	var adcs: Dictionary = _part(D, "adcs", design["adcs"])
	for iid in design["instruments"]:
		var ins: Dictionary = _find(D["instruments"], str(iid))
		if ins.is_empty():
			continue
		if float(adcs.get("pointing_deg", 0)) > float(ins.get("point_req_deg", 90)):
			leaks.append("The %s needs steadier pointing (FLIGHT: reaction wheels): it works at 35%%." % str(ins["name"]))
		if not (ins.get("weather_blocked_tags", []) as Array).is_empty() and float(sc.get("cloud_factor", 1.0)) < 1.0:
			leaks.append("Clouds hide the ground from the %s: its flood maps work at %d%%." % [str(ins["name"]), int(float(sc["cloud_factor"]) * 100.0)])
		if bool(ins.get("sun_dependent", false)) and float(orb.get("lighting", 1.0)) < 0.8:
			leaks.append("The %s needs sunlight; this orbit's low sun gives it %d%%." % [str(ins["name"]), int(float(orb["lighting"]) * 100.0)])
	return {"points": float(r["science"]["points"]), "raw": raw, "uptime": up, "data_ratio": dr, "life_factor": lf,
		"objectives": objs, "leaks": leaks, "coverage": oc.get("coverage", {})}


# ======================================================================
# LEAD (round 9) TEAM INFO everybody may see: built only from the DESIGN (public) and the data file (every laptop
# has it), never from the host's secret numbers. So it works on crew laptops too.
# ======================================================================

const SHORT_GOAL := {
	"typhoon_track": "storms", "flood_map": "floods", "rain_wind": "rain & wind",
	"relay_service": "relay", "ice_mapping": "ice", "navigation": "navigation",
	"magnetosphere": "magnetic field", "atmosphere": "atmosphere", "moons": "moons", "gravity": "gravity",
}


static func short_goal(tag: String, label: String = "") -> String:
	return str(SHORT_GOAL.get(tag, label if label != "" else tag))


## "GREAT" / "good" / "a little" / "" for a 0..1 amount.
static func word(frac: float) -> String:
	if frac >= 0.5:
		return "GREAT"
	if frac >= 0.25:
		return "good"
	if frac > 0.0:
		return "a little"
	return ""


## How much ONE instrument fills each goal in the chosen orbit (0..1 per goal), with the same penalties as
## SimEngine.evaluate (clouds, low sun, wobbly pointing, no deep-space radio). Not multiplied by power/data/life.
static func inst_fit(D: Dictionary, design: Dictionary, ins: Dictionary) -> Dictionary:
	var out := {}
	var sc: Dictionary = _find(D["scenarios"], str(design.get("scenario", "")))
	var oc: Dictionary = sc.get("orbits", {}).get(str(design.get("orbit", "")), {})
	var orb: Dictionary = _find(D["orbits"], str(design.get("orbit", "")))
	var adcs: Dictionary = _part(D, "adcs", design.get("adcs", ""))
	var comm: Dictionary = _part(D, "comm", design.get("comm", ""))
	var C: Dictionary = D["meta"]["constants"]
	for o in sc.get("objectives", []):
		var tag: String = str(o["tag"])
		var v: float = float(ins.get("values", {}).get(tag, 0))
		if v <= 0.0:
			continue
		var f := 1.0
		if (ins.get("weather_blocked_tags", []) as Array).has(tag):
			f *= float(sc.get("cloud_factor", 1.0))
		if bool(ins.get("sun_dependent", false)):
			f *= float(orb.get("lighting", 1.0))
		if not adcs.is_empty() and float(adcs.get("pointing_deg", 0)) > float(ins.get("point_req_deg", 90)):
			f *= float(C["pointing_fail_factor"])
		if ins.get("requires_deep_rate_mbps") != null and not comm.is_empty() and not orb.is_empty():
			if float(comm["rates_mbps"].get(orb["range_class"], 0)) < float(ins["requires_deep_rate_mbps"]):
				f = 0.0
		out[tag] = v * f * float(oc.get("coverage", {}).get(tag, 0)) / maxf(1.0, float(o["sat"]))
	return out


## Every mission goal: how full it is with the chosen instruments in the chosen orbit, and how well the orbit sees it.
## [{tag, label, short, weight, fill 0..1, seen 0..1}]
static func goal_fill(D: Dictionary, design: Dictionary) -> Array:
	var sc: Dictionary = _find(D["scenarios"], str(design.get("scenario", "")))
	var oc: Dictionary = sc.get("orbits", {}).get(str(design.get("orbit", "")), {})
	var sums := {}
	for iid in design.get("instruments", []):
		var ins: Dictionary = _find(D["instruments"], str(iid))
		var fit: Dictionary = inst_fit(D, design, ins)
		for t in fit:
			sums[t] = float(sums.get(t, 0.0)) + float(fit[t])
	var out: Array = []
	for o in sc.get("objectives", []):
		var tag: String = str(o["tag"])
		out.append({"tag": tag, "label": str(o["label"]), "short": short_goal(tag, str(o["label"])), "weight": int(o["weight"]),
			"fill": minf(1.0, float(sums.get(tag, 0.0))), "seen": float(oc.get("coverage", {}).get(tag, 0.0))})
	return out


## One short line per crew member: what they have picked so far (names only, no numbers).
static func team_lines(D: Dictionary, design: Dictionary) -> Dictionary:
	var out := {}
	for role in ["flight", "systems", "payload", "ground"]:
		var bits: Array = []
		for cat in D["meta"]["roles"][role]["owns_choices"]:
			var v = design.get(cat)
			if cat == "rtg_count":
				if int(v if v != null else 0) > 0:
					bits.append(SimEngine._item_name(D, "rtg_count", v))
				continue
			if v is Array:
				if (v as Array).is_empty():
					bits.append("no %s yet" % ("instruments" if cat == "instruments" else "ground station"))
				for x in v:
					bits.append(SimEngine._item_name(D, str(cat), x).get_slice(" (", 0).get_slice(" [", 0))
			elif cat == "orbit":
				bits.append(str(_find(D["orbits"], str(v)).get("name", v)))
			elif v != null:
				bits.append(SimEngine._item_name(D, str(cat), v).get_slice(" (", 0))
		out[role] = ", ".join(bits)
	return out


## LEAD (round 9): up to 3 plain hints for the whole crew, from the public design only.
static func team_hints(D: Dictionary, design: Dictionary) -> Array:
	var out: Array = []
	var adcs: Dictionary = _part(D, "adcs", design.get("adcs", ""))
	var shaky: Array = []
	for iid in design.get("instruments", []):
		var ins: Dictionary = _find(D["instruments"], str(iid))
		if not adcs.is_empty() and float(adcs.get("pointing_deg", 0)) > float(ins.get("point_req_deg", 90)):
			shaky.append(str(ins.get("name", iid)).get_slice(" (", 0))
	if not shaky.is_empty():
		out.append("FLIGHT: steadier pointing! The %s only works at 35%% with wobbly aim." % " and ".join(shaky.slice(0, 2)))
	for g in goal_fill(D, design):
		if float(g["fill"]) <= 0.01 and not (design.get("instruments", []) as Array).is_empty():
			out.append("PAYLOAD: nothing helps %s yet (%d points waiting)." % [g["short"], int(g["weight"])])
		elif float(g["seen"]) < 0.4 and float(g["fill"]) < 0.5:
			out.append("This orbit hardly sees %s. FLIGHT and PAYLOAD: talk about it!" % g["short"])
	if (design.get("instruments", []) as Array).is_empty():
		out.append("PAYLOAD: add instruments. Pick ones that help the biggest goals.")
	return out.slice(0, 3)
