# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Autoload "MissionState": the one shared picture of the mission.
##
## HOST (and offline single-process): AUTHORITATIVE. Holds the full evaluate() result in `eval_result`.
## CLIENT: holds only a FILTERED copy. `view` is the role_view() the host sent for this client's role.
## Clients NEVER get `eval_result`.
##
## Read-only for UI code. Change things through Net (Net.submit_choice, Net.request_seat, ...)
## or, on the host only, through the setters below (lobby settings, phase changes).
##
## Signals fire on every peer, so UI code can listen without caring if it runs on host or client:
##   design_changed   the design OR the lights/numbers (`view`) changed
##   phase_changed    the phase string changed (see Protocol.PHASES)
##   seats_changed    a seat was taken/freed, or a READY flag changed
##   tokens_changed   tokens changed (filled in by the flight module later)
##   settings_changed scenario, difficulty, mission length, demo mode or team name changed

signal design_changed
signal phase_changed(phase: String)
signal seats_changed
signal tokens_changed
signal settings_changed
signal poll_changed            # launch poll (GO / NO-GO lights) changed
signal clock_changed          # LEAD (round 7): the build clock ticked a whole second, or investors cut the budget
signal commander_changed     # LEAD (round 4): Commander mode, OK/SWAP marks or the Commander's GO changed
signal flight_status_changed   # who has acted, pings, beat number, Radio Silence flag changed
signal lives_changed           # LEAD (round 8): the crew lost (or gained) a life

const DEMO_SEED := 2026

## role -> peer id (0 = empty seat, -1 is reserved for AutoCrew bots)
var seats: Dictionary = {}
## role -> bool (READY button in the lobby / briefing)
var seat_ready: Dictionary = {}

var scenario_id: String = "bagyo_watch"
## UX_GUIDE rule 10: the first run is Cadet, so that is the default. The host lobby can change it.
var difficulty: String = "cadet"
var mission_length: String = "short"   # "short" or "full"
var demo_mode: bool = false
var team_name: String = "Pawstronauts"
var mission_seed: int = 0              # host only; never sent to clients
var phase: String = "LOBBY"
var phase_payload: Dictionary = {}

## The design Dictionary, exactly the shape in spec section 3.
var design: Dictionary = {}
## role -> {token: count}. Filled by the flight module (Part 2). Clients only ever get their own role.
var tokens: Dictionary = {}

## Which role THIS process plays ("" on the host in a networked game, and for spectators).
var local_role: String = ""

## HOST / OFFLINE ONLY: the full SimEngine.evaluate() result. Never send this to a client.
var eval_result: Dictionary = {}
## What THIS process may show: valid, errors, lights and a "private" dictionary (SimEngine.role_view).
## Host (networked): the public view (lights only in Engineer/Flight Director; everything in Cadet).
## Offline: the view for local_role, or everything if no role is set (handy when testing panels alone).
var view: Dictionary = {}

## Launch poll, public to everyone: role -> {state: "pending"|"go"|"nogo", reason: String}. Empty outside REVIEW.
var poll: Dictionary = {}
## Public flight info: {active, beat, total, kind, event_id, title, acted{role:bool}, pings[{role,card}], radio_silence, untimed}
var flight_status: Dictionary = {}
## LEAD (round 4) COMMANDER MODE. The host laptop is played by the Commander: a private screen with the handbook,
## the budget and the ship health. The crew cannot see whether their picks are right; the Commander marks them.
var commander_mode: bool = true
## design category -> "swap" (flagged by the Commander; cleared when the crew changes that part). Public.
var commander_marks: Dictionary = {}
## The Commander's own GO in the launch poll. Public.
var commander_go: bool = false
## LEAD (round 7) BUILD CLOCK. Seconds left to design (-1 = no clock), and money investors pulled for taking too long.
## Both public. The cut lowers the budget cap AFTER SimEngine.evaluate (SimEngine's formulas are untouched).
var design_left: int = -1
var budget_penalty: float = 0.0
## HOST ONLY, never synced: true while a human Commander screen is open (headless hosts and tests skip the Commander GO).
var commander_present: bool = false

## LEAD (round 8) LIVES: a mistake in a crisis costs a life (Cadet 3, Engineer 2, Flight Director 1). 0 = mission lost.
## Public. -1 = not flying yet.
var lives: int = -1
var lives_max: int = -1
## LEAD (round 8) BUILD TIME, chosen in the lobby (seconds). Cadet gets a little extra. Public.
var build_seconds: int = 180
## LEAD (round 8) MISSION TWISTS: the twist ids rolled for this mission (meta.twists). Public, so everyone can read them.
var twists: Array = []
var twists_on: bool = true

## The last debrief report (host and clients), set before the DEBRIEF phase arrives.
var last_report: Dictionary = {}


func _ready() -> void:
	# Intentionally empty: Net (loaded after this autoload) calls reset_all() in its own _ready,
	# because reset_all() needs Net to exist.
	pass


# ----------------------------------------------------------------------
# Resetting / defaults
# ----------------------------------------------------------------------

## A plain starting design. It is intentionally incomplete (no instruments, no ground station)
## so the review lights show real work to do.
func make_default_design(sid: String) -> Dictionary:
	var first_orbit := ""
	if not Data.db.is_empty():
		var sc: Dictionary = Data.scenario(sid)
		if sc.has("orbits") and not sc["orbits"].is_empty():
			first_orbit = str(sc["orbits"].keys()[0])
	return {
		"scenario": sid, "orbit": first_orbit,
		"bus": "bus_mini", "panel": "si_6", "rtg_count": 0, "battery": "bat_800",
		"comm": "x_band_steer", "adcs": "adcs_basic", "obc": "obc_basic",
		"shield": "shield_none", "prop": "prop_none",
		"rocket": "workhorse", "stations": [], "instruments": [],
	}


## Fresh mission. Keeps nothing except the setting values (scenario, difficulty, ...).
## clear_seats = false keeps the crew in their seats ("Again!" with the same crew).
func reset_all(clear_seats: bool = true) -> void:
	if clear_seats or seats.is_empty():
		seats = {}
		seat_ready = {}
		for r in Protocol.ROLES:
			seats[r] = 0
			seat_ready[r] = false
	else:
		for r in Protocol.ROLES:
			seat_ready[r] = false
	tokens = {}
	for r in Protocol.ROLES:
		tokens[r] = {}
	poll = {}
	flight_status = {}
	last_report = {}
	commander_marks = {}
	commander_go = false
	design_left = -1
	budget_penalty = 0.0
	lives = -1
	lives_max = -1
	twists = []
	phase = "LOBBY"
	phase_payload = {}
	_roll_seed()
	design = make_default_design(scenario_id)
	_update_local_role(false)
	if Net.mode != Net.Mode.CLIENT:
		reevaluate(false)
	seats_changed.emit()
	settings_changed.emit()
	tokens_changed.emit()
	phase_changed.emit(phase)
	design_changed.emit()


func _roll_seed() -> void:
	mission_seed = DEMO_SEED if demo_mode else (randi() % 999999) + 1


# ----------------------------------------------------------------------
# Evaluating (host / offline only)
# ----------------------------------------------------------------------

## Re-runs SimEngine.evaluate on the current design and refreshes `view`. Host/offline only.
func reevaluate(announce: bool = true) -> void:
	if Data.db.is_empty() or Net.mode == Net.Mode.CLIENT:
		return
	eval_result = SimEngine.evaluate(Data.db, design, difficulty)
	_apply_budget_penalty(eval_result)
	view = _own_view()
	if announce:
		design_changed.emit()


## The filtered view for ONE role, built from the full result. This is the ONLY thing the host
## may send to a client (Net uses this). A role of "" gives the public view.
func view_for_role(role: String) -> Dictionary:
	if eval_result.is_empty():
		return {"valid": false, "errors": []}
	return SimEngine.role_view(Data.db, eval_result, role, difficulty)


func _own_view() -> Dictionary:
	if eval_result.is_empty():
		return {"valid": false, "errors": []}
	if Net.mode == Net.Mode.OFFLINE and local_role == "":
		# no role chosen while testing a panel alone: show everything (same as Cadet)
		return SimEngine.role_view(Data.db, eval_result, "", "cadet")
	return view_for_role(local_role)


# ----------------------------------------------------------------------
# Design changes (host / offline only; Net validates first)
# ----------------------------------------------------------------------

## Stores one design value and re-evaluates. Call only AFTER Protocol.validate_choice() said OK.
func set_choice(category: String, value: Variant) -> void:
	var v: Variant = Protocol.normalize_choice(category, value)
	if design.has(category) and design[category] == v:
		return
	design[category] = v
	var cleared := false
	if commander_marks.has(category):
		commander_marks.erase(category)   # round 5: the crew changed a flagged part: the flag clears (Commander can flag again)
		cleared = true
	if v is Array:   # round 7: per-item flags ("instruments:sar_c") clear when that item is taken out
		for k in commander_marks.keys():
			if str(k).begins_with(category + ":") and not (v as Array).has(str(k).substr(category.length() + 1)):
				commander_marks.erase(k)
				cleared = true
	if cleared:
		commander_changed.emit()
	reevaluate()


# ----------------------------------------------------------------------
# Settings (host / offline only)
# ----------------------------------------------------------------------

func set_scenario(id: String) -> void:
	if Data.db.is_empty() or Data.scenario(id).is_empty() or id == scenario_id:
		return
	scenario_id = id
	design = make_default_design(id)
	settings_changed.emit()
	reevaluate()


func set_difficulty(d: String) -> void:
	if Data.db.is_empty() or not Data.db["meta"]["difficulty"].has(d) or d == difficulty:
		return
	difficulty = d
	settings_changed.emit()
	reevaluate()


func set_mission_length(length: String) -> void:
	if length != "short" and length != "full":
		return
	mission_length = length
	settings_changed.emit()


func set_demo_mode(on: bool) -> void:
	demo_mode = on
	_roll_seed()
	settings_changed.emit()


func set_build_seconds(sec: int) -> void:
	build_seconds = clampi(sec, 60, 600)
	settings_changed.emit()


func set_twists_on(on: bool) -> void:
	twists_on = on
	settings_changed.emit()


## Host only: the twists for this mission. Re-evaluates (a twist can change the budget).
func set_twists(ids: Array) -> void:
	twists = ids.duplicate()
	settings_changed.emit()
	reevaluate()


func set_lives(n: int, n_max: int = -2) -> void:
	lives = n
	if n_max != -2:
		lives_max = n_max
	lives_changed.emit()


## The sum of every twist's effect[key] (numbers) or the product (for *_mult keys).
func twist_effect(key: String, default_value: float = 0.0) -> float:
	var out: float = default_value
	for id in twists:
		var t: Dictionary = Data.twist(str(id))
		var e: Dictionary = t.get("effect", {})
		if not e.has(key):
			continue
		if key.ends_with("_mult"):
			out *= float(e[key])
		else:
			out += float(e[key])
	return out


func twist_names() -> Array:
	var out: Array = []
	for id in twists:
		var t: Dictionary = Data.twist(str(id))
		if not t.is_empty():
			out.append(t)
	return out


func set_team_name(n: String) -> void:
	team_name = n.strip_edges().substr(0, 24)
	settings_changed.emit()


## Host only. Net sends the new phase to every client.
func set_phase(p: String, payload: Dictionary = {}) -> void:
	if not (p in Protocol.PHASES):
		push_warning("MissionState.set_phase: unknown phase %s" % p)
		return
	if p == phase:
		return
	phase = p
	phase_payload = payload
	phase_changed.emit(phase)


# ----------------------------------------------------------------------
# Seats (Net validates who may do what; these just change the data)
# ----------------------------------------------------------------------

func role_of_peer(peer: int) -> String:
	if peer == 0:
		return ""
	for r in Protocol.ROLES:
		if seats[r] == peer:
			return r
	return ""


func seat_is_free(role: String) -> bool:
	return seats.has(role) and seats[role] == 0


## Gives `role` to `peer`. A peer holds one seat at a time (the old one is freed).
func assign_seat(role: String, peer: int) -> bool:
	if not seats.has(role) or peer == 0:
		return false
	if seats[role] != 0 and seats[role] != peer:
		return false
	for r in Protocol.ROLES:
		if seats[r] == peer and r != role:
			seats[r] = 0
			seat_ready[r] = false
	seats[role] = peer
	_update_local_role(true)
	seats_changed.emit()
	return true


func release_peer(peer: int) -> void:
	var role := role_of_peer(peer)
	if role == "":
		return
	seats[role] = 0
	seat_ready[role] = false
	_update_local_role(true)
	seats_changed.emit()


func set_ready(role: String, flag: bool) -> void:
	if not seat_ready.has(role) or seat_ready[role] == flag:
		return
	seat_ready[role] = flag
	seats_changed.emit()


func all_seated_ready() -> bool:
	for r in Protocol.ROLES:
		if seats[r] != 0 and not seat_ready[r]:
			return false
	return true


func filled_seat_count() -> int:
	var n := 0
	for r in Protocol.ROLES:
		if seats[r] != 0:
			n += 1
	return n


func _update_local_role(refresh_view: bool) -> void:
	var new_role := role_of_peer(multiplayer.get_unique_id())
	if new_role == local_role:
		return
	local_role = new_role
	if refresh_view and Net.mode == Net.Mode.OFFLINE:
		view = _own_view()
		design_changed.emit()


# ----------------------------------------------------------------------
# Tokens (the flight module fills these in Part 2)
# ----------------------------------------------------------------------

func set_tokens(all_tokens: Dictionary) -> void:
	tokens = all_tokens.duplicate(true)
	tokens_changed.emit()


func role_tokens(role: String) -> Dictionary:
	return tokens.get(role, {})


## HOST: which tokens may THIS role's client see? Cadet shows everyone everything; otherwise only its own.
func tokens_for_role(role: String) -> Dictionary:
	if not Data.db.is_empty() and not bool(Data.db["meta"]["difficulty"][difficulty]["private_info"]):
		return tokens.duplicate(true)
	if role == "" or not tokens.has(role):
		return {}
	return {role: tokens[role].duplicate(true)}


func set_poll(p: Dictionary) -> void:
	poll = p.duplicate(true)
	poll_changed.emit()


func set_flight_status(s: Dictionary) -> void:
	flight_status = s.duplicate(true)
	flight_status_changed.emit()


# ----------------------------------------------------------------------
# Network: what is shared with clients
# ----------------------------------------------------------------------

## Everything every client may know. Part names are public (spec section 3); numbers are not.
## Contains NO evaluate() numbers, NO seed, NO tokens.
func public_state() -> Dictionary:
	return {
		"phase": phase, "scenario": scenario_id, "difficulty": difficulty,
		"mission_length": mission_length, "demo_mode": demo_mode, "team_name": team_name,
		"design": design.duplicate(true),
		"seats": seats.duplicate(), "seat_ready": seat_ready.duplicate(),
		"poll": poll.duplicate(true), "flight_status": flight_status.duplicate(true),
		"commander_mode": commander_mode, "commander_marks": commander_marks.duplicate(), "commander_go": commander_go,
		"design_left": design_left, "budget_penalty": budget_penalty,
		"lives": lives, "lives_max": lives_max, "build_seconds": build_seconds, "twists": twists.duplicate(),
		"twists_on": twists_on,
	}


## CLIENT side: take what the host sent. Changes data first, THEN emits signals, so listeners see a
## consistent state.
func apply_sync(pub: Dictionary, private_view_in: Dictionary) -> void:
	# tokens ride inside the private view; split them off so a token change does not look like a design change
	var private_view: Dictionary = private_view_in.duplicate(true)
	var new_tokens: Dictionary = private_view.get("tokens", {})
	private_view.erase("tokens")
	var tokens_flag := false
	if new_tokens != tokens:
		tokens = new_tokens.duplicate(true)
		tokens_flag = true
	var poll_flag := false
	if pub.get("poll", poll) != poll:
		poll = pub["poll"].duplicate(true)
		poll_flag = true
	var flight_flag := false
	if pub.get("flight_status", flight_status) != flight_status:
		flight_status = pub["flight_status"].duplicate(true)
		flight_flag = true
	var commander_flag := false
	if pub.get("commander_mode", commander_mode) != commander_mode or pub.get("commander_marks", commander_marks) != commander_marks \
			or pub.get("commander_go", commander_go) != commander_go:
		commander_mode = bool(pub.get("commander_mode", commander_mode))
		commander_marks = (pub.get("commander_marks", commander_marks) as Dictionary).duplicate()
		commander_go = bool(pub.get("commander_go", commander_go))
		commander_flag = true
	var settings_changed_flag := false
	if pub.get("scenario", scenario_id) != scenario_id:
		scenario_id = str(pub["scenario"])
		settings_changed_flag = true
	if pub.get("difficulty", difficulty) != difficulty:
		difficulty = str(pub["difficulty"])
		settings_changed_flag = true
	if pub.get("mission_length", mission_length) != mission_length:
		mission_length = str(pub["mission_length"])
		settings_changed_flag = true
	if pub.get("demo_mode", demo_mode) != demo_mode:
		demo_mode = bool(pub["demo_mode"])
		settings_changed_flag = true
	if pub.get("team_name", team_name) != team_name:
		team_name = str(pub["team_name"])
		settings_changed_flag = true
	if int(pub.get("build_seconds", build_seconds)) != build_seconds or pub.get("twists", twists) != twists \
			or bool(pub.get("twists_on", twists_on)) != twists_on:
		build_seconds = int(pub.get("build_seconds", build_seconds))
		twists = (pub.get("twists", twists) as Array).duplicate()
		twists_on = bool(pub.get("twists_on", twists_on))
		settings_changed_flag = true
	var lives_flag := false
	if int(pub.get("lives", lives)) != lives or int(pub.get("lives_max", lives_max)) != lives_max:
		lives = int(pub.get("lives", lives))
		lives_max = int(pub.get("lives_max", lives_max))
		lives_flag = true

	var seats_changed_flag := false
	if pub.has("seats") and (pub["seats"] != seats or pub.get("seat_ready", seat_ready) != seat_ready):
		seats = pub["seats"].duplicate()
		seat_ready = pub.get("seat_ready", seat_ready).duplicate()
		seats_changed_flag = true
		_update_local_role(false)

	var design_changed_flag := false
	if pub.has("design") and (pub["design"] != design or private_view != view):
		design = pub["design"].duplicate(true)
		view = private_view.duplicate(true)
		design_changed_flag = true
	elif private_view != view:
		view = private_view.duplicate(true)
		design_changed_flag = true

	if settings_changed_flag:
		settings_changed.emit()
	if seats_changed_flag:
		seats_changed.emit()
	if design_changed_flag:
		design_changed.emit()
	if tokens_flag:
		tokens_changed.emit()
	if poll_flag:
		poll_changed.emit()
	if flight_flag:
		flight_status_changed.emit()
	if commander_flag:
		commander_changed.emit()
	if lives_flag:
		lives_changed.emit()
	if int(pub.get("design_left", design_left)) != design_left or float(pub.get("budget_penalty", budget_penalty)) != budget_penalty:
		design_left = int(pub.get("design_left", design_left))
		budget_penalty = float(pub.get("budget_penalty", budget_penalty))
		clock_changed.emit()
	if pub.has("phase") and str(pub["phase"]) != phase:
		phase = str(pub["phase"])
		phase_changed.emit(phase)


# ----------------------------------------------------------------------
# Commander mode (host / offline only for the setters)
# ----------------------------------------------------------------------

func set_design_clock(seconds_left: int) -> void:
	if seconds_left == design_left:
		return
	design_left = seconds_left
	clock_changed.emit()


## Investors pulled money (host only). Re-evaluates so every light and the Commander's money meter see it.
func set_budget_penalty(amount: float) -> void:
	budget_penalty = amount
	reevaluate()
	clock_changed.emit()


## The budget multiplier the contract gives for an orbit (round 8: "the budget depends on the orbit").
func orbit_budget_mult(orbit_id: String = "") -> float:
	var oid: String = orbit_id if orbit_id != "" else str(design.get("orbit", ""))
	return float(Data.scenario(scenario_id).get("orbits", {}).get(oid, {}).get("budget_mult", 1.0))


## Runs AFTER SimEngine.evaluate (its formulas stay untouched): the real cap is
##   cap x orbit budget x twist budget  -  money the investors pulled.
## Then everything that depends on the cap (the over-budget error, the light, the budget token) is redone the same
## way evaluate does it.
func _apply_budget_penalty(r: Dictionary) -> void:
	if not r.has("cost") or not r.has("lights"):
		return
	var base_cap: float = float(r["cost"]["cap"])
	var mult: float = orbit_budget_mult() * twist_effect("budget_mult", 1.0)
	if is_equal_approx(mult, 1.0) and budget_penalty <= 0.0:
		return
	var cap: float = base_cap * mult - budget_penalty
	r["cost"]["cap"] = snappedf(cap, 0.1)
	r["cost"]["base_cap"] = base_cap
	r["cost"]["orbit_mult"] = orbit_budget_mult()
	r["cost"]["investor_cut"] = budget_penalty
	var total: float = float(r["cost"]["total"])
	var errs: Array = r["errors"]
	errs.erase("over budget")
	if total > cap:
		errs.append("over budget")
	r["valid"] = errs.is_empty()
	var frac: float = (cap - total) / cap if cap > 0.0 else -1.0
	var reserve: float = float(Data.db["meta"]["constants"]["targets"]["cost_reserve_frac"])
	r["lights"]["budget"] = "red" if frac < 0.0 else ("amber" if frac < reserve else "green")
	if r.has("tokens"):
		r["tokens"]["budget"] = int(mini(5, maxi(0, int(floor((cap - total) / (0.05 * cap)))))) if cap > 0.0 else 0


## "3:12" while there is time, "OVERTIME" after. "" when there is no clock.
static func clock_text(seconds_left: int) -> String:
	if seconds_left < 0:
		return ""
	return "%d:%02d" % [seconds_left / 60, seconds_left % 60]


func set_commander_mode(on: bool) -> void:
	if commander_mode == on:
		return
	commander_mode = on
	commander_changed.emit()
	settings_changed.emit()


func set_mark(category: String, state: String) -> void:
	if state == "":
		commander_marks.erase(category)
	else:
		commander_marks[category] = state
	commander_changed.emit()


func set_commander_go(go: bool) -> void:
	commander_go = go
	commander_changed.emit()


## The design categories a role owns that the Commander marked SWAP (still not changed).
func swaps_for_role(role: String) -> Array:
	var out: Array = []
	if not commander_mode or Data.db.is_empty():
		return out
	var owns: Array = Data.db["meta"]["roles"].get(role, {}).get("owns_choices", [])
	for k in commander_marks:
		if str(commander_marks[k]) == "swap" and owns.has(str(k).get_slice(":", 0)):
			out.append(str(k))
	return out


## Kid words for a flag key: "Body", "Orbit", or an instrument / station name for "instruments:sar_c".
static func mark_label(key: String) -> String:
	var cat: String = key.get_slice(":", 0)
	if key.contains(":"):
		return SimEngine._item_name(Data.db, cat, key.get_slice(":", 1))
	return "Orbit" if cat == "orbit" else str(SimEngine.CATEGORY_LABELS.get(cat, cat))


func any_swaps() -> bool:
	for c in commander_marks:
		if str(commander_marks[c]) == "swap":
			return true
	return false


## CLIENT side: left the game / lost connection. Back to a clean offline state.
func reset_local() -> void:
	local_role = ""
	reset_all()
