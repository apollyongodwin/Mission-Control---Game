# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Autoload "Net": ENet networking, host-authoritative (spec section 6).
##
## Host = Mission Control = peer id 1. It is NOT a player.
## Clients send requests (request_seat, submit_choice, ...). The host validates every one,
## re-runs SimEngine.evaluate, and sends each client ONLY its own filtered view (sync_state).
##
## Three modes:
##   OFFLINE  single process, no network. Net.submit_choice() applies the change locally,
##            so panels can be built and tested without hosting. (Role checks only apply if a
##            seat was taken with Net.request_seat(role).)
##   HOST     after host_game()
##   CLIENT   after join_game(ip)
##
## UI code calls these (same call works in all three modes):
##   Net.request_seat(role)   Net.submit_choice(category, value)   Net.set_seat_ready(flag)
##   Net.call_review()   Net.poll_answer(go, reason)   Net.play_action(id)
##   Net.give_token(token, to_role)   Net.ping(card_id)   Net.event_choice(option_id)

enum Mode { OFFLINE, HOST, CLIENT }

signal hosting_started
signal joined_server                    # client: connected to the host
signal join_failed                      # client: could not connect
signal left_network                     # client: lost the host or left
signal peer_joined(peer_id: int)        # host
signal peer_left(peer_id: int)          # host
## The host said "no" (or "FYI"). code examples: "choice_rejected", "seat_rejected".
signal server_message_received(code: String, text: String)
signal phase_started(phase: String, payload: Dictionary)
signal crisis_event(event: Dictionary, timer_s: float)    # client: crisis_started RPC arrived
signal crisis_result(result: Dictionary)                  # client: crisis_resolved RPC arrived
signal debrief_report(report: Dictionary)                 # client: debrief RPC arrived

# HOST-side signals: a validated request from a seated player. Part 2 (phase machine,
# flight director) connects to these. `role` is who asked.
signal ready_changed(role: String, flag: bool)
signal review_requested(role: String)
signal poll_answered(role: String, go: bool, reason: String)
signal action_requested(role: String, action_id: String)
signal token_give_requested(from_role: String, to_role: String, token: String)
signal ping_received(role: String, card_id: String)
signal event_choice_made(role: String, option_id: String)
signal chat_received(role: String, text: String)
signal version_mismatch(text: String)   # client: this copy does not match Mission Control's   # everyone (host, offline and clients): a chat line arrived

var mode: Mode = Mode.OFFLINE
var _broadcast_pending: bool = false
var phase_machine: PhaseMachine = null   # host-side phase machine (net/PhaseMachine.gd)
var _pending_seat: Dictionary = {}       # round 6: peer -> role asked for before the version check finished
var _client_key: String = ""             # random per app run; lets the host recognise us after a dropped connection


func _ready() -> void:
	# The phase machine is created FIRST so its phase-entry code runs before our own phase listener below.
	phase_machine = PhaseMachine.new()
	phase_machine.name = "PhaseMachine"
	add_child(phase_machine)
	_client_key = "%d-%d" % [Time.get_ticks_usec(), randi()]
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_ok)
	multiplayer.connection_failed.connect(_on_connect_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	# LAN fix: version handshake on RAW packets (they do not depend on matching RPC tables, so they work
	# even between mismatched copies, which is exactly when we need them).
	(multiplayer as SceneMultiplayer).peer_packet.connect(_on_raw_packet)
	# Host: whenever shared state changes, queue ONE broadcast (many changes in a frame = one send).
	MissionState.design_changed.connect(_queue_broadcast)
	MissionState.seats_changed.connect(_queue_broadcast)
	MissionState.settings_changed.connect(_queue_broadcast)
	MissionState.tokens_changed.connect(_queue_broadcast)
	MissionState.commander_changed.connect(_queue_broadcast)   # round 4: Commander marks / GO
	MissionState.clock_changed.connect(_queue_broadcast)       # round 7: build clock (once a second)
	MissionState.phase_changed.connect(_on_phase_changed)
	MissionState.reset_all()


func is_host() -> bool:
	return mode == Mode.HOST


func is_client() -> bool:
	return mode == Mode.CLIENT


func is_offline() -> bool:
	return mode == Mode.OFFLINE


## True on the host and offline: this process owns the truth.
func is_authority() -> bool:
	return mode != Mode.CLIENT


# ----------------------------------------------------------------------
# Hosting / joining
# ----------------------------------------------------------------------

func host_game(port: int = Protocol.PORT) -> Error:
	leave()
	var peer := ENetMultiplayerPeer.new()
	var err: Error = peer.create_server(port, Protocol.MAX_CLIENTS)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	mode = Mode.HOST
	_verified = {}
	MissionState.reset_all()
	hosting_started.emit()
	return OK


func join_game(ip: String, port: int = Protocol.PORT) -> Error:
	leave()
	var addr := ip.strip_edges()
	if addr == "":
		return ERR_INVALID_PARAMETER
	var peer := ENetMultiplayerPeer.new()
	var err: Error = peer.create_client(addr, port)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	mode = Mode.CLIENT
	MissionState.eval_result = {}   # a client never holds the full result (leave() may have computed one offline)
	return OK


## Drops any connection and goes back to OFFLINE with a clean MissionState.
func leave() -> void:
	if mode == Mode.OFFLINE:
		return
	var was_client := mode == Mode.CLIENT
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	mode = Mode.OFFLINE
	chat_log = []
	MissionState.reset_local()
	if was_client:
		left_network.emit()


## Best guess at this machine's LAN address, for the lobby to show ("192.168.x.x").
func local_ip() -> String:
	var fallback := ""
	for a in IP.get_local_addresses():
		var s := str(a)
		if s.contains(":") or s.begins_with("127.") or s.begins_with("169.254."):
			continue
		if s.begins_with("192.168.") or s.begins_with("10."):
			return s
		if s.begins_with("172."):
			var second := int(s.split(".")[1])
			if second >= 16 and second <= 31:
				return s
		if fallback == "":
			fallback = s
	return fallback if fallback != "" else "127.0.0.1"


func _version_text() -> String:
	var v: Dictionary = Engine.get_version_info()
	# round 8: the mods fingerprint is part of the check, so laptops with different mods are refused with a clear reason
	var mods: String = Data.mods_fingerprint if Data.mods_fingerprint != "" else "none"
	return "%s|%d.%d.%d|mods:%s" % [Protocol.GAME_VERSION, int(v["major"]), int(v["minor"]), int(v["patch"]), mods]


var _verified: Dictionary = {}   # host: peer id -> true once its copy matches ours


func is_verified(peer: int) -> bool:
	return mode != Mode.HOST or peer == 1 or _verified.has(peer)


func _on_raw_packet(id: int, packet: PackedByteArray) -> void:
	var msg := packet.get_string_from_utf8()
	if mode == Mode.HOST and msg.begins_with("MCV|"):
		if msg.substr(4) == _version_text():
			_verified[id] = true
			if _pending_seat.has(id):   # round 6: the seat they tapped before the check finished
				var want: String = str(_pending_seat[id])
				_pending_seat.erase(id)
				if want in Protocol.ROLES and not MissionState.assign_seat(want, id):
					_reject(id, "seat_rejected", "That seat is already taken.")
			_queue_broadcast()
		else:
			(multiplayer as SceneMultiplayer).send_bytes(("MCBAD|" + _version_text()).to_utf8_buffer(), id)
			get_tree().create_timer(0.5).timeout.connect(func() -> void:
				if multiplayer.has_multiplayer_peer() and mode == Mode.HOST:
					(multiplayer.multiplayer_peer as ENetMultiplayerPeer).disconnect_peer(id))
	elif mode == Mode.CLIENT and msg.begins_with("MCBAD|"):
		var theirs := msg.substr(6).split("|")
		var mine := _version_text().split("|")
		var text := "This laptop runs a different copy of the game than Mission Control.\n" + \
			"Mission Control: %s (Godot %s)   This laptop: %s (Godot %s)\n" % [theirs[0], theirs[1] if theirs.size() > 1 else "?", mine[0], mine[1]] + \
			"Everyone must use the same zip (or the same exported build)" + \
			("." if (theirs.size() < 3 or mine.size() < 3 or theirs[2] == mine[2]) else \
			", and the same mods folder. Mission Control has %s, this laptop has %s." % [theirs[2], mine[2]])
		version_mismatch.emit(text)
		server_message_received.emit("version_mismatch", text)


func _on_peer_connected(id: int) -> void:
	if mode != Mode.HOST:
		return
	peer_joined.emit(id)
	# LAN fix: a peer that never proves its version (an older copy) is dropped after a few seconds
	get_tree().create_timer(6.0).timeout.connect(func() -> void:
		if mode == Mode.HOST and multiplayer.has_multiplayer_peer() and not _verified.has(id) \
				and id in multiplayer.get_peers():
			(multiplayer.multiplayer_peer as ENetMultiplayerPeer).disconnect_peer(id))
	# a late joiner or a rejoiner needs the current phase (sync_state alone does not fire phase_started)
	phase_changed.rpc_id(id, MissionState.phase, MissionState.phase_payload)
	_queue_broadcast()


func _on_peer_disconnected(id: int) -> void:
	if mode != Mode.HOST:
		return
	_verified.erase(id)
	_pending_seat.erase(id)
	# Part 2: the seat is held for 60 seconds (PhaseMachine); in the lobby it is freed at once.
	phase_machine.on_peer_disconnected(id)
	peer_left.emit(id)
	_queue_broadcast()


func _on_connected_ok() -> void:
	(multiplayer as SceneMultiplayer).send_bytes(("MCV|" + _version_text()).to_utf8_buffer(), 1)
	hello(_client_key)
	joined_server.emit()


func _on_connect_failed() -> void:
	leave()
	join_failed.emit()


func _on_server_disconnected() -> void:
	leave()


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------

## Who sent this call? 0 means a local call, which is "me" (peer id 1 when offline).
func _sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return s if s != 0 else multiplayer.get_unique_id()


## Tell a peer "no". If the peer is this very process (offline), emit the signal directly.
func _reject(peer: int, code: String, text: String) -> void:
	if peer == multiplayer.get_unique_id():
		server_message_received.emit(code, text)
	else:
		server_message.rpc_id(peer, code, text)


## The role of whoever is calling, or "" (and the caller gets told) if they have no seat.
func _caller_role() -> String:
	var sender := _sender()
	var role := MissionState.role_of_peer(sender)
	if role == "":
		_reject(sender, "no_seat", "Pick a seat first.")
	return role


# ----------------------------------------------------------------------
# CLIENT -> HOST requests (spec section 6)
# Pattern: a client forwards the call to the host (peer 1); the host (or offline) does the work.
# ----------------------------------------------------------------------

@rpc("any_peer", "call_remote", "reliable")
func request_seat(role: String) -> void:
	if mode == Mode.CLIENT:
		request_seat.rpc_id(1, role)
		return
	var sender := _sender()
	if mode == Mode.HOST and sender == 1:
		return   # Mission Control is not a player
	if not is_verified(sender):   # LAN fix: an unknown copy of the game never gets a seat...
		_pending_seat[sender] = role   # round 6: ...but a fast tap is remembered and granted once the check passes
		return
	if not (role in Protocol.ROLES):
		_reject(sender, "seat_rejected", "That seat does not exist.")
		return
	if not MissionState.assign_seat(role, sender):
		_reject(sender, "seat_rejected", "That seat is already taken.")


## Validates and applies a design change. Works with NO network (single process).
## The host checks: the sender owns the category, the value exists in the data, list sizes are sane,
## and (when hosting) the game is in the DESIGN phase.
@rpc("any_peer", "call_remote", "reliable")
func submit_choice(category: String, value: Variant) -> void:
	if mode == Mode.CLIENT:
		submit_choice.rpc_id(1, category, value)
		return
	var sender := _sender()
	if mode == Mode.HOST and sender == 1:
		return
	var err := apply_choice_as(MissionState.role_of_peer(sender), category, value)
	if err != "":
		_reject(sender, "choice_rejected", err)


## Host/offline only. Also the door for AutoCrew bots (they act for a role without a network peer).
## Returns "" when applied, otherwise a short reason.
func apply_choice_as(role: String, category: String, value: Variant) -> String:
	if mode == Mode.CLIENT:
		return "Only the host applies choices."
	if mode == Mode.HOST:
		if role == "":
			return "Pick a seat first."
		if MissionState.phase != "DESIGN":
			return "The design is locked right now."
	# Offline with no seat chosen: allow anything valid, so single-panel tests are easy.
	if role != "" and not Protocol.role_may_submit(Data.db, role, category):
		return "That choice belongs to another role."
	var err := Protocol.validate_choice(Data.db, category, value)
	if err != "":
		return err
	MissionState.set_choice(category, value)
	return ""


## The READY button. (Spec name is `ready`; Godot's Node already has a `ready` signal and a `request_ready()` method,
## so the function is called set_seat_ready.)
@rpc("any_peer", "call_remote", "reliable")
func set_seat_ready(flag: bool) -> void:
	if mode == Mode.CLIENT:
		set_seat_ready.rpc_id(1, flag)
		return
	var role := _caller_role()
	if role == "":
		return
	MissionState.set_ready(role, flag)
	ready_changed.emit(role, flag)


@rpc("any_peer", "call_remote", "reliable")
func call_review() -> void:
	if mode == Mode.CLIENT:
		call_review.rpc_id(1)
		return
	var role := _caller_role()
	if role != "":
		review_requested.emit(role)


@rpc("any_peer", "call_remote", "reliable")
func poll_answer(go: bool, reason: String) -> void:
	if mode == Mode.CLIENT:
		poll_answer.rpc_id(1, go, reason)
		return
	var role := _caller_role()
	if role != "":
		poll_answered.emit(role, go, reason.substr(0, 140))


@rpc("any_peer", "call_remote", "reliable")
func play_action(action_id: String) -> void:
	if mode == Mode.CLIENT:
		play_action.rpc_id(1, action_id)
		return
	var role := _caller_role()
	if role != "":
		action_requested.emit(role, action_id)


@rpc("any_peer", "call_remote", "reliable")
func give_token(token: String, to_role: String) -> void:
	if mode == Mode.CLIENT:
		give_token.rpc_id(1, token, to_role)
		return
	var role := _caller_role()
	if role != "" and (to_role in Protocol.ROLES):
		token_give_requested.emit(role, to_role, token)


@rpc("any_peer", "call_remote", "reliable")
func ping(card_id: String) -> void:
	if mode == Mode.CLIENT:
		ping.rpc_id(1, card_id)
		return
	var role := _caller_role()
	if role != "":
		ping_received.emit(role, card_id)


@rpc("any_peer", "call_remote", "reliable")
func event_choice(option_id: String) -> void:
	if mode == Mode.CLIENT:
		event_choice.rpc_id(1, option_id)
		return
	var role := _caller_role()
	if role != "":
		event_choice_made.emit(role, option_id)


# ----------------------------------------------------------------------
# HOST -> CLIENT (spec section 6)
# ----------------------------------------------------------------------

## Sent per peer. `private_view` is SimEngine.role_view for THAT peer's role. Never the full result.
@rpc("authority", "call_remote", "reliable")
func sync_state(public_state: Dictionary, private_view: Dictionary) -> void:
	MissionState.apply_sync(public_state, private_view)


@rpc("authority", "call_remote", "reliable")
func phase_changed(new_phase: String, payload: Dictionary) -> void:
	MissionState.set_phase(new_phase, payload)
	phase_started.emit(new_phase, payload)


@rpc("authority", "call_remote", "reliable")
func crisis_started(event: Dictionary, timer_s: float) -> void:
	crisis_event.emit(event, timer_s)


@rpc("authority", "call_remote", "reliable")
func crisis_resolved(result: Dictionary) -> void:
	crisis_result.emit(result)


@rpc("authority", "call_remote", "reliable")
func debrief(report: Dictionary) -> void:
	MissionState.last_report = report   # stored first, so a scene created on the DEBRIEF phase can read it
	debrief_report.emit(report)


## Extra (not in the spec list): a short "no" or "FYI" from the host, so a rejected click is not silent.
@rpc("authority", "call_remote", "reliable")
func server_message(code: String, text: String) -> void:
	server_message_received.emit(code, text)


# ----------------------------------------------------------------------
# Host broadcasting
# ----------------------------------------------------------------------

func _on_phase_changed(p: String) -> void:
	if mode != Mode.HOST:
		return
	# Send the phase first; the state sync below arrives after it on the same reliable channel.
	phase_changed.rpc(p, MissionState.phase_payload)
	_queue_broadcast()


func _queue_broadcast() -> void:
	if mode != Mode.HOST or _broadcast_pending:
		return
	_broadcast_pending = true
	_flush_broadcast.call_deferred()


func _flush_broadcast() -> void:
	_broadcast_pending = false
	if mode != Mode.HOST:
		return
	var pub := MissionState.public_state()
	for peer in multiplayer.get_peers():
		var role := MissionState.role_of_peer(peer)
		var private_view: Dictionary = MissionState.view_for_role(role)
		private_view["tokens"] = MissionState.tokens_for_role(role)   # token privacy: only this role's tokens (all in Cadet)
		sync_state.rpc_id(peer, pub, private_view)


# ----------------------------------------------------------------------
# CHAT (Lead, Part 3): host-relayed text chat + quick chat. LAN only, nothing leaves the room.
# ----------------------------------------------------------------------

const QUICK_CHAT: Array = ["Too heavy!", "Need power!", "Over budget!", "Need a faster antenna!", "Ready!", "Wait!",
	"Nice one!", "Check your lights!", "GO?", "I can fix it!", "Help!", "Hand me a token!"]
const CHAT_MAX_LEN := 80
const CHAT_HISTORY := 40
var chat_log: Array = []          # [{role, text}] on every machine, newest last
var typed_chat_allowed := true    # host setting: false = quick phrases only (classroom mode)
var _chat_times: Dictionary = {}  # peer -> last message msec (spam guard)


## Any player (or the host / offline) sends a line. The host checks it and relays it to everyone.
@rpc("any_peer", "call_remote", "reliable")
func send_chat(text: String) -> void:
	if mode == Mode.CLIENT:
		send_chat.rpc_id(1, text)
		return
	var sender := _sender()
	var role := "mission_control" if (mode == Mode.HOST and sender == 1) else MissionState.role_of_peer(sender)
	if role == "":
		return
	var clean := text.strip_edges().replace("[", "(").replace("]", ")").substr(0, CHAT_MAX_LEN)
	if clean == "":
		return
	var now := Time.get_ticks_msec()
	if now - int(_chat_times.get(sender, -10000)) < 700:
		_reject(sender, "chat_rejected", "Slow down, space cadet! One message at a time.")
		return   # one line per 0.7 s
	_chat_times[sender] = now
	if not typed_chat_allowed and not (clean in QUICK_CHAT) and role != "mission_control":
		_reject(sender, "chat_rejected", "Mission Control set chat to quick phrases only.")
		return
	var fs: Dictionary = MissionState.flight_status
	if bool(fs.get("radio_silence", false)) and bool(fs.get("active", false)) and role != "mission_control":
		_reject(sender, "chat_rejected", "Radio silence! Use the ping wheel.")
		return
	if mode == Mode.HOST:
		chat_message.rpc(role, clean)
	chat_message(role, clean)


@rpc("authority", "call_remote", "reliable")
func chat_message(role: String, text: String) -> void:
	chat_log.append({"role": role, "text": text})
	while chat_log.size() > CHAT_HISTORY:
		chat_log.pop_front()
	chat_received.emit(role, text)


# ----------------------------------------------------------------------
# PART 2 additions
# ----------------------------------------------------------------------

## Client -> host, sent once right after connecting. The key is random per app run, so after a dropped
## connection the host can give the same player their seat back (PhaseMachine holds it for 60 s).
@rpc("any_peer", "call_remote", "reliable")
func hello(key: String) -> void:
	if mode == Mode.CLIENT:
		hello.rpc_id(1, key)
		return
	if mode == Mode.HOST:
		phase_machine.on_hello(_sender(), key.substr(0, 64))


## Host/offline: the ONE way phases change (PhaseMachine, tests and the lobby START button all use it).
func host_set_phase(p: String, payload: Dictionary = {}) -> void:
	if mode == Mode.CLIENT:
		return
	MissionState.set_phase(p, payload)


## Host/offline: "Again!" - same crew, same design, new seed, straight back to DESIGN.
func host_again() -> void:
	if mode != Mode.CLIENT:
		phase_machine.again()


## Host/offline: back to the lobby with the crew kept in their seats.
func host_new_mission() -> void:
	if mode != Mode.CLIENT:
		MissionState.reset_all(false)


## A short message to ONE peer (or to this process when offline). Same channel as rejected choices.
func say_to(peer: int, code: String, text: String) -> void:
	if mode == Mode.OFFLINE and peer != multiplayer.get_unique_id():
		return   # offline there is nobody else to tell (tests use fake peer ids)
	_reject(peer, code, text)


## A short message to everybody, including the host's own screen.
func say_all(code: String, text: String) -> void:
	if mode == Mode.HOST:
		server_message.rpc(code, text)
	server_message_received.emit(code, text)


## Host: re-send the current phase to one peer (used when a dropped player comes back).
func resend_to(peer: int) -> void:
	if mode != Mode.HOST:
		return
	phase_changed.rpc_id(peer, MissionState.phase, MissionState.phase_payload)
	_queue_broadcast()
