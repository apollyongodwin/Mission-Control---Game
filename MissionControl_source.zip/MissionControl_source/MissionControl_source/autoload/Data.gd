# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Autoload "Data": loads countdown_data.json once. Use Data.db everywhere.
## SimEngine is pure, so you always pass the data in: SimEngine.evaluate(Data.db, design, difficulty)
##
## LEAD (round 8) MODS: players can add their own instruments, parts, rockets, stations, crises, cards and twists
## without touching the game. Drop a .json file in a "mods" folder (see MODDING.md):
##   * next to MissionControl.exe  (easy to share: zip the folder with the game)
##   * or the user folder: Settings > "Open mods folder"
## Every laptop in a game must have the SAME mods: the version check compares a fingerprint and refuses a mismatch.
## Start with  -- --no-mods  to ignore every mod (the tests do).

var db: Dictionary = {}
var mods_loaded: Array = []        ## [{"file", "name", "added", "replaced"}]
var mod_problems: Array = []       ## plain-language lines for Settings ("bad_mod.json: instrument 'x' is missing 'mass'")
var mods_fingerprint: String = ""  ## "" when no mods are loaded

const LIST_KEYS: Array = ["orbits", "rockets", "stations", "instruments", "actions", "events"]
const MOD_DIR_USER := "user://mods"


func _ready() -> void:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://data/countdown_data.json"))
	assert(typeof(parsed) == TYPE_DICTIONARY, "countdown_data.json could not be parsed")
	db = parsed
	if not _mods_disabled():
		_load_mods()
	# optional kid-friendly text, edited separately by the non-coders
	if FileAccess.file_exists("res://data/kid_text.json"):
		var kid = JSON.parse_string(FileAccess.get_file_as_string("res://data/kid_text.json"))
		if typeof(kid) == TYPE_DICTIONARY:
			KidText.apply(db, kid)


func by_id(arr: Array, id: String) -> Dictionary:
	for x in arr:
		if x["id"] == id:
			return x
	return {}


func orbit(id: String) -> Dictionary:
	return by_id(db["orbits"], id)


func rocket(id: String) -> Dictionary:
	return by_id(db["rockets"], id)


func station(id: String) -> Dictionary:
	return by_id(db["stations"], id)


func instrument(id: String) -> Dictionary:
	return by_id(db["instruments"], id)


func scenario(id: String) -> Dictionary:
	return by_id(db["scenarios"], id)


## category is one of: bus, panel, battery, comm, adcs, obc, shield, prop
func part(category: String, id: String) -> Dictionary:
	return by_id(db["parts"][category], id)


func twist(id: String) -> Dictionary:
	return by_id(db["meta"].get("twists", []), id)


# ----------------------------------------------------------------------
# Mods (round 8)
# ----------------------------------------------------------------------

static func mod_dirs() -> Array:
	var out: Array = [ProjectSettings.globalize_path(MOD_DIR_USER)]
	if not OS.has_feature("editor"):
		out.append(OS.get_executable_path().get_base_dir().path_join("mods"))
	return out


func _mods_disabled() -> bool:
	for a in OS.get_cmdline_user_args() + OS.get_cmdline_args():
		if str(a) == "--no-mods":
			return true
	return false


func _load_mods() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(MOD_DIR_USER))
	var files: Array = []
	for dir in mod_dirs():
		var d := DirAccess.open(str(dir))
		if d == null:
			continue
		for f in d.get_files():
			if str(f).to_lower().ends_with(".json"):
				files.append(str(dir).path_join(str(f)))
	files.sort()
	var prints: PackedStringArray = []
	for path in files:
		var text := FileAccess.get_file_as_string(str(path))
		var m = JSON.parse_string(text)
		var fname: String = str(path).get_file()
		if typeof(m) != TYPE_DICTIONARY:
			mod_problems.append("%s: this is not valid JSON. Check the commas and brackets." % fname)
			continue
		var res: Dictionary = apply_mod(db, m, fname)
		mod_problems.append_array(res["problems"])
		if int(res["added"]) + int(res["replaced"]) > 0:
			var info: Dictionary = m.get("mod", {}) if m.get("mod", {}) is Dictionary else {}
			mods_loaded.append({"file": fname, "name": str(info.get("name", fname)), "added": res["added"], "replaced": res["replaced"]})
			prints.append(fname + ":" + text.md5_text())
	mods_fingerprint = "" if prints.is_empty() else ",".join(prints).md5_text().substr(0, 8)
	for p in mod_problems:
		push_warning("MOD: " + str(p))


## Merges one mod Dictionary into db. Same id = replaces the original; new id = added.
## Every new item must have the same keys as an item of the same kind in the base game (so nothing crashes later).
## Public and static so tests can check it without files.
static func apply_mod(base: Dictionary, m: Dictionary, fname: String = "mod") -> Dictionary:
	var problems: Array = []
	var added := 0
	var replaced := 0
	for key in LIST_KEYS:
		if not m.has(key):
			continue
		if not (m[key] is Array):
			problems.append("%s: '%s' must be a list [ ... ]." % [fname, key])
			continue
		for item in m[key]:
			var r: String = _merge_item(base[key], item, key, fname, problems)
			if r == "added":
				added += 1
			elif r == "replaced":
				replaced += 1
	if m.has("parts") and m["parts"] is Dictionary:
		for cat in m["parts"]:
			if not base["parts"].has(cat):
				problems.append("%s: there is no part category '%s' (use bus, panel, battery, comm, adcs, obc, shield or prop)." % [fname, cat])
				continue
			for item in m["parts"][cat]:
				var r2: String = _merge_item(base["parts"][cat], item, "parts." + str(cat), fname, problems)
				if r2 == "added":
					added += 1
				elif r2 == "replaced":
					replaced += 1
	if m.has("twists") and m["twists"] is Array:
		for item in m["twists"]:
			var r3: String = _merge_item(base["meta"]["twists"], item, "twists", fname, problems)
			if r3 == "added":
				added += 1
			elif r3 == "replaced":
				replaced += 1
	# a new orbit needs a place in a scenario: "scenario_orbits": {"bagyo_watch": {"my_orbit": {coverage, min_life_days, ...}}}
	if m.has("scenario_orbits") and m["scenario_orbits"] is Dictionary:
		for sid in m["scenario_orbits"]:
			var sc: Dictionary = {}
			for s in base["scenarios"]:
				if s["id"] == sid:
					sc = s
			if sc.is_empty():
				problems.append("%s: there is no mission '%s'." % [fname, sid])
				continue
			for oid in m["scenario_orbits"][sid]:
				var oc = m["scenario_orbits"][sid][oid]
				var known := false
				for o in base["orbits"]:
					if o["id"] == oid:
						known = true
				if not known or not (oc is Dictionary) or not oc.has("coverage") or not oc.has("min_life_days") or not oc.has("target_life_days"):
					problems.append("%s: orbit '%s' for %s needs a known orbit id plus coverage, min_life_days and target_life_days." % [fname, oid, sid])
					continue
				if not oc.has("budget_mult"):
					oc["budget_mult"] = 1.0
				sc["orbits"][oid] = oc
				added += 1
	return {"added": added, "replaced": replaced, "problems": problems}


static func _merge_item(arr: Array, item, kind: String, fname: String, problems: Array) -> String:
	if not (item is Dictionary) or not item.has("id"):
		problems.append("%s: every item in '%s' needs an \"id\"." % [fname, kind])
		return ""
	var id: String = str(item["id"])
	var template: Dictionary = {}
	for x in arr:
		if kind == "events" and str(x.get("kind", "")) != str(item.get("kind", "")):
			continue
		template = x
		break
	if template.is_empty():
		problems.append("%s: '%s' has an unknown kind." % [fname, id])
		return ""
	var missing: Array = []
	for k in template.keys():
		if not item.has(k) and not (k in ["kid", "learn", "real_analog", "pros", "cons", "exclude_orbits", "autonomy_reduces"]):
			missing.append(str(k))
	if not missing.is_empty():
		problems.append("%s: '%s' is missing %s (copy an item from the game's data file and change it)." % [fname, id, ", ".join(missing)])
		return ""
	for i in arr.size():
		if str(arr[i]["id"]) == id:
			arr[i] = item
			return "replaced"
	arr.append(item)
	return "added"
