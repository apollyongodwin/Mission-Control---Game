# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name GameSettings
extends RefCounted
## Dev D, Part 2. Saves/loads user://settings.cfg and applies it. All static.
## Dev C (Audio.gd): put music on a bus named "Music" and sound effects on "SFX"
## (Project > Audio tab), then call GameSettings.apply() after creating them.
## Missing buses are skipped, so nothing crashes if they do not exist yet.

const PATH := "user://settings.cfg"
const DEFAULTS := {"master": 0.8, "music": 0.6, "sfx": 0.8, "fullscreen": false, "voice": false}   # MERGE: robot announcer voice, off by default
const BUS_FOR := {"master": "Master", "music": "Music", "sfx": "SFX"}


static func load_all() -> Dictionary:
	var out: Dictionary = DEFAULTS.duplicate()
	var cf := ConfigFile.new()
	if cf.load(PATH) == OK:
		for k in DEFAULTS:
			out[k] = cf.get_value("settings", k, DEFAULTS[k])
	return out


static func set_value(key: String, value: Variant) -> void:
	var cf := ConfigFile.new()
	cf.load(PATH)   # fine if the file does not exist yet
	cf.set_value("settings", key, value)
	cf.save(PATH)
	apply()


static func get_volume(key: String) -> float:
	return float(load_all().get(key, 0.8))


static func apply() -> void:
	var s := load_all()
	for key in BUS_FOR:
		var idx := AudioServer.get_bus_index(BUS_FOR[key])
		if idx < 0:
			continue
		var v := clampf(float(s[key]), 0.0, 1.0)
		AudioServer.set_bus_mute(idx, v <= 0.001)
		AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.001)))
	var want_full := bool(s["fullscreen"])
	var mode := DisplayServer.window_get_mode()
	var is_full := mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN
	if want_full and not is_full:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	elif not want_full and is_full:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
