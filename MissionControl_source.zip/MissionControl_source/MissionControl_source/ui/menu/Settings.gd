# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## Settings (Dev D, Part 2): volume sliders and fullscreen.
## Changes apply and save instantly.

# ==========================================
# THEME
# ==========================================

const BG := Color("0B1530")
const PANEL_BG := Color("182747")
const PANEL_BORDER := Color("0D192E")

const AMBER := Color("FFC857")
const TEXT := Color("E8EEF9")

const MENU_SCENE := "res://ui/menu/MainMenu.tscn"

const SLIDERS := [
	["master", "Main volume"],
	["music", "Music"],
	["sfx", "Sound effects"]
]


# ==========================================
# INITIALIZATION
# ==========================================

func _ready() -> void:
	var settings := GameSettings.load_all()

	_create_background()
	_create_panel(settings)


# ==========================================
# BACKGROUND
# ==========================================

func _create_background() -> void:
	var bg := TextureRect.new()

	bg.texture = _tex("res://assets/images/background.png")
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE

	add_child(bg)
	Credits.corner_tag.call_deferred(self, "background.png")   # LEAD (round 9)


# ==========================================
# SETTINGS PANEL
# ==========================================

func _create_panel(settings: Dictionary) -> void:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)

	add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(850, 0)

	# Panel background and border
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = PANEL_BG
	panel_style.border_color = PANEL_BORDER

	panel_style.set_border_width_all(3)
	panel_style.set_corner_radius_all(20)

	panel_style.content_margin_left = 32
	panel_style.content_margin_right = 32
	panel_style.content_margin_top = 28
	panel_style.content_margin_bottom = 28

	panel.add_theme_stylebox_override("panel", panel_style)

	center.add_child(panel)

	# Content
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 20)

	panel.add_child(box)

	# Settings title image
	var title_image := TextureRect.new()
	title_image.texture = _tex("res://assets/images/settings.png")
	title_image.custom_minimum_size = Vector2(0, 100)
	title_image.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	title_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	title_image.mouse_filter = Control.MOUSE_FILTER_IGNORE

	box.add_child(title_image)

	# Volume sliders
	for item in SLIDERS:
		box.add_child(_create_slider_row(item, settings))

	# Fullscreen toggle
	box.add_child(_create_fullscreen_toggle(settings))

	# MERGE (Lead): the robot announcer voice on the Mission Control laptop (off by default)
	var voice := _create_fullscreen_toggle(settings)
	voice.text = "Robot announcer voice (Mission Control)"
	voice.toggled.disconnect(_on_fullscreen_toggled)
	voice.button_pressed = bool(settings.get("voice", false))
	voice.toggled.connect(func(on: bool) -> void: GameSettings.set_value("voice", on))
	box.add_child(voice)

	# MERGE (Lead): System check, for "it works on my laptop but not on theirs"
	var check := _create_back_button()
	check.text = "System check (send this to the Lead)"
	check.pressed.disconnect(_on_back_pressed)
	check.pressed.connect(func() -> void: SystemCheck.popup(self))
	box.add_child(check)

	# LEAD (round 8): MODS. Players make their own parts, instruments, crises and twists (see MODDING.md).
	var mods := _create_back_button()
	var n_mods: int = Data.mods_loaded.size()
	mods.text = "Mods: %d loaded%s  (open the mods folder)" % [n_mods, ", %d problem(s)" % Data.mod_problems.size() if not Data.mod_problems.is_empty() else ""]
	mods.tooltip_text = _mods_text()
	mods.pressed.disconnect(_on_back_pressed)
	mods.pressed.connect(func() -> void:
		var dir: String = ProjectSettings.globalize_path(Data.MOD_DIR_USER)
		DirAccess.make_dir_recursive_absolute(dir)
		if not FileAccess.file_exists(dir.path_join("README.txt")):
			var f := FileAccess.open(dir.path_join("README.txt"), FileAccess.WRITE)
			if f != null:
				f.store_string(MOD_README)
				f.close()
		OS.shell_open(dir)
		_show_mods_popup())
	box.add_child(mods)

	# Back button
	box.add_child(_create_back_button())


# ==========================================
# VOLUME SLIDERS
# ==========================================

const MOD_README := """MISSION CONTROL MODS
Put .json mod files in this folder (or in a folder called "mods" next to MissionControl.exe), then restart the game.
Every laptop in the game needs the SAME mods, or Mission Control will refuse to connect.
How to write one: see MODDING.md in the game's source, or copy example_mod.json from it.
Start the game with  -- --no-mods  to switch all mods off.
"""


func _mods_text() -> String:
	var lines: PackedStringArray = []
	for m in Data.mods_loaded:
		lines.append("%s (%s): %d new, %d changed" % [m["name"], m["file"], int(m["added"]), int(m["replaced"])])
	for p in Data.mod_problems:
		lines.append("PROBLEM: " + str(p))
	if lines.is_empty():
		lines.append("No mods loaded. Put .json files in the mods folder and restart the game.")
	return "\n".join(lines)


func _show_mods_popup() -> void:
	var d := AcceptDialog.new()
	d.title = "Mods"
	d.dialog_text = _mods_text() + "\n\nFolder: " + ProjectSettings.globalize_path(Data.MOD_DIR_USER) + "\nRestart the game after adding or changing mods."
	add_child(d)
	d.popup_centered()


func _create_slider_row(item: Array, settings: Dictionary) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)

	var name_label := _label(item[1], 24, TEXT)
	name_label.custom_minimum_size = Vector2(240, 0)
	name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	row.add_child(name_label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = float(settings[item[0]])
	slider.custom_minimum_size = Vector2(0, 40)   # taller so the handle is not clipped
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	# Thicker yellow filled portion
	var fill_style := StyleBoxFlat.new()
	fill_style.bg_color = AMBER
	fill_style.border_color = Color("B8860B")
	fill_style.set_border_width_all(2)
	fill_style.set_corner_radius_all(8)
	fill_style.content_margin_top = 4
	fill_style.content_margin_bottom = 4

	# Thicker dark track with yellow border
	var track_style := StyleBoxFlat.new()
	track_style.bg_color = Color("263653")
	track_style.border_color = Color("B8860B")
	track_style.set_border_width_all(2)
	track_style.set_corner_radius_all(8)
	track_style.content_margin_top = 4
	track_style.content_margin_bottom = 4

	slider.add_theme_stylebox_override("grabber_area", fill_style)
	slider.add_theme_stylebox_override("grabber_area_highlight", fill_style)
	slider.add_theme_stylebox_override("slider", track_style)

	# Larger white circular handle with darker yellow border (grabber is an ICON, not a stylebox)
	var handle := _circle_icon(36, Color("FFFFFF"), Color("B8860B"))
	slider.add_theme_icon_override("grabber", handle)
	slider.add_theme_icon_override("grabber_highlight", handle)

	row.add_child(slider)

	var percentage := _label(
		_get_percentage(slider.value),
		24,
		TEXT
	)

	percentage.custom_minimum_size = Vector2(90, 0)
	percentage.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	row.add_child(percentage)

	slider.value_changed.connect(
		_on_volume_changed.bind(item[0], percentage)
	)

	return row


func _circle_icon(diameter: int, fill: Color, border: Color) -> ImageTexture:
	var img := Image.create(diameter, diameter, false, Image.FORMAT_RGBA8)
	var c := Vector2(diameter, diameter) / 2.0 - Vector2(0.5, 0.5)
	var r := diameter / 2.0
	for y in diameter:
		for x in diameter:
			var d := Vector2(x, y).distance_to(c)
			if d <= r - 3.0:
				img.set_pixel(x, y, fill)
			elif d <= r:
				img.set_pixel(x, y, border)
	return ImageTexture.create_from_image(img)


func _on_volume_changed(value: float, key: String, percentage: Label) -> void:
	percentage.text = _get_percentage(value)
	GameSettings.set_value(key, value)


func _get_percentage(value: float) -> String:
	return "%d%%" % int(round(value * 100.0))


# ==========================================
# FULLSCREEN
# ==========================================

func _create_fullscreen_toggle(settings: Dictionary) -> CheckButton:
	var fullscreen := CheckButton.new()

	fullscreen.text = "Full screen"
	fullscreen.button_pressed = bool(settings["fullscreen"])
	fullscreen.custom_minimum_size = Vector2(0, 64)

	fullscreen.add_theme_font_size_override("font_size", 28)
	fullscreen.add_theme_color_override("font_color", TEXT)

	fullscreen.toggled.connect(_on_fullscreen_toggled)

	return fullscreen


func _on_fullscreen_toggled(enabled: bool) -> void:
	GameSettings.set_value("fullscreen", enabled)
	# MERGE: when the game runs INSIDE the Godot editor's Game tab, the window cannot go full screen.
	if enabled and SystemCheck.embedded_in_editor():
		var d := AcceptDialog.new()
		d.title = "Full screen"
		d.dialog_text = "The game is running inside the Godot editor's Game tab, which cannot go full screen.\n" + \
			"Use the exported game (MissionControl.exe), or turn off 'Embed Game' in the editor's Game tab."
		add_child(d)
		d.popup_centered()


# ==========================================
# BACK BUTTON
# ==========================================

func _create_back_button() -> Button:
	var back := Button.new()

	back.text = "Back"
	back.custom_minimum_size = Vector2(0, 70)

	back.add_theme_font_size_override("font_size", 24)
	back.add_theme_color_override("font_color", TEXT)

	# Button colors
	var normal := _button_style(Color("243B64"))
	var hover := _button_style(Color("192D4D"))
	var pressed := _button_style(Color("152641"))

	back.add_theme_stylebox_override("normal", normal)
	back.add_theme_stylebox_override("hover", hover)
	back.add_theme_stylebox_override("pressed", pressed)
	back.add_theme_stylebox_override("focus", normal)

	back.pressed.connect(_on_back_pressed)

	return back


func _button_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()

	style.bg_color = color
	style.border_color = color.darkened(0.25)

	style.set_border_width_all(2)
	style.set_corner_radius_all(12)

	return style


func _on_back_pressed() -> void:
	get_tree().change_scene_to_file(MENU_SCENE)


# ==========================================
# UTILITIES
# ==========================================

func _label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()

	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)

	return label


func _tex(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		return load(path) as Texture2D
	push_warning("Missing image: " + path)
	return null
