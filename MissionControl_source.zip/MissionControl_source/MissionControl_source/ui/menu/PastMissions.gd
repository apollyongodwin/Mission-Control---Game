# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.

extends Control
## Past Missions (Dev D, Part 2). Lists saved missions; tapping one opens the Debrief in read-only mode.

# ==========================================
# THEME
# ==========================================

const BG := Color("0B1530")
const PANEL_BG := Color("182747")
const PANEL_BORDER := Color("0D192E")
const INNER_BG := Color("263653")

const AMBER := Color("FFC857")
const TEXT := Color("E8EEF9")
const GOOD := Color("7CE08A")
const BAD := Color("FF7A6B")

const BUTTON_BLUE := Color("243B64")
const BUTTON_RED := Color("7A3038")
const DISABLED_BG := Color("3A4660")
const DISABLED_TEXT := Color("9AA6BD")

# ==========================================
# ASSETS
# ==========================================

const BACKGROUND_IMAGE := "res://assets/images/background.png"
const MENU_SCENE := "res://ui/menu/MainMenu.tscn"
const DEBRIEF_SCRIPT := "res://ui/debrief/Debrief.gd"

var _root: VBoxContainer


# ==========================================
# INITIALIZATION
# ==========================================

func _ready() -> void:
	_create_background()

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)

	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 20)

	add_child(margin)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	margin.add_child(scroll)

	var center := CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.add_child(center)

	var panel := _panel()
	panel.custom_minimum_size = Vector2(780, 0)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.add_child(panel)

	_root = VBoxContainer.new()
	_root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_root.add_theme_constant_override("separation", 14)
	panel.add_child(_root)

	_build_list()


# ==========================================
# BACKGROUND
# ==========================================

func _create_background() -> void:
	var solid := ColorRect.new()
	solid.color = BG
	solid.set_anchors_preset(Control.PRESET_FULL_RECT)
	solid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(solid)

	if ResourceLoader.exists(BACKGROUND_IMAGE):
		var bg := TextureRect.new()
		bg.texture = load(BACKGROUND_IMAGE) as Texture2D
		bg.set_anchors_preset(Control.PRESET_FULL_RECT)
		bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(bg)
		Credits.corner_tag.call_deferred(self, "background.png")   # LEAD (round 9): AI notice, added last so it is on top

		var tint := ColorRect.new()
		tint.color = Color(BG.r, BG.g, BG.b, 0.55)
		tint.set_anchors_preset(Control.PRESET_FULL_RECT)
		tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(tint)


# ==========================================
# MISSION LIST
# ==========================================

func _build_list() -> void:
	# CENTERED TITLE IMAGE
	var title_center := CenterContainer.new()
	title_center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_center.custom_minimum_size = Vector2(0, 90)

	var title_image := TextureRect.new()
	title_image.texture = load("res://assets/images/history.png") as Texture2D
	title_image.custom_minimum_size = Vector2(300, 72)
	title_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	title_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	title_image.mouse_filter = Control.MOUSE_FILTER_IGNORE

	title_center.add_child(title_image)
	_root.add_child(title_center)

	_root.add_child(_label("Review your previous launches and mission reports.", 20, TEXT))

	var missions := MissionStore.list_missions()

	if missions.is_empty():
		var empty_panel := _panel(INNER_BG, 18, 20)
		empty_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		var empty_label := _label("No missions yet. Go fly one!", 24, TEXT)
		empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty_panel.add_child(empty_label)

		_root.add_child(empty_panel)

	for m in missions:
		var sc_name := str(
			Data.scenario(str(m.get("scenario", ""))).get("name", "Mission")
		)

		var is_lost := bool(m.get("mission_lost", false))
		var result := "MISSION LOST" if is_lost else "Grade %s" % str(m.get("grade", "?"))
		var points := int(round(float(m.get("total", 0.0))))

		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 100)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.add_theme_font_size_override("font_size", 22)

		b.text = "%s  -  %s\n%s  |  %s  |  %d points" % [
			str(m.get("team_name", "Crew")),
			sc_name,
			str(m.get("saved_text", "")),
			result,
			points
		]

		_apply_button_theme(b, BUTTON_BLUE, TEXT)
		b.pressed.connect(_open.bind(m))
		_root.add_child(b)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 8)
	_root.add_child(spacer)

	_root.add_child(_button("BACK", _on_back, 68, BUTTON_RED, TEXT))


# ==========================================
# DEBRIEF VIEWER
# ==========================================

func _open(m: Dictionary) -> void:
	var d: Control = load(DEBRIEF_SCRIPT).new()
	d.set("read_only", true)

	add_child(d)
	d.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var ctx := {
		"design": m.get("design", {}),
		"team_name": m.get("team_name", "Pawstronauts"),
		"difficulty": m.get("difficulty", "")
	}

	d.call("show_report", m.get("report", {}), m.get("eval", {}), ctx)
	d.connect("menu_pressed", Callable(d, "queue_free"))


func _on_back() -> void:
	get_tree().change_scene_to_file(MENU_SCENE)


# ==========================================
# THEMED WIDGET HELPERS
# ==========================================

func _panel(
	color: Color = PANEL_BG,
	margin_h: int = 20,
	margin_v: int = 14
) -> PanelContainer:
	var panel := PanelContainer.new()

	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = PANEL_BORDER
	style.set_border_width_all(3)
	style.set_corner_radius_all(20)
	style.content_margin_left = margin_h
	style.content_margin_right = margin_h
	style.content_margin_top = margin_v
	style.content_margin_bottom = margin_v

	panel.add_theme_stylebox_override("panel", style)
	return panel


func _button_style(color: Color, bevel_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = bevel_color
	style.border_width_top = 2
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_bottom = 4
	style.set_corner_radius_all(15)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 8
	style.content_margin_bottom = 10
	return style


func _apply_button_theme(
	b: Button,
	bg_color: Color,
	text_color: Color
) -> void:
	var bevel := bg_color.darkened(0.25)

	var normal := _button_style(bg_color, bevel)
	var hover := _button_style(bevel, bevel)
	var pressed := _button_style(bg_color.darkened(0.35), bevel)
	pressed.border_width_top = 4
	pressed.border_width_bottom = 2

	var disabled := _button_style(
		DISABLED_BG,
		DISABLED_BG.darkened(0.25)
	)

	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_stylebox_override("focus", normal)

	for c in [
		"font_color",
		"font_hover_color",
		"font_pressed_color",
		"font_focus_color"
	]:
		b.add_theme_color_override(c, text_color)

	b.add_theme_color_override("font_disabled_color", DISABLED_TEXT)


func _button(
	text: String,
	handler: Callable,
	height: int = 70,
	bg: Color = BUTTON_BLUE,
	fg: Color = TEXT
) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, height)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 24)

	_apply_button_theme(b, bg, fg)

	if handler.is_valid():
		b.pressed.connect(handler)

	return b


func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l
