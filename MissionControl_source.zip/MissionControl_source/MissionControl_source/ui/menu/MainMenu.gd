# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## MainMenu (Dev D). UI is built entirely in code.

# ==========================================
# THEME
# ==========================================

const BG := Color("0B1530")
const AMBER := Color("FFC857")
const TEXT := Color("E8EEF9")

const BUTTON_BLUE := Color("243B64")
const BUTTON_RED := Color("7A3038")

# ==========================================
# SCENE PATHS
# ==========================================

const LOBBY_SCENE := "res://ui/menu/Lobby.tscn"
const PAST_SCENE := "res://ui/menu/PastMissions.tscn"
const SETTINGS_SCENE := "res://ui/menu/Settings.tscn"

# ==========================================
# INITIALIZATION
# ==========================================

func _ready() -> void:
	GameSettings.apply()
	_create_background()
	_create_menu()
	_show_notice()
	Audio.play_music()   # MERGE (Lead): the lounge music loop (Settings > Music volume)
	LaunchArgs.apply_once(self)   # MERGE (Lead): --host / --join=IP / --role=systems for quick multi-window testing


## MERGE (Lead): a one-line message from the last screen (e.g. "Lost the connection to Mission Control").
func _show_notice() -> void:
	var msg: String = str(Engine.get_meta("menu_notice", ""))
	if msg == "":
		return
	Engine.set_meta("menu_notice", "")
	var l := Label.new()
	l.text = msg
	l.add_theme_font_size_override("font_size", 24)
	l.add_theme_color_override("font_color", AMBER)
	l.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	l.position.y -= 60
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(l)

# ==========================================
# BACKGROUND
# ==========================================

func _create_background() -> void:
	var bg := TextureRect.new()
	bg.texture = load("res://assets/images/background.png")
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED

	add_child(bg)
	Credits.corner_tag.call_deferred(self, "background.png")   # LEAD (round 9): "Background: AI-generated / AI-assisted"

# ==========================================
# MAIN MENU
# ==========================================

func _create_menu() -> void:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 500

	add_child(center)

	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(480, 0)
	box.add_theme_constant_override("separation", 8)

	center.add_child(box)

	_create_logo(box)
	_create_buttons(box)

# ==========================================
# LOGO
# ==========================================

func _create_logo(parent: VBoxContainer) -> void:
	var logo := TextureRect.new()
	logo.texture = load("res://assets/images/mission_control.png")
	logo.custom_minimum_size = Vector2(500, 250)
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

	parent.add_child(logo)
	parent.add_child(_spacer(10))

# ==========================================
# BUTTON CREATION
# ==========================================

func _create_buttons(parent: VBoxContainer) -> void:
	# Host Mission Control
	parent.add_child(
		_create_button("Host a Mission", _on_host, AMBER, BG)
	)

	# Join as Crew
	parent.add_child(
		_create_button("Join as Crew", _on_join, BUTTON_BLUE, TEXT)
	)

	# Past Missions and Settings
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)

	row.add_child(
		_create_button("Past Missions", _on_past, BUTTON_BLUE, TEXT, 250)
	)

	row.add_child(
		_create_button("Settings", _on_settings, BUTTON_BLUE, TEXT, 250)
	)

	parent.add_child(row)

	# LEAD (round 9): who made what, and what was AI-assisted (data/credits.json)
	parent.add_child(
		_create_button("Credits & AI use", func() -> void: Credits.popup(self), BUTTON_BLUE, TEXT)
	)

	# Quit
	parent.add_child(
		_create_button("Quit", _on_quit, BUTTON_RED, TEXT)
	)


func _create_button(
	button_text: String,
	handler: Callable,
	bg_color: Color,
	text_color: Color,
	width: int = 450
) -> Button:
	var button := Button.new()

	button.text = button_text
	button.custom_minimum_size = Vector2(width, 70)

	button.add_theme_font_size_override("font_size", 20)
	button.add_theme_color_override("font_color", text_color)
	button.add_theme_color_override("font_hover_color", text_color)
	button.add_theme_color_override("font_pressed_color", text_color)
	button.add_theme_color_override("font_focus_color", text_color)

	# Calculate the bevel once using the original button color
	var bevel_color := bg_color.darkened(0.25)

	# Button states
	var normal_style := _button_style(bg_color, bevel_color)
	var hover_style := _button_style(bevel_color, bevel_color)
	var pressed_style := _button_style(bg_color.darkened(0.35), bevel_color)

	# Normal appearance
	button.add_theme_stylebox_override("normal", normal_style)

	# Hover: background changes, bevel stays the same
	button.add_theme_stylebox_override("hover", hover_style)

	# Pressed: darker background, same bevel
	pressed_style.border_width_bottom = 2
	pressed_style.border_width_top = 4
	button.add_theme_stylebox_override("pressed", pressed_style)

	# Focus appearance
	button.add_theme_stylebox_override("focus", normal_style)

	button.pressed.connect(handler)

	return button

# ==========================================
# BUTTON STYLE
# ==========================================

func _button_style(color: Color, bevel_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()

	style.bg_color = color

	# Fixed bevel color
	style.border_color = bevel_color

	style.border_width_top = 2
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_bottom = 4

	# Rounded corners
	style.set_corner_radius_all(15)

	# Text padding
	style.content_margin_left = 20
	style.content_margin_right = 20
	style.content_margin_top = 15
	style.content_margin_bottom = 17

	return style

# ==========================================
# NAVIGATION
# ==========================================

func _on_host() -> void:
	Engine.set_meta("lobby_mode", "host")
	get_tree().change_scene_to_file(LOBBY_SCENE)


func _on_join() -> void:
	Engine.set_meta("lobby_mode", "client")
	get_tree().change_scene_to_file(LOBBY_SCENE)


func _on_past() -> void:
	get_tree().change_scene_to_file(PAST_SCENE)


func _on_settings() -> void:
	get_tree().change_scene_to_file(SETTINGS_SCENE)


func _on_quit() -> void:
	get_tree().quit()

# ==========================================
# UTILITIES
# ==========================================

func _spacer(height: int) -> Control:
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, height)

	return spacer
