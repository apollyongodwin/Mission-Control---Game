# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.

extends Control
## Lobby (Dev D). HOST (Mission Control) and CLIENT (crew member).
## Styled to match MainMenu and Settings.
## Host: two columns (crew roster left, mission configuration right).
## Client: one centred panel with selectable crew cards.

signal start_pressed(settings: Dictionary)

const ROLES: Array[String] = ["flight", "systems", "payload", "ground"]

# ---- THEME ----
const BG := Color("0B1530")
const PANEL_BG := Color("182747")
const PANEL_BORDER := Color("0D192E")
const INNER_BG := Color("263653")
const AMBER := Color("FFC857")
const TEXT := Color("E8EEF9")
const GOOD := Color("7CE08A")
const BUTTON_BLUE := Color("243B64")
const BUTTON_RED := Color("7A3038")
const DISABLED_BG := Color("3A4660")
const DISABLED_TEXT := Color("9AA6BD")

const BACKGROUND_IMAGE := "res://assets/images/background.png"
const HOST_TITLE_IMAGE := "res://assets/images/lobby.png"
const CLIENT_TITLE_IMAGE := "res://assets/images/client.png"
const MENU_SCENE := "res://ui/menu/MainMenu.tscn"
const HOST_SCREEN := "res://ui/main/HostScreen.tscn"   # MERGE (Lead): after START
const CREW_SCREEN := "res://ui/main/CrewScreen.tscn"   # MERGE (Lead): when the host starts the mission
const ROLE_ICON_PATH := "res://assets/images/roles/%s.png"

const DIFFS := [
	["cadet", "Cadet (easiest, start here)"],
	["engineer", "Engineer"],
	["flight_director", "Flight Director (hard)"],
]

const LENGTHS := [
	["short", "Short mission"],
	["full", "Full mission"],
]

const ROLE_BADGES := {
	"flight": "F",
	"systems": "S",
	"payload": "P",
	"ground": "G",
}

var _mode := "host"
var _my_role := ""
var _ready_on := false

var _status: Label
var _scenario_opt: OptionButton
var _diff_opt: OptionButton
var _len_opt: OptionButton
var _demo: CheckButton
var _build_opt: OptionButton
var _team: LineEdit
var _ip_field: LineEdit
var _ready_btn: Button
var _you_label: Label

var _seat_parts: Dictionary = {}
var _scenario_ids: Array[String] = []
var _seat_widgets: Dictionary = {}
var _seat_sig: Dictionary = {}

var _disc: Discovery
var _found_box: VBoxContainer
var _listen_error: int = OK


# ==========================================
# INITIALIZATION
# ==========================================

func _ready() -> void:
	_mode = str(Engine.get_meta("lobby_mode", "host"))

	_create_background()

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)

	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)

	add_child(margin)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	margin.add_child(scroll)

	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 10)
	scroll.add_child(box)

	_status = _label("", 22, AMBER)
	_status.visible = false

	if _mode == "host":
		_build_host(box)
		_hook_host_game()
		_start_beacon()
	else:
		_build_client(box)

	var ms := _ms()
	if ms != null and ms.has_signal("seats_changed"):
		ms.connect("seats_changed", _refresh_seats)

	var t := Timer.new()
	t.wait_time = 0.5
	t.autostart = true
	t.timeout.connect(_refresh_seats)
	add_child(t)

	multiplayer.connected_to_server.connect(_on_connected_ok)
	multiplayer.connection_failed.connect(_on_connect_failed)
	if _mode != "host":
		add_child(ChatDrawer.new())   # MERGE (Part 3): chat with the crew while waiting

	# MERGE (Lead): the host's START moves every crew laptop to its role screen.
	MissionState.phase_changed.connect(_on_phase_changed)
	if _mode != "host" and Net.is_client():
		_my_role = MissionState.local_role   # back from a mission: still connected, still seated
		_set_status("Connected! Waiting for Mission Control to start.")
	Net.server_message_received.connect(func(code: String, text: String) -> void:
		if code in ["seat_rejected", "no_seat"]:
			_my_role = ""
			_seat_sig.clear()
			_refresh_seats()
			_set_status(text)
		elif code == "version_mismatch":   # MERGE (LAN fix): say it loudly, it explains every weird bug
			_set_status("Different game copies! See the message.")
			var d := AcceptDialog.new()
			d.title = "Update your copy"
			d.dialog_text = text
			add_child(d)
			d.popup_centered(Vector2i(820, 300)))

	_refresh_seats()


func _on_phase_changed(p: String) -> void:
	if not is_inside_tree():
		return
	if _mode != "host" and Net.is_client() and p != "LOBBY":
		get_tree().change_scene_to_file.call_deferred(CREW_SCREEN)


func _on_connected_ok() -> void:
	_set_status("Connected! Pick your seat.")

	if _my_role != "":
		_hook_request_seat(_my_role)


func _on_connect_failed() -> void:
	_set_status("Could not connect. Check the address and try again.")


# ==========================================
# BACKGROUND
# ==========================================

func _create_background() -> void:
	var solid := ColorRect.new()
	solid.color = BG
	solid.set_anchors_preset(Control.PRESET_FULL_RECT)
	solid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(solid)

	var bg := TextureRect.new()
	bg.texture = _tex(BACKGROUND_IMAGE)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	Credits.corner_tag.call_deferred(self, "background.png")   # LEAD (round 9): AI notice, added last so it is on top

	var tint := ColorRect.new()
	tint.color = Color(BG.r, BG.g, BG.b, 0.55)
	tint.set_anchors_preset(Control.PRESET_FULL_RECT)
	tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tint)


# ==========================================
# HOST VIEW
# ==========================================

func _build_host(box: VBoxContainer) -> void:
	# TOP BAR
	var header := Control.new()
	header.custom_minimum_size = Vector2(0, 72)
	box.add_child(header)

	var title_center := CenterContainer.new()
	title_center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	title_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title_center)
	title_center.add_child(_make_title(HOST_TITLE_IMAGE, "MISSION CONTROL"))

	var side := HBoxContainer.new()
	side.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	side.add_theme_constant_override("separation", 14)
	header.add_child(side)

	var addr_panel := _panel(PANEL_BG, 14, 4)
	addr_panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	side.add_child(addr_panel)

	var addr_box := VBoxContainer.new()
	addr_box.add_theme_constant_override("separation", 0)
	addr_panel.add_child(addr_box)

	var addr_title := _label("Crew address", 20, TEXT)
	addr_title.autowrap_mode = TextServer.AUTOWRAP_OFF
	addr_box.add_child(addr_title)

	var ip_label := _label(_local_ip(), 32, GOOD)
	ip_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	addr_box.add_child(ip_label)
	# MERGE (LAN fix): a laptop can have several addresses; show the others too, smaller
	var others: Array = NetInfo.other_ips()
	if not others.is_empty():
		var ol := _label("or try: " + ", ".join(others.slice(0, 3)), 15, TEXT)
		ol.autowrap_mode = TextServer.AUTOWRAP_OFF
		addr_box.add_child(ol)
	var help_btn := _button("Crew can't connect?", _show_net_help, 40, BUTTON_BLUE, TEXT, 0)
	help_btn.add_theme_font_size_override("font_size", 16)
	side.add_child(help_btn)

	var gap := Control.new()
	gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	side.add_child(gap)

	side.add_child(_button("BACK", _on_back, 64, BUTTON_RED, TEXT, 140))

	# TWO-COLUMN LAYOUT
	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 20)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(columns)

	# LEFT: CREW ROSTER
	var roster_panel := _panel()
	roster_panel.custom_minimum_size = Vector2(300, 0)
	roster_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	roster_panel.size_flags_stretch_ratio = 0.85
	columns.add_child(roster_panel)

	var roster_box := VBoxContainer.new()
	roster_box.add_theme_constant_override("separation", 10)
	roster_panel.add_child(roster_box)

	roster_box.add_child(_label("CREW ROSTER", 28, AMBER))

	for role in ROLES:
		roster_box.add_child(_create_host_seat(role))

	roster_box.add_child(_status)

	# RIGHT: MISSION CONFIGURATION
	var config_panel := _panel()
	config_panel.custom_minimum_size = Vector2(400, 0)
	config_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	config_panel.size_flags_stretch_ratio = 1.15
	columns.add_child(config_panel)

	var config_box := VBoxContainer.new()
	config_box.add_theme_constant_override("separation", 8)
	config_panel.add_child(config_box)

	config_box.add_child(_label("MISSION CONFIGURATION", 28, AMBER))
	var opts_scroll := ScrollContainer.new()   # round 8: more options than fit on a small screen
	opts_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	opts_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	config_box.add_child(opts_scroll)
	var opts := VBoxContainer.new()
	opts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	opts.add_theme_constant_override("separation", 8)
	opts_scroll.add_child(opts)

	_team = LineEdit.new()
	_team.text = "Pawstronauts"
	_team.placeholder_text = "Team name"
	_style_line_edit(_team)
	opts.add_child(_row("Team name", _team))

	_scenario_opt = OptionButton.new()
	for sc in Data.db["scenarios"]:
		_scenario_ids.append(str(sc["id"]))
		_scenario_opt.add_item(str(sc["name"]))
		_scenario_opt.set_item_tooltip(
			_scenario_opt.item_count - 1,
			str(sc.get("subtitle", ""))
		)

	_style_option(_scenario_opt)
	opts.add_child(_row("Mission", _scenario_opt))

	_diff_opt = OptionButton.new()
	for d in DIFFS:
		_diff_opt.add_item(d[1])

	_style_option(_diff_opt)
	opts.add_child(_row("Difficulty", _diff_opt))

	_len_opt = OptionButton.new()
	for l in LENGTHS:
		_len_opt.add_item(l[1])

	_style_option(_len_opt)
	# round 8: build time (customisable clock), next to the length
	_build_opt = OptionButton.new()
	var bopts: Array = Data.db["meta"].get("build_clock", {}).get("options_s", [120, 180, 240, 300])
	for sec in bopts:
		_build_opt.add_item("Build %d:%02d" % [int(sec) / 60, int(sec) % 60])
	_build_opt.tooltip_text = "How long the crew has to build before investors start taking money back."
	_style_option(_build_opt)
	_build_opt.select(maxi(0, bopts.find(MissionState.build_seconds)))
	_build_opt.item_selected.connect(func(i: int) -> void: MissionState.set_build_seconds(int(bopts[i])))
	var len_row := HBoxContainer.new()
	len_row.add_theme_constant_override("separation", 8)
	len_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_len_opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_build_opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	len_row.add_child(_len_opt)
	len_row.add_child(_build_opt)
	opts.add_child(_row("Length", len_row))

	_demo = CheckButton.new()
	_demo.text = "Demo Mode (same result every time)"
	_demo.custom_minimum_size = Vector2(0, 40)
	_demo.add_theme_font_size_override("font_size", 22)

	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		_demo.add_theme_color_override(c, TEXT)

	opts.add_child(_demo)

	# round 8: one random twist per mission, so no two games feel the same
	var tw := CheckButton.new()
	tw.text = "Mission twists (a surprise rule each game)"
	tw.custom_minimum_size = Vector2(0, 40)
	tw.add_theme_font_size_override("font_size", 22)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		tw.add_theme_color_override(c, TEXT)
	tw.button_pressed = MissionState.twists_on
	tw.toggled.connect(func(on: bool) -> void: MissionState.set_twists_on(on))
	opts.add_child(tw)

	# MERGE (Part 3): classroom mode for the crew chat
	var quick := CheckButton.new()
	quick.text = "Chat: quick phrases only (no typing)"
	quick.custom_minimum_size = Vector2(0, 40)
	quick.add_theme_font_size_override("font_size", 22)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		quick.add_theme_color_override(c, TEXT)
	quick.button_pressed = not Net.typed_chat_allowed
	quick.toggled.connect(func(on: bool) -> void: Net.typed_chat_allowed = not on)
	opts.add_child(quick)
	# LEAD (round 4): this laptop is the Commander with the handbook (crew can't see right/wrong)
	var cmd := CheckButton.new()
	cmd.text = "Commander mode: I hold the handbook"
	cmd.tooltip_text = "ON: the crew can't see if their picks are right or the budget; you mark them OK or SWAP and talk them through crises.\nOFF: classic mode, everyone sees everything on their own screen."
	cmd.custom_minimum_size = Vector2(0, 40)
	cmd.add_theme_font_size_override("font_size", 22)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		cmd.add_theme_color_override(c, TEXT)
	cmd.button_pressed = MissionState.commander_mode
	cmd.toggled.connect(func(on: bool) -> void: MissionState.set_commander_mode(on))
	opts.add_child(cmd)
	var hb := _button("Open the Commander's Handbook (PDF to print)", _open_handbook, 44, BUTTON_BLUE, TEXT, 0)
	hb.add_theme_font_size_override("font_size", 18)
	opts.add_child(hb)


	config_box.add_child(_button("INITIATE LAUNCH", _on_start, 64, AMBER, BG))


func _make_title(image_path: String, fallback_text: String) -> Control:
	var tex := _tex(image_path)

	if tex == null:
		var fallback := _label(fallback_text, 40, AMBER)
		fallback.autowrap_mode = TextServer.AUTOWRAP_OFF
		return fallback

	var img := TextureRect.new()
	img.texture = tex
	img.custom_minimum_size = Vector2(300, 72)
	img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	img.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return img


func _create_host_seat(role: String) -> PanelContainer:
	var card := _panel(INNER_BG, 12, 8)
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	card.add_child(row)

	var roles: Dictionary = Data.db["meta"]["roles"]
	var info: Dictionary = roles[role]

	row.add_child(CrewArt.make(role, 64))   # MERGE: cat astronaut portrait (assets/images/roles/<role>.png)

	var info_box := VBoxContainer.new()
	info_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_box.add_theme_constant_override("separation", 0)
	info_box.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(info_box)

	info_box.add_child(_label(str(info["name"]).to_upper(), 22, TEXT))

	var status := _label("[ ] Waiting for crew", 20, TEXT)
	info_box.add_child(status)
	_seat_widgets[role] = status

	return card


func _on_start() -> void:
	var settings := {
		"scenario": _scenario_ids[maxi(_scenario_opt.selected, 0)],
		"difficulty": DIFFS[maxi(_diff_opt.selected, 0)][0],
		"length": LENGTHS[maxi(_len_opt.selected, 0)][0],
		"demo_mode": _demo.button_pressed,
		"team_name": _team.text.strip_edges() if _team.text.strip_edges() != "" else "Pawstronauts",
	}

	start_pressed.emit(settings)
	# MERGE (Lead): apply the settings, start the mission, switch to the broadcast screen.
	MissionState.set_team_name(str(settings["team_name"]))
	MissionState.set_scenario(str(settings["scenario"]))
	MissionState.set_difficulty(str(settings["difficulty"]))
	MissionState.set_mission_length(str(settings["length"]))
	MissionState.set_demo_mode(bool(settings["demo_mode"]))
	Net.host_set_phase("BRIEFING")
	get_tree().change_scene_to_file(HOST_SCREEN)


# ==========================================
# CLIENT VIEW
# ==========================================

func _build_client(box: VBoxContainer) -> void:
	box.alignment = BoxContainer.ALIGNMENT_CENTER

	var panel := _panel(PANEL_BG, 28, 16)
	panel.custom_minimum_size = Vector2(780, 0)
	panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(panel)

	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 8)
	panel.add_child(inner)

	var title_center := CenterContainer.new()
	title_center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_center.custom_minimum_size = Vector2(0, 90)
	inner.add_child(title_center)

	var title_image := _make_title(CLIENT_TITLE_IMAGE, "JOIN THE CREW")
	title_center.add_child(title_image)

	inner.add_child(_status)

	_ip_field = LineEdit.new()
	_ip_field.text = "127.0.0.1"
	_ip_field.placeholder_text = "Type the address shown on Mission Control"
	_style_line_edit(_ip_field)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.add_child(_ip_field)
	row.add_child(_button("Connect", _on_connect, 64, AMBER, BG, 200))
	inner.add_child(row)

	inner.add_child(_label("Games found (or type the address above)", 24, AMBER))

	_found_box = VBoxContainer.new()
	_found_box.add_theme_constant_override("separation", 8)
	inner.add_child(_found_box)

	_start_listen()

	_you_label = _label("Pick your seat", 24, AMBER)
	inner.add_child(_you_label)

	var seat_grid := GridContainer.new()
	seat_grid.columns = 2
	seat_grid.add_theme_constant_override("h_separation", 12)
	seat_grid.add_theme_constant_override("v_separation", 8)
	inner.add_child(seat_grid)

	for role in ROLES:
		var b := _create_client_seat(role)
		seat_grid.add_child(b)
		_seat_widgets[role] = b

	# READY AND BACK
	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 12)
	inner.add_child(bottom)

	_ready_btn = _button("PICK A SEAT FIRST", Callable(), 72, BUTTON_BLUE, TEXT)
	_ready_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_ready_btn.toggle_mode = true
	_ready_btn.disabled = true

	var on_style := _button_style(GOOD, GOOD.darkened(0.25))
	_ready_btn.add_theme_stylebox_override("pressed", on_style)
	_ready_btn.add_theme_color_override("font_pressed_color", BG)
	_ready_btn.add_theme_color_override("font_hover_pressed_color", BG)
	_ready_btn.toggled.connect(_on_ready_toggled)
	bottom.add_child(_ready_btn)

	bottom.add_child(_button("Back", _on_back, 72, BUTTON_RED, TEXT, 160))


func _on_connect() -> void:
	var ip := _ip_field.text.strip_edges()

	if ip == "":
		_set_status("Please type the host address first.")
		return

	_set_status("Connecting to %s ..." % ip)
	_hook_join(ip)


## LEAD (round 4): open the printable handbook that ships next to the game (or inside the project).
func _open_handbook() -> void:
	var candidates: Array = [OS.get_executable_path().get_base_dir().path_join("Commander_Handbook.pdf"),
		ProjectSettings.globalize_path("res://handbook/Commander_Handbook.pdf")]
	for p in candidates:
		if FileAccess.file_exists(p):
			OS.shell_open(p)
			return
	var d := AcceptDialog.new()
	d.title = "Handbook"
	d.dialog_text = "Commander_Handbook.pdf should sit next to MissionControl.exe.\nAsk the Lead for it, or use the handbook tabs on the Commander screen."
	add_child(d)
	d.popup_centered()


func _on_seat_pressed(role: String) -> void:
	if role == _my_role:
		return
	# MERGE (LAN fix): a seat request sent before the connection is up is lost, but the lobby used to show
	# the seat as yours anyway; then a bot took it at launch. Only ask once connected.
	if not (multiplayer.has_multiplayer_peer() and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED and Net.is_client()):
		_set_status("Connect to Mission Control first, then pick your seat.")
		return
	_set_status("Asking Mission Control for the %s seat..." % role.to_upper())

	_my_role = role
	_hook_request_seat(role)
	_seat_sig.clear()
	_refresh_seats()


func _on_ready_toggled(on: bool) -> void:
	if _my_role == "":
		_ready_on = false
		if _ready_btn != null:
			_ready_btn.set_pressed_no_signal(false)
		_update_ready_button()
		return

	_ready_on = on
	_update_ready_button()
	_hook_ready(on)


# ==========================================
# CLIENT SEAT CARDS
# ==========================================

func _create_client_seat(role: String) -> Button:
	var info: Dictionary = Data.db["meta"]["roles"][role]
	var color := Color(str(info["color"]))

	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 76)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.clip_contents = true
	b.tooltip_text = str(info.get("private_goal", ""))
	b.pressed.connect(_on_seat_pressed.bind(role))

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_theme_constant_override("margin_left", 14)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	b.add_child(margin)

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12)
	margin.add_child(row)

	row.add_child(_make_role_icon(role, 52))

	var texts := VBoxContainer.new()
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.alignment = BoxContainer.ALIGNMENT_CENTER
	texts.add_theme_constant_override("separation", 0)
	row.add_child(texts)

	var title := _label(str(info["title"]), 22, BG)
	title.autowrap_mode = TextServer.AUTOWRAP_OFF
	title.clip_text = true
	texts.add_child(title)

	var status := _label("", 20, BG)
	status.autowrap_mode = TextServer.AUTOWRAP_OFF
	status.clip_text = true
	texts.add_child(status)

	_seat_parts[role] = {
		"button": b,
		"title": title,
		"status": status,
		"color": color
	}

	_style_seat(role, "free")
	return b


func _make_role_icon(role: String, px: int) -> Control:
	var path := ROLE_ICON_PATH % role

	if ResourceLoader.exists(path):
		var img := TextureRect.new()
		img.texture = load(path) as Texture2D
		img.custom_minimum_size = Vector2(px, px)
		img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		img.mouse_filter = Control.MOUSE_FILTER_IGNORE
		return img

	if true:   # MERGE: shared cat placeholder until the art arrives
		return CrewArt.make(role, px)

	var color := Color(str(Data.db["meta"]["roles"][role]["color"]))

	var badge := PanelContainer.new()
	badge.custom_minimum_size = Vector2(px, px)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var st := StyleBoxFlat.new()
	st.bg_color = BG
	st.set_corner_radius_all(int(px * 0.5))
	badge.add_theme_stylebox_override("panel", st)

	var l := _label(str(ROLE_BADGES[role]), 30, color)
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.add_child(l)

	return badge


func _style_seat(role: String, state: String) -> void:
	var p: Dictionary = _seat_parts[role]
	var b: Button = p["button"]
	var color: Color = p["color"]
	var title: Label = p["title"]
	var status: Label = p["status"]
	var ink := BG

	match state:
		"mine":
			var selected_color := color.darkened(0.4)
			var selected_style := _button_style(selected_color, selected_color.darkened(0.2))

			selected_style.set_border_width_all(6)

			b.add_theme_stylebox_override("normal", selected_style)
			b.add_theme_stylebox_override("hover", selected_style)
			b.add_theme_stylebox_override("pressed", selected_style)
			b.add_theme_stylebox_override("focus", selected_style)
			b.add_theme_stylebox_override("disabled", selected_style)

			b.disabled = false
			ink = Color.WHITE
			status.text = "[OK] This is you!"

		"taken":
			_apply_button_theme(b, DISABLED_BG, DISABLED_TEXT)
			b.disabled = true
			ink = DISABLED_TEXT
			status.text = "[X] Taken"

		_:
			_apply_button_theme(b, color, BG)
			b.disabled = false
			ink = BG
			status.text = "Tap to choose"

	title.add_theme_color_override("font_color", ink)
	status.add_theme_color_override("font_color", ink)


func _update_you_label() -> void:
	if _my_role == "":
		_you_label.text = "Pick your seat"
		_you_label.add_theme_color_override("font_color", AMBER)
	else:
		var info: Dictionary = Data.db["meta"]["roles"][_my_role]
		var role_color: Color = _seat_parts[_my_role]["color"]

		_you_label.text = "You are: %s!" % info["title"].to_upper()
		_you_label.add_theme_color_override("font_color", role_color)


func _update_ready_button() -> void:
	if _ready_btn == null:
		return

	var has_seat := _my_role != ""
	_ready_btn.disabled = not has_seat

	if not has_seat:
		if _ready_on:
			_ready_on = false
			_ready_btn.set_pressed_no_signal(false)

		_ready_btn.text = "PICK A SEAT FIRST"
	else:
		_ready_btn.text = "READY!!!" if _ready_on else "READY UP"


# ==========================================
# SEAT DISPLAY
# ==========================================

func _refresh_seats() -> void:
	if _seat_widgets.is_empty() or not is_inside_tree():   # MERGE: signals can arrive while the scene is switching
		return

	var me := multiplayer.get_unique_id() if multiplayer.has_multiplayer_peer() else 0

	for role in ROLES:
		var owner_id := _seat_owner(role)
		var sig := "%d|%d|%s|%s" % [owner_id, me, _my_role, str(MissionState.seat_ready.get(role, false))]

		if _seat_sig.get(role, "") == sig:
			continue

		_seat_sig[role] = sig

		var taken := owner_id != 0

		if _mode == "host":
			var w: Label = _seat_widgets[role]
			if owner_id == -2:
				w.text = "[..] Reconnecting..."
			elif owner_id == -1:
				w.text = "[BOT] AutoCrew"
			elif taken and bool(MissionState.seat_ready.get(role, false)):
				w.text = "READY!"   # MERGE: the host can see who pressed READY
			elif taken:
				w.text = "Joined - not ready yet"
			else:
				w.text = "[ ] Empty: a bot will fly it"
			var is_ready: bool = taken and bool(MissionState.seat_ready.get(role, false))
			w.add_theme_color_override("font_color", GOOD if is_ready else (AMBER if taken else TEXT))
		else:
			var state := "free"

			if taken and me != 0 and owner_id == me:
				_my_role = role
				state = "mine"
			elif _my_role == role and not taken:
				state = "mine"
			elif taken:
				state = "taken"

				if _my_role == role:
					_my_role = ""
					_set_status("Someone else took that seat. Pick another one.")

			_style_seat(role, state)

	if _mode != "host":
		_update_you_label()
		_update_ready_button()


func _seat_owner(role: String) -> int:
	## 0 = free. MissionState.seats is expected to be a Dictionary role -> peer id.
	var ms := _ms()

	if ms == null:
		return 0

	var seats = ms.get("seats")

	if typeof(seats) != TYPE_DICTIONARY:
		return 0

	var v = seats.get(role, 0)

	if v == null:
		return 0

	if typeof(v) == TYPE_INT:
		return v   # MERGE: -1 = AutoCrew bot, -2 = seat held for a dropped player; non-zero = taken

	return 1 if str(v) != "" else 0


# ==========================================
# LEAD HOOKS
# ==========================================

func _net() -> Node:
	return get_node_or_null("/root/Net")


func _ms() -> Node:
	return get_node_or_null("/root/MissionState")


func _hook_host_game() -> void:
	var n := _net()

	if n != null and n.has_method("is_host") and n.call("is_host"):
		_restore_host_settings()   # MERGE: back from a mission, keep the crew connected
	elif n != null and n.has_method("host_game"):
		var err: int = n.call("host_game")
		if err != OK:
			_set_status("Could not open port 7777. Is another Mission Control already running on this laptop?")
		_apply_cmdline_presets()
	else:
		_set_status("Net.gd is not ready yet (Lead's file). Layout only for now.")


func _hook_join(ip: String) -> void:
	var n := _net()

	if n != null and n.has_method("join_game"):
		var err: int = n.call("join_game", ip)
		if err != OK:
			_set_status("That address does not look right. Type the numbers shown on Mission Control, like 192.168.1.23")
			return
		# MERGE (LAN fix): ENet keeps trying for ~30 s; tell people what to check much sooner
		var attempt := ip
		get_tree().create_timer(8.0).timeout.connect(func() -> void:
			if is_inside_tree() and Net.is_client() and multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
				_set_status("Still trying %s... Same Wi-Fi? Firewall allowed? Try another address shown on Mission Control." % attempt))
	else:
		_set_status("Net.gd is not ready yet (Lead's file). Layout only for now.")


func _hook_request_seat(role: String) -> void:
	var n := _net()

	if n != null and n.has_method("request_seat"):
		n.call("request_seat", role)


func _hook_ready(on: bool) -> void:
	var n := _net()

	if n != null and n.has_method("set_seat_ready"):   # MERGE: spec name `ready`, Net's name set_seat_ready
		n.call("set_seat_ready", on)


# ==========================================
# DISCOVERY
# ==========================================

func _start_beacon() -> void:
	_disc = Discovery.new()
	add_child(_disc)

	var nm := "Mission Control"

	if _team != null and _team.text.strip_edges() != "":
		nm = _team.text.strip_edges()

	_disc.start_beacon(nm, _local_ip(), 7777)

	if _team != null:
		_team.text_changed.connect(_on_team_changed)


func _on_team_changed(t: String) -> void:
	if _disc != null:
		_disc.set_beacon_name(t)


func _start_listen() -> void:
	_disc = Discovery.new()
	add_child(_disc)

	_disc.hosts_changed.connect(_rebuild_found)
	_listen_error = _disc.start_listen()

	_rebuild_found()


func _rebuild_found() -> void:
	if _found_box == null:
		return

	for c in _found_box.get_children():
		c.queue_free()

	if _listen_error != OK:
		_found_box.add_child(_label("Could not search on this computer. Type the address above instead.", 22, AMBER))
		return

	var list := _disc.get_sorted()

	if list.is_empty():
		_found_box.add_child(_label("Looking for games...", 22, TEXT))

	for h in list:
		_found_box.add_child(_button(
			"%s   (%s)" % [h["name"], h["ip"]],
			_on_found_pressed.bind(str(h["ip"])),
			64
		))


func _on_found_pressed(ip: String) -> void:
	_ip_field.text = ip
	_on_connect()


# ==========================================
# THEMED WIDGET HELPERS
# ==========================================

func _panel(color: Color = PANEL_BG, margin_h: int = 20, margin_v: int = 14) -> PanelContainer:
	var panel := PanelContainer.new()

	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = PANEL_BORDER
	style.set_border_width_all(3)
	style.set_corner_radius_all(20)
	style.content_margin_left = margin_h
	style.content_margin_right = margin_h
	style.content_margin_top = margin_v
	style.content_margin_bottom = margin_v

	panel.add_theme_stylebox_override("panel", style)
	return panel


func _button_style(color: Color, bevel_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = bevel_color
	style.border_width_top = 2
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_bottom = 4
	style.set_corner_radius_all(15)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 8
	style.content_margin_bottom = 10
	return style


func _apply_button_theme(b: Button, bg_color: Color, text_color: Color) -> void:
	var bevel := bg_color.darkened(0.25)

	var normal := _button_style(bg_color, bevel)
	var hover := _button_style(bevel, bevel)
	var pressed := _button_style(bg_color.darkened(0.35), bevel)
	pressed.border_width_top = 4
	pressed.border_width_bottom = 2

	var disabled := _button_style(DISABLED_BG, DISABLED_BG.darkened(0.25))

	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_stylebox_override("focus", normal)

	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(c, text_color)

	b.add_theme_color_override("font_disabled_color", DISABLED_TEXT)


func _button(
	text: String,
	handler: Callable,
	height: int = 70,
	bg: Color = BUTTON_BLUE,
	fg: Color = TEXT,
	width: int = 0,
	font: int = 24
) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, height)
	b.add_theme_font_size_override("font_size", font)
	_apply_button_theme(b, bg, fg)

	if handler.is_valid():
		b.pressed.connect(handler)

	return b


func _style_option(opt: OptionButton) -> void:
	opt.custom_minimum_size = Vector2(0, 52)   # round 6: tighter so INITIATE LAUNCH always fits
	opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	opt.add_theme_font_size_override("font_size", 22)
	opt.clip_text = true
	_apply_button_theme(opt, BUTTON_BLUE, TEXT)

	var pop := opt.get_popup()
	var pop_bg := _panel(INNER_BG, 8, 8).get_theme_stylebox("panel")

	var pop_hover := StyleBoxFlat.new()
	pop_hover.bg_color = Color("3A5A94")
	pop_hover.set_corner_radius_all(8)

	pop.add_theme_stylebox_override("panel", pop_bg)
	pop.add_theme_stylebox_override("hover", pop_hover)
	pop.add_theme_font_size_override("font_size", 22)
	pop.add_theme_color_override("font_color", TEXT)
	pop.add_theme_color_override("font_hover_color", TEXT)
	pop.add_theme_constant_override("v_separation", 12)


func _style_line_edit(le: LineEdit) -> void:
	le.custom_minimum_size = Vector2(0, 52)
	le.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	le.add_theme_font_size_override("font_size", 24)
	le.add_theme_color_override("font_color", TEXT)
	le.add_theme_color_override("font_placeholder_color", DISABLED_TEXT)
	le.add_theme_color_override("caret_color", AMBER)

	var normal := StyleBoxFlat.new()
	normal.bg_color = INNER_BG
	normal.border_color = PANEL_BORDER
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(12)
	normal.content_margin_left = 16
	normal.content_margin_right = 16

	var focus: StyleBoxFlat = normal.duplicate()
	focus.border_color = AMBER
	focus.set_border_width_all(3)

	le.add_theme_stylebox_override("normal", normal)
	le.add_theme_stylebox_override("focus", focus)


func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


func _row(title: String, input: Control) -> HBoxContainer:
	var r := HBoxContainer.new()
	r.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.add_theme_constant_override("separation", 12)

	var l := _label(title, 22, TEXT)
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	l.custom_minimum_size = Vector2(120, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	r.add_child(l)
	r.add_child(input)
	return r


func _tex(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		return load(path) as Texture2D

	push_warning("Missing image: " + path)
	return null


# ==========================================
# SMALL HELPERS
# ==========================================

func _on_back() -> void:
	var n := _net()

	if n != null and n.has_method("leave"):   # MERGE: Net's name is leave()
		n.call("leave")

	get_tree().change_scene_to_file(MENU_SCENE)


func _set_status(text: String) -> void:
	if _status != null:
		_status.text = text
		_status.visible = text != ""


## MERGE (LAN fix): the real Wi-Fi / Ethernet address, not a virtual adapter (see net/NetInfo.gd).
func _local_ip() -> String:
	return NetInfo.best_ip()


func _show_net_help() -> void:
	var d := AcceptDialog.new()
	d.title = "Connection help"
	var lines: Array = []
	for c in NetInfo.candidates():
		lines.append("%s   (%s)" % [c["ip"], c["name"]])
	d.dialog_text = NetInfo.HELP + "\n\nThis laptop's addresses (best first):\n" + "\n".join(lines) \
		+ "\n\nGame version: %s   Godot %s" % [Protocol.GAME_VERSION, Engine.get_version_info()["string"]]
	add_child(d)
	d.popup_centered(Vector2i(900, 640))


func _old_local_ip() -> String:
	var best := ""

	for a in IP.get_local_addresses():
		var s := str(a)

		if s.count(".") != 3 or s.begins_with("127.") or s.begins_with("169.254."):
			continue

		if s.begins_with("192.168.") or s.begins_with("10.") or _is_172_private(s):
			return s

		if best == "":
			best = s

	return best if best != "" else "127.0.0.1"


func _is_172_private(ip: String) -> bool:
	## 172.16.x.x to 172.31.x.x are also normal home/office addresses.
	var p := ip.split(".")
	return p.size() == 4 and p[0] == "172" and int(p[1]) >= 16 and int(p[1]) <= 31


## MERGE (Lead): --scenario= --difficulty= --length= --demo from the command line (see ui/main/LaunchArgs.gd).
func _apply_cmdline_presets() -> void:
	if not Engine.has_meta("host_presets"):
		return
	var a: Dictionary = Engine.get_meta("host_presets")
	Engine.remove_meta("host_presets")
	if a.has("scenario") and _scenario_ids.has(str(a["scenario"])):
		_scenario_opt.select(_scenario_ids.find(str(a["scenario"])))
	for i in DIFFS.size():
		if DIFFS[i][0] == str(a.get("difficulty", "")):
			_diff_opt.select(i)
	for i in LENGTHS.size():
		if LENGTHS[i][0] == str(a.get("length", "")):
			_len_opt.select(i)
	if a.has("demo"):
		_demo.button_pressed = true
	if a.has("build"):
		MissionState.set_build_seconds(int(a["build"]))
	if a.has("no-twists"):
		MissionState.set_twists_on(false)
	if a.has("autostart"):
		get_tree().create_timer(float(a["autostart"])).timeout.connect(_on_start)


## MERGE (Lead): show the settings of the mission we just came back from.
func _restore_host_settings() -> void:
	if _team != null:
		_team.text = MissionState.team_name
	if _scenario_opt != null:
		_scenario_opt.select(maxi(0, _scenario_ids.find(MissionState.scenario_id)))
	if _diff_opt != null:
		for i in DIFFS.size():
			if DIFFS[i][0] == MissionState.difficulty:
				_diff_opt.select(i)
	if _len_opt != null:
		for i in LENGTHS.size():
			if LENGTHS[i][0] == MissionState.mission_length:
				_len_opt.select(i)
	if _demo != null:
		_demo.button_pressed = MissionState.demo_mode
