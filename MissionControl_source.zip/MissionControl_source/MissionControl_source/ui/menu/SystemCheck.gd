# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name SystemCheck
extends RefCounted
## LEAD. "Works on my laptop but not on theirs?" Settings > System check shows (and copies) everything that
## usually differs between laptops: game copy, Godot version, editor vs exported game, sound device, network
## addresses and whether the game ports are free. Ask a teammate to press "Copy report" and paste it to you.


static func embedded_in_editor() -> bool:
	return Engine.has_method("is_embedded_in_editor") and bool(Engine.call("is_embedded_in_editor"))


static func report() -> Array:
	var lines: Array = []   # [ok: int (1 ok, 0 warn, -1 problem), text]
	var v: Dictionary = Engine.get_version_info()
	lines.append([1, "Game copy: %s" % Protocol.GAME_VERSION])
	lines.append([1 if (int(v["major"]) == 4 and int(v["minor"]) == 7) else -1,
		"Godot %s  (the team uses 4.7 stable)" % str(v["string"])])
	lines.append([1, "System: %s  |  data folder: %s" % [OS.get_name(), OS.get_user_data_dir()]])
	if OS.has_feature("editor"):
		lines.append([0, "Running from the Godot EDITOR. For playing, use the exported game (MissionControl.exe)."])
	if embedded_in_editor():
		lines.append([-1, "The game is EMBEDDED in the editor's Game tab: full screen cannot work here. " +
			"Turn off 'Embed Game' in the Game tab, or use the exported game."])
	lines.append([1, "Graphics: %s (%s)" % [RenderingServer.get_video_adapter_name(), str(ProjectSettings.get_setting("rendering/renderer/rendering_method", "?"))]])
	# sound
	var dev: String = AudioServer.output_device
	lines.append([1 if dev != "" else 0, "Sound device: %s  (mix rate %d Hz)" % [dev, int(AudioServer.get_mix_rate())]])
	for bus in ["Master", "Music", "SFX"]:
		var i := AudioServer.get_bus_index(bus)
		if i < 0:
			lines.append([-1, "Sound bus '%s' is missing" % bus])
		elif AudioServer.is_bus_mute(i) or AudioServer.get_bus_volume_db(i) < -60.0:
			lines.append([0, "Sound bus '%s' is muted / at zero (Settings sliders)" % bus])
	lines.append([1 if ResourceLoader.exists(Audio.MUSIC) else -1, "Music file " + ("found" if ResourceLoader.exists(Audio.MUSIC) else "MISSING (copy is incomplete?)")])
	# network
	var c: Array = NetInfo.candidates()
	if c.is_empty():
		lines.append([-1, "No network address! Wi-Fi off or not connected."])
	for a in c:
		lines.append([1 if int(a["score"]) > 0 else 0, "Address %s  (%s)%s" % [a["ip"], a["name"], "" if int(a["score"]) > 0 else "  <- probably virtual, crew cannot use it"]])
	if not Net.is_host() and not Net.is_client():
		var probe := ENetMultiplayerPeer.new()
		var e := probe.create_server(Protocol.PORT, 1)
		lines.append([1 if e == OK else -1, "Game port %d %s" % [Protocol.PORT, "is free" if e == OK else "is BUSY (another copy running?)"]])
		probe.close()
		var u := PacketPeerUDP.new()
		var e2 := u.bind(Protocol.DISCOVERY_PORT)
		lines.append([1 if e2 == OK else 0, "Finder port %d %s" % [Protocol.DISCOVERY_PORT, "is free" if e2 == OK else "is busy (the game list may not show hosts; type the address instead)"]])
		u.close()
	if OS.get_name() == "Windows":
		lines.append([0, "Windows: if crew cannot connect, allow this game in Windows Firewall on Private networks and set the Wi-Fi to Private."])
	return lines


static func as_text() -> String:
	var out: Array = ["MISSION CONTROL system check"]
	for l in report():
		out.append({1: "[ok]  ", 0: "[!]   ", -1: "[X]   "}[int(l[0])] + str(l[1]))
	return "\n".join(out)


## A ready-made popup (used by Settings).
static func popup(parent: Node) -> void:
	var d := AcceptDialog.new()
	d.title = "System check"
	d.ok_button_text = "Close"
	var copy := d.add_button("Copy report", true, "copy")
	d.custom_action.connect(func(a: StringName) -> void:
		if a == "copy":
			DisplayServer.clipboard_set(as_text())
			copy.text = "Copied!")
	var rt := RichTextLabel.new()
	rt.bbcode_enabled = true
	rt.fit_content = true
	rt.custom_minimum_size = Vector2(880, 0)
	rt.add_theme_font_size_override("normal_font_size", 18)
	var txt := ""
	for l in report():
		var col: String = {1: "#7CE08A", 0: "#FFC857", -1: "#FF7A6B"}[int(l[0])]
		var mark: String = {1: "OK", 0: "!", -1: "X"}[int(l[0])]
		txt += "[color=%s][b]%s[/b][/color]  %s\n" % [col, mark, str(l[1]).replace("[", "(")]
	rt.text = txt
	d.add_child(rt)
	parent.add_child(d)
	d.popup_centered(Vector2i(940, 600))
