# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name WhyDisabled
extends RefCounted
## One-line "why can't I pick this?" texts (UX_GUIDE section 9). Two kinds:
##   block_*  = truly impossible, the card is greyed out and can't be pressed
##   warn_*   = allowed but will cause a problem, the card stays pressable and shows an amber note
## Every function returns "" when there is nothing to say. All use public part data only (no private numbers).


static func block_prop(opt: Dictionary, orbit: Dictionary) -> String:
	var need: int = int(orbit.get("requires_prop_tier", 0))
	if int(opt.get("tier", 0)) < need:
		return "Needs a thruster of tier %d or better for this orbit." % need
	return ""


static func block_rocket(opt: Dictionary, orbit: Dictionary) -> String:
	var caps: Dictionary = opt.get("capacity_kg", {})
	if float(caps.get(str(orbit.get("launch_class", "")), 0)) <= 0.0:
		return "This rocket can't reach this orbit."
	return ""


static func block_station(opt: Dictionary, orbit: Dictionary) -> String:
	if not (opt.get("ranges", []) as Array).has(orbit.get("range_class", "")):
		return "This station can't see this orbit."
	return ""


static func _slots(design: Dictionary) -> int:
	return int(Data.part("bus", str(design.get("bus", ""))).get("slots", 0))


static func _instrument_mass(design: Dictionary) -> float:
	var total: float = 0.0
	for iid in design.get("instruments", []):
		total += float(Data.instrument(str(iid)).get("mass", 0))
	return total


## SYSTEMS: a body that is too small for the instruments already chosen.
static func warn_bus(opt: Dictionary, design: Dictionary) -> String:
	var used: int = (design.get("instruments", []) as Array).size()
	if used > int(opt.get("slots", 0)):
		return "Only %d instrument slots, you have %d. Ask PAYLOAD." % [int(opt["slots"]), used]
	var mass: float = _instrument_mass(design)
	if mass > float(opt.get("payload_capacity_kg", 0)):
		return "Instruments weigh %d kg, this body carries %d kg." % [int(mass), int(opt["payload_capacity_kg"])]
	return ""


## PAYLOAD: an instrument that will not fit on the current body.
static func warn_instrument(opt: Dictionary, design: Dictionary, selected: bool) -> String:
	if selected:
		return ""
	var used: int = (design.get("instruments", []) as Array).size()
	var bus: Dictionary = Data.part("bus", str(design.get("bus", "")))
	if used >= int(bus.get("slots", 0)):
		return "The body is full (%d slots). Ask SYSTEMS for a bigger body." % int(bus.get("slots", 0))
	if _instrument_mass(design) + float(opt.get("mass", 0)) > float(bus.get("payload_capacity_kg", 0)):
		return "Too heavy for this body. Ask SYSTEMS for a bigger body."
	return ""


## SYSTEMS (Engineer): pointing that is too wobbly for the chosen instruments or antenna.
static func warn_adcs(opt: Dictionary, design: Dictionary) -> String:
	var need: float = 999.0
	var who: String = ""
	for iid in design.get("instruments", []):
		var ins: Dictionary = Data.instrument(str(iid))
		var p: float = float(ins.get("point_req_deg", 999))
		if p < need:
			need = p
			who = str(ins.get("name", iid))
	var comm: Dictionary = Data.part("comm", str(design.get("comm", "")))
	if comm.has("point_req_deg") and float(comm["point_req_deg"]) < need:
		need = float(comm["point_req_deg"])
		who = str(comm.get("name", "antenna"))
	if need < 999.0 and float(opt.get("pointing_deg", 0)) > need:
		return "Too wobbly for %s (needs %s degrees)." % [who, CardStats.fmt(need)]
	return ""


## SYSTEMS: no wings and no nuclear battery means no power at all.
static func warn_panel(opt: Dictionary, design: Dictionary) -> String:
	if float(opt.get("area_m2", 1)) <= 0.0 and int(design.get("rtg_count", 0)) <= 0:
		return "No wings and no nuclear battery: no power!"
	return ""


## GROUND: an antenna that none of the chosen stations can hear.
static func warn_comm(opt: Dictionary, design: Dictionary) -> String:
	var stations: Array = design.get("stations", [])
	if stations.is_empty() or not opt.has("band"):
		return ""
	for sid in stations:
		if (Data.station(str(sid)).get("bands", []) as Array).has(opt["band"]):
			return ""
	return "None of your stations can hear this antenna."


## GROUND: a station that cannot hear the chosen antenna.
static func warn_station(opt: Dictionary, design: Dictionary, selected: bool) -> String:
	if selected:
		return ""
	var band: String = str(Data.part("comm", str(design.get("comm", ""))).get("band", ""))
	if band != "" and not (opt.get("bands", []) as Array).has(band):
		return "Can't hear your antenna. Pick another antenna or station."
	return ""
