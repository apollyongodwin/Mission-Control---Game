# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CrewArt
extends Control
## The four Pawstronaut crew portraits, one per role. Used by the lobby, role panels, broadcast and debrief.
##
## DROP THE REAL ART HERE (PNG, square, transparent background, about 512 x 512):
##   res://assets/images/roles/flight.png     FLIGHT  - Flight Director
##   res://assets/images/roles/systems.png    SYSTEMS - Spacecraft Engineer
##   res://assets/images/roles/payload.png    PAYLOAD - Science Lead
##   res://assets/images/roles/ground.png     GROUND  - Operations & Budget
## Mood variants (from the artist, 2026-11-14):
##   <role>_worried.png   crisis, NO-GO, poor grade        <role>_kaboom.png   explosions: failed launch, crisis hit
##   ("happy" uses the normal portrait: the normal cats already smile)
## Until a file exists, a drawn placeholder (a cat in a helmet, in the role colour) is shown instead.
##
## Usage:  var a := CrewArt.make("systems", 96)   or   CrewArt.make("systems", 96, "happy")

const PATH := "res://assets/images/roles/%s.png"
const MOOD_PATH := "res://assets/images/roles/%s_%s.png"
const LETTERS := {"flight": "F", "systems": "S", "payload": "P", "ground": "G"}

var role: String = "flight"
var mood: String = ""            # "", "happy", "worried"
var dimmed: bool = false         # empty seat look
var _tex: Texture2D = null
var _bob_t: float = 0.0
var bob: bool = false            # gentle floating animation (zero-g)


static func texture_for(r: String, m: String = "") -> Texture2D:
	if m == "kaboom" and not ResourceLoader.exists(MOOD_PATH % [r, m]):
		m = "worried"
	if m != "":
		var mp: String = MOOD_PATH % [r, m]
		if ResourceLoader.exists(mp):
			return load(mp) as Texture2D
	var p: String = PATH % r
	if ResourceLoader.exists(p):
		return load(p) as Texture2D
	return null


static func has_art(r: String) -> bool:
	return ResourceLoader.exists(PATH % r)


static func make(r: String, px: int = 96, m: String = "") -> CrewArt:
	var a := CrewArt.new()
	a.role = r
	a.mood = m
	a.custom_minimum_size = Vector2(px, px)
	a.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return a


func set_role(r: String, m: String = "") -> void:
	role = r
	mood = m
	_tex = texture_for(role, mood)
	queue_redraw()


func _ready() -> void:
	_tex = texture_for(role, mood)
	set_process(bob)


func _process(delta: float) -> void:
	_bob_t += delta
	queue_redraw()


func _role_color() -> Color:
	var roles: Dictionary = Data.db.get("meta", {}).get("roles", {})
	if roles.has(role):
		return Color(str(roles[role]["color"]))
	return Color("8A93B2")


func _draw() -> void:
	var s: float = minf(size.x, size.y)
	var off := Vector2((size.x - s) / 2.0, (size.y - s) / 2.0 + (sin(_bob_t * 2.0) * s * 0.03 if bob else 0.0))
	var tint := Color(1, 1, 1, 0.35) if dimmed else Color.WHITE
	if _tex != null:
		draw_texture_rect(_tex, Rect2(off, Vector2(s, s)), false, tint)
		return
	_draw_placeholder(off, s, tint)


## A friendly cat astronaut: helmet bubble, cat head with ears, eyes, role badge.
func _draw_placeholder(o: Vector2, s: float, tint: Color) -> void:
	var col: Color = _role_color() * tint
	var c: Vector2 = o + Vector2(s * 0.5, s * 0.52)
	var r: float = s * 0.44
	var fur := Color("F3E9D2") * tint
	var ink := Color("0B1530") * tint
	# suit collar
	draw_circle(c + Vector2(0, r * 0.95), r * 0.62, col.darkened(0.15))
	# helmet back
	draw_circle(c, r, Color(col.r, col.g, col.b, 0.22 * tint.a))
	# ears
	var ear_l := PackedVector2Array([c + Vector2(-r * 0.62, -r * 0.18), c + Vector2(-r * 0.5, -r * 0.78), c + Vector2(-r * 0.12, -r * 0.42)])
	var ear_r := PackedVector2Array([c + Vector2(r * 0.62, -r * 0.18), c + Vector2(r * 0.5, -r * 0.78), c + Vector2(r * 0.12, -r * 0.42)])
	draw_colored_polygon(ear_l, fur)
	draw_colored_polygon(ear_r, fur)
	# head
	draw_circle(c + Vector2(0, r * 0.05), r * 0.58, fur)
	# eyes (worried = flatter, happy = arcs)
	var ey: float = -r * 0.02
	if mood == "happy":
		draw_arc(c + Vector2(-r * 0.22, ey), r * 0.09, PI, TAU, 10, ink, maxf(2.0, s * 0.025))
		draw_arc(c + Vector2(r * 0.22, ey), r * 0.09, PI, TAU, 10, ink, maxf(2.0, s * 0.025))
	else:
		draw_circle(c + Vector2(-r * 0.22, ey), r * 0.08, ink)
		draw_circle(c + Vector2(r * 0.22, ey), r * 0.08, ink)
	# nose + mouth
	draw_circle(c + Vector2(0, r * 0.14), r * 0.05, Color("FF8FA3") * tint)
	if mood == "worried":
		draw_arc(c + Vector2(0, r * 0.36), r * 0.12, PI * 1.15, PI * 1.85, 8, ink, maxf(1.5, s * 0.02))
	else:
		draw_arc(c + Vector2(-r * 0.07, r * 0.2), r * 0.07, 0.2, PI - 0.2, 8, ink, maxf(1.5, s * 0.02))
		draw_arc(c + Vector2(r * 0.07, r * 0.2), r * 0.07, 0.2, PI - 0.2, 8, ink, maxf(1.5, s * 0.02))
	# helmet rim + glare
	draw_arc(c, r, 0, TAU, 48, col, maxf(3.0, s * 0.05), true)
	draw_arc(c, r * 0.82, PI * 1.15, PI * 1.45, 12, Color(1, 1, 1, 0.55 * tint.a), maxf(2.0, s * 0.03), true)
	# role badge
	var bc: Vector2 = o + Vector2(s * 0.8, s * 0.82)
	var br: float = s * 0.15
	draw_circle(bc, br, col)
	draw_arc(bc, br, 0, TAU, 24, ink, maxf(1.5, s * 0.015), true)
	var font: Font = get_theme_default_font()
	var fs: int = int(br * 1.3)
	var letter: String = str(LETTERS.get(role, "?"))
	var tw: Vector2 = font.get_string_size(letter, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	draw_string(font, bc + Vector2(-tw.x / 2.0, fs * 0.36), letter, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, ink)
