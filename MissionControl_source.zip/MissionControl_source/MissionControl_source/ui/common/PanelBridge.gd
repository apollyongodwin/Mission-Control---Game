# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name PanelBridge
extends RefCounted
## The ONE place where DEV B's panels talk to the Lead's autoloads (MissionState and Net).
## If the Lead names something differently, fix it here and nowhere else.
## Assumed (confirm with the Lead):
##   MissionState.design        Dictionary, the full shared design (spec section 3)
##   MissionState.difficulty    "cadet" / "engineer" / "flight_director"
##   MissionState.view          this player's SimEngine.role_view(...) result (lights, errors, private)
##   MissionState.design_changed  signal, also fired when `view` changes
##   Net.submit_choice(category, value)   value for instruments/stations is the WHOLE new list
## Part 2 adds (all optional: if the Lead has not built one yet it just warns, nothing crashes):
##   MissionState.tokens        this role's tokens {token: count}  (or {role: {token: count}}), signal tokens_changed
##   MissionState.phase         "LOBBY" ... "DEBRIEF" (a String, or the int index of that list), signal phase_changed(phase)
##   signal crisis_started(event: Dictionary, timer_s: float)   on Net OR MissionState
##   signal crisis_resolved(result: Dictionary)                 on Net OR MissionState
##   Net.play_action(action_id)  Net.give_token(token, to_role)  Net.ping(card_id)
##   Net.poll_answer(go, reason)  Net.event_choice(option_id)


static func design() -> Dictionary:
	return MissionState.design


static func difficulty() -> String:
	return str(MissionState.difficulty)


static func is_cadet() -> bool:
	return difficulty() == "cadet"


static func view() -> Dictionary:
	return MissionState.view


static func submit(category: String, value) -> void:
	Net.submit_choice(category, value)


static func on_changed(callback: Callable) -> void:
	if not MissionState.design_changed.is_connected(callback):
		MissionState.design_changed.connect(callback)


# ---- only used while testing with the stand-in autoloads
static func is_dev_stub() -> bool:
	return MissionState.get("dev_stub") == true


static func dev_set_role(role: String) -> void:
	MissionState.call("set_dev_role", role)


static func dev_set_difficulty(diff: String) -> void:
	MissionState.call("set_dev_difficulty", diff)


# ================================================================ Part 2
const PHASES: Array = ["LOBBY", "BRIEFING", "DESIGN", "REVIEW", "LAUNCH", "FLIGHT", "DEBRIEF"]


static func phase_name(p) -> String:
	if typeof(p) == TYPE_INT:
		return str(PHASES[p]) if p >= 0 and p < PHASES.size() else ""
	return str(p).to_upper()


static func phase() -> String:
	var p = MissionState.get("phase")
	if p == null:
		return "DESIGN"
	return phase_name(p)


## Radio Silence: always on for Flight Director, or when the Lead sets MissionState.radio_silence = true.
static func radio_silence() -> bool:
	var fs = MissionState.get("flight_status")   # MERGE: the host puts the live flag in flight_status
	if fs is Dictionary and bool((fs as Dictionary).get("radio_silence", false)):
		return true
	var diffs: Dictionary = Data.db["meta"]["difficulty"]
	return bool((diffs.get(difficulty(), {}) as Dictionary).get("radio_silence", false))


## This role's tokens as {token: count}. Accepts {token: n} (client copy) or {role: {token: n}} (host copy).
static func my_tokens(role: String) -> Dictionary:
	var t = MissionState.get("tokens")
	if not (t is Dictionary):
		return {}
	var d: Dictionary = t
	if d.has(role) and d[role] is Dictionary:
		return (d[role] as Dictionary).duplicate()
	var out: Dictionary = {}
	for k in d:
		if not (d[k] is Dictionary):
			out[str(k)] = int(d[k])
	return out


static func _signal_source(sig: String) -> Object:
	if Net.has_signal(sig):
		return Net
	if MissionState.has_signal(sig):
		return MissionState
	return null


static func _connect_sig(sig: String, cb: Callable) -> void:
	var src: Object = _signal_source(sig)
	if src == null:
		push_warning("PanelBridge: no signal '%s' on Net or MissionState yet" % sig)
		return
	if not src.is_connected(sig, cb):
		src.connect(sig, cb)


static func on_tokens_changed(cb: Callable) -> void:
	_connect_sig("tokens_changed", cb)


static func on_phase_changed(cb: Callable) -> void:
	_connect_sig("phase_changed", cb)


## MERGE: on the Lead's Net, crisis_started / crisis_resolved are the RPC names; the SIGNALS are
## crisis_event(event, timer_s) and crisis_result(result).
static func on_crisis_started(cb: Callable) -> void:
	_connect_sig("crisis_event", cb)


static func on_crisis_resolved(cb: Callable) -> void:
	_connect_sig("crisis_result", cb)


## MERGE: the host's short "no" / "FYI" messages (code, text), e.g. action_rejected, review_blocked, nogo.
static func on_server_message(cb: Callable) -> void:
	_connect_sig("server_message_received", cb)


## MERGE: "Call Design Review" (DESIGN -> REVIEW). The host checks the design and answers with review_blocked if not ready.
static func call_review() -> void:
	_net_call("call_review", [])


## MERGE: "Done / nothing to play" for the current crisis, opportunity or decision.
static func pass_turn(kind: String) -> void:
	if kind == "crisis":
		_net_call("play_action", ["pass"])
	else:
		_net_call("event_choice", ["pass"])


## MERGE: briefing READY button (spec name `ready`; Net calls it set_seat_ready).
static func set_ready(flag: bool) -> void:
	_net_call("set_seat_ready", [flag])


static func _net_call(method: String, args: Array) -> void:
	if Net.has_method(method):
		Net.callv(method, args)
	else:
		push_warning("PanelBridge: Net.%s() does not exist yet (ask the Lead)" % method)


static func play_action(action_id: String) -> void:
	_net_call("play_action", [action_id])


static func give_token(token: String, to_role: String) -> void:
	_net_call("give_token", [token, to_role])


static func ping(card_id: String) -> void:
	_net_call("ping", [card_id])


static func poll_answer(go: bool, reason: String) -> void:
	_net_call("poll_answer", [go, reason])


static func event_choice(option_id: String) -> void:
	_net_call("event_choice", [option_id])


# ---- only used while testing with the stand-in autoloads
static func dev_set_phase(p: String) -> void:
	MissionState.call("set_dev_phase", p)


static func dev_next_event() -> void:
	Net.call("dev_start_next_event")


static func dev_resolve_event() -> void:
	Net.call("dev_resolve_event")
