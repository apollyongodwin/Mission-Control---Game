# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CardStats
extends RefCounted
## Picks the 2 to 3 key numbers shown on each PartCard. Each stat is {label, v, text}:
## v is used for the Cadet bars (the panel divides by the biggest v in the list), text is for Engineer mode.


static func fmt(v) -> String:
	var f: float = float(v)
	if is_equal_approx(f, roundf(f)):
		return str(int(roundf(f)))
	return "%.1f" % f


static func stat(label: String, v: float, text: String) -> Dictionary:
	return {"label": label, "v": v, "text": text}


static func _cost(item: Dictionary, key: String = "cost") -> Dictionary:
	return stat("Cost", float(item[key]), "C$" + fmt(item[key]) + "M")


## category: bus, panel, battery, comm, adcs, obc, shield, prop, rocket, stations, instruments, orbit
## orbit: the currently chosen orbit dictionary (can be {})
static func for_item(category: String, item: Dictionary, orbit: Dictionary) -> Array:
	match category:
		"bus":
			return [stat("Weight", float(item["mass"]), fmt(item["mass"]) + " kg"),
				stat("Room", float(item["slots"]), fmt(item["slots"]) + " slots"), _cost(item)]
		"panel":
			var watts: float = float(item["area_m2"]) * float(item["w_per_m2_1au"])
			return [stat("Power", watts, fmt(watts) + " W"), stat("Weight", float(item["mass"]), fmt(item["mass"]) + " kg"), _cost(item)]
		"battery":
			return [stat("Energy", float(item["capacity_wh"]), fmt(item["capacity_wh"]) + " Wh"),
				stat("Weight", float(item["mass"]), fmt(item["mass"]) + " kg"), _cost(item)]
		"comm":
			var rates: Dictionary = item["rates_mbps"]
			var rate: float = float(rates.get(str(orbit.get("range_class", "leo")), 0))
			return [stat("Speed", rate, fmt(rate) + " Mbps"), stat("Power use", float(item["power_w"]), fmt(item["power_w"]) + " W"), _cost(item)]
		"adcs":
			# lower pointing angle = steadier aim, so we turn it into a "goodness" number on a log scale
			var goodness: float = 3.0 - log(maxf(float(item["pointing_deg"]), 0.0001)) / log(10.0)
			return [stat("Aim", goodness, fmt(item["pointing_deg"]) + " deg"),
				stat("Power use", float(item["power_w"]), fmt(item["power_w"]) + " W"), _cost(item)]
		"obc":
			return [stat("Memory", float(item["storage_gb"]), fmt(item["storage_gb"]) + " GB"),
				stat("Tough", float(item["rad_tol_krad"]), fmt(item["rad_tol_krad"]) + " krad"), _cost(item)]
		"shield":
			return [stat("Protection", float(item["rad_bonus_krad"]), fmt(item["rad_bonus_krad"]) + " krad"),
				stat("Weight", float(item["mass"]), fmt(item["mass"]) + " kg"), _cost(item)]
		"prop":
			return [stat("Engine", float(item["tier"]), "tier " + fmt(item["tier"])),
				stat("Weight", float(item["mass"]), fmt(item["mass"]) + " kg"), _cost(item)]
		"rocket":
			var caps: Dictionary = item["capacity_kg"]
			var lift: float = float(caps.get(str(orbit.get("launch_class", "leo")), 0))
			return [stat("Lifts", lift, fmt(lift) + " kg"),
				stat("Safe", float(item["reliability"]), fmt(float(item["reliability"]) * 100.0) + "%"), _cost(item)]
		"stations":
			var contact: Dictionary = item["contact_min_day"]
			var mins: float = float(contact.get(str(orbit.get("contact_class", "")), 0)) * float(item["weather_factor"])
			return [stat("Contact", mins, fmt(mins) + " min/day"), stat("Setup", float(item["setup_cost"]), "C$" + fmt(item["setup_cost"]) + "M"),
				stat("Upkeep", float(item["ops_cost_per_year"]), "C$" + fmt(item["ops_cost_per_year"]) + "M/yr")]
		"instruments":
			return [stat("Weight", float(item["mass"]), fmt(item["mass"]) + " kg"),
				stat("Power use", float(item["power_w"]), fmt(item["power_w"]) + " W"),
				stat("Data", float(item["data_gb_day"]), fmt(item["data_gb_day"]) + " GB/day")]
		"orbit":
			return [stat("Shadow", float(item["eclipse_avg_frac"]), fmt(float(item["eclipse_avg_frac"]) * 100.0) + "% in shadow"),
				stat("Radiation", float(item["dose_krad_yr"]), fmt(item["dose_krad_yr"]) + " krad/yr"),
				stat("Engine need", float(item["requires_prop_tier"]), "tier " + fmt(item["requires_prop_tier"]))]
	return []
