# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name LaunchPoll
extends PanelContainer
## The GO / NO-GO poll shown in the REVIEW phase: the 7-row checklist, the coach line, a reason box and two big buttons.
## Sends PanelBridge.poll_answer(go, reason). Call reset() when a new poll starts and set_view(view) to refresh the checklist.

signal answered(go: bool, reason: String)

const ROWS: Array = ["mass", "power", "budget", "data", "comms", "time", "lifetime"]

var role_id: String = "systems"
var _accent: Color = Color("F2B134")
var _built: bool = false
var _icons: Dictionary = {}
var _coach: Label
var _reason: LineEdit
var _go: Button
var _nogo: Button
var _status: Label

var _grid: GridContainer   # LEAD (round 4)
var _answered := false


func setup(role: String, accent: Color) -> void:
	role_id = role
	_accent = accent
	_build()
	reset()


func _ready() -> void:
	if not _built:
		var info: Dictionary = Data.db["meta"]["roles"][role_id]
		setup(role_id, Color(str(info["color"])))


func _build() -> void:
	if _built:
		return
	_built = true
	MissionState.commander_changed.connect(_on_commander_changed)
	Net.server_message_received.connect(_on_server_message)
	custom_minimum_size = Vector2(620, 0)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	add_child(vb)
	var info: Dictionary = Data.db["meta"]["roles"][role_id]
	var title := Label.new()
	title.text = "LAUNCH POLL: %s, are you GO?" % str(info["name"])
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", _accent)
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(title)

	var grid := GridContainer.new()
	_grid = grid
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 6)
	for k in ROWS:
		var row := HBoxContainer.new()
		var icon := LightIcon.new()
		icon.custom_minimum_size = Vector2(34, 34)
		row.add_child(icon)
		var l := Label.new()
		l.text = str(ResourceStrip.NAMES[k])
		l.add_theme_font_size_override("font_size", 22)
		row.add_child(l)
		grid.add_child(row)
		_icons[k] = icon
	vb.add_child(grid)

	_coach = Label.new()
	_coach.add_theme_font_size_override("font_size", 22)
	_coach.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(_coach)

	_reason = LineEdit.new()
	_reason.placeholder_text = "Why NO-GO? (optional)"
	_reason.custom_minimum_size = Vector2(0, 48)
	_reason.add_theme_font_size_override("font_size", 22)
	vb.add_child(_reason)

	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 16)
	_go = Button.new()
	_go.text = "GO"
	_go.custom_minimum_size = Vector2(0, 80)
	_go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_go.add_theme_font_size_override("font_size", 34)
	GameTheme.paint_button(_go, Color("2E8B57"), Color.WHITE)   # round 6: real GO / NO-GO colours
	_go.pressed.connect(func() -> void: _answer(true))
	row2.add_child(_go)
	_nogo = Button.new()
	_nogo.text = "NO-GO"
	_nogo.custom_minimum_size = Vector2(0, 80)
	_nogo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_nogo.add_theme_font_size_override("font_size", 34)
	GameTheme.paint_button(_nogo, Color("B03A2E"), Color.WHITE)
	_nogo.pressed.connect(func() -> void: _answer(false))
	row2.add_child(_nogo)
	vb.add_child(row2)

	_status = Label.new()
	_status.add_theme_font_size_override("font_size", 22)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(_status)


func _on_commander_changed() -> void:
	set_view(PanelBridge.view())


## The host refused a GO (a SWAP is still open): buttons back on.
func _on_server_message(code: String, text: String) -> void:
	if code == "poll_rejected":
		_answered = false
		_nogo.disabled = false
		_reason.editable = true
		_status.text = text
		set_view(PanelBridge.view())


## A new poll: buttons live again, reason cleared.
func reset() -> void:
	_build()
	_reason.text = ""
	_answered = false
	_reason.editable = true
	_go.disabled = false
	_nogo.disabled = false
	_status.text = ""
	set_view(PanelBridge.view())


func set_view(view: Dictionary) -> void:
	_build()
	var lights: Dictionary = view.get("lights", {})
	for k in ROWS:
		(_icons[k] as LightIcon).state = str(lights.get(k, "unknown"))
	_coach.text = str(CoachText.pick(view, PanelBridge.is_cadet())["text"])
	# LEAD (round 4): Commander mode. The crew cannot see the lights; the Commander's marks decide.
	_grid.visible = not MissionState.commander_mode
	if MissionState.commander_mode:
		var swaps: Array = MissionState.swaps_for_role(role_id)
		if not swaps.is_empty():
			var names: PackedStringArray = []
			for c in swaps:
				names.append(MissionState.mark_label(str(c)))
			_coach.text = "The Commander wants you to SWAP: %s.\nSay NO-GO, then fix it." % ", ".join(names)
			_coach.add_theme_color_override("font_color", GameTheme.BAD)
			if not _answered:
				_go.disabled = true
		else:
			_coach.text = "Did the Commander say your parts are OK? Then you're GO!" + \
				("\nThe Commander is GO." if MissionState.commander_go else "")
			_coach.add_theme_color_override("font_color", GameTheme.TEXT)
			if not _answered:
				_go.disabled = false


func _answer(go: bool) -> void:
	var reason: String = _reason.text.strip_edges()
	if not go and reason == "":
		reason = "Not ready yet"
	if go:
		reason = ""
	_answered = true
	_go.disabled = true
	_nogo.disabled = true
	_reason.editable = false
	_status.text = "You said GO. Waiting for the others..." if go else "You said NO-GO: %s" % reason
	PanelBridge.poll_answer(go, reason)
	answered.emit(go, reason)
