# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name TokenIcon
extends Control
## One token drawn with shapes (no art needed). Each token has its own SHAPE, so it never relies on colour alone.
## kind = the data meta.tokens[token].icon: bolt, disk, coin, dish, flame, clock

var kind: String = "coin":
	set(value):
		kind = value
		queue_redraw()


func _init() -> void:
	custom_minimum_size = Vector2(44, 44)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	var c: Vector2 = size / 2.0
	var r: float = minf(size.x, size.y) * 0.45
	match kind:
		"bolt":
			var col := Color("FFE066")
			draw_colored_polygon(PackedVector2Array([c + Vector2(r * 0.2, -r), c + Vector2(-r * 0.6, r * 0.1), c + Vector2(-r * 0.05, r * 0.1),
				c + Vector2(-r * 0.2, r), c + Vector2(r * 0.6, -r * 0.2), c + Vector2(r * 0.05, -r * 0.2)]), col)
		"disk":
			draw_rect(Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), Color("6EC6FF"))
			draw_rect(Rect2(c + Vector2(-r * 0.6, -r), Vector2(r * 1.2, r * 0.7)), Color("0B132B"))
			draw_rect(Rect2(c + Vector2(-r * 0.5, r * 0.2), Vector2(r, r * 0.65)), Color("DDF3FF"))
		"coin":
			draw_circle(c, r, Color("F2B134"))
			draw_arc(c, r * 0.62, 0.0, TAU, 32, Color("7A5200"), 3.0)
			draw_line(c + Vector2(0.0, -r * 0.3), c + Vector2(0.0, r * 0.3), Color("7A5200"), 3.0)
		"dish":
			draw_arc(c + Vector2(0.0, -r * 0.1), r * 0.85, 0.15 * PI, 0.85 * PI, 24, Color("C5E1A5"), 6.0)
			draw_line(c + Vector2(0.0, r * 0.2), c + Vector2(0.0, r * 0.9), Color("C5E1A5"), 4.0)
			draw_line(c + Vector2(-r * 0.4, r * 0.9), c + Vector2(r * 0.4, r * 0.9), Color("C5E1A5"), 4.0)
			draw_circle(c + Vector2(0.0, -r * 0.55), 3.5, Color.WHITE)
		"flame":
			draw_colored_polygon(PackedVector2Array([c + Vector2(0.0, -r), c + Vector2(r * 0.65, r * 0.1), c + Vector2(r * 0.45, r * 0.75),
				c + Vector2(0.0, r), c + Vector2(-r * 0.45, r * 0.75), c + Vector2(-r * 0.65, r * 0.1)]), Color("FF7043"))
			draw_colored_polygon(PackedVector2Array([c + Vector2(0.0, -r * 0.1), c + Vector2(r * 0.3, r * 0.5), c + Vector2(0.0, r * 0.85),
				c + Vector2(-r * 0.3, r * 0.5)]), Color("FFD54F"))
		"clock":
			draw_circle(c, r, Color("CE93D8"))
			draw_circle(c, r * 0.82, Color("2A1B33"))
			draw_line(c, c + Vector2(0.0, -r * 0.6), Color.WHITE, 3.0)
			draw_line(c, c + Vector2(r * 0.4, r * 0.15), Color.WHITE, 3.0)
		_:
			draw_circle(c, r, Color(0.5, 0.5, 0.55))
