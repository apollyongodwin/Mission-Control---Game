# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name LightIcon
extends Control
## One traffic light that never relies on colour alone:
## green = circle with a check, amber = triangle with !, red = square with X (UX_GUIDE rule 8).

var state: String = "unknown":
	set(value):
		state = value
		queue_redraw()


func _init() -> void:
	custom_minimum_size = Vector2(44, 44)


func _draw() -> void:
	var c: Vector2 = size / 2.0
	var r: float = minf(size.x, size.y) * 0.45
	match state:
		"green":
			draw_circle(c, r, Color("4CAF50"))
			draw_polyline(PackedVector2Array([c + Vector2(-r * 0.5, 0.0), c + Vector2(-r * 0.1, r * 0.4), c + Vector2(r * 0.5, -r * 0.4)]), Color.WHITE, 4.0)
		"amber":
			draw_colored_polygon(PackedVector2Array([c + Vector2(0.0, -r), c + Vector2(r, r * 0.85), c + Vector2(-r, r * 0.85)]), Color("FFB300"))
			draw_line(c + Vector2(0.0, -r * 0.25), c + Vector2(0.0, r * 0.25), Color.BLACK, 4.0)
			draw_circle(c + Vector2(0.0, r * 0.55), 2.5, Color.BLACK)
		"red":
			draw_rect(Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), Color("E53935"))
			draw_line(c + Vector2(-r * 0.5, -r * 0.5), c + Vector2(r * 0.5, r * 0.5), Color.WHITE, 4.0)
			draw_line(c + Vector2(-r * 0.5, r * 0.5), c + Vector2(r * 0.5, -r * 0.5), Color.WHITE, 4.0)
		_:
			draw_circle(c, r, Color(0.4, 0.4, 0.45))
