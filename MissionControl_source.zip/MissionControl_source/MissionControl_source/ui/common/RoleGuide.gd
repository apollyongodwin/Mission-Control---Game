# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name RoleGuide
extends RefCounted
## LEAD (round 4). "What is my job again?" One short card per role, in kid words.
## Shown on the briefing, behind the MY JOB button on every crew screen, in the Commander's handbook and in the PDF.
## Non-coders can edit the text here. Keep every line short.

const GAUGES := {
	# threat tag -> [who reads it, gauge name]
	"radiation": ["flight", "Particle counter"],
	"debris": ["flight", "Tracking radar"],
	"power": ["systems", "Battery voltage"],
	"software": ["systems", "Computer health"],
	"thermal": ["payload", "Detector temperature"],
	"data": ["payload", "Recorder fill"],
	"comms": ["ground", "Radio signal"],
	"budget": ["ground", "Mission bank account"],
}

## round 6: where each token comes from, in kid words (spare margins at launch become tokens)
const TOKEN_FROM := {"power": "spare power", "data": "spare storage", "budget": "money left over", "comms": "a fast radio",
	"fuel": "spare fuel", "time": "spare months"}

const GUIDES := {
	"commander": {
		"name": "COMMANDER", "title": "Mission Control (the host laptop)", "color": "#FFC857",
		"one_line": "You have the handbook. The crew has the spaceship. Nobody wins alone.",
		"you_do": ["Check every crew pick and mark it OK or SWAP.", "Tell the crew what to change and why.",
			"In a crisis: ask the crew for their gauges, find the crisis in the handbook, tell each crew member which card to play."],
		"only_you": ["The budget and every number.", "Ship health lights (are the picks right?).", "The crisis handbook."],
		"you_cannot": ["See the crisis gauges or the crew's cards.", "See the clock. When your screen flashes red, hurry!"],
		"tip": "Ask questions! \"FLIGHT, what does your particle counter say?\"",
	},
	"flight": {
		"name": "FLIGHT", "title": "Flight Director", "color": "#FF6B5E",
		"one_line": "You pick WHERE the spacecraft flies and HOW it moves: orbit, engines and pointing.",
		"you_do": ["Pick the orbit, the engines and the pointing.", "In a crisis: dodge, go to safe mode, or change the plan."],
		"only_you": ["Particle counter (space radiation).", "Tracking radar (space junk)."],
		"you_cannot": ["See if your orbit is a good pick: ask the Commander.", "See the budget."],
		"tip": "Read your gauges out loud the second a crisis starts.",
	},
	"systems": {
		"name": "SYSTEMS", "title": "Spacecraft Engineer", "color": "#F5B83D",
		"one_line": "You BUILD the spacecraft: body, power and brain.",
		"you_do": ["Pick the body, the power pack (wings + battery) and the brain (computer + shield).",
			"In a crisis: shed load, reboot, turn the shield, or fix the battery."],
		"only_you": ["Battery voltage (power).", "Computer health (software)."],
		"you_cannot": ["See if the ship is too heavy or too weak: ask the Commander.", "See the budget."],
		"tip": "You own the most parts. Tell the Commander what you picked, one by one.",
	},
	"payload": {
		"name": "PAYLOAD", "title": "Science Lead", "color": "#5B9BFF",
		"one_line": "You pick the SCIENCE: the cameras and sensors that do the mission's job.",
		"you_do": ["Pick the instruments.", "In a crisis: throttle, recalibrate or squeeze the data."],
		"only_you": ["Detector temperature (heat).", "Recorder fill (data)."],
		"you_cannot": ["See if your instruments fit the ship: ask the Commander.", "See the budget."],
		"tip": "Read the mission goals, then tell the Commander which goal each instrument helps.",
	},
	"ground": {
		"name": "GROUND", "title": "Operations & Budget", "color": "#B57BEA",
		"one_line": "You get the ship INTO space and keep talking to it: rocket, antenna, ground stations.",
		"you_do": ["Pick the rocket, the antenna and the ground stations.",
			"In a crisis: book an emergency pass, send a patch, rent an antenna, or absorb a budget cut."],
		"only_you": ["Radio signal (comms).", "Mission bank account (budget)."],
		"you_cannot": ["See the price tags or the budget: the Commander has it.", "See if the rocket is strong enough: ask."],
		"tip": "Ask the Commander \"Can we afford it?\" before picking big things.",
	},
}


static func guide(role: String) -> Dictionary:
	return GUIDES.get(role, GUIDES["commander"])


static func color(role: String) -> Color:
	return Color(str(guide(role)["color"]))


## Gauges one role reads in a crisis: [{tag, name}].
static func gauges_for(role: String) -> Array:
	var out: Array = []
	for tag in GAUGES:
		if str(GAUGES[tag][0]) == role:
			out.append({"tag": tag, "name": str(GAUGES[tag][1])})
	return out


## round 5 (kid-simple): a gauge is just "ALARM" or "OK". Every crisis still has its own pattern (tested).
static func level(weight: float) -> String:
	return "ALARM" if weight >= 0.2 else "OK"


static func level_color(lv: String) -> Color:
	return Color("FF4D4D") if lv == "ALARM" else Color("7CE08A")


## The ALARM gauges of a crisis: [{tag, role, name}].
static func alarms(event: Dictionary) -> Array:
	var out: Array = []
	var threat: Dictionary = event.get("threat", {})
	for tag in GAUGES:
		if level(float(threat.get(tag, 0.0))) == "ALARM":
			out.append({"tag": tag, "role": str(GAUGES[tag][0]), "name": str(GAUGES[tag][1])})
	return out


## What the Commander says: the best card of the (at most two) crew members whose card helps most.
## [{role, action, label}]
static func calls(event: Dictionary) -> Array:
	## LEAD (round 8): the handbook used to name the two "best looking" cards, but for 4 crises those two only
	## blocked 60-87% of the threat, so a crew that did EXACTLY what the Commander said still got hurt.
	## Now we search for the smallest set (1 or 2 cards, different crew) that blocks 100% with the same formula
	## FlightDirector uses. Ties: fewer teammate tokens needed first, then the stronger set.
	var cards: Array = best_cards(event)
	var best: Array = []
	var best_key: Array = []
	for i in cards.size():
		var single: Array = [cards[i]]
		_consider(event, single, best, best_key)
		for j in range(i + 1, cards.size()):
			if str(cards[i]["role"]) == str(cards[j]["role"]):
				continue
			_consider(event, [cards[i], cards[j]], best, best_key)
	if best.is_empty():   # nothing blocks it all (a modded crisis?): fall back to the two strongest, one per role
		var seen: Dictionary = {}
		for c in cards:
			if seen.has(c["role"]):
				continue
			seen[c["role"]] = true
			best.append(c)
			if best.size() >= 2:
				break
	return best


## FlightDirector's formula: sum over tags of threat[t] * min(1, sum of mitigates[t]).
static func blocked(event: Dictionary, action_ids: Array) -> float:
	var threat: Dictionary = event.get("threat", {})
	var m := 0.0
	for tag in threat:
		var s := 0.0
		for a in Data.db["actions"]:
			if action_ids.has(str(a["id"])):
				s += float((a["mitigates"] as Dictionary).get(tag, 0.0))
		m += float(threat[tag]) * minf(1.0, s)
	return clampf(m, 0.0, 1.0)


static func _consider(event: Dictionary, set_: Array, best: Array, best_key: Array) -> void:
	var ids: Array = []
	var borrowed := 0
	for c in set_:
		ids.append(str(c["action"]))
		if cost_note(str(c["action"])) != "":
			borrowed += 1
	var m: float = blocked(event, ids)
	if m < 0.999:
		return
	var key: Array = [set_.size(), borrowed]
	if best.is_empty() or key[0] < best_key[0] or (key[0] == best_key[0] and key[1] < best_key[1]):
		best.clear()
		best.append_array(set_)
		best_key.clear()
		best_key.append_array(key)


## The handbook fix for a crisis: per role, the cards that block its threats, best first.
## [{role, action, label, score}] sorted by score.
static func best_cards(event: Dictionary) -> Array:
	var threat: Dictionary = event.get("threat", {})
	var out: Array = []
	for a in Data.db["actions"]:
		var s := 0.0
		for tag in (a["mitigates"] as Dictionary):
			s += minf(float(threat.get(tag, 0.0)), float(a["mitigates"][tag]))
		if s > 0.05 and str(a["id"]) != "override":
			out.append({"role": str(a["role"]), "action": str(a["id"]), "label": str(a["label"]), "score": s})
	out.sort_custom(func(x, y): return float(x["score"]) > float(y["score"]))
	return out


## "needs 1 power from SYSTEMS" for a card that costs a teammate's token ("" if it only costs your own).
static func cost_note(action_id: String) -> String:
	for a in Data.db["actions"]:
		if str(a["id"]) != action_id:
			continue
		var parts: PackedStringArray = []
		for tk in (a["cost"] as Dictionary):
			var owner: String = CrisisPanel.owner_role(str(tk))
			if owner != "" and owner != str(a["role"]):
				parts.append("%d %s from %s" % [int(a["cost"][tk]), CrisisPanel.token_word(str(tk)), guide(owner)["name"]])
		return ("needs " + " and ".join(parts)) if not parts.is_empty() else ""
	return ""


## A Label-built card for a role guide (used by the MY JOB popup, the briefing and the Commander handbook).
static func make_card(role: String, compact: bool = false) -> Control:
	var g: Dictionary = guide(role)
	var col := color(role)
	var pc := GameTheme.panel(GameTheme.PANEL.lerp(col, 0.12), Color(col, 0.75), 3, 18, 14)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	pc.add_child(v)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	if role != "commander":
		head.add_child(CrewArt.make(role, 56 if not compact else 44))
	var names := VBoxContainer.new()
	names.size_flags_horizontal = Control.SIZE_EXPAND_FILL   # round 6: without this the labels get 0 width (1 letter per line)
	names.add_child(_l(str(g["name"]), 26 if not compact else 22, col))
	names.add_child(_l(str(g["title"]), 16, GameTheme.MUTED))
	head.add_child(names)
	v.add_child(head)
	v.add_child(_l(str(g["one_line"]), 19 if not compact else 17, GameTheme.TEXT))
	for sec in [["YOU DO", "you_do", GameTheme.TEXT], ["ONLY YOU SEE", "only_you", col], ["YOU CAN'T SEE", "you_cannot", GameTheme.MUTED]]:
		v.add_child(_l(str(sec[0]), 15, GameTheme.AMBER))
		for line in g[sec[1]]:
			v.add_child(_l("  - " + str(line), 16 if not compact else 15, sec[2]))
	var toks: Array = Data.db["meta"]["roles"].get(role, {}).get("owns_tokens", []) if role != "commander" else []
	if not toks.is_empty():
		var words: PackedStringArray = []
		var from: PackedStringArray = []
		for t in toks:
			words.append(CrisisPanel.token_word(str(t)))
			from.append(str(TOKEN_FROM.get(str(t), "")))
		v.add_child(_l("YOUR TOKENS", 15, GameTheme.AMBER))
		v.add_child(_l("  - %s. A ship with %s gives you more!" % [" and ".join(words).capitalize(), " and ".join(from)], 16, GameTheme.TEXT))
		v.add_child(_l("  - Cards cost tokens. Short? Tap ASK. A teammate needs one? Tap GIVE.", 16, GameTheme.TEXT))
	if not compact:
		v.add_child(_l("TIP: " + str(g["tip"]), 16, Color("9FD4FF")))
	return pc


static func _l(text: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	return l


## A popup with this role's card. parent = any node in the scene.
## round 6: an in-game card on a dimmed screen (the old system dialog squeezed the text to one letter per line).
static func popup(parent: Node, role: String) -> void:
	var layer := CanvasLayer.new()
	layer.layer = 60
	parent.add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.theme = GameTheme.build(color(role))
	layer.add_child(root)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.1, 0.8)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	v.custom_minimum_size = Vector2(640, 0)
	center.add_child(v)
	var card := make_card(role)
	card.custom_minimum_size = Vector2(640, 0)
	v.add_child(card)
	var ok := Button.new()
	ok.text = "Got it!"
	ok.custom_minimum_size = Vector2(220, 60)
	ok.add_theme_font_size_override("font_size", 24)
	ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	GameTheme.paint_button(ok, color(role), GameTheme.NAVY)
	ok.pressed.connect(layer.queue_free)
	v.add_child(ok)
	dim.gui_input.connect(func(e: InputEvent) -> void:
		if e is InputEventMouseButton and (e as InputEventMouseButton).pressed:
			layer.queue_free())
