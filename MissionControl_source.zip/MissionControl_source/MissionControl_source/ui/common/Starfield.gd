# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Starfield
extends Control
## LEAD (UI pass). A quiet, slowly twinkling star background so the crew screens share the space mood of Dev D's menus.
## Purely decorative: ignores the mouse and costs almost nothing.

@export var count: int = 90
@export var max_alpha: float = 0.55

var _stars: Array = []   # [Vector2 (0..1), radius, phase, speed]
var _t: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rng := RandomNumberGenerator.new()
	rng.seed = 2026
	for i in count:
		_stars.append([Vector2(rng.randf(), rng.randf()), rng.randf_range(0.6, 1.8), rng.randf() * TAU, rng.randf_range(0.4, 1.4)])


func _process(delta: float) -> void:
	_t += delta
	if Engine.get_process_frames() % 3 == 0:
		queue_redraw()


func _draw() -> void:
	for s in _stars:
		var p: Vector2 = (s[0] as Vector2) * size
		var a: float = max_alpha * (0.45 + 0.55 * (0.5 + 0.5 * sin(_t * float(s[3]) + float(s[2]))))
		var c := Color(1.0, 0.95, 0.8, a) if float(s[1]) > 1.5 else Color(0.85, 0.9, 1.0, a)
		draw_circle(p, float(s[1]), c)
