# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CountdownRing
extends Control
## A ring that empties as the crisis timer runs out. Cosmetic only: the HOST owns the real timer.
## start(seconds), stop(). Emits finished when it reaches zero.

signal finished

var total: float = 1.0
var left: float = 0.0
var running: bool = false
var ring_color: Color = Color("FFC857")


func _init() -> void:
	custom_minimum_size = Vector2(120, 120)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(false)


func start(seconds: float) -> void:
	total = maxf(seconds, 0.01)
	left = maxf(seconds, 0.0)
	running = seconds > 0.0
	set_process(running)
	queue_redraw()


func stop() -> void:
	running = false
	set_process(false)
	queue_redraw()


func _process(delta: float) -> void:
	if not running:
		return
	left = maxf(left - delta, 0.0)
	if left <= 0.0:
		running = false
		set_process(false)
		finished.emit()
	queue_redraw()


func _draw() -> void:
	var c: Vector2 = size / 2.0
	var r: float = minf(size.x, size.y) * 0.42
	draw_arc(c, r, 0.0, TAU, 48, Color(1, 1, 1, 0.15), 10.0)
	var frac: float = clampf(left / total, 0.0, 1.0)
	if frac > 0.0:
		var col: Color = ring_color if frac > 0.33 else Color("FF5252")
		draw_arc(c, r, -PI / 2.0, -PI / 2.0 + TAU * frac, 48, col, 10.0)
	var font: Font = get_theme_default_font()
	var fs: int = 36
	var txt: String = str(int(ceil(left)))
	var sz: Vector2 = font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	var base_y: float = c.y + (font.get_ascent(fs) - font.get_descent(fs)) / 2.0
	draw_string(font, Vector2(c.x - sz.x / 2.0, base_y), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE)
