# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Credits
extends RefCounted
## LEAD (round 9). What was made with AI, read from data/credits.json (the team edits that ONE file).
##   Credits.short_line()        "Made with AI assistance"  (bottom corner of every screen)
##   Credits.tag_for("background.png")  "Background: AI-generated / AI-assisted"  ("" if none)
##   Credits.popup(parent)       the full list (main menu > Credits)

static var _data: Dictionary = {}


static func data() -> Dictionary:
	if _data.is_empty():
		var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://data/credits.json"))
		_data = parsed if parsed is Dictionary else {"short": "Made with AI assistance", "items": []}
	return _data


static func short_line() -> String:
	return str(data().get("short", "Made with AI assistance"))


static func tag_for(image_file: String) -> String:
	return str(data().get("screen_tags", {}).get(image_file, ""))


## A small label for the bottom-left corner of a screen whose background is that image.
static func corner_tag(parent: Control, image_file: String) -> void:
	var t: String = tag_for(image_file)
	if t == "":
		return
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 12)
	l.add_theme_color_override("font_color", Color(1, 1, 1, 0.55))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	l.add_theme_constant_override("outline_size", 3)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	l.grow_vertical = Control.GROW_DIRECTION_BEGIN
	l.offset_left = 8
	l.offset_bottom = -2
	parent.add_child(l)


static func popup(parent: Node) -> void:
	var d := AcceptDialog.new()
	d.title = "Credits and AI use"
	var lines: PackedStringArray = [str(data().get("summary", "")), ""]
	for it in data().get("items", []):
		lines.append("- %s: %s (%s)" % [it.get("what", ""), it.get("ai", ""), it.get("who", "")])
	lines.append("")
	lines.append("AI tool: " + str(data().get("ai_tool", "")) + ". Full details: AI_DISCLOSURE.md in the game's source.")
	d.dialog_text = "\n".join(lines)
	d.dialog_autowrap = true
	d.size = Vector2i(820, 520)
	parent.add_child(d)
	d.popup_centered()
