# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name PartIcon
extends Control
## LEAD (art pass). A small drawn picture for every part card (UX guide rule 2: "picture, a name, one short line").
## Pure vector drawing, so it is crisp at any size and needs no image files. The picture follows the numbers:
## bigger wings for bigger panels, fuller batteries, bigger dishes, taller rockets.

var category: String = ""
var item: Dictionary = {}
var accent: Color = Color("FFC857")

const INK := Color("0B1530")
const METAL := Color("C9D3E6")
const BLUE_CELL := Color("3D6FD6")


static func make(cat: String, it: Dictionary, col: Color, px: int = 64) -> PartIcon:
	var p := PartIcon.new()
	p.category = cat
	p.item = it
	p.accent = col
	p.custom_minimum_size = Vector2(px, px)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p


func _f(key: String, d: float = 0.0) -> float:
	return float(item.get(key, d))


func _draw() -> void:
	var s: float = minf(size.x, size.y)
	var o := Vector2((size.x - s) / 2.0, (size.y - s) / 2.0)
	draw_circle(o + Vector2(s, s) / 2.0, s * 0.5, Color(accent, 0.16))
	draw_arc(o + Vector2(s, s) / 2.0, s * 0.48, 0, TAU, 40, Color(accent, 0.55), maxf(1.5, s * 0.03), true)
	draw_set_transform(o, 0.0, Vector2(s / 100.0, s / 100.0))   # draw in a 100 x 100 box
	var id := str(item.get("id", ""))
	match category:
		"bus":
			var k: float = clampf(_f("slots", 5.0) / 9.0, 0.3, 1.0)
			var w: float = 30.0 + 34.0 * k
			_box(Rect2(50 - w / 2, 50 - w / 2, w, w), Color("E8EEF9"))
			for i in int(_f("slots", 3)):
				draw_rect(Rect2(50 - w / 2 + 5 + (i % 3) * (w - 10) / 3.0, 50 - w / 2 + 5 + (i / 3) * 10, (w - 10) / 3.0 - 3, 7), accent)
		"panel", "power_pack":
			var area: float = _f("area_m2", 6.0) if category == "panel" else 8.0
			var ww: float = clampf(10.0 + area * 1.0, 10.0, 42.0)
			_box(Rect2(42, 42, 16, 16), METAL)
			if area > 0.0 or category == "power_pack":
				for side in [-1, 1]:
					var x0: float = 50.0 + side * 10.0 - (ww if side < 0 else 0.0)
					draw_rect(Rect2(x0, 38, ww, 24), BLUE_CELL)
					for gx in range(1, int(ww / 7.0) + 1):
						draw_line(Vector2(x0 + gx * 7.0, 38), Vector2(x0 + gx * 7.0, 62), Color(1, 1, 1, 0.35), 1.0)
					draw_rect(Rect2(x0, 38, ww, 24), INK, false, 2.0)
			else:
				draw_string(get_theme_default_font(), Vector2(30, 82), "none", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, INK)
			if id.begins_with("mj"):
				draw_circle(Vector2(80, 22), 6, Color("FFC857"))   # fancy cells: a little star
		"battery":
			var frac: float = clampf(log(_f("capacity_wh", 800.0)) / log(5000.0), 0.2, 1.0)
			_box(Rect2(28, 30, 44, 50), Color("E8EEF9"))
			draw_rect(Rect2(42, 24, 16, 7), INK)
			draw_rect(Rect2(32, 76 - 42 * frac, 36, 42 * frac), Color("7CE08A"))
			draw_polyline(PackedVector2Array([Vector2(52, 38), Vector2(45, 54), Vector2(55, 54), Vector2(48, 70)]), INK, 3.0)
		"rtg_count":
			_box(Rect2(36, 26, 28, 50), Color("8A93B2"))
			for i in 4:
				draw_line(Vector2(30, 32 + i * 12), Vector2(70, 32 + i * 12), INK, 3.0)
			draw_circle(Vector2(50, 84), 6, Color("FFC857"))
		"comm":
			var band: String = str(item.get("band", "x"))
			match band:
				"uhf":
					draw_line(Vector2(50, 80), Vector2(50, 18), INK, 3.0)
					draw_circle(Vector2(50, 18), 4, accent)
				"optical":
					_box(Rect2(34, 50, 32, 26), METAL)
					draw_line(Vector2(50, 50), Vector2(92, 12), Color("FF4D6D"), 4.0)
				_:
					var r: float = 14.0 + clampf(_f("mass", 10) / 38.0, 0.0, 1.0) * 18.0
					draw_arc(Vector2(50, 52), r, PI * 0.15, PI * 0.85, 20, INK, 4.0)
					draw_colored_polygon(_arc_poly(Vector2(50, 52), r, PI * 0.15, PI * 0.85), Color("E8EEF9"))
					draw_line(Vector2(50, 52), Vector2(50, 52 - r * 0.9), INK, 3.0)
					draw_line(Vector2(50, 52), Vector2(50, 84), INK, 4.0)
					if band == "ka":
						_waves(Vector2(50, 20), 3)
		"adcs":
			draw_arc(Vector2(50, 50), 26, 0, TAU, 32, INK, 5.0)
			for i in 6:
				var a: float = TAU * i / 6.0
				draw_line(Vector2(50, 50), Vector2(50, 50) + Vector2(cos(a), sin(a)) * 24, INK, 2.0)
			draw_circle(Vector2(50, 50), 6, accent)
			if id == "adcs_precision":
				draw_circle(Vector2(80, 20), 7, Color("FFC857"))
		"obc", "brain":
			_box(Rect2(30, 30, 40, 40), Color("2D3A55"))
			for i in 4:
				for side in [26, 70]:
					draw_line(Vector2(side, 36 + i * 9), Vector2(side + 4, 36 + i * 9), INK, 3.0)
			draw_string(get_theme_default_font(), Vector2(36, 56), "CPU", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("7CE08A"))
		"shield":
			var t: float = clampf(_f("rad_bonus_krad", 0) / 200.0, 0.0, 1.0)
			var pts := PackedVector2Array([Vector2(50, 18), Vector2(78, 28), Vector2(74, 60), Vector2(50, 84), Vector2(26, 60), Vector2(22, 28)])
			draw_colored_polygon(pts, Color(METAL, 0.35 + 0.65 * t))
			pts.append(pts[0])
			draw_polyline(pts, INK, 3.0 + 4.0 * t)
		"prop":
			var tier: int = int(_f("tier", 0))
			if tier == 0:
				draw_string(get_theme_default_font(), Vector2(26, 58), "none", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, INK)
			for i in tier:
				var x: float = 50.0 + (float(i) - (tier - 1) / 2.0) * 18.0
				draw_colored_polygon(PackedVector2Array([Vector2(x - 6, 30), Vector2(x + 6, 30), Vector2(x + 10, 56), Vector2(x - 10, 56)]), METAL)
				draw_colored_polygon(PackedVector2Array([Vector2(x - 8, 58), Vector2(x + 8, 58), Vector2(x, 58 + 10 + 6 * tier)]), Color("FF7A1A"))
		"rocket":
			var cap: float = float(item.get("capacity_kg", {}).get("leo", 1000))
			var h: float = clampf(30.0 + log(cap) * 5.5, 36.0, 86.0)
			var top: float = 92.0 - h
			draw_rect(Rect2(42, top + 14, 16, h - 14), Color("E8EEF9"))
			draw_colored_polygon(PackedVector2Array([Vector2(42, top + 14), Vector2(58, top + 14), Vector2(50, top)]), accent)
			draw_colored_polygon(PackedVector2Array([Vector2(42, 80), Vector2(32, 92), Vector2(42, 92)]), accent)
			draw_colored_polygon(PackedVector2Array([Vector2(58, 80), Vector2(68, 92), Vector2(58, 92)]), accent)
			if cap > 30000:   # heavy: side boosters
				draw_rect(Rect2(32, top + 30, 8, h - 34), METAL)
				draw_rect(Rect2(60, top + 30, 8, h - 34), METAL)
		"stations":
			draw_rect(Rect2(14, 78, 72, 8), Color("4A7A3A"))
			var big: bool = id == "dsn_like" or id.begins_with("perth")
			var r2: float = 22.0 if big else 15.0
			draw_colored_polygon(_arc_poly(Vector2(50, 48), r2, PI * 0.1, PI * 0.9), Color("E8EEF9"))
			draw_arc(Vector2(50, 48), r2, PI * 0.1, PI * 0.9, 16, INK, 3.0)
			draw_line(Vector2(50, 48), Vector2(50, 78), INK, 4.0)
			if id == "optical_gs":
				draw_line(Vector2(50, 40), Vector2(80, 10), Color("FF4D6D"), 3.0)
			elif id == "commercial_net":
				draw_circle(Vector2(80, 22), 9, Color("7CE08A"))
		"orbit":
			draw_circle(Vector2(50, 50), 14, Color("3D6FD6") if str(item.get("group", "")) == "earth" else (Color("B8B8C0") if str(item.get("group", "")) == "moon" else Color("D9A066")))
			var tilt: float = -0.35 if id.contains("polar") or id.contains("sso") or id.contains("dawn") else -0.12
			draw_set_transform(o + Vector2(50, 50) * s / 100.0, tilt, Vector2(s / 100.0, s / 100.0 * (0.35 if not id.begins_with("geo") else 1.0)))
			draw_arc(Vector2.ZERO, 38 if id.begins_with("geo") or id.begins_with("lunar_nrho") else 30, 0, TAU, 40, accent, 3.0, true)
			draw_set_transform(o, 0.0, Vector2(s / 100.0, s / 100.0))
		"instruments":
			_instrument(id)
		_:
			draw_circle(Vector2(50, 50), 16, accent)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _instrument(id: String) -> void:
	if id.contains("camera") or id.contains("imager") or id == "ir_mapper":
		_box(Rect2(26, 36, 44, 32), Color("2D3A55"))
		draw_circle(Vector2(48, 52), 11, METAL)
		draw_circle(Vector2(48, 52), 6, BLUE_CELL)
		draw_rect(Rect2(70, 44, 10, 16), INK)
		if id.contains("thermal") or id.contains("ir"):
			draw_circle(Vector2(78, 28), 7, Color("FF7A1A"))
	elif id.contains("sar") or id.contains("radar") or id.contains("sounder") or id == "scatterometer":
		draw_rect(Rect2(20, 62, 60, 10), METAL)
		draw_rect(Rect2(20, 62, 60, 10), INK, false, 2.0)
		_waves(Vector2(50, 50), 3)
		if id.contains("precip"):
			for i in 3:
				draw_line(Vector2(34 + i * 14, 80), Vector2(30 + i * 14, 92), BLUE_CELL, 3.0)
	elif id.contains("lightning"):
		draw_colored_polygon(PackedVector2Array([Vector2(56, 14), Vector2(32, 54), Vector2(48, 54), Vector2(40, 88), Vector2(68, 42), Vector2(52, 42)]), Color("FFC857"))
	elif id.contains("relay") and not id.contains("gauge"):
		draw_line(Vector2(50, 84), Vector2(50, 40), INK, 4.0)
		_waves(Vector2(50, 36), 3)
	elif id.contains("gauge"):
		_box(Rect2(38, 34, 24, 46), Color("E8EEF9"))
		draw_rect(Rect2(41, 56, 18, 21), BLUE_CELL)
		for i in 3:
			draw_line(Vector2(36 + i * 12, 14), Vector2(33 + i * 12, 26), BLUE_CELL, 3.0)
	elif id.contains("neutron") or id.contains("ice") or id.contains("thermal_radiometer"):
		draw_colored_polygon(PackedVector2Array([Vector2(50, 18), Vector2(72, 50), Vector2(50, 82), Vector2(28, 50)]), Color("BFE6FF"))
		draw_polyline(PackedVector2Array([Vector2(50, 18), Vector2(72, 50), Vector2(50, 82), Vector2(28, 50), Vector2(50, 18)]), INK, 2.5)
	elif id.contains("laser"):
		draw_rect(Rect2(30, 24, 22, 22), METAL)
		draw_line(Vector2(42, 46), Vector2(42, 86), Color("FF4D6D"), 4.0)
		draw_rect(Rect2(20, 86, 60, 4), Color("8A93B2"))
	elif id.contains("beacon"):
		draw_circle(Vector2(50, 50), 8, Color("7CE08A"))
		for r in [16, 26, 36]:
			draw_arc(Vector2(50, 50), r, 0, TAU, 32, Color(Color("7CE08A"), 0.6), 2.0, true)
	elif id.contains("magnet"):
		draw_arc(Vector2(50, 46), 18, 0, PI, 20, Color("FF4D6D"), 10.0)
		draw_rect(Rect2(28, 22, 9, 24), Color("FF4D6D"))
		draw_rect(Rect2(63, 22, 9, 24), BLUE_CELL)
	elif id.contains("plasma") or id.contains("dust") or id.contains("uv"):
		for i in 7:
			draw_circle(Vector2(30 + (i * 37) % 44, 28 + (i * 23) % 44), 4, accent)
		draw_arc(Vector2(50, 50), 30, 0, TAU, 32, INK, 2.0)
	elif id.contains("gravity"):
		draw_circle(Vector2(50, 50), 14, Color("D9A066"))
		for r in [22, 30]:
			draw_arc(Vector2(50, 50), r, -0.6, 0.6, 12, INK, 2.0)
	elif id.contains("spectro") or id.contains("spectrometer"):
		for i in 5:
			draw_rect(Rect2(24 + i * 11, 30, 9, 40), Color.from_hsv(float(i) / 5.0, 0.7, 0.95))
	else:
		_box(Rect2(30, 30, 40, 40), METAL)


func _box(r: Rect2, col: Color) -> void:
	draw_rect(r, col)
	draw_rect(r, INK, false, 3.0)


func _waves(c: Vector2, n: int) -> void:
	for i in n:
		draw_arc(c, 10.0 + i * 9.0, PI * 1.2, PI * 1.8, 12, INK, 3.0, true)


func _arc_poly(c: Vector2, r: float, a0: float, a1: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 17:
		var a: float = lerpf(a0, a1, float(i) / 16.0)
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	return pts
