# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name PartCard
extends PanelContainer
## One option card: name, short line, 2 to 3 key numbers, a "?" button (blurb + learn), selected and disabled states.
## Use: card.setup(item, opts), then card.set_selected(bool) and card.set_disabled_reason(text).
## opts keys: bars (Array of {label, frac, text}), cadet (bool), multi (bool), value (what chosen() sends),
##            extra (small line under the text), more (extra text revealed by "?"), accent (Color)

signal chosen(value)

var value = null
var _selected: bool = false
var _reason: String = ""
var _warning: String = ""
var _multi: bool = false
var _accent: Color = Color("F2B134")
var _pick: Button
var _help: Button
var _learn_label: Label
var _reason_label: Label
var _warning_label: Label
var _badge: Label


func setup(item: Dictionary, opts: Dictionary) -> void:
	var cadet: bool = bool(opts.get("cadet", true))
	_multi = bool(opts.get("multi", false))
	value = opts.get("value", item.get("id"))
	_accent = opts.get("accent", _accent)
	custom_minimum_size = Vector2(200, 0)   # round 9: the row decides the width (2-3 cards on a laptop)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)   # round 8: compact, so Pick fits on a 1280 x 720 screen
	add_child(vb)

	var name_label := _make_label(str(item.get("name", "?")), 19)
	name_label.add_theme_color_override("font_color", _accent)
	# MERGE (art pass): a drawn picture of the part next to its name
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	head.add_child(PartIcon.make(str(opts.get("category", "")), item, _accent, 52))
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.custom_minimum_size.x = 120
	head.add_child(name_label)
	vb.add_child(head)
	_badge = Label.new()   # MERGE (UI pass): a clear "chosen" stamp (shape + word, not colour alone)
	_badge.text = "CHOSEN" if not _multi else "ADDED"
	_badge.add_theme_font_size_override("font_size", 15)
	_badge.add_theme_color_override("font_color", GameTheme.NAVY)
	var bsb := GameTheme.box(_accent, _accent, 0, 10, 4)
	bsb.content_margin_left = 10
	bsb.content_margin_right = 10
	_badge.add_theme_stylebox_override("normal", bsb)
	_badge.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_badge.visible = false
	vb.add_child(_badge)

	var text: String = KidText.kid_or_blurb(item) if cadet else str(item.get("blurb", ""))
	vb.add_child(_make_label(text, 16))

	for b in opts.get("bars", []):
		if cadet:
			var row := HBoxContainer.new()
			var l := Label.new()
			l.text = str(b["label"])
			l.add_theme_font_size_override("font_size", 17)
			l.custom_minimum_size = Vector2(104, 0)
			row.add_child(l)
			var bar := ProgressBar.new()
			bar.min_value = 0.0
			bar.max_value = 1.0
			bar.value = float(b["frac"])
			bar.show_percentage = false
			bar.custom_minimum_size = Vector2(0, 15)
			bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			row.add_child(bar)
			vb.add_child(row)
		else:
			vb.add_child(_make_label("%s: %s" % [b["label"], b["text"]], 16))

	var extra: String = str(opts.get("extra", ""))
	if extra != "":
		var ex := _make_label(extra, 15)
		ex.add_theme_color_override("font_color", Color("9FD4FF"))
		vb.add_child(ex)

	# "?" text: blurb (hidden by the kid line in Cadet) + learn + real-world note + anything extra
	var more: Array = []
	if cadet and item.has("kid"):
		more.append(str(item.get("blurb", "")))
	if item.has("learn"):
		more.append(str(item["learn"]))
	if item.has("real_analog"):
		more.append("Inspired by: " + str(item["real_analog"]))
	if str(opts.get("more", "")) != "":
		more.append(str(opts["more"]))
	_learn_label = _make_label("\n".join(PackedStringArray(more)), 18)
	_learn_label.visible = false
	vb.add_child(_learn_label)

	_reason_label = _make_label("", 18)
	_reason_label.add_theme_color_override("font_color", Color("FF8A80"))
	_reason_label.visible = false
	vb.add_child(_reason_label)

	_warning_label = _make_label("", 18)
	_warning_label.add_theme_color_override("font_color", Color("FFB300"))
	_warning_label.visible = false
	vb.add_child(_warning_label)

	var row2 := HBoxContainer.new()
	_pick = Button.new()
	_pick.custom_minimum_size = Vector2(0, 56)
	_pick.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_pick.add_theme_font_size_override("font_size", 22)
	_pick.pressed.connect(_on_pick_pressed)
	row2.add_child(_pick)
	_help = Button.new()
	_help.text = "?"
	_help.tooltip_text = "Tell me more"
	_help.custom_minimum_size = Vector2(56, 56)
	_help.add_theme_font_size_override("font_size", 24)
	_help.disabled = _learn_label.text == ""
	_help.pressed.connect(func() -> void: _learn_label.visible = not _learn_label.visible)
	row2.add_child(_help)
	vb.add_child(row2)
	_refresh_state()


func set_selected(selected: bool) -> void:
	_selected = selected
	_refresh_state()


func set_disabled_reason(reason: String) -> void:
	_reason = reason
	_refresh_state()


## Amber note for "allowed, but it will cause a problem". Does NOT disable the card.
func set_warning(text: String) -> void:
	_warning = text
	_refresh_state()


func _refresh_state() -> void:
	if _pick == null:
		return
	var blocked: bool = _reason != "" and not _selected
	_pick.disabled = blocked
	if _selected:
		_pick.text = "Remove" if _multi else "Picked"
	else:
		_pick.text = "Add" if _multi else "Pick"
	_reason_label.text = _reason
	_reason_label.visible = blocked
	_warning_label.text = "! " + _warning
	_warning_label.visible = _warning != "" and not blocked
	modulate = Color(1, 1, 1, 0.6) if blocked else Color(1, 1, 1, 1)
	# MERGE (UI pass): Dev D's rounded cards; the chosen card glows in the role colour
	var sb := GameTheme.box(GameTheme.PANEL_HI if not _selected else _accent.darkened(0.62),
		_accent if _selected else GameTheme.EDGE, 4 if _selected else 2, 18, 14)
	if _selected:
		sb.shadow_color = Color(_accent, 0.35)
		sb.shadow_size = 10
	add_theme_stylebox_override("panel", sb)
	if _badge != null:
		_badge.visible = _selected
	if _selected:
		GameTheme.paint_button(_pick, _accent.darkened(0.4), GameTheme.TEXT)
	else:
		GameTheme.paint_button(_pick, _accent, GameTheme.NAVY)


func _on_pick_pressed() -> void:
	Audio.play_sfx("snap")   # MERGE (juice): every pick pops
	Fx.burst(self, Vector2(size.x / 2.0, size.y * 0.3), [_accent, Color.WHITE], 16)
	pivot_offset = size / 2.0
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(1.05, 1.05), 0.08)
	tw.tween_property(self, "scale", Vector2(1.0, 1.0), 0.12)
	chosen.emit(value)


func _make_label(text: String, font_size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(170, 0)
	return l
