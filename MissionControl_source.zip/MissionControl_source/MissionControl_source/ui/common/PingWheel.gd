# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name PingWheel
extends Control
## Radio Silence: five preset cards in a wheel. Each press calls Net.ping(card_id).
## card ids: need_power, have_spare_data, on_it, wait, help

signal pinged(card_id: String)

const CARDS: Array = [
	{"id": "need_power", "text": "NEED POWER"},
	{"id": "have_spare_data", "text": "HAVE SPARE DATA"},
	{"id": "on_it", "text": "ON IT"},
	{"id": "wait", "text": "WAIT"},
	{"id": "help", "text": "HELP"},
]
const WHEEL_SIZE: Vector2 = Vector2(600, 420)
const BTN_SIZE: Vector2 = Vector2(190, 68)
const COOLDOWN_S: float = 1.2

var _buttons: Array = []
var _built: bool = false


func _ready() -> void:
	_build()


func _build() -> void:
	if _built:
		return
	_built = true
	custom_minimum_size = WHEEL_SIZE
	var centre: Vector2 = WHEEL_SIZE / 2.0
	var hub := Label.new()
	hub.text = "PING"
	hub.add_theme_font_size_override("font_size", 28)
	hub.size = Vector2(120, 40)
	hub.position = centre - hub.size / 2.0
	hub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(hub)
	for i in CARDS.size():
		var ang: float = deg_to_rad(-90.0 + 72.0 * float(i))
		var pos: Vector2 = centre + Vector2(cos(ang) * 200.0, sin(ang) * 140.0) - BTN_SIZE / 2.0
		var b := Button.new()
		b.text = str(CARDS[i]["text"])
		b.size = BTN_SIZE
		b.position = pos
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(_on_pressed.bind(str(CARDS[i]["id"])))
		add_child(b)
		_buttons.append(b)


func set_enabled(on: bool) -> void:
	_build()
	for b in _buttons:
		(b as Button).disabled = not on


func _on_pressed(card_id: String) -> void:
	PanelBridge.ping(card_id)
	pinged.emit(card_id)
	set_enabled(false)   # short cooldown so nobody spams the radio
	get_tree().create_timer(COOLDOWN_S).timeout.connect(set_enabled.bind(true))
