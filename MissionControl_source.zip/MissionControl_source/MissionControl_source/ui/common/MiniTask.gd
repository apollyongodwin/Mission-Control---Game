# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name MiniTask
extends Control
## LEAD (round 8) MINI-TASKS, Among Us style. One quick game per role:
##   FLIGHT   "asteroids"  tap the space rocks before they hit the ship
##   SYSTEMS  "wires"      drag each wire to the socket with the same colour AND shape
##   PAYLOAD  "binary"     read a binary number and pick its value (the place values are shown under the bits)
##   GROUND   "trace"      drag the radio signal from the dish to the satellite without touching the walls
## The host starts one with Net.say_to(peer, "task_start", "<task>|<kind>|<seconds>"). This screen answers with
## Net.ping("@task:ok") or Net.ping("@task:fail"). A finished task earns the player 1 token.
## Difficulty (cadet / engineer / flight_director) makes each game a little harder.
## Test one alone:  godot --path . res://tests/minitask_shot.tscn -- --task=wires

signal finished(ok: bool)

const NAMES := {
	"asteroids": ["ASTEROID FIELD", "Tap the space rocks before they hit the ship!"],
	"wires": ["FIX THE WIRING", "Drag each wire to the socket with the same colour and shape."],
	"binary": ["DECODE THE DATA", "What number is this? Add the numbers under every 1."],
	"trace": ["ALIGN THE ANTENNA", "Drag the signal from the dish to the satellite. Don't touch the walls!"],
}

var task: String = "wires"
var kind: String = "random"
var seconds: float = 20.0
var difficulty: String = "cadet"
var report_to_host: bool = true

var _left: float = 0.0
var _done: bool = false
var _bar: ProgressBar = null
var _time_label: Label = null
var _status: Label = null
var _game: Control = null


func setup(p_task: String, p_kind: String, p_seconds: float, p_difficulty: String) -> void:
	task = p_task if NAMES.has(p_task) else "wires"
	kind = p_kind
	seconds = maxf(5.0, p_seconds)
	difficulty = p_difficulty


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_left = seconds
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.1, 0.82)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var card := GameTheme.panel(GameTheme.PANEL, GameTheme.AMBER, 4, 22, 18)
	card.custom_minimum_size = Vector2(minf(980.0, get_viewport_rect().size.x - 40.0), minf(600.0, get_viewport_rect().size.y - 40.0))
	center.add_child(card)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	card.add_child(col)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 14)
	col.add_child(top)
	var tv := VBoxContainer.new()
	tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(tv)
	var kind_text: String = "CHIP-IN TASK: finish it to capture the chance!" if kind == "chip" else "SURPRISE TASK: finish it to earn a token!"
	tv.add_child(GameTheme.label(kind_text, 18, GameTheme.MUTED, false))
	tv.add_child(GameTheme.label(str(NAMES[task][0]), 34, GameTheme.AMBER, false))
	var how := GameTheme.label(str(NAMES[task][1]), 22, GameTheme.TEXT, true)
	how.custom_minimum_size.x = 600
	tv.add_child(how)
	_time_label = GameTheme.label("", 40, GameTheme.AMBER, false)
	top.add_child(_time_label)
	_bar = ProgressBar.new()
	_bar.show_percentage = false
	_bar.custom_minimum_size.y = 12
	_bar.max_value = seconds
	col.add_child(_bar)
	match task:
		"asteroids":
			_game = Asteroids.new()
		"binary":
			_game = Binary.new()
		"trace":
			_game = Trace.new()
		_:
			_game = Wires.new()
	_game.set("level", {"cadet": 0, "engineer": 1, "flight_director": 2}.get(difficulty, 0))
	_game.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_game.custom_minimum_size = Vector2(0, 360)
	_game.clip_contents = true
	col.add_child(_game)
	_game.connect("solved", func() -> void: _finish(true))
	_game.connect("failed", func() -> void: _finish(false))
	_status = GameTheme.label("", 22, GameTheme.GOOD, false)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(_status)
	Audio.play_sfx("quindar_in")


func _process(delta: float) -> void:
	if _done:
		return
	_left -= delta
	_bar.value = maxf(0.0, _left)
	_time_label.text = str(maxi(0, int(ceil(_left))))
	if _left <= 0.0:
		_finish(false, "Time's up!")


## Called by the crew screen when the host stops the task (the chance passed, the round ended).
func stop(message: String) -> void:
	if _done:
		return
	_done = true
	_status.text = message
	_status.add_theme_color_override("font_color", GameTheme.MUTED)
	_close_soon(1.2)


func _finish(ok: bool, message: String = "") -> void:
	if _done:
		return
	_done = true
	if report_to_host:
		Net.ping("@task:ok" if ok else "@task:fail")
	_status.text = (message if message != "" else ("TASK DONE! +1 token" if ok else "Oops! Task failed."))
	_status.add_theme_color_override("font_color", GameTheme.GOOD if ok else GameTheme.BAD)
	Audio.play_sfx("success" if ok else "fail")
	if ok:
		Fx.burst(self, size * 0.5, [GameTheme.GOOD, Color.WHITE], 30)
	finished.emit(ok)
	_close_soon(1.6)


func _close_soon(t: float) -> void:
	get_tree().create_timer(t).timeout.connect(func() -> void:
		if is_instance_valid(self):
			queue_free())


# ======================================================================
# FLIGHT: asteroids. Rocks drift in from the right towards the ship; tap them.
# ======================================================================
class Asteroids extends Control:
	signal solved
	signal failed
	var level: int = 0
	var _rocks: Array = []        # [{p: Vector2, v: Vector2, r: float, spin: float}]
	var _booms: Array = []        # [{p, t}]
	var _shots: Array = []        # [{to, t}]
	var _spawn_t: float = 0.3
	var _hit: int = 0
	var _hurt: int = 0
	var _rng := RandomNumberGenerator.new()
	var _over: bool = false

	func _need() -> int:
		return [6, 8, 10][level]

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		_rng.randomize()

	func _ship() -> Vector2:
		return Vector2(70, size.y * 0.5)

	func _process(delta: float) -> void:
		if _over:
			return
		_spawn_t -= delta
		if _spawn_t <= 0.0:
			_spawn_t = [1.0, 0.8, 0.6][level]
			var p := Vector2(size.x + 30, _rng.randf_range(30, size.y - 30))
			var v := (_ship() - p).normalized() * _rng.randf_range(90, 140 + 40 * level)
			_rocks.append({"p": p, "v": v, "r": _rng.randf_range(22, 34), "spin": _rng.randf() * TAU})
		for rk in _rocks:
			rk["p"] += rk["v"] * delta
			rk["spin"] += delta
		for i in range(_rocks.size() - 1, -1, -1):
			if (_rocks[i]["p"] as Vector2).distance_to(_ship()) < 36.0:
				_booms.append({"p": _rocks[i]["p"], "t": 0.5})
				_rocks.remove_at(i)
				_hurt += 1
				Audio.play_sfx("hit")
				if _hurt >= 3:
					_over = true
					failed.emit()
		for b in _booms:
			b["t"] -= delta
		_booms = _booms.filter(func(b): return float(b["t"]) > 0.0)
		for s in _shots:
			s["t"] -= delta
		_shots = _shots.filter(func(s): return float(s["t"]) > 0.0)
		queue_redraw()

	func _gui_input(ev: InputEvent) -> void:
		if _over or not (ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT):
			return
		for i in range(_rocks.size() - 1, -1, -1):
			if (_rocks[i]["p"] as Vector2).distance_to(ev.position) < float(_rocks[i]["r"]) + 14.0:
				_shots.append({"to": _rocks[i]["p"], "t": 0.15})
				_booms.append({"p": _rocks[i]["p"], "t": 0.4})
				_rocks.remove_at(i)
				_hit += 1
				Audio.play_sfx("snap")
				if _hit >= _need():
					_over = true
					solved.emit()
				return

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color("070D1F"))
		var rng2 := RandomNumberGenerator.new()
		rng2.seed = 7
		for i in 60:
			draw_circle(Vector2(rng2.randf() * size.x, rng2.randf() * size.y), rng2.randf_range(0.6, 1.8), Color(1, 1, 1, 0.5))
		var s := _ship()
		draw_colored_polygon(PackedVector2Array([s + Vector2(30, 0), s + Vector2(-20, -18), s + Vector2(-10, 0), s + Vector2(-20, 18)]), GameTheme.role_color("flight"))
		for sh in _shots:
			draw_line(s + Vector2(30, 0), sh["to"], Color(1, 0.9, 0.4), 4.0)
		for rk in _rocks:
			var pts := PackedVector2Array()
			for k in 9:
				var a: float = float(k) / 9.0 * TAU + float(rk["spin"])
				pts.append(rk["p"] + Vector2(cos(a), sin(a)) * float(rk["r"]) * (0.8 + 0.2 * sin(a * 3.0)))
			draw_colored_polygon(pts, Color("8C7A6B"))
			draw_polyline(pts + PackedVector2Array([pts[0]]), Color("C9B8A6"), 2.0)
		for b in _booms:
			draw_circle(b["p"], 40.0 * (1.0 - float(b["t"])), Color(1, 0.6, 0.2, float(b["t"]) * 1.5))
		var font := get_theme_default_font()
		draw_string(font, Vector2(16, 30), "ZAPPED %d / %d" % [_hit, _need()], HORIZONTAL_ALIGNMENT_LEFT, -1, 24, GameTheme.AMBER)
		draw_string(font, Vector2(size.x - 210, 30), "HULL", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, GameTheme.BAD)
		for i in 3:
			LivesBar.draw_heart(self, Vector2(size.x - 130 + i * 36, 22), 13.0, Color("FF5E7A"), i < 3 - _hurt)


# ======================================================================
# SYSTEMS: wires. Colour AND shape match (never colour alone: UX rule 8).
# ======================================================================
class Wires extends Control:
	signal solved
	signal failed
	var level: int = 0
	const COLORS := [Color("FF5E5E"), Color("4FB3FF"), Color("FFD23F"), Color("7CE08A"), Color("D07CFF")]
	const SHAPES := ["circle", "square", "triangle", "star", "diamond"]
	var _n: int = 4
	var _left_order: Array = []
	var _right_order: Array = []
	var _done: Dictionary = {}     # wire index -> true
	var _drag: int = -1
	var _drag_pos: Vector2 = Vector2.ZERO
	var _over: bool = false

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		_n = [3, 4, 5][level]
		for i in _n:
			_left_order.append(i)
			_right_order.append(i)
		_left_order.shuffle()
		_right_order.shuffle()
		while _right_order == _left_order and _n > 1:
			_right_order.shuffle()

	func _slot(side: int, row: int) -> Vector2:
		var y: float = size.y * (float(row) + 0.5) / float(_n)
		return Vector2(80.0 if side == 0 else size.x - 80.0, y)

	func _gui_input(ev: InputEvent) -> void:
		if _over:
			return
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				for row in _n:
					var w: int = _left_order[row]
					if not _done.has(w) and _slot(0, row).distance_to(ev.position) < 44.0:
						_drag = w
						_drag_pos = ev.position
						return
			elif _drag >= 0:
				for row in _n:
					if _slot(1, row).distance_to(ev.position) < 48.0:
						if _right_order[row] == _drag:
							_done[_drag] = true
							Audio.play_sfx("snap")
							if _done.size() >= _n:
								_over = true
								solved.emit()
						else:
							Audio.play_sfx("buzz")
				_drag = -1
				queue_redraw()
		elif ev is InputEventMouseMotion and _drag >= 0:
			_drag_pos = ev.position
			queue_redraw()

	func _shape(c: Vector2, shape: String, col: Color, r: float) -> void:
		match shape:
			"square":
				draw_rect(Rect2(c - Vector2(r, r) * 0.8, Vector2(r, r) * 1.6), col)
			"triangle":
				draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r, r * 0.8), c + Vector2(-r, r * 0.8)]), col)
			"diamond":
				draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r, 0), c + Vector2(0, r), c + Vector2(-r, 0)]), col)
			"star":
				var pts := PackedVector2Array()
				for k in 10:
					var a: float = -PI / 2.0 + float(k) * PI / 5.0
					pts.append(c + Vector2(cos(a), sin(a)) * (r if k % 2 == 0 else r * 0.45))
				draw_colored_polygon(pts, col)
			_:
				draw_circle(c, r, col)

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color("10192F"))
		draw_rect(Rect2(Vector2(40, 10), Vector2(80, size.y - 20)), Color("2A3550"))
		draw_rect(Rect2(Vector2(size.x - 120, 10), Vector2(80, size.y - 20)), Color("2A3550"))
		for row in _n:
			var w: int = _left_order[row]
			var a := _slot(0, row)
			if _done.has(w):
				var b := _slot(1, _right_order.find(w))
				draw_line(a, b, COLORS[w], 12.0)
			_shape(a, SHAPES[w], COLORS[w], 22.0)
		for row in _n:
			var w2: int = _right_order[row]
			var b2 := _slot(1, row)
			draw_circle(b2, 30.0, Color("0B1530"))
			_shape(b2, SHAPES[w2], COLORS[w2], 22.0)
		if _drag >= 0:
			draw_line(_slot(0, _left_order.find(_drag)), _drag_pos, COLORS[_drag], 12.0)


# ======================================================================
# PAYLOAD: binary. 3 numbers in a row. A wrong answer just gives a new number (and costs time).
# ======================================================================
class Binary extends Control:
	signal solved
	signal failed
	var level: int = 0
	var _bits: int = 4
	var _value: int = 0
	var _right: int = 0
	var _need: int = 3
	var _bits_box: HBoxContainer = null
	var _answers: HBoxContainer = null
	var _count: Label = null
	var _rng := RandomNumberGenerator.new()

	func _ready() -> void:
		_rng.randomize()
		_bits = [4, 5, 6][level]
		var col := VBoxContainer.new()
		col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		col.alignment = BoxContainer.ALIGNMENT_CENTER
		col.add_theme_constant_override("separation", 18)
		add_child(col)
		_count = GameTheme.label("", 22, GameTheme.MUTED, false)
		_count.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(_count)
		_bits_box = HBoxContainer.new()
		_bits_box.alignment = BoxContainer.ALIGNMENT_CENTER
		_bits_box.add_theme_constant_override("separation", 10)
		col.add_child(_bits_box)
		_answers = HBoxContainer.new()
		_answers.alignment = BoxContainer.ALIGNMENT_CENTER
		_answers.add_theme_constant_override("separation", 16)
		col.add_child(_answers)
		_next()

	func _next() -> void:
		_count.text = "Number %d of %d" % [_right + 1, _need]
		_value = _rng.randi_range(1, (1 << _bits) - 1)
		for c in _bits_box.get_children():
			c.queue_free()
		for c in _answers.get_children():
			c.queue_free()
		for i in range(_bits - 1, -1, -1):
			var on: bool = (_value >> i) & 1 == 1
			var cell := VBoxContainer.new()
			cell.add_theme_constant_override("separation", 2)
			var big := GameTheme.label("1" if on else "0", 64, GameTheme.AMBER if on else GameTheme.MUTED, false)
			big.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			big.custom_minimum_size = Vector2(76, 0)
			cell.add_child(big)
			var place := GameTheme.label(str(1 << i), 20, GameTheme.TEXT if on else Color(GameTheme.MUTED, 0.5), false)
			place.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			cell.add_child(place)
			_bits_box.add_child(cell)
		var opts: Array = [_value]
		while opts.size() < 4:
			var w: int = clampi(_value + _rng.randi_range(-6, 6), 0, (1 << _bits) - 1)
			if randf() < 0.4:
				w = _value ^ (1 << _rng.randi_range(0, _bits - 1))   # a "one bit wrong" answer
			if not opts.has(w):
				opts.append(w)
		opts.shuffle()
		for o in opts:
			var b := Button.new()
			b.text = str(o)
			b.custom_minimum_size = Vector2(120, 72)
			b.add_theme_font_size_override("font_size", 34)
			GameTheme.primary(b)
			var val: int = o
			b.pressed.connect(func() -> void: _pick(val))
			_answers.add_child(b)

	func _pick(v: int) -> void:
		if v == _value:
			_right += 1
			Audio.play_sfx("chime")
			if _right >= _need:
				for c in _answers.get_children():
					(c as Button).disabled = true
				solved.emit()
				return
		else:
			Audio.play_sfx("buzz")
		_next()


# ======================================================================
# GROUND: trace. A winding corridor from the dish to the satellite. Leave it and you start again.
# ======================================================================
class Trace extends Control:
	signal solved
	signal failed
	var level: int = 0
	var _path: PackedVector2Array = PackedVector2Array()
	var _half: float = 30.0
	var _tracing: bool = false
	var _best: int = 0
	var _pos: Vector2 = Vector2.ZERO
	var _flash: float = 0.0
	var _over: bool = false
	var _resets: int = 0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		_half = [34.0, 26.0, 20.0][level]
		resized.connect(_build)
		_build()

	func _build() -> void:
		if size.x < 10:
			return
		var rng := RandomNumberGenerator.new()
		rng.randomize()
		_path = PackedVector2Array()
		var n: int = 7 + level * 2
		for i in n:
			var x: float = lerpf(70.0, size.x - 70.0, float(i) / float(n - 1))
			var y: float = size.y * 0.5 if i == 0 or i == n - 1 else rng.randf_range(_half + 20.0, size.y - _half - 20.0)
			_path.append(Vector2(x, y))
		_best = 0
		queue_redraw()

	func _dist(p: Vector2) -> Array:
		## [distance to the corridor's centre line, how far along (segment index + fraction)]
		var best_d := INF
		var best_t := 0.0
		for i in _path.size() - 1:
			var a := _path[i]
			var b := _path[i + 1]
			var ab := b - a
			var t: float = clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
			var d: float = p.distance_to(a + ab * t)
			if d < best_d:
				best_d = d
				best_t = float(i) + t
		return [best_d, best_t]

	func _gui_input(ev: InputEvent) -> void:
		if _over:
			return
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed and ev.position.distance_to(_path[0]) < _half + 12.0:
				_tracing = true
				_pos = ev.position
			elif not ev.pressed:
				_tracing = false
			queue_redraw()
		elif ev is InputEventMouseMotion and _tracing:
			_pos = ev.position
			var r: Array = _dist(_pos)
			if float(r[0]) > _half:
				_tracing = false
				_flash = 0.4
				_resets += 1
				Audio.play_sfx("buzz")
			elif float(r[1]) >= float(_path.size() - 1) - 0.02:
				_over = true
				_tracing = false
				solved.emit()
			queue_redraw()

	func _process(delta: float) -> void:
		if _flash > 0.0:
			_flash -= delta
			queue_redraw()

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color("BF3A3A") if _flash > 0.0 else Color("10192F"))
		if _path.size() < 2:
			return
		draw_polyline(_path, Color("2D4A7A"), _half * 2.0 + 8.0, true)
		draw_polyline(_path, Color("0B1530"), _half * 2.0, true)
		for p in _path:
			draw_circle(p, _half, Color("0B1530"))
		draw_polyline(_path, Color(1, 1, 1, 0.12), 2.0)
		# the dish (start) and the satellite (finish)
		var s := _path[0]
		draw_arc(s + Vector2(-6, 0), 26.0, -PI * 0.5, PI * 0.5, 16, GameTheme.role_color("ground"), 6.0)
		draw_circle(s, 10.0, GameTheme.AMBER)
		var e := _path[_path.size() - 1]
		draw_rect(Rect2(e - Vector2(12, 12), Vector2(24, 24)), Color("C9D3E6"))
		draw_rect(Rect2(e + Vector2(-44, -6), Vector2(28, 12)), Color("4FB3FF"))
		draw_rect(Rect2(e + Vector2(16, -6), Vector2(28, 12)), Color("4FB3FF"))
		if _tracing:
			draw_line(s, _pos, Color(GameTheme.AMBER, 0.5), 3.0)
			draw_circle(_pos, 12.0, GameTheme.AMBER)
		var font := get_theme_default_font()
		var tip := "Press on the yellow dot and drag!" if not _tracing else "Keep going..."
		if _resets > 0 and not _tracing:
			tip = "Bumped the wall! Start again from the yellow dot."
		draw_string(font, Vector2(16, size.y - 14), tip, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, GameTheme.TEXT)
