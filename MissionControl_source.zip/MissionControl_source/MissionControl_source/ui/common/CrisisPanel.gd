# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CrisisPanel
extends PanelContainer
## What a crew member sees while an event is live. (Dev B's panel, rebuilt by the Lead in round 6.)
## Compact and see-through, so the ship and orbit stay visible behind it. Top to bottom:
##   header      cat, what is happening, the clock, HURRY COMMANDER, I'm done, HIDE
##   info row    your two gauges (Commander mode) and MY TOKENS (icons + counts, always visible)
##   asks        "FLIGHT asks you for 1 power  [GIVE]"  (one tap)
##   cards       every card in ONE row. Costs are token pictures. A card that needs a teammate's token
##               shows a big "ASK SYSTEMS" button instead of Play.
##   give row    one-tap "give 1 power to FLIGHT" buttons
## Handles the three event kinds: crisis (action cards), opportunity (chip in), decision (pick an option).
## API (unchanged): setup(role, accent), show_event(event, timer_s), show_result(result), refresh(), signal dismissed,
##                  signal hide_requested (RoleOverlay minimises the panel).

signal dismissed
signal hide_requested
signal shown_again

const TAG_NAMES: Dictionary = {"radiation": "Radiation", "power": "Power", "data": "Data", "comms": "Radio link",
	"thermal": "Heat", "debris": "Space junk", "software": "Software", "budget": "Money"}
const TOKEN_WORDS: Dictionary = {"power": "power", "data": "data", "budget": "money", "comms": "signal", "fuel": "fuel", "time": "time"}

var role_id: String = "systems"
var _accent: Color = Color("F2B134")
var _built: bool = false
var _event: Dictionary = {}
var _kind: String = "crisis"
var _acted: bool = false
var _active: bool = false
var _action_cards: Array = []   # {cost, button, panel, kind, id, title}
var _ask_ready_at: int = 0
var _hurry_ready_at: int = 0

var _head_cat: CrewArt
var _title: Label
var _flavor: Label
var _ring: CountdownRing
var _hurry_btn: Button
var _pass_btn: Button
var _hide_btn: Button
var _gauge_box: HBoxContainer
var _tokens_box: HBoxContainer
var _asks_box: VBoxContainer
var _banner: Label
var _status: Label
var _cards_row: HBoxContainer
var _give_box: HFlowContainer
var _ping: PingWheel
var _result_box: VBoxContainer
var _result_cat: CrewArt
var _quip: Label
var _result_label: Label
var _learn_label: Label


func setup(role: String, accent: Color) -> void:
	role_id = role
	_accent = accent
	if _built:
		return
	_built = true
	# round 8: nearly solid. At 0.93 the words behind it showed through and looked like a mess.
	add_theme_stylebox_override("panel", GameTheme.box(Color(0.06, 0.09, 0.19, 0.985), Color(_accent, 0.9), 3, 22, 14))
	PanelBridge.on_tokens_changed(refresh)
	PanelBridge.on_server_message(_on_server_message)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	add_child(vb)

	# ---- header
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	vb.add_child(head)
	_head_cat = CrewArt.make(role_id, 70, "worried")
	head.add_child(_head_cat)
	var ht := VBoxContainer.new()
	ht.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ht.add_theme_constant_override("separation", 0)
	_title = _label("", 30, Color("FF6B5E"))
	ht.add_child(_title)
	_flavor = _label("", 18, GameTheme.TEXT)
	ht.add_child(_flavor)
	head.add_child(ht)
	_ring = CountdownRing.new()
	head.add_child(_ring)
	_hurry_btn = _button("HURRY,\nCOMMANDER!", Color("C0392B"), Color.WHITE, Vector2(150, 64), 17)
	_hurry_btn.tooltip_text = "Flashes the Commander's screen red. They can't see your clock!"
	_hurry_btn.pressed.connect(_on_hurry_pressed)
	head.add_child(_hurry_btn)
	_pass_btn = _button("I'm done", GameTheme.PANEL_HI, GameTheme.TEXT, Vector2(120, 64), 18)
	_pass_btn.tooltip_text = "Nothing (more) to play this time? Tell the crew you are done."
	_pass_btn.pressed.connect(_on_pass_pressed)
	head.add_child(_pass_btn)
	_hide_btn = _button("Hide", GameTheme.PANEL_HI, GameTheme.MUTED, Vector2(80, 64), 16)
	_hide_btn.tooltip_text = "Shrink this to see your ship. Tap the red bar to bring it back."
	_hide_btn.pressed.connect(func() -> void: hide_requested.emit())
	head.add_child(_hide_btn)

	# ---- gauges + my tokens
	var info := HBoxContainer.new()
	info.add_theme_constant_override("separation", 12)
	vb.add_child(info)
	_gauge_box = HBoxContainer.new()
	_gauge_box.add_theme_constant_override("separation", 10)
	info.add_child(_gauge_box)
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_child(sp)
	var lives := LivesBar.new()   # round 8
	lives.heart = 13.0
	lives.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	info.add_child(lives)
	var tk := GameTheme.panel(Color(1, 1, 1, 0.05), Color(GameTheme.AMBER, 0.6), 2, 14, 8)
	info.add_child(tk)
	var tkv := VBoxContainer.new()
	tkv.add_theme_constant_override("separation", 2)
	tk.add_child(tkv)
	tkv.add_child(_label("MY TOKENS (cards cost these)", 13, GameTheme.AMBER, false))
	_tokens_box = HBoxContainer.new()
	_tokens_box.add_theme_constant_override("separation", 12)
	tkv.add_child(_tokens_box)

	_asks_box = VBoxContainer.new()
	_asks_box.add_theme_constant_override("separation", 6)
	vb.add_child(_asks_box)
	_banner = _label("RADIO SILENCE: crew, don't talk to each other! Talk only to the Commander, or use the Ping Wheel.", 18, Color("FF6B5E"))
	vb.add_child(_banner)
	_status = _label("", 18, Color("9FD4FF"))
	vb.add_child(_status)

	# ---- cards (one row)
	_cards_row = HBoxContainer.new()
	_cards_row.add_theme_constant_override("separation", 10)
	vb.add_child(_cards_row)

	# ---- give row
	_give_box = HFlowContainer.new()
	_give_box.add_theme_constant_override("h_separation", 8)
	_give_box.add_theme_constant_override("v_separation", 6)
	vb.add_child(_give_box)

	_ping = PingWheel.new()
	_ping.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(_ping)

	# ---- result
	_result_box = VBoxContainer.new()
	_result_box.add_theme_constant_override("separation", 8)
	var rh := HBoxContainer.new()
	rh.add_theme_constant_override("separation", 16)
	_result_cat = CrewArt.make(role_id, 120)
	rh.add_child(_result_cat)
	var rv := VBoxContainer.new()
	rv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_quip = _label("", 30, GameTheme.AMBER)
	rv.add_child(_quip)
	_result_label = _label("", 20, GameTheme.TEXT)
	rv.add_child(_result_label)
	_learn_label = _label("", 17, Color("9FD4FF"))
	rv.add_child(_learn_label)
	rh.add_child(rv)
	_result_box.add_child(rh)
	var ok := _button("OK", _accent, GameTheme.NAVY, Vector2(220, 64), 26)
	ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ok.pressed.connect(_on_ok_pressed)
	_result_box.add_child(ok)
	vb.add_child(_result_box)
	_clear_view()


func _ready() -> void:
	if not _built:
		var info: Dictionary = Data.db["meta"]["roles"][role_id]
		setup(role_id, Color(str(info["color"])))


## wrap = false for labels inside a row (a wrapping label in an HBox gets 0 width: one letter per line).
func _label(text: String, size: int, col: Color, wrap: bool = true) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if wrap else TextServer.AUTOWRAP_OFF
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	return l


func _button(text: String, bg: Color, fg: Color, min_size: Vector2, font: int) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font)
	GameTheme.paint_button(b, bg, fg)
	return b


func _token_icon(tok: String, px: int) -> TokenIcon:
	var t := TokenIcon.new()
	t.kind = str(Data.db["meta"]["tokens"].get(tok, {}).get("icon", "coin"))
	t.custom_minimum_size = Vector2(px, px)
	return t


static func token_word(tok: String) -> String:
	return str(TOKEN_WORDS.get(tok, tok))


## Who OWNS a token type (role id).
static func owner_role(tok: String) -> String:
	var roles: Dictionary = Data.db["meta"]["roles"]
	for r in roles:
		if ((roles[r] as Dictionary)["owns_tokens"] as Array).has(tok):
			return str(r)
	return ""


func _clear_view() -> void:
	for c in _cards_row.get_children():
		_cards_row.remove_child(c)
		c.queue_free()
	for c in _asks_box.get_children():
		_asks_box.remove_child(c)
		c.queue_free()
	_action_cards.clear()
	_ring.stop()
	_ring.visible = false
	_banner.visible = false
	_status.text = ""
	_give_box.visible = false
	_ping.visible = false
	_result_box.visible = false
	_pass_btn.visible = false
	_hurry_btn.visible = false
	_hide_btn.visible = false
	_gauge_box.visible = false


# ================================================================== the host starts an event
func show_event(event: Dictionary, timer_s: float = 0.0) -> void:
	_clear_view()
	_cards_row.visible = true
	_event = event
	_kind = str(event.get("kind", "crisis"))
	_acted = false
	_active = true
	_title.text = str(event.get("title", "Alert!")).to_upper()
	_flavor.text = str(event.get("flavor", ""))
	if MissionState.commander_mode and _kind == "crisis":
		_title.text = "ANOMALY!"
		_flavor.text = "Tell the Commander which of your gauges say ALARM. The Commander knows which card to play!"
		_build_gauges()
	Audio.duck(true)
	_head_cat.set_role(role_id, "worried" if _kind == "crisis" else "")
	if _kind == "crisis":
		Audio.play_sfx("whoosh" if PanelBridge.is_cadet() else "alarm")
		Fx.shake(_head_cat, 8.0, 0.4)   # (shaking the panel itself un-does its container placement)
	else:
		Audio.play_sfx("warp")
	Fx.pop(_title, 1.15)
	_ring.visible = timer_s > 0.0   # round 7: every difficulty has a clock (Cadet's is longer)
	if _ring.visible:
		_ring.start(timer_s)
	var silent: bool = PanelBridge.radio_silence() and _kind == "crisis"
	_banner.visible = silent
	_ping.visible = silent
	_ping.set_enabled(true)
	_hurry_btn.visible = MissionState.commander_mode
	_hurry_btn.disabled = false
	_hide_btn.visible = true
	match _kind:
		"opportunity":
			_build_opportunity()
		"decision":
			_build_decision()
		_:
			_build_actions()
	_give_box.visible = _kind == "crisis"   # tokens can only be handed over during a crisis (spec 5.1)
	_pass_btn.visible = true
	_pass_btn.disabled = false
	refresh()


func _build_gauges() -> void:
	for c in _gauge_box.get_children():
		_gauge_box.remove_child(c)
		c.queue_free()
	var threat: Dictionary = _event.get("threat", {})
	for g in RoleGuide.gauges_for(role_id):
		var lv: String = RoleGuide.level(float(threat.get(g["tag"], 0.0)))
		var col: Color = RoleGuide.level_color(lv)
		var pc := GameTheme.panel(Color(col, 0.16), col, 3, 14, 8)
		pc.custom_minimum_size = Vector2(210, 0)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", -2)
		pc.add_child(v)
		v.add_child(_label(str(g["name"]).to_upper(), 14, GameTheme.MUTED, false))
		v.add_child(_label("!!! ALARM" if lv == "ALARM" else "OK", 28, col, false))   # shape + word, never colour alone
		_gauge_box.add_child(pc)
		if lv == "ALARM":
			var tw := pc.create_tween().set_loops(6)
			tw.tween_property(pc, "modulate:a", 0.55, 0.35)
			tw.tween_property(pc, "modulate:a", 1.0, 0.35)
	_gauge_box.visible = true


func _build_actions() -> void:
	var threat: Dictionary = _event.get("threat", {})
	for a in Data.db["actions"]:
		if str(a["role"]) != role_id:
			continue
		var helps := false
		var blocks: PackedStringArray = []
		for tag in (a["mitigates"] as Dictionary):
			if float(threat.get(tag, 0.0)) > 0.0:
				helps = true
			blocks.append(str(TAG_NAMES.get(tag, tag)))
		if MissionState.commander_mode:
			helps = false   # which card works is in the Commander's handbook, not on the card
		var extra: String = "" if MissionState.commander_mode else "Fixes: " + ", ".join(blocks)
		var se: String = _side_effect_text(a.get("side_effect", {}))
		if se != "":
			extra += ("\n" if extra != "" else "") + "Side effect: " + se
		_add_card(str(a["label"]), str(a.get("blurb", "")), extra, helps, "Play", a["cost"], "action", str(a["id"]))
	if _action_cards.is_empty():
		_status.text = "You have no cards. Give your tokens to a teammate and cheer them on!"


func _build_opportunity() -> void:
	var needs: Dictionary = _event.get("needs", {})
	var gain: Dictionary = _event.get("gain", {})
	var extra := ""
	if gain.has("science_pct"):
		extra = "Reward: +%s%% science" % CardStats.fmt(gain["science_pct"])
	var mine: Dictionary = {}
	var owned: Array = Data.db["meta"]["roles"][role_id]["owns_tokens"]
	for tok in needs:
		if owned.has(tok):
			mine[tok] = needs[tok]
	_status.text = "The whole team pays together. Total needed is shown on the card."
	if mine.is_empty():
		_status.text = "This needs tokens you don't own. Cheer on the crew (or give them yours)!"
		return
	# round 8: chipping in starts a quick mini-task. Finish it and the team pays, wins the reward, and you earn a token.
	_add_card("Chip in!", "Tap CHIP IN, then finish a quick task. Done = the team wins the reward and you earn a token!", extra, true, "CHIP IN", mine, "capture", "capture")


func _build_decision() -> void:
	for opt in _event.get("options", []):
		var o: Dictionary = opt
		var eff: Dictionary = o.get("effect", {})
		var extra := ""
		if eff.has("crisis_score"):
			extra = "Bonus: +%s points" % CardStats.fmt(eff["crisis_score"])
		_add_card(str(o.get("label", o.get("id", "?"))), "", extra, false, "Choose", o.get("cost", {}), "decision", str(o.get("id", "")))


func _add_card(title: String, blurb: String, extra: String, highlight: bool, button_text: String, cost: Dictionary, kind: String, id: String) -> void:
	var pc := PanelContainer.new()
	pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pc.custom_minimum_size = Vector2(230, 0)
	pc.add_theme_stylebox_override("panel", GameTheme.box(GameTheme.PANEL_HI if highlight else Color(GameTheme.PANEL, 0.95),
		_accent if highlight else Color(_accent, 0.45), 3 if highlight else 2, 16, 10))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	pc.add_child(v)
	v.add_child(_label(title, 20, _accent))
	if blurb != "":
		v.add_child(_label(blurb, 15, GameTheme.TEXT))
	# cost as token pictures
	var cr := HBoxContainer.new()
	cr.add_theme_constant_override("separation", 4)
	cr.add_child(_label("Costs:", 15, GameTheme.MUTED, false))
	if cost.is_empty():
		cr.add_child(_label("free!", 15, GameTheme.GOOD, false))
	for tok in cost:
		for i in int(cost[tok]):
			cr.add_child(_token_icon(str(tok), 26))
		var owner: String = owner_role(str(tok))
		var word: String = token_word(str(tok))
		cr.add_child(_label(word, 15, GameTheme.TEXT, false))
		if owner != role_id and owner != "":
			cr.add_child(_label("from " + str(RoleGuide.guide(owner)["name"]), 14, RoleGuide.color(owner), false))
	v.add_child(cr)
	if extra != "":
		v.add_child(_label(extra, 14, GameTheme.MUTED))
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(sp)
	var btn := _button(button_text, _accent if highlight else Color(_accent, 0.85).darkened(0.25), GameTheme.NAVY if highlight else Color.WHITE, Vector2(0, 52), 20)
	v.add_child(btn)
	_cards_row.add_child(pc)
	var rec := {"cost": cost, "button": btn, "panel": pc, "kind": kind, "id": id, "title": title, "label": button_text}
	btn.pressed.connect(_on_card_button.bind(rec))
	_action_cards.append(rec)


func _cost_text(cost: Dictionary) -> String:
	if cost.is_empty():
		return "free"
	var parts: PackedStringArray = []
	for k in cost:
		parts.append("%d %s" % [int(cost[k]), token_word(str(k))])
	return ", ".join(parts)


func _side_effect_text(se: Dictionary) -> String:
	var parts: PackedStringArray = []
	if se.has("science_pct"):
		parts.append("science %s%%" % CardStats.fmt(se["science_pct"]))
	if se.has("lifetime_days"):
		parts.append("life %s days" % CardStats.fmt(se["lifetime_days"]))
	return ", ".join(parts)


# ================================================================== live state (tokens, acted)
## The first token this card still needs: {} when affordable, else {tok, missing}.
func _missing(cost: Dictionary, tokens: Dictionary) -> Dictionary:
	for k in cost:
		var miss: int = int(cost[k]) - int(tokens.get(str(k), 0))
		if miss > 0:
			return {"tok": str(k), "missing": miss}
	return {}


func refresh() -> void:
	if not _built:
		return
	var tokens: Dictionary = PanelBridge.my_tokens(role_id)
	# my tokens (always visible)
	for c in _tokens_box.get_children():
		_tokens_box.remove_child(c)
		c.queue_free()
	var any := false
	for tok in tokens:
		var n: int = int(tokens[tok])
		var chip := HBoxContainer.new()
		chip.add_theme_constant_override("separation", 2)
		chip.add_child(_token_icon(str(tok), 30))
		chip.add_child(_label("x%d %s" % [n, token_word(str(tok))], 18, GameTheme.TEXT if n > 0 else GameTheme.MUTED, false))
		_tokens_box.add_child(chip)
		any = true
	if not any:
		_tokens_box.add_child(_label("none", 16, GameTheme.MUTED, false))
	if not _active:
		return
	# cards: Play, ASK a teammate, or out of tokens
	for c in _action_cards:
		var b: Button = c["button"]
		var miss: Dictionary = _missing(c["cost"], tokens)
		var panel: PanelContainer = c["panel"]
		if _acted:
			b.text = c["label"]
			b.disabled = true
			panel.modulate = Color(1, 1, 1, 0.6)
			continue
		if miss.is_empty():
			b.text = c["label"]
			b.disabled = false
			b.set_meta("ask", "")
			panel.modulate = Color.WHITE
		else:
			var owner: String = owner_role(str(miss["tok"]))
			if owner != role_id and owner != "" and c["kind"] == "action":
				b.text = "ASK %s for %d %s" % [RoleGuide.guide(owner)["name"], int(miss["missing"]), token_word(str(miss["tok"]))]
				b.disabled = false
				b.set_meta("ask", str(miss["tok"]))
				panel.modulate = Color.WHITE
			else:
				b.text = "Out of %s" % token_word(str(miss["tok"]))
				b.disabled = true
				b.set_meta("ask", "")
				panel.modulate = Color(1, 1, 1, 0.6)
	_build_give_row(tokens)


func _build_give_row(tokens: Dictionary) -> void:
	for c in _give_box.get_children():
		_give_box.remove_child(c)
		c.queue_free()
	if _kind != "crisis":
		return
	var has_any := false
	for tok in tokens:
		if int(tokens[tok]) > 0:
			has_any = true
	if not has_any:
		return
	var pad := Control.new()
	pad.custom_minimum_size = Vector2(110, 0)   # room for the CHAT button in the corner
	_give_box.add_child(pad)
	_give_box.add_child(_label("Give 1 token:", 15, GameTheme.MUTED, false))
	for tok in tokens:
		if int(tokens[tok]) <= 0:
			continue
		for r in Protocol.ROLES:
			if r == role_id:
				continue
			var b := Button.new()
			b.custom_minimum_size = Vector2(0, 38)
			b.add_theme_font_size_override("font_size", 14)
			b.text = "%s to %s" % [token_word(str(tok)), RoleGuide.guide(r)["name"]]
			b.icon = null
			GameTheme.paint_button(b, Color(RoleGuide.color(r), 0.35), GameTheme.TEXT)
			b.pressed.connect(_give.bind(str(tok), r))
			_give_box.add_child(b)


func _give(tok: String, to_role: String) -> void:
	PanelBridge.give_token(tok, to_role)
	Audio.play_sfx("token")
	_status.text = "You gave 1 %s to %s. Nice teamwork!" % [token_word(tok), RoleGuide.guide(to_role)["name"]]


func _on_card_button(rec: Dictionary) -> void:
	if _acted or not _active:
		return
	var b: Button = rec["button"]
	var ask: String = str(b.get_meta("ask", ""))
	if ask != "":
		var now := Time.get_ticks_msec()
		if now < _ask_ready_at:
			return
		_ask_ready_at = now + 2500
		Net.ping("@ask:" + ask)
		Audio.play_sfx("quindar_in")
		_status.text = "You asked %s for %s. Wait for it, then press Play!" % [RoleGuide.guide(owner_role(ask))["name"], token_word(ask)]
		return
	_acted = true
	_pass_btn.disabled = true
	match str(rec["kind"]):
		"action":
			PanelBridge.play_action(str(rec["id"]))
			_status.text = "You played: %s. Waiting for the others..." % str(rec["title"])
		_:
			PanelBridge.event_choice(str(rec["id"]))
			_status.text = "You chose: %s. Waiting for the others..." % str(rec["title"])
	Audio.play_sfx("snap")
	refresh()


func _on_pass_pressed() -> void:
	if _acted or not _active:
		return
	_acted = true
	_pass_btn.disabled = true
	PanelBridge.pass_turn(_kind)
	_status.text = "You are done. Waiting for the others..."
	refresh()


func _on_hurry_pressed() -> void:
	var now := Time.get_ticks_msec()
	if now < _hurry_ready_at:
		return
	_hurry_ready_at = now + 3000
	Net.ping("@commander")
	Audio.play_sfx("quindar_in")
	Fx.pop(_hurry_btn, 1.15)
	_hurry_btn.disabled = true
	get_tree().create_timer(3.0).timeout.connect(func() -> void:
		if is_instance_valid(_hurry_btn):
			_hurry_btn.disabled = false)


## The host said no (not enough tokens, already acted, time is up...), or a teammate asks for a token.
func _on_server_message(code: String, text: String) -> void:
	if not _active:
		return
	match code:
		"action_rejected", "choice_rejected":
			_acted = false
			_pass_btn.disabled = false
			_status.text = text
			refresh()
		"give_rejected", "token_given":
			_status.text = text
			if code == "token_given":
				Audio.play_sfx("coin")
		"token_ask":
			var parts: PackedStringArray = text.split("|")
			if parts.size() >= 2:
				_show_ask(parts[0], parts[1])


func _show_ask(from_role: String, tok: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var pc := GameTheme.panel(Color(RoleGuide.color(from_role), 0.2), RoleGuide.color(from_role), 3, 14, 8)
	pc.add_child(row)
	row.add_child(CrewArt.make(from_role, 40))
	var l := _label("%s needs 1 %s to play a card!" % [RoleGuide.guide(from_role)["name"], token_word(tok)], 20, GameTheme.TEXT, false)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	row.add_child(_token_icon(tok, 34))
	var have: int = int(PanelBridge.my_tokens(role_id).get(tok, 0))
	var b := _button("GIVE" if have > 0 else "You have none", RoleGuide.color(from_role) if have > 0 else GameTheme.PANEL_HI,
		GameTheme.NAVY if have > 0 else GameTheme.MUTED, Vector2(170, 50), 22)
	b.disabled = have <= 0
	b.pressed.connect(func() -> void:
		_give(tok, from_role)
		pc.queue_free())
	row.add_child(b)
	_asks_box.add_child(pc)
	Audio.play_sfx("join")
	Fx.pop(pc, 1.05)
	shown_again.emit()   # RoleOverlay re-opens the panel if it was hidden


# ================================================================== the host resolves it
func show_result(result: Dictionary) -> void:
	_active = false
	_ring.stop()
	Audio.duck(false)
	_result_cat.set_role(role_id, Quips.mood_for(result))
	_quip.text = Quips.for_result(result, role_id)
	Fx.pop(_result_cat, 1.2)
	var residual: float = float(result.get("residual", 0.0))
	if str(result.get("kind", _kind)) != "crisis" or residual < 0.05:
		Audio.play_sfx("success")
		Fx.burst(self, Vector2(size.x / 2.0, size.y * 0.3), [Color("7CE08A"), Color("FFC857"), Color.WHITE], 36)
	else:
		Audio.play_sfx("hit")
		Fx.shake(_result_cat, 6.0 + 18.0 * residual, 0.5)
		Fx.flash(self, Color(1.0, 0.25, 0.2, 0.35 * residual + 0.1), 0.5)
	_give_box.visible = false
	_ping.visible = false
	_banner.visible = false
	_ring.visible = false
	_pass_btn.visible = false
	_hurry_btn.visible = false
	_hide_btn.visible = false
	_gauge_box.visible = false
	for c in _asks_box.get_children():
		c.queue_free()
	_cards_row.visible = false
	var text: String = ""
	for key in ["line", "text", "summary", "why"]:
		if result.has(key) and str(result[key]) != "":
			text = str(result[key])
			break
	if text == "":
		text = "That one is over."
	if MissionState.commander_mode and _kind == "crisis":
		text = "It was: %s!\n%s" % [str(_event.get("title", "?")).to_upper(), text]
	if bool(result.get("mistake", false)):   # round 8: lives
		_quip.text = "-1 LIFE!  " + _quip.text
		_quip.add_theme_color_override("font_color", GameTheme.BAD)
	elif str(result.get("kind", _kind)) == "crisis" and residual < 0.05:
		_quip.text = "SAVED! 100% blocked.  " + _quip.text
		_quip.add_theme_color_override("font_color", GameTheme.GOOD)
	else:
		_quip.add_theme_color_override("font_color", GameTheme.AMBER)
	_result_label.text = text
	var learn: String = str(_event.get("learn", ""))
	_learn_label.text = "" if (learn == "" or text.contains(learn)) else learn
	_status.text = ""
	_result_box.visible = true


func _on_ok_pressed() -> void:
	_result_box.visible = false
	_cards_row.visible = true
	dismissed.emit()
