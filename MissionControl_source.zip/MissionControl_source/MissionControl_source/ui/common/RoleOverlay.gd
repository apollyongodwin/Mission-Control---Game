# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name RoleOverlay
extends Control
## Sits on top of a role panel. Shows the crisis screen while an event is live and the launch poll during REVIEW.
## Otherwise it is invisible and lets every click through. RolePanel creates it: overlay.setup(role_id, accent).

var role_id: String = "systems"
var _dim: ColorRect
var _crisis_margin: MarginContainer
var _crisis: CrisisPanel
var _poll_center: CenterContainer
var _poll: LaunchPoll
var _mini: Button   # LEAD (round 6): the "hidden" crisis bar


func setup(role: String, accent: Color) -> void:
	role_id = role
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	_dim = ColorRect.new()
	_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_dim.mouse_filter = Control.MOUSE_FILTER_STOP   # modal: nothing behind it can be clicked
	_dim.visible = false
	add_child(_dim)

	_crisis_margin = MarginContainer.new()
	_crisis_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# round 6: a bottom sheet, so the ship and the orbit stay visible above it
	_crisis_margin.add_theme_constant_override("margin_left", 18)
	_crisis_margin.add_theme_constant_override("margin_right", 18)
	_crisis_margin.add_theme_constant_override("margin_top", 96)
	_crisis_margin.add_theme_constant_override("margin_bottom", 14)
	_crisis_margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_crisis_margin.visible = false
	add_child(_crisis_margin)
	_crisis = CrisisPanel.new()
	_crisis.size_flags_vertical = Control.SIZE_SHRINK_END
	_crisis.setup(role, accent)   # set up BEFORE it enters the tree, so its own _ready does not default to another role
	_crisis_margin.add_child(_crisis)
	_crisis.dismissed.connect(_on_crisis_dismissed)
	_crisis.hide_requested.connect(_minimise.bind(true))
	_crisis.shown_again.connect(_minimise.bind(false))
	_mini = Button.new()
	_mini.text = "ANOMALY!  Tap to show your cards"
	_mini.add_theme_font_size_override("font_size", 22)
	_mini.custom_minimum_size = Vector2(520, 60)
	GameTheme.paint_button(_mini, Color("C0392B"), Color.WHITE)
	_mini.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_mini.offset_left = -260
	_mini.offset_right = 260
	_mini.offset_top = -78
	_mini.offset_bottom = -18
	_mini.visible = false
	_mini.pressed.connect(_minimise.bind(false))
	add_child(_mini)

	_poll_center = CenterContainer.new()
	_poll_center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_poll_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_poll_center.visible = false
	add_child(_poll_center)
	_poll = LaunchPoll.new()
	_poll.setup(role, accent)
	_poll.custom_minimum_size = Vector2(760, 0)   # MERGE (UI pass): a proper centred dialog
	_poll_center.add_child(_poll)

	PanelBridge.on_crisis_started(_on_crisis_started)
	PanelBridge.on_crisis_resolved(_on_crisis_resolved)
	PanelBridge.on_phase_changed(_on_phase_changed)
	PanelBridge.on_changed(_on_design_changed)
	_apply_phase(PanelBridge.phase())


func _on_crisis_started(event: Dictionary, timer_s: float = 0.0) -> void:
	_poll_center.visible = false
	_dim.color = Color(0.35, 0.02, 0.02, 0.35)   # alarm tint, see-through (round 6)
	if PanelBridge.is_cadet():
		_dim.color = Color(0.12, 0.05, 0.2, 0.35)
	_dim.visible = true
	_crisis_margin.visible = true
	_mini.visible = false
	_crisis.show_event(event, timer_s)


## Hide = shrink to the red bar (see the ship); the bar or a teammate's token request brings it back.
func _minimise(on: bool) -> void:
	if not _crisis_margin.visible and not _mini.visible:
		return
	_crisis_margin.visible = not on
	_dim.visible = not on
	_mini.visible = on
	if on:
		var tw := _mini.create_tween().set_loops(4)
		tw.tween_property(_mini, "modulate:a", 0.6, 0.4)
		tw.tween_property(_mini, "modulate:a", 1.0, 0.4)


func _on_crisis_resolved(result: Dictionary) -> void:
	_crisis.show_result(result)
	_dim.visible = true
	_crisis_margin.visible = true
	_mini.visible = false


func _on_crisis_dismissed() -> void:
	_crisis_margin.visible = false
	_mini.visible = false
	_dim.visible = false
	_apply_phase(PanelBridge.phase())


func _on_phase_changed(phase) -> void:
	_apply_phase(PanelBridge.phase_name(phase))


func _apply_phase(phase: String) -> void:
	if _crisis_margin.visible:
		return   # a live crisis (or its result) always wins
	if phase == "REVIEW":
		_dim.color = Color(0.02, 0.05, 0.12, 0.85)
		_dim.visible = true
		_poll.reset()
		_poll_center.visible = true
	else:
		_dim.visible = false
		_poll_center.visible = false


func _on_design_changed() -> void:
	if _poll_center.visible:
		_poll.set_view(PanelBridge.view())
