# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name TokenTray
extends HBoxContainer
## This role's tokens as icons with counts. It listens to MissionState.tokens_changed by itself.
## Use: var tray := TokenTray.new(); tray.setup("systems"); add_child(tray)
## Manual use (tests): tray.set_tokens({"power": 3}).

var role_id: String = "systems"
var _built: bool = false


func setup(role: String) -> void:
	role_id = role
	add_theme_constant_override("separation", 18)
	PanelBridge.on_tokens_changed(refresh)
	_built = true
	refresh()


func refresh() -> void:
	set_tokens(PanelBridge.my_tokens(role_id))


## Shows one icon per token this role OWNS (even at 0), so players can see an empty pocket.
func set_tokens(tokens: Dictionary) -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()
	var defs: Dictionary = Data.db["meta"]["tokens"]
	var owned: Array = Data.db["meta"]["roles"][role_id]["owns_tokens"]
	if owned.is_empty():
		return
	var lead := Label.new()
	lead.text = "TOKENS"
	lead.add_theme_font_size_override("font_size", 18)
	add_child(lead)
	for tok in owned:
		var d: Dictionary = defs.get(str(tok), {})
		var n: int = int(tokens.get(str(tok), 0))
		var box := HBoxContainer.new()
		box.add_theme_constant_override("separation", 4)
		box.tooltip_text = "%s token: %s" % [str(tok).capitalize(), str(d.get("from", ""))]
		var icon := TokenIcon.new()
		icon.kind = str(d.get("icon", "coin"))
		icon.modulate = Color(1, 1, 1, 1) if n > 0 else Color(1, 1, 1, 0.3)
		box.add_child(icon)
		var count := Label.new()
		count.text = "x%d" % n
		count.add_theme_font_size_override("font_size", 26)
		box.add_child(count)
		var name_l := Label.new()
		name_l.text = str(tok)
		name_l.add_theme_font_size_override("font_size", 16)
		box.add_child(name_l)
		add_child(box)
