# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Fx
extends RefCounted
## LEAD (juice pass). Small, reusable visual effects. All are fire-and-forget and clean themselves up.
##   Fx.shake(node, 12.0, 0.4)          rattle a Control (screen shake on the root Control of a screen)
##   Fx.flash(parent, Color.WHITE)      a full-screen flash that fades out
##   Fx.burst(parent, pos, colors)      a puff of sparks (part picked, medal, crisis averted)
##   Fx.explosion(parent, pos, scale)   fireball + smoke + debris (failed launch, crisis hit)
##   Fx.pop(node)                       bouncy "boing" scale


static func shake(c: CanvasItem, strength: float = 10.0, duration: float = 0.35) -> void:
	if c == null or not is_instance_valid(c) or not c.is_inside_tree():
		return
	var base: Vector2 = c.position if c is Control or c is Node2D else Vector2.ZERO
	var tw := c.create_tween()
	var steps: int = maxi(4, int(duration / 0.035))
	for i in steps:
		var k: float = 1.0 - float(i) / float(steps)
		tw.tween_property(c, "position", base + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * strength * k, 0.035)
	tw.tween_property(c, "position", base, 0.04)


static func flash(parent: Node, color: Color = Color(1, 1, 1, 0.8), duration: float = 0.35) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	var r := ColorRect.new()
	r.color = color
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	r.z_index = 50
	parent.add_child(r)
	var tw := r.create_tween()
	tw.tween_property(r, "modulate:a", 0.0, duration)
	tw.tween_callback(r.queue_free)


static func pop(c: Control, amount: float = 1.08) -> void:
	if c == null or not c.is_inside_tree():
		return
	c.pivot_offset = c.size / 2.0
	var tw := c.create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(c, "scale", Vector2(amount, amount), 0.07)
	tw.tween_property(c, "scale", Vector2.ONE, 0.22)


static var _dot: Texture2D = null


## A soft round particle (without a texture, particles are hard squares).
static func _soft_dot() -> Texture2D:
	if _dot == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.85), Color(1, 1, 1, 0)])
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 64
		t.height = 64
		_dot = t
	return _dot


static func _particles(parent: Node, pos: Vector2, amount: int, colors: Array, speed: Vector2, lifetime: float,
		size: Vector2, gravity: float, spread: float = 180.0) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.texture = _soft_dot()
	size = size / 40.0   # sizes below are in pixels; the dot texture is 64 px
	p.position = pos
	p.emitting = false
	p.one_shot = true
	p.explosiveness = 0.95
	p.amount = amount
	p.lifetime = lifetime
	p.spread = spread
	p.direction = Vector2(0, -1)
	p.initial_velocity_min = speed.x
	p.initial_velocity_max = speed.y
	p.gravity = Vector2(0, gravity)
	p.damping_min = 20.0
	p.damping_max = 60.0
	p.scale_amount_min = size.x
	p.scale_amount_max = size.y
	p.angular_velocity_min = -360.0
	p.angular_velocity_max = 360.0
	var g := Gradient.new()
	g.offsets = PackedFloat32Array()
	g.colors = PackedColorArray()
	for i in colors.size():
		g.add_point(float(i) / maxf(1.0, float(colors.size() - 1)), colors[i])
	g.add_point(1.0, Color(colors[-1], 0.0))
	p.color_ramp = g
	p.z_index = 40
	parent.add_child(p)
	p.emitting = true
	p.finished.connect(p.queue_free)
	return p


static func burst(parent: Node, pos: Vector2, colors: Array = [Color("FFC857"), Color("FFFFFF")], amount: int = 24) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	_particles(parent, pos, amount, colors, Vector2(120, 320), 0.7, Vector2(3, 7), 300.0)


static func explosion(parent: Node, pos: Vector2, scale: float = 1.0) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	# fireball, smoke, sparks/debris
	_particles(parent, pos, 60, [Color("FFF3C4"), Color("FFC857"), Color("FF7A1A"), Color("B3261E")],
		Vector2(150, 520) * scale, 0.9, Vector2(10, 26) * scale, -60.0)
	_particles(parent, pos, 40, [Color(0.35, 0.33, 0.38, 0.9), Color(0.18, 0.17, 0.2, 0.7)],
		Vector2(60, 220) * scale, 1.8, Vector2(18, 40) * scale, -90.0)
	_particles(parent, pos, 40, [Color("FFFFFF"), Color("FFC857"), Color("6B6B6B")],
		Vector2(300, 900) * scale, 1.4, Vector2(2, 6), 700.0)
