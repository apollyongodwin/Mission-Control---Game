# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name GameTheme
extends RefCounted
## ONE shared look for every screen (MERGE: re-skinned to Dev D's menu style, which the team chose as the house style).
## Navy space panels, warm amber headings, chunky rounded "bevel" buttons, role colour as the accent.
## Use: control.theme = GameTheme.build(role_color). RolePanel, the crew screens and the debrief do this.
## Optional fonts (SIL OFL), used automatically if present:
##   res://assets/fonts/Fredoka-SemiBold.ttf      friendly rounded headings and buttons
##   res://assets/fonts/ShareTechMono-Regular.ttf  numbers ("Show numbers" readouts)

# ---- palette (Dev D) ----
const NAVY: Color = Color("0B1530")        # background
const PANEL: Color = Color("182747")       # panels
const PANEL_HI: Color = Color("263653")    # inner cards
const EDGE: Color = Color("0D192E")        # panel border
const LINE: Color = Color("3A5A94")        # light divider / hover
const BUTTON: Color = Color("243B64")      # normal button
const BUTTON_RED: Color = Color("7A3038")
const AMBER: Color = Color("FFC857")       # headings, primary buttons
const AMBER_DIM: Color = Color("A88B4A")
const TEXT: Color = Color("E8EEF9")        # body text
const MUTED: Color = Color("9AA6BD")
const DISABLED_BG: Color = Color("3A4660")
const GOOD: Color = Color("7CE08A")
const WARN: Color = Color("FFC857")
const BAD: Color = Color("FF7A6B")

const FONT_PATH: String = "res://assets/fonts/Fredoka-SemiBold.ttf"
const MONO_PATH: String = "res://assets/fonts/ShareTechMono-Regular.ttf"


static func make_font() -> Font:
	if ResourceLoader.exists(FONT_PATH):
		var bundled: Font = load(FONT_PATH) as Font
		if bundled != null:
			return bundled
	return ThemeDB.fallback_font


static func mono_font() -> Font:
	if ResourceLoader.exists(MONO_PATH):
		var bundled: Font = load(MONO_PATH) as Font
		if bundled != null:
			return bundled
	var f := SystemFont.new()
	f.font_names = PackedStringArray(["Share Tech Mono", "Consolas", "Menlo", "DejaVu Sans Mono", "monospace"])
	return f


static func role_color(role: String) -> Color:
	var roles: Dictionary = Data.db.get("meta", {}).get("roles", {})
	if roles.has(role):
		return Color(str(roles[role]["color"]))
	return AMBER


static func box(bg: Color, border: Color, border_w: int = 2, radius: int = 14, margin: int = 12) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(margin)
	sb.anti_aliasing = true
	return sb


## Dev D's chunky button: thicker bottom edge looks like a key you can press.
static func bevel(color: Color, bevel_color: Color, pressed: bool = false) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.border_color = bevel_color
	sb.border_width_left = 2
	sb.border_width_right = 2
	sb.border_width_top = 4 if pressed else 2
	sb.border_width_bottom = 2 if pressed else 5
	sb.set_corner_radius_all(15)
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	sb.content_margin_top = 8
	sb.content_margin_bottom = 10
	sb.anti_aliasing = true
	return sb


## Paint one button in a colour (primary = amber with navy text, danger = red, role = role colour).
static func paint_button(b: Button, bg: Color, fg: Color = TEXT) -> void:
	var dark: Color = bg.darkened(0.3)
	b.add_theme_stylebox_override("normal", bevel(bg, dark))
	b.add_theme_stylebox_override("hover", bevel(bg.lightened(0.08), dark))
	b.add_theme_stylebox_override("pressed", bevel(bg.darkened(0.15), dark, true))
	b.add_theme_stylebox_override("focus", bevel(bg, AMBER))
	b.add_theme_stylebox_override("disabled", bevel(DISABLED_BG, DISABLED_BG.darkened(0.25)))
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		b.add_theme_color_override(c, fg)
	b.add_theme_color_override("font_disabled_color", MUTED)


static func primary(b: Button) -> void:
	paint_button(b, AMBER, NAVY)


static func danger(b: Button) -> void:
	paint_button(b, BUTTON_RED, TEXT)


static func label(text: String, size: int = 20, color: Color = TEXT, wrap: bool = true) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


static func panel(bg: Color = PANEL, border: Color = EDGE, border_w: int = 3, radius: int = 20, margin: int = 16) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", box(bg, border, border_w, radius, margin))
	return p


static func build(accent: Color) -> Theme:
	var t := Theme.new()
	t.default_font = make_font()
	t.default_font_size = 20

	t.set_color("font_color", "Label", TEXT)

	for type_name in ["Button", "OptionButton", "CheckButton", "CheckBox", "MenuButton"]:
		t.set_color("font_color", type_name, TEXT)
		t.set_color("font_hover_color", type_name, Color.WHITE)
		t.set_color("font_pressed_color", type_name, Color.WHITE)
		t.set_color("font_hover_pressed_color", type_name, Color.WHITE)
		t.set_color("font_focus_color", type_name, TEXT)
		t.set_color("font_disabled_color", type_name, MUTED)
	for type_name in ["Button", "OptionButton", "MenuButton"]:
		t.set_stylebox("normal", type_name, bevel(BUTTON, BUTTON.darkened(0.3)))
		t.set_stylebox("hover", type_name, bevel(BUTTON.lightened(0.1), accent))
		t.set_stylebox("pressed", type_name, bevel(BUTTON.darkened(0.2), accent, true))
		t.set_stylebox("disabled", type_name, bevel(DISABLED_BG, DISABLED_BG.darkened(0.25)))
		var focus: StyleBoxFlat = bevel(BUTTON, accent)
		t.set_stylebox("focus", type_name, focus)
	for type_name in ["CheckButton", "CheckBox"]:
		var empty := StyleBoxEmpty.new()
		for st in ["normal", "hover", "pressed", "focus", "hover_pressed", "disabled"]:
			t.set_stylebox(st, type_name, empty)

	t.set_stylebox("panel", "PanelContainer", box(PANEL, EDGE, 3, 20, 14))
	t.set_stylebox("panel", "Panel", box(PANEL, EDGE, 3, 20, 14))
	t.set_stylebox("panel", "PopupMenu", box(PANEL_HI, EDGE, 2, 12, 8))
	t.set_stylebox("hover", "PopupMenu", box(LINE, LINE, 0, 8, 6))
	t.set_color("font_color", "PopupMenu", TEXT)
	t.set_color("font_hover_color", "PopupMenu", Color.WHITE)
	t.set_font_size("font_size", "PopupMenu", 22)
	t.set_constant("v_separation", "PopupMenu", 12)

	t.set_color("font_color", "LineEdit", TEXT)
	t.set_color("font_placeholder_color", "LineEdit", MUTED)
	t.set_color("caret_color", "LineEdit", AMBER)
	t.set_stylebox("normal", "LineEdit", box(PANEL_HI, EDGE, 2, 12, 12))
	t.set_stylebox("focus", "LineEdit", box(PANEL_HI, AMBER, 3, 12, 12))
	t.set_stylebox("read_only", "LineEdit", box(PANEL_HI, EDGE, 1, 12, 12))

	t.set_stylebox("background", "ProgressBar", box(PANEL_HI, EDGE, 1, 8, 2))
	t.set_stylebox("fill", "ProgressBar", box(accent, accent, 0, 8, 2))

	var tip := box(PANEL_HI, AMBER, 2, 10, 10)
	t.set_stylebox("panel", "TooltipPanel", tip)
	t.set_color("font_color", "TooltipLabel", TEXT)
	t.set_font_size("font_size", "TooltipLabel", 18)

	t.set_stylebox("scroll", "VScrollBar", box(Color(0, 0, 0, 0.15), Color(0, 0, 0, 0), 0, 6, 2))
	t.set_stylebox("grabber", "VScrollBar", box(LINE, LINE, 0, 6, 4))
	t.set_stylebox("grabber_highlight", "VScrollBar", box(AMBER_DIM, AMBER_DIM, 0, 6, 4))
	return t
