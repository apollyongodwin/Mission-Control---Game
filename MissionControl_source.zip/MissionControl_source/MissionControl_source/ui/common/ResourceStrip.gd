# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name ResourceStrip
extends HFlowContainer
## The traffic lights: mass, power, budget, data, comms, time + lifetime.
## Feed it result["lights"] (or view["lights"]) with set_lights().

const KEYS: Array = ["mass", "power", "budget", "data", "comms", "time", "lifetime"]
const NAMES: Dictionary = {"mass": "Mass", "power": "Power", "budget": "Budget", "data": "Data",
	"comms": "Comms", "time": "Time", "lifetime": "Lifetime"}
const WORDS: Dictionary = {"green": "OK", "amber": "Careful", "red": "Problem", "unknown": "Not checked yet"}

var _icons: Dictionary = {}
var _built: bool = false


func _ready() -> void:
	_build()


func _build() -> void:
	if _built:
		return
	_built = true
	add_theme_constant_override("h_separation", 14)
	add_theme_constant_override("v_separation", 8)
	for k in KEYS:
		var box := VBoxContainer.new()
		var icon := LightIcon.new()
		icon.custom_minimum_size = Vector2(44, 44)
		box.add_child(icon)
		var lab := Label.new()
		lab.text = str(NAMES[k])
		lab.add_theme_font_size_override("font_size", 20)
		lab.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(lab)
		add_child(box)
		_icons[k] = icon


func set_lights(lights: Dictionary) -> void:
	_build()
	for k in KEYS:
		var icon: LightIcon = _icons[k]
		var st: String = str(lights.get(k, "unknown"))
		icon.state = st
		icon.tooltip_text = "%s: %s" % [NAMES[k], WORDS.get(st, st)]
