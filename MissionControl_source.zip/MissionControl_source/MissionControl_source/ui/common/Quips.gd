# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Quips
extends RefCounted
## LEAD (writing pass). Short witty lines. NON-CODERS: edit freely, keep them kind, short (max ~12 words)
## and TRUE where they teach something. The educational part stays in the data file's "learn" text.

const CRISIS_PERFECT := [
	"Flawless! Not a scratch.",
	"That's what margin is for. Chef's kiss.",
	"Mission Control is impressed. Mildly. They're engineers.",
	"Crisis? What crisis?",
]
const CRISIS_PARTIAL := [
	"Bent, not broken.",
	"Could have been worse. Could have been a LOT worse.",
	"A few scratches. The spacecraft will tell its friends.",
	"Half saved is better than none!",
]
const CRISIS_BAD := [
	"Ouch. The spacecraft has filed a complaint.",
	"That one goes in the accident report.",
	"Lesson learned the expensive way.",
	"Somewhere, an engineer just sighed very loudly.",
]
const OPPORTUNITY_YES := ["Science bonus: acquired!", "Teamwork makes the data work."]
const OPPORTUNITY_NO := ["The universe offered. We were broke.", "Next time, save a token for luck."]
const DECISION := ["Decision made. Bold. Very bold.", "The Flight Director nods slowly."]

## What a crisis looks like to your cat: "" (fine), "worried", "kaboom".
static func mood_for(result: Dictionary) -> String:
	if str(result.get("kind", "crisis")) != "crisis":
		return ""
	var r: float = float(result.get("residual", 0.0))
	if r < 0.05:
		return ""
	return "kaboom" if r > 0.6 else "worried"


static func for_result(result: Dictionary, seed_text: String = "") -> String:
	var list: Array
	match str(result.get("kind", "crisis")):
		"opportunity":
			list = OPPORTUNITY_YES if bool(result.get("captured", false)) else OPPORTUNITY_NO
		"decision":
			list = DECISION
		_:
			var r: float = float(result.get("residual", 0.0))
			list = CRISIS_PERFECT if r < 0.05 else (CRISIS_PARTIAL if r < 0.6 else CRISIS_BAD)
	return str(list[abs(hash(seed_text + str(result.get("id", "")))) % list.size()])
