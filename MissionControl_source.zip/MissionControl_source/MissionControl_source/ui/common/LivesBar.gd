# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name LivesBar
extends Control
## LEAD (round 8) LIVES: drawn hearts (no font glyphs needed). Full hearts = lives left, grey outlines = lives lost.
## Follows MissionState.lives by itself. Hidden while there are no lives yet (before the flight).
##   var lb := LivesBar.new(); lb.heart = 18; add_child(lb)

var heart: float = 16.0
var show_word: bool = true
var _lives: int = -1
var _max: int = -1
var _pulse: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	MissionState.lives_changed.connect(_sync)
	_sync()


func _sync() -> void:
	var lost: bool = _lives > 0 and MissionState.lives < _lives
	_lives = MissionState.lives
	_max = MissionState.lives_max
	visible = _max > 0
	var w: float = (heart * 2.3) * float(maxi(_max, 1)) + (heart * 4.2 if show_word else 0.0)
	custom_minimum_size = Vector2(w, heart * 2.4)
	tooltip_text = "Lives: a crisis mistake costs one. No lives left = mission over."
	if lost:
		_pulse = 1.0
		Audio.play_sfx("hit")
	queue_redraw()


func _process(delta: float) -> void:
	if _pulse > 0.0:
		_pulse = maxf(0.0, _pulse - delta * 1.2)
		queue_redraw()


static func draw_heart(ci: CanvasItem, c: Vector2, r: float, col: Color, filled: bool = true) -> void:
	var pts := PackedVector2Array()
	for i in 32:
		var t: float = float(i) / 32.0 * TAU
		# the classic heart curve, scaled to radius r
		var x: float = 16.0 * pow(sin(t), 3)
		var y: float = -(13.0 * cos(t) - 5.0 * cos(2.0 * t) - 2.0 * cos(3.0 * t) - cos(4.0 * t))
		pts.append(c + Vector2(x, y) * (r / 17.0))
	if filled:
		ci.draw_colored_polygon(pts, col)
	else:
		pts.append(pts[0])
		ci.draw_polyline(pts, col, maxf(1.5, r * 0.14), true)


func _draw() -> void:
	if _max <= 0:
		return
	var x: float = heart * 1.1
	var cy: float = size.y * 0.5
	if show_word:
		draw_string(get_theme_default_font(), Vector2(0, cy + heart * 0.45), "LIVES", HORIZONTAL_ALIGNMENT_LEFT, -1, int(heart * 1.05), GameTheme.MUTED)
		x += heart * 4.2
	for i in _max:
		var c := Vector2(x + float(i) * heart * 2.3, cy)
		if i < _lives:
			var r: float = heart * (1.0 + 0.25 * _pulse if i == _lives - 1 else 1.0)
			draw_heart(self, c, r, Color("FF5E7A"))
		else:
			draw_heart(self, c, heart, Color(GameTheme.MUTED, 0.7), false)
			if _pulse > 0.0 and i == _lives:
				draw_heart(self, c, heart * (1.0 + _pulse), Color(1, 0.3, 0.3, _pulse * 0.6))
