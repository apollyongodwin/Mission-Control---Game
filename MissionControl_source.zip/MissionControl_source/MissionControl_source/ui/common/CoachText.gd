# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CoachText
extends RefCounted
## Chooses the ONE coach-bubble message (UX_GUIDE section 4) and who can fix it.
## pick(view, cadet) returns {"text": String, "roles": Array}.

const ORDER: Array = ["mass", "power", "budget", "data", "comms", "time", "lifetime"]

# [error text from evaluate, priority (1 = most important), kid line]
const ERRORS: Array = [
	["no instruments", 1, "No instruments yet. Pick some science gadgets!"],
	["no ground station", 1, "Nobody is listening! Pick a ground station."],
	["too many instruments for bus slots", 2, "Too many gadgets! Pick a bigger body or fewer gadgets."],
	["instrument mass exceeds bus payload capacity", 2, "The gadgets are too heavy for this body."],
	["orbit needs more propulsion", 3, "This orbit needs a stronger engine."],
	["rocket cannot reach this orbit", 4, "This rocket can't fly that far. Pick another one."],
	["spacecraft too heavy for rocket", 4, "Too heavy! Pick lighter parts or a bigger rocket."],
	["over budget", 5, "Too expensive! Pick cheaper parts."],
	["misses the launch window", 6, "We can't build it in time. Pick quicker parts."],
]

# light name -> [kid line, roles who can fix it]
const LIGHTS: Dictionary = {
	"mass": ["Getting heavy. Lighter parts are safer.", ["systems", "ground"]],
	"power": ["Power is low. Add bigger wings or a battery.", ["systems"]],
	"budget": ["Money is getting tight.", ["ground"]],
	"data": ["Not all the pictures can get home. Try a faster antenna.", ["ground", "systems"]],
	"comms": ["The radio link is weak. Try a faster antenna.", ["ground", "systems"]],
	"time": ["This takes a long time to build. Try quicker parts.", ["ground", "systems"]],
	"lifetime": ["The satellite may not last long enough.", ["flight", "systems"]],
}


static func _priority(err: String) -> int:
	for row in ERRORS:
		if row[0] == err:
			return int(row[1])
	return 0   # other errors (duplicate instrument, wrong scenario, RTG) come first


static func pick(view: Dictionary, cadet: bool) -> Dictionary:
	var errors: Array = view.get("errors", [])
	if not errors.is_empty():
		var best: String = str(errors[0])
		for e in errors:
			if _priority(str(e)) < _priority(best):
				best = str(e)
		var msgs: Array = SimEngine.review_messages({"errors": [best]})
		var text: String = str(msgs[0]["text"])
		if cadet:
			for row in ERRORS:
				if row[0] == best:
					text = str(row[2])
		return {"text": text, "roles": msgs[0]["roles"]}
	var lights: Dictionary = view.get("lights", {})
	if lights.is_empty():
		return {"text": "Pick something to begin!", "roles": []}
	for want in ["red", "amber"]:
		for k in ORDER:
			if str(lights.get(k, "")) == want:
				var info: Array = LIGHTS[k]
				var prefix: String = "Red light! " if want == "red" else "Careful! "
				var text2: String = prefix + str(info[0]) if cadet else "%s light on %s." % [want.capitalize(), str(k).capitalize()]
				return {"text": text2, "roles": info[1]}
	return {"text": "Ready! Press GO.", "roles": []}
