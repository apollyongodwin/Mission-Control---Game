# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name ChatDrawer
extends Control
## LEAD (Part 3). Crew chat: a small CHAT tab (bottom-left) with an unread badge that opens a drawer with
## quick-phrase chips, the last messages (each with the sender's cat), and a text box.
## Talks only to Net.send_chat / Net.chat_received. Radio Silence and "quick phrases only" are enforced on the host.

const ROLE_ORDER := ["flight", "systems", "payload", "ground"]

var _open := false
var _unread := 0
var _tab: Button
var _badge: Label
var _drawer: PanelContainer
var _list: VBoxContainer
var _scroll: ScrollContainer
var _edit: LineEdit
var _note: Label
## LEAD (round 8): a screen can give the chat a button in its own top bar (the floating tab used to cover cards).
var external_button: Button = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = GameTheme.build(GameTheme.AMBER)

	_drawer = GameTheme.panel(Color(GameTheme.PANEL, 0.97), GameTheme.AMBER, 3, 20, 12)
	_drawer.anchor_left = 0.0
	_drawer.anchor_top = 1.0
	_drawer.anchor_bottom = 1.0
	_drawer.offset_left = 14.0
	_drawer.offset_right = 534.0
	_drawer.offset_top = -500.0
	_drawer.offset_bottom = -84.0
	_drawer.visible = false
	add_child(_drawer)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	_drawer.add_child(v)
	var head := HBoxContainer.new()
	head.add_child(GameTheme.label("CREW CHAT", 20, GameTheme.AMBER))
	var close := Button.new()
	close.text = "X"
	close.custom_minimum_size = Vector2(44, 40)
	close.pressed.connect(toggle)
	head.add_child(close)
	v.add_child(head)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(_scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 6)
	_scroll.add_child(_list)
	var chips := HFlowContainer.new()
	chips.add_theme_constant_override("h_separation", 6)
	chips.add_theme_constant_override("v_separation", 6)
	for q in Net.QUICK_CHAT:
		var b := Button.new()
		b.text = str(q)
		b.add_theme_font_size_override("font_size", 16)
		b.custom_minimum_size = Vector2(0, 38)
		b.pressed.connect(func() -> void: Net.send_chat(str(q)))
		chips.add_child(b)
	v.add_child(chips)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	_edit = LineEdit.new()
	_edit.text_changed.connect(func(_t): Audio.play_sfx("type", -12.0, 0.15))   # LEAD (round 3): keyboard clicks
	_edit.placeholder_text = "Type a message..."
	_edit.max_length = Net.CHAT_MAX_LEN
	_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_edit.text_submitted.connect(func(_t: String) -> void: _send())
	row.add_child(_edit)
	var send := Button.new()
	send.text = "Send"
	send.custom_minimum_size = Vector2(90, 48)
	GameTheme.primary(send)
	send.pressed.connect(_send)
	row.add_child(send)
	v.add_child(row)
	_note = GameTheme.label("", 16, GameTheme.BAD)
	_note.visible = false
	v.add_child(_note)

	_tab = Button.new()
	_tab.text = "CHAT"
	_tab.tooltip_text = "Crew chat (T)"
	_tab.anchor_top = 1.0
	_tab.anchor_bottom = 1.0
	_tab.offset_left = 14.0
	_tab.offset_right = 134.0
	_tab.offset_top = -74.0
	_tab.offset_bottom = -18.0
	_tab.add_theme_font_size_override("font_size", 20)
	_tab.pressed.connect(toggle)
	add_child(_tab)
	_badge = GameTheme.label("", 16, GameTheme.NAVY, false)
	var bsb := GameTheme.box(GameTheme.BAD, GameTheme.BAD, 0, 12, 4)
	_badge.add_theme_stylebox_override("normal", bsb)
	_badge.position = Vector2(100, -10)
	_badge.visible = false
	_tab.add_child(_badge)

	for m in Net.chat_log:
		_add_line(str(m["role"]), str(m["text"]))
	set_process(true)
	Net.chat_received.connect(_on_chat)
	Net.server_message_received.connect(func(code: String, text: String) -> void:
		if code == "chat_rejected":
			_note.text = text
			_note.visible = true)


func _unhandled_key_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k != null and k.pressed and not k.echo and k.keycode == KEY_T and not _open:
		toggle()
		get_viewport().set_input_as_handled()


func toggle() -> void:
	_open = not _open
	_drawer.visible = _open
	if _open:
		_unread = 0
		_badge.visible = false
		_note.visible = false
		_edit.grab_focus.call_deferred()
		Fx.pop(_drawer, 1.03)


func _send() -> void:
	var t: String = _edit.text.strip_edges()
	if t == "":
		return
	Net.send_chat(t)
	_edit.text = ""


func _on_chat(role: String, text: String) -> void:
	_add_line(role, text)
	Audio.play_sfx("quindar_in")   # NASA's real "Quindar" beep
	if not _open:
		_unread += 1
		_badge.text = " %d " % _unread
		_badge.visible = true
		Fx.pop(_tab, 1.15)


func _add_line(role: String, text: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	if role in ROLE_ORDER:
		row.add_child(CrewArt.make(role, 36))
	var col: Color = GameTheme.role_color(role) if role in ROLE_ORDER else GameTheme.AMBER
	var who: String = str(Data.db["meta"]["roles"][role]["name"]) if role in ROLE_ORDER else "MISSION CONTROL"
	var l := GameTheme.label("%s: %s" % [who, text], 18, GameTheme.TEXT)
	l.add_theme_color_override("font_color", col.lightened(0.35))
	row.add_child(l)
	_list.add_child(row)
	while _list.get_child_count() > Net.CHAT_HISTORY:
		_list.get_child(0).queue_free()
	await get_tree().process_frame
	if is_inside_tree():
		_scroll.scroll_vertical = int(_scroll.get_v_scroll_bar().max_value)


## LEAD (round 8): use a button the screen already has (top bar) instead of the floating tab.
func use_button(b: Button) -> void:
	external_button = b
	b.pressed.connect(toggle)
	_paint_external()


func _paint_external() -> void:
	if external_button == null or not is_instance_valid(external_button):
		return
	external_button.text = "CHAT" if _unread <= 0 else "CHAT (%d)" % _unread


func _process(_delta: float) -> void:
	var ext_on: bool = external_button != null and is_instance_valid(external_button) and external_button.is_visible_in_tree()
	_tab.visible = not ext_on
	_paint_external()
