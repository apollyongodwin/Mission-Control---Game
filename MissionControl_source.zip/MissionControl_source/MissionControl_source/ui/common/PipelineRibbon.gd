# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name PipelineRibbon
extends Control
## LEAD (UI pass). UX guide section 5: the pipeline ribbon in NASA's words.
## NEED > DESIGN > CHECK > LAUNCH > RESULTS, with the current step lit up. Drawn, so it never wraps or squashes.

const STEPS: Array = ["NEED", "DESIGN", "CHECK", "LAUNCH", "RESULTS"]
const PHASE_TO_STEP: Dictionary = {"LOBBY": 0, "BRIEFING": 0, "DESIGN": 1, "REVIEW": 2, "LAUNCH": 3, "FLIGHT": 3, "DEBRIEF": 4}

var accent: Color = GameTheme.AMBER
var current: int = 1


func _ready() -> void:
	custom_minimum_size = Vector2(300, 40)
	tooltip_text = "NASA's own steps: Identify Need and Goals, Define Concept, Define Requirements, Design, Build and Verify, Implement."
	mouse_filter = Control.MOUSE_FILTER_PASS


func set_phase(p: String) -> void:
	var c: int = int(PHASE_TO_STEP.get(p, 1))
	if c != current:
		current = c
		queue_redraw()


func _draw() -> void:
	var font: Font = get_theme_default_font()
	var fs: int = 15 if size.x < 520 else 17
	var gap: float = 14.0
	var widths: Array = []
	var total: float = 0.0
	for s in STEPS:
		var w: float = font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x + 22.0
		widths.append(w)
		total += w
	total += gap * (STEPS.size() - 1)
	var x: float = maxf(0.0, (size.x - total) / 2.0)
	var h: float = 30.0
	var y: float = (size.y - h) / 2.0
	for i in STEPS.size():
		var w: float = widths[i]
		var r := Rect2(x, y, w, h)
		var done: bool = i < current
		var now: bool = i == current
		var bg: Color = accent if now else (Color(accent, 0.22) if done else Color(1, 1, 1, 0.06))
		var sb := StyleBoxFlat.new()
		sb.bg_color = bg
		sb.set_corner_radius_all(15)
		sb.anti_aliasing = true
		draw_style_box(sb, r)
		var fg: Color = GameTheme.NAVY if now else (GameTheme.TEXT if done else GameTheme.MUTED)
		var tw: float = font.get_string_size(STEPS[i], HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string(font, Vector2(x + (w - tw) / 2.0, y + h / 2.0 + fs * 0.36), STEPS[i], HORIZONTAL_ALIGNMENT_LEFT, -1, fs, fg)
		if i < STEPS.size() - 1:
			var ax: float = x + w + gap / 2.0
			var ay: float = y + h / 2.0
			draw_polyline(PackedVector2Array([Vector2(ax - 3, ay - 5), Vector2(ax + 2, ay), Vector2(ax - 3, ay + 5)]), GameTheme.MUTED, 2.0, true)
		x += w + gap
