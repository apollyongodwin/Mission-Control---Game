# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends RolePanel
## PAYLOAD owns: instruments (a list of instrument ids).


func _init() -> void:
	role_id = "payload"


func _make_sections(_cadet: bool) -> Array:
	var sc: Dictionary = _scenario()
	var options: Array = []
	for ins in Data.db["instruments"]:
		if ins["scenario"] != sc["id"]:
			continue
		var o: Dictionary = ins.duplicate()
		# round 9: how much it helps each goal IN THE ORBIT FLIGHT PICKED (clouds, sunlight and pointing included)
		var fit: Dictionary = ShipDoctor.inst_fit(Data.db, PanelBridge.design(), ins)
		var helps: PackedStringArray = []
		for tag in ins["values"]:
			var w: String = ShipDoctor.word(float(fit.get(tag, 0.0)))
			helps.append("%s %s" % [ShipDoctor.short_goal(str(tag), _objective_label(str(tag))), w if w != "" else "(not here)"])
		o["extra"] = "In our orbit: " + ", ".join(helps)
		options.append(o)
	return [{"key": "instruments", "category": "instruments", "kind": "multi", "title": "Pick your instruments",
		"rule": "", "options": options}]


func _warning_for(_def: Dictionary, opt: Dictionary, selected: bool) -> String:
	return WhyDisabled.warn_instrument(opt, PanelBridge.design(), selected)


# keeps the "slots" line up to date as the bus or the instruments change
func _after_refresh() -> void:
	if _sections.is_empty():
		return
	var design: Dictionary = PanelBridge.design()
	var slots: int = int(Data.part("bus", str(design.get("bus", "")))["slots"])
	var used: int = (design.get("instruments", []) as Array).size()
	var text: String = "Slots: " + "[X] ".repeat(mini(used, slots)) + "[ ] ".repeat(maxi(slots - used, 0))
	if used > slots:
		text += "  TOO MANY!"
	(_sections[0]["rule_label"] as Label).text = text
