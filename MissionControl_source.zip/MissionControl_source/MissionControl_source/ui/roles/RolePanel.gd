# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name RolePanel
extends Control
## Shared base for the four role panels. Each panel script only says WHICH role it is and WHICH cards to show:
##   _init()                         set role_id
##   _make_sections(cadet) -> Array  the groups of cards (see the section format below)
##   _disabled_reason(def, opt)      optional: why a card is greyed out
##   _after_refresh()                optional: extra work after every update
## Section format: {"key": design key, "category": CardStats category, "kind": "single" | "multi" | "bundle",
##                  "title": String, "rule": String, "options": Array of item Dictionaries}
## An option may carry "sets" (bundle: {design key: value}), "value", "stats", "extra", "more".

const PART_CARD: PackedScene = preload("res://ui/common/PartCard.tscn")
const STRIP: PackedScene = preload("res://ui/common/ResourceStrip.tscn")
const DIFFICULTIES: Array = ["cadet", "engineer", "flight_director"]
const PRIVATE_ORDER: Array = ["lifetime", "schedule", "objectives", "mass_dry", "power", "data_generated_gb_day",
	"science", "cost", "rocket_capacity", "launch_mass_margin", "downlink_gb_day", "contact_min_day"]

var role_id: String = "systems"

var _role: Dictionary = {}
var _accent: Color = Color("F2B134")
var _coach_label: Label
var _coach_roles: HBoxContainer
var _cards_root: VBoxContainer
var _pager_box: HBoxContainer
var _page_label: Label
var _strip: ResourceStrip
var _numbers_toggle: CheckButton
var _private_title: Label
var _private_label: Label
var _chips_box: VBoxContainer
var _fix_btn: Button
var _fix_label: Label
var _undo_btn: Button
var _sections: Array = []
var _page: int = 0
var _sig: String = ""
var _undo: Dictionary = {}
var _tray: TokenTray
var _overlay: RoleOverlay
var _review_btn: Button        # MERGE: DESIGN -> REVIEW (no other screen could start the launch poll)
var _ribbon: PipelineRibbon     # MERGE (UI pass)
var _coach_panel: PanelContainer
var _coach_icon: Label
var _page_dots: HBoxContainer
var _ship: ShipSchematic
var _health_tag: Label          # LEAD (round 4): hidden in Commander mode
var _cmd_box: VBoxContainer     # LEAD (round 4): "COMMANDER SAYS" list
var _job_btn: Button
var _clock: Label               # LEAD (round 7): the build clock


# ---------------------------------------------------------------- override these
func _make_sections(_cadet: bool) -> Array:
	return []


func _disabled_reason(_def: Dictionary, _opt: Dictionary) -> String:
	return ""


func _after_refresh() -> void:
	pass


## optional: an amber "this will cause a problem" note that does NOT block the card (see WhyDisabled.warn_*)
func _warning_for(_def: Dictionary, _opt: Dictionary, _selected: bool) -> String:
	return ""


func _on_user_pick() -> void:
	pass


# ---------------------------------------------------------------- setup
func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_role = Data.db["meta"]["roles"][role_id]
	_accent = Color(str(_role["color"]))
	theme = GameTheme.build(_accent)
	var bg := ColorRect.new()
	bg.color = GameTheme.NAVY
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	var stars := Starfield.new()   # MERGE: same space mood as Dev D's menus, very subtle
	stars.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(stars)
	if PanelBridge.is_dev_stub():
		PanelBridge.dev_set_role(role_id)
	_build_skeleton()
	_overlay = RoleOverlay.new()   # crisis screen + launch poll, on top of everything
	add_child(_overlay)
	_overlay.setup(role_id, _accent)
	PanelBridge.on_changed(_refresh)
	PanelBridge.on_phase_changed(_refresh.unbind(1))
	PanelBridge.on_server_message(_on_server_message)
	MissionState.commander_changed.connect(_refresh)
	MissionState.clock_changed.connect(_update_clock)
	_refresh()


func _label(text: String, size: int = 20) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


## A label that never wraps (safe inside a crowded row: wrapping labels there collapse to one letter per line).
func _tag(text: String, size: int = 20, color: Color = GameTheme.TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


## MERGE (Lead, UI pass): one clean layout in Dev D's style, built for a 1280 x 720 laptop screen.
##  +--------------------------------------------------------------------------------------+
##  | [cat] SYSTEMS        NEED > DESIGN > CHECK > LAUNCH > RESULTS     tokens  [REVIEW]    |
##  | (coach bubble: ONE message + avatars of who can fix it)                               |
##  | +-- cards for the current decision ------------------+ +-- ship + health ----------+ |
##  | | Pick your body              < 1 of 3 >  rule        | |   (live ship drawing)     | |
##  | | [card] [card] [card]                                | |   lights   numbers        | |
##  | +-----------------------------------------------------+ |   autopilot  Fix it       | |
##  +--------------------------------------------------------------------------------------+
var chat_button: Button = null
var _goals_box: VBoxContainer = null
var _team_box: VBoxContainer = null
var _team_sig: String = ""


func _build_skeleton() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 14)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	margin.add_child(root)

	# ---- top bar
	var top := GameTheme.panel(GameTheme.PANEL, GameTheme.EDGE, 3, 20, 10)
	root.add_child(top)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 14)
	top.add_child(head)
	var avatar := CrewArt.make(role_id, 60)   # MERGE: the role's cat astronaut (assets/images/roles/<role>.png)
	avatar.bob = true
	head.add_child(avatar)
	var names := VBoxContainer.new()
	names.add_theme_constant_override("separation", -4)
	names.alignment = BoxContainer.ALIGNMENT_CENTER
	names.add_child(_tag(str(_role["name"]), 28, _accent))
	names.add_child(_tag(str(_role["title"]), 17, GameTheme.MUTED))
	head.add_child(names)
	_ribbon = PipelineRibbon.new()
	_ribbon.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_ribbon.accent = _accent
	head.add_child(_ribbon)
	_tray = TokenTray.new()
	_tray.setup(role_id)
	head.add_child(_tray)
	_clock = _tag("", 24, GameTheme.TEXT)
	_clock.custom_minimum_size = Vector2(150, 0)
	_clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	head.add_child(_clock)
	_review_btn = Button.new()
	_review_btn.text = "CALL DESIGN REVIEW"
	_review_btn.tooltip_text = "Everyone happy with the ship? Ask the whole crew for GO / NO-GO."
	_review_btn.custom_minimum_size = Vector2(220, 60)
	_review_btn.add_theme_font_size_override("font_size", 20)
	GameTheme.primary(_review_btn)
	_review_btn.pressed.connect(_on_review_pressed)
	head.add_child(_review_btn)
	_job_btn = Button.new()   # LEAD (round 4): "what is my job again?"
	_job_btn.text = "MY JOB"
	_job_btn.custom_minimum_size = Vector2(100, 60)
	_job_btn.add_theme_font_size_override("font_size", 18)
	_job_btn.pressed.connect(func() -> void: RoleGuide.popup(self, role_id))
	head.add_child(_job_btn)
	chat_button = Button.new()   # round 8: the crew chat lives up here now (CrewScreen hands it to the ChatDrawer)
	chat_button.text = "CHAT"
	chat_button.custom_minimum_size = Vector2(100, 60)
	chat_button.add_theme_font_size_override("font_size", 18)
	head.add_child(chat_button)
	if PanelBridge.is_dev_stub():
		var dev := OptionButton.new()
		for d in DIFFICULTIES:
			dev.add_item(str(d))
		dev.selected = DIFFICULTIES.find(PanelBridge.difficulty())
		dev.item_selected.connect(func(i: int) -> void: PanelBridge.dev_set_difficulty(str(DIFFICULTIES[i])))
		head.add_child(dev)

	# ---- coach bubble: always ONE message (UX guide section 4)
	_coach_panel = GameTheme.panel(Color(_accent, 0.12), Color(_accent, 0.6), 2, 18, 10)
	root.add_child(_coach_panel)
	var bubble_row := HBoxContainer.new()
	bubble_row.add_theme_constant_override("separation", 12)
	_coach_panel.add_child(bubble_row)
	_coach_icon = _tag("!", 30, _accent)
	_coach_icon.custom_minimum_size = Vector2(30, 0)
	_coach_icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bubble_row.add_child(_coach_icon)
	_coach_label = _label("", 19)
	_coach_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_coach_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bubble_row.add_child(_coach_label)
	_coach_roles = HBoxContainer.new()
	_coach_roles.add_theme_constant_override("separation", 6)
	bubble_row.add_child(_coach_roles)

	# ---- body
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	root.add_child(body)

	var left := GameTheme.panel(GameTheme.PANEL, GameTheme.EDGE, 3, 20, 14)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(left)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 10)
	left.add_child(lv)
	_pager_box = HBoxContainer.new()
	_pager_box.add_theme_constant_override("separation", 10)
	_pager_box.custom_minimum_size.y = 44
	var prev := Button.new()
	prev.text = "<"
	prev.custom_minimum_size = Vector2(64, 44)
	prev.add_theme_font_size_override("font_size", 24)
	prev.pressed.connect(func() -> void: _go_page(-1))
	_pager_box.add_child(prev)
	_page_dots = HBoxContainer.new()
	_page_dots.add_theme_constant_override("separation", 8)
	_page_dots.alignment = BoxContainer.ALIGNMENT_CENTER
	_page_dots.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_pager_box.add_child(_page_dots)
	_page_label = _tag("1 of 1", 20, GameTheme.MUTED)
	_pager_box.add_child(_page_label)
	var nxt := Button.new()
	nxt.text = ">"
	nxt.custom_minimum_size = Vector2(64, 44)
	nxt.add_theme_font_size_override("font_size", 24)
	nxt.pressed.connect(func() -> void: _go_page(1))
	_pager_box.add_child(nxt)
	lv.add_child(_pager_box)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	lv.add_child(scroll)
	_cards_root = VBoxContainer.new()
	_cards_root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_cards_root.size_flags_vertical = Control.SIZE_EXPAND_FILL   # round 9: the card row fills the height
	_cards_root.add_theme_constant_override("separation", 22)
	_cards_root.resized.connect(_fit_cards)
	scroll.add_child(_cards_root)

	var right := GameTheme.panel(GameTheme.PANEL, GameTheme.EDGE, 3, 20, 12)
	right.custom_minimum_size = Vector2(360, 0)
	body.add_child(right)
	var right_scroll := ScrollContainer.new()
	right_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(right_scroll)
	var rv := VBoxContainer.new()
	rv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rv.add_theme_constant_override("separation", 10)
	right_scroll.add_child(rv)
	_ship = ShipSchematic.new()   # MERGE: Dev C's live spaceship drawing, so every pick visibly changes the ship
	_ship.custom_minimum_size = Vector2(0, 130)
	_ship.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_ship.show_caption = false
	rv.add_child(_ship)
	_cmd_box = VBoxContainer.new()
	_cmd_box.add_theme_constant_override("separation", 6)
	rv.add_child(_cmd_box)
	# round 9: everyone sees the mission goals and the whole team's picks, so the crew can plan TOGETHER
	_goals_box = VBoxContainer.new()
	_goals_box.add_theme_constant_override("separation", 3)
	rv.add_child(_goals_box)
	_team_box = VBoxContainer.new()
	_team_box.add_theme_constant_override("separation", 4)
	rv.add_child(_team_box)
	_health_tag = _tag("SHIP HEALTH", 18, GameTheme.AMBER)
	rv.add_child(_health_tag)
	_strip = STRIP.instantiate() as ResourceStrip
	rv.add_child(_strip)
	_numbers_toggle = CheckButton.new()
	_numbers_toggle.text = "Show numbers"
	_numbers_toggle.add_theme_font_size_override("font_size", 18)
	_numbers_toggle.toggled.connect(func(_on: bool) -> void: _refresh())
	rv.add_child(_numbers_toggle)
	_private_title = _label("", 18)
	_private_title.add_theme_color_override("font_color", GameTheme.AMBER)
	rv.add_child(_private_title)
	_private_label = _label("", 17)
	_private_label.add_theme_font_override("font", GameTheme.mono_font())
	rv.add_child(_private_label)
	_chips_box = VBoxContainer.new()
	_chips_box.add_theme_constant_override("separation", 6)
	rv.add_child(_chips_box)
	_fix_btn = Button.new()
	_fix_btn.text = "Fix it for me"
	_fix_btn.custom_minimum_size = Vector2(0, 58)
	_fix_btn.add_theme_font_size_override("font_size", 20)
	GameTheme.paint_button(_fix_btn, _accent.darkened(0.35), GameTheme.TEXT)
	_fix_btn.pressed.connect(_on_fix_pressed)
	rv.add_child(_fix_btn)
	_fix_label = _label("", 18)
	rv.add_child(_fix_label)
	_undo_btn = Button.new()
	_undo_btn.text = "Undo"
	_undo_btn.custom_minimum_size = Vector2(0, 52)
	_undo_btn.add_theme_font_size_override("font_size", 20)
	_undo_btn.pressed.connect(_on_undo_pressed)
	rv.add_child(_undo_btn)


# ---------------------------------------------------------------- helpers for subclasses
func _orbit() -> Dictionary:
	return Data.orbit(str(PanelBridge.design().get("orbit", "")))


func _scenario() -> Dictionary:
	return Data.scenario(str(PanelBridge.design().get("scenario", "")))


func _set_chips(notes: Array) -> void:
	for c in _chips_box.get_children():
		_chips_box.remove_child(c)
		c.queue_free()
	if notes.is_empty():
		return
	_chips_box.add_child(_tag("AUTOPILOT CHOSE", 18, GameTheme.AMBER))
	for n in notes:
		var chip := GameTheme.panel(GameTheme.PANEL_HI, GameTheme.LINE, 1, 14, 8)
		var l := _label(str(n["text"]), 16)
		l.custom_minimum_size = Vector2(300, 0)
		chip.add_child(l)
		_chips_box.add_child(chip)


# ---------------------------------------------------------------- refresh
func _refresh() -> void:
	var cadet: bool = PanelBridge.is_cadet()
	var design: Dictionary = PanelBridge.design()
	var sig: String = "%s|%s|%s" % [cadet, design.get("scenario"), design.get("orbit")]
	if sig != _sig:
		_sig = sig
		_page = 0
		_rebuild(cadet)
	_update_states(design)
	var view: Dictionary = PanelBridge.view()
	var lights_now: Dictionary = view.get("lights", {})
	var cmd: bool = MissionState.commander_mode
	_strip.set_lights(lights_now)
	if not cmd:
		_light_sounds(lights_now)
		_update_coach(view, cadet)
	else:
		_update_commander_view()
	_update_private(view, cadet)
	_fix_btn.visible = cadet and not cmd
	_fix_label.visible = cadet and _fix_label.text != "" and not cmd
	_undo_btn.visible = cadet and not _undo.is_empty() and not cmd
	_chips_box.visible = cadet and not cmd
	# round 4: in Commander mode the crew is blind: no health lights, no numbers, no "fix it for me"
	_strip.visible = not cmd
	_health_tag.visible = not cmd
	_cmd_box.visible = cmd
	if cmd:
		_numbers_toggle.visible = false
		_private_title.visible = false
		_private_label.visible = false
	_update_pager(cadet)
	if _review_btn != null:
		_review_btn.disabled = PanelBridge.phase() != "DESIGN"
	if _tray != null:
		_tray.visible = PanelBridge.phase() in ["LAUNCH", "FLIGHT", "DEBRIEF"]   # tokens only exist from launch on
	if _ship != null:
		_ship.set_design(design)
	_update_team_info(design)
	if _ribbon != null:
		_ribbon.set_phase(PanelBridge.phase())
	_update_clock()
	_after_refresh()


func _rebuild(cadet: bool) -> void:
	for c in _cards_root.get_children():
		_cards_root.remove_child(c)
		c.queue_free()
	_sections.clear()
	var orbit: Dictionary = _orbit()
	for def in _make_sections(cadet):
		var box := VBoxContainer.new()
		var title_row := HBoxContainer.new()
		title_row.add_theme_constant_override("separation", 16)
		var title := _tag(str(def["title"]), 26, _accent)
		title_row.add_child(title)
		var rule := _label(str(def.get("rule", "")), 19)
		rule.add_theme_color_override("font_color", GameTheme.MUTED)
		rule.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rule.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		title_row.add_child(rule)
		box.add_child(title_row)
		# round 9: ONE row of cards that scrolls sideways with big arrows. A wrapping grid hid every card after
		# the third below the bottom of the screen (and long cards pushed their own button off the bottom).
		box.size_flags_vertical = Control.SIZE_EXPAND_FILL
		var strip_row := HBoxContainer.new()
		strip_row.add_theme_constant_override("separation", 6)
		strip_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
		box.add_child(strip_row)
		var left_btn := _arrow_button("<")
		strip_row.add_child(left_btn)
		var strip := ScrollContainer.new()
		strip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		strip.size_flags_vertical = Control.SIZE_EXPAND_FILL
		strip.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
		strip_row.add_child(strip)
		var right_btn := _arrow_button(">")
		strip_row.add_child(right_btn)
		var flow := HBoxContainer.new()
		flow.add_theme_constant_override("separation", 12)
		flow.size_flags_vertical = Control.SIZE_EXPAND_FILL
		strip.add_child(flow)
		left_btn.pressed.connect(_scroll_strip.bind(strip, -1))
		right_btn.pressed.connect(_scroll_strip.bind(strip, 1))

		var options: Array = def["options"]
		var all_stats: Array = []
		var maxes: Array = []
		for opt in options:
			var st: Array = opt["stats"] if opt.has("stats") else CardStats.for_item(str(def.get("category", "")), opt, orbit)
			all_stats.append(st)
			for i in st.size():
				if maxes.size() <= i:
					maxes.append(0.0)
				maxes[i] = maxf(float(maxes[i]), float(st[i]["v"]))
		var cards: Array = []
		for n in options.size():
			var opt: Dictionary = options[n]
			var st2: Array = all_stats[n]
			var bars: Array = []
			for i in st2.size():
				var mx: float = float(maxes[i])
				if MissionState.commander_mode and str(st2[i]["label"]) in ["Cost", "Price", "Budget"]:
					continue   # round 4: only the Commander sees money
				bars.append({"label": st2[i]["label"], "text": st2[i]["text"], "frac": (float(st2[i]["v"]) / mx) if mx > 0.0 else 0.0})
			var card := PART_CARD.instantiate() as PartCard
			card.setup(opt, {"bars": bars, "cadet": cadet, "multi": str(def.get("kind", "single")) == "multi",
				"value": opt.get("value", opt.get("id")), "extra": opt.get("extra", ""), "more": opt.get("more", ""), "accent": _accent,
				"category": str(def.get("category", "")) if str(def.get("category", "")) != "" else str(def.get("key", ""))})
			card.chosen.connect(_on_card_chosen.bind(def, opt))
			flow.add_child(card)
			cards.append(card)
		_cards_root.add_child(box)
		_sections.append({"def": def, "box": box, "cards": cards, "rule_label": rule, "strip": strip, "arrows": [left_btn, right_btn]})
	_fit_cards.call_deferred()


func _update_states(design: Dictionary) -> void:
	for s in _sections:
		var def: Dictionary = s["def"]
		var options: Array = def["options"]
		var cards: Array = s["cards"]
		for n in options.size():
			var card: PartCard = cards[n]
			card.set_selected(_is_selected(def, options[n], design))
			card.set_disabled_reason(_disabled_reason(def, options[n]))
			card.set_warning(_commander_card_flag(def, options[n], _is_selected(def, options[n], design)) if MissionState.commander_mode
				else _warning_for(def, options[n], _is_selected(def, options[n], design)))
		_stamp_section(s)


func _is_selected(def: Dictionary, opt: Dictionary, design: Dictionary) -> bool:
	if opt.has("sets"):
		var sets: Dictionary = opt["sets"]
		for k in sets:
			if str(design.get(k, "")) != str(sets[k]):
				return false
		return true
	var key: String = str(def["key"])
	var val = opt.get("value", opt.get("id"))
	if str(def.get("kind", "single")) == "multi":
		var cur: Array = design.get(key, [])
		return cur.has(val)
	return str(design.get(key, "")) == str(val)


func _on_card_chosen(value, def: Dictionary, opt: Dictionary) -> void:
	_undo = {}
	_fix_label.text = ""
	_on_user_pick()
	if opt.has("sets"):
		var sets: Dictionary = opt["sets"]
		for k in sets:
			PanelBridge.submit(str(k), sets[k])
		return
	var key: String = str(def["key"])
	if str(def.get("kind", "single")) == "multi":
		var cur: Array = (PanelBridge.design().get(key, []) as Array).duplicate()
		if cur.has(value):
			cur.erase(value)
		else:
			cur.append(value)
		PanelBridge.submit(key, cur)
		return
	PanelBridge.submit(key, value)


## MERGE (UI pass): stretch the cards so each row is filled edge to edge (3 across on a laptop, more on a big screen).
func _fit_cards() -> void:
	var gap: float = 12.0
	for sec in _sections:
		var strip: ScrollContainer = sec.get("strip")
		var w: float = strip.size.x if strip != null and strip.size.x > 0.0 else _cards_root.size.x - 120.0
		if w <= 0.0:
			continue
		var per_row: int = maxi(1, int(floor((w + gap) / (215.0 + gap))))
		var card_w: float = floor((w - gap * float(per_row - 1)) / float(per_row)) - 1.0
		for c in sec["cards"]:
			(c as Control).custom_minimum_size.x = card_w
		var many: bool = (sec["cards"] as Array).size() > per_row
		for b in sec.get("arrows", []):
			(b as Button).visible = many
		if strip != null and not strip.resized.is_connected(_fit_cards):
			strip.resized.connect(_fit_cards)


func _arrow_button(t: String) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(44, 0)
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 30)
	b.tooltip_text = "More cards this way"
	return b


## round 9: the arrows slide the card row by one card.
func _scroll_strip(strip: ScrollContainer, dir: int) -> void:
	var step: float = 242.0
	var row: Control = strip.get_child(0) if strip.get_child_count() > 0 else null
	if row != null and row.get_child_count() > 0:
		step = (row.get_child(0) as Control).size.x + 12.0
	var tw := create_tween()
	tw.tween_property(strip, "scroll_horizontal", int(strip.scroll_horizontal + dir * step), 0.25)
	Audio.play_sfx("click")


## MERGE (juice): a soft buzz when a light turns red, a chime when the last red/amber clears (UX guide section 6).
var _prev_lights: Dictionary = {}
func _light_sounds(lights: Dictionary) -> void:
	if _prev_lights.is_empty() or lights.is_empty():
		_prev_lights = lights.duplicate()
		return
	var new_red := false
	var all_green := true
	var was_all_green := true
	for k in lights:
		if str(lights[k]) == "red" and str(_prev_lights.get(k, "")) != "red":
			new_red = true
		if str(lights[k]) != "green":
			all_green = false
		if str(_prev_lights.get(k, "")) != "green":
			was_all_green = false
	if new_red:
		Audio.play_sfx("buzz")
		Fx.shake(_strip, 4.0, 0.25)
	elif all_green and not was_all_green:
		Audio.play_sfx("chime")
		Fx.burst(_strip, _strip.size / 2.0, [Color("7CE08A"), Color.WHITE], 20)
	_prev_lights = lights.duplicate()


# ---------------------------------------------------------------- LEAD (round 4): Commander mode
## The design categories one section controls (bundles like "power pack" set several at once).
func _section_categories(def: Dictionary) -> Array:
	var c: String = str(def.get("category", ""))
	if c != "":
		return [c]
	var out: Array = []
	for opt in def.get("options", []):
		for k in (opt.get("sets", {}) as Dictionary):
			if not out.has(k):
				out.append(k)
	return out


func _stamp_section(s: Dictionary) -> void:
	var rule: Label = s.get("rule_label")
	if rule == null:
		return
	var base: String = str(s["def"].get("rule", ""))
	var flagged := false
	if MissionState.commander_mode:
		for c in _section_categories(s["def"]):
			for k in MissionState.commander_marks:
				if (str(k) == c or str(k).begins_with(c + ":")) and str(MissionState.commander_marks[k]) == "swap":
					flagged = true
	rule.text = base + ("      COMMANDER SAYS: SWAP THIS!" if flagged else "")
	rule.add_theme_color_override("font_color", GameTheme.BAD if flagged else GameTheme.MUTED)


## round 7: the Commander's SWAP shows right on the chosen card (one instrument at a time for lists).
func _commander_card_flag(def: Dictionary, opt: Dictionary, selected: bool) -> String:
	if not selected:
		return ""
	var val = opt.get("value", opt.get("id"))
	if str(def.get("kind", "")) == "multi":
		return "COMMANDER: SWAP THIS ONE OUT!" if str(MissionState.commander_marks.get("%s:%s" % [def["key"], val], "")) == "swap" else ""
	for c in _section_categories(def):
		if str(MissionState.commander_marks.get(c, "")) == "swap":
			return "COMMANDER: SWAP THIS!"
	return ""


## round 5 (simple): the bubble + right-hand box only talk about parts the Commander FLAGGED.
func _update_commander_view() -> void:
	var swaps: Array = []
	for c in MissionState.swaps_for_role(role_id):
		swaps.append(MissionState.mark_label(str(c)))
	for c in _cmd_box.get_children():
		_cmd_box.remove_child(c)
		c.queue_free()
	_cmd_box.add_child(_tag("COMMANDER SAYS", 18, GameTheme.AMBER))
	if swaps.is_empty():
		var l := _label("Nothing to swap right now.", 18)
		l.add_theme_color_override("font_color", GameTheme.GOOD)
		_cmd_box.add_child(l)
	for sw in swaps:
		var l2 := _label("X  Swap your %s!" % str(sw).to_lower(), 20)
		l2.add_theme_color_override("font_color", GameTheme.BAD)
		_cmd_box.add_child(l2)
	var hint := _label("You can't see if your parts are right. The Commander can: tell them what you picked!", 15)
	hint.add_theme_color_override("font_color", Color("9FD4FF"))
	_cmd_box.add_child(hint)
	for c in _coach_roles.get_children():
		_coach_roles.remove_child(c)
		c.queue_free()
	var col2: Color = GameTheme.WARN
	if not swaps.is_empty():
		_coach_label.text = "The Commander says: swap your %s! Ask why." % ", ".join(swaps).to_lower()
		_coach_icon.text = "X"
		col2 = GameTheme.BAD
	else:
		_coach_label.text = "Tell the Commander what you picked. Ask: \"Is that OK?\""
		_coach_icon.text = "?"
	_coach_icon.add_theme_color_override("font_color", col2)
	_coach_panel.add_theme_stylebox_override("panel", GameTheme.box(Color(col2, 0.13), Color(col2, 0.7), 2, 18, 10))


# ---------------------------------------------------------------- LEAD (round 7): build clock
func _update_clock() -> void:
	if _clock == null:
		return
	var left: int = MissionState.design_left
	_clock.visible = left >= 0 and PanelBridge.phase() == "DESIGN"
	if left > 0:
		_clock.text = "BUILD\n" + MissionState.clock_text(left)
		_clock.add_theme_color_override("font_color", GameTheme.BAD if left <= 30 else (GameTheme.WARN if left <= 60 else GameTheme.TEXT))
	else:
		_clock.text = "OVERTIME!\n-C$%d M" % int(MissionState.budget_penalty)
		_clock.add_theme_color_override("font_color", GameTheme.BAD)


# ---------------------------------------------------------------- MERGE: review button + host messages
func _on_review_pressed() -> void:
	PanelBridge.call_review()
	_review_btn.text = "ASKING THE CREW..."
	get_tree().create_timer(1.5).timeout.connect(func() -> void:
		if is_instance_valid(_review_btn):
			_review_btn.text = "CALL DESIGN REVIEW")


## The host explains a "no" (design not ready, choice belongs to someone else, a NO-GO). Show it in the coach bubble.
func _on_server_message(code: String, text: String) -> void:
	if code == "commander_swap":
		Audio.play_sfx("error")
		Fx.shake(_coach_panel, 6.0, 0.3)
	if code in ["review_blocked", "choice_rejected", "nogo", "seat_held", "seat_freed", "rejoined", "commander_swap", "bot_swap", "commander_go", "waiting_commander", "build_clock", "investors"]:
		if code == "investors":
			Audio.play_sfx("coin", -2.0)
			Fx.shake(_coach_panel, 8.0, 0.4)
		_coach_label.text = text
		var tw := create_tween()
		_coach_label.modulate = Color(1.0, 0.85, 0.4)
		tw.tween_property(_coach_label, "modulate", Color.WHITE, 1.2)


# ---------------------------------------------------------------- pager (Cadet: one decision at a time)
func _go_page(delta: int) -> void:
	_page = clampi(_page + delta, 0, maxi(_sections.size() - 1, 0))
	_update_pager(PanelBridge.is_cadet())


func _update_pager(cadet: bool) -> void:
	var paged: bool = _sections.size() > 1   # round 9: ONE decision at a time on every level (UX rule 1)
	_pager_box.visible = paged
	_page = clampi(_page, 0, maxi(_sections.size() - 1, 0))
	_page_label.text = "%d of %d" % [_page + 1, _sections.size()]
	for c in _page_dots.get_children():
		c.queue_free()
	for i in _sections.size():
		var dot := _tag(str(_sections[i]["def"].get("title", "")).trim_prefix("Pick ").trim_prefix("your ").capitalize() if i == _page else "o",
			20 if i == _page else 16, _accent if i == _page else GameTheme.MUTED)
		_page_dots.add_child(dot)
	for i in _sections.size():
		var box: Control = _sections[i]["box"]
		box.visible = (not paged) or i == _page
		# round 9: the pager already names the page, so the title row only keeps its rule ("Pick ONE", slots)
		var tr: Control = (box.get_child(0) as Control)
		if tr != null and tr.get_child_count() > 0:
			(tr.get_child(0) as Control).visible = not paged


# ---------------------------------------------------------------- coach bubble
func _update_coach(view: Dictionary, cadet: bool) -> void:
	var msg: Dictionary = CoachText.pick(view, cadet)
	_coach_label.text = str(msg["text"])
	for c in _coach_roles.get_children():
		_coach_roles.remove_child(c)
		c.queue_free()
	# colour + shape by how serious it is (never colour alone): ! red problem, ? amber careful, check = all good
	var lights: Dictionary = view.get("lights", {})
	var worst: String = "green"
	for k in lights:
		if str(lights[k]) == "red":
			worst = "red"
		elif str(lights[k]) == "amber" and worst != "red":
			worst = "amber"
	if not (view.get("errors", []) as Array).is_empty():
		worst = "red"
	var col: Color = {"red": GameTheme.BAD, "amber": GameTheme.WARN}.get(worst, GameTheme.GOOD)
	_coach_icon.text = {"red": "X", "amber": "!"}.get(worst, "OK")
	_coach_icon.add_theme_color_override("font_color", col)
	_coach_panel.add_theme_stylebox_override("panel", GameTheme.box(Color(col, 0.13), Color(col, 0.7), 2, 18, 10))
	var roles: Array = msg["roles"]
	if roles.is_empty() or roles.size() >= 4:
		return
	_coach_roles.add_child(_tag("Who can fix it:", 17, GameTheme.MUTED))
	for r in roles:
		var a := CrewArt.make(str(r), 44)
		a.tooltip_text = str(Data.db["meta"]["roles"][str(r)]["name"])
		a.mouse_filter = Control.MOUSE_FILTER_STOP
		_coach_roles.add_child(a)


# ---------------------------------------------------------------- numbers (ONLY what the host put in view["private"])
func _update_private(view: Dictionary, cadet: bool) -> void:
	var priv: Dictionary = view.get("private", {})
	var show: bool = (not cadet) or _numbers_toggle.button_pressed
	_numbers_toggle.visible = cadet
	_private_title.text = "Numbers for everyone" if cadet else "Your numbers (only you see these)"
	_private_title.visible = show and not priv.is_empty()
	_private_label.visible = show
	_private_label.text = _private_text(priv)


func _f(v) -> String:
	return CardStats.fmt(v)


func _objective_label(tag: String) -> String:
	for o in _scenario().get("objectives", []):
		if o["tag"] == tag:
			return str(o["label"])
	return tag


func _private_text(priv: Dictionary) -> String:
	var lines: PackedStringArray = []
	for k in PRIVATE_ORDER:
		if not priv.has(k):
			continue
		match str(k):
			"lifetime":
				var l: Dictionary = priv[k]
				lines.append("Lifetime: %s days (needs %s, goal %s)" % [_f(l["days"]), _f(l["required"]), _f(l["target"])])
				lines.append("Limited by: " + str(l["limiting"]).replace("_", " "))
			"schedule":
				var s: Dictionary = priv[k]
				lines.append("Build time: %s months (deadline %s, spare %s)" % [_f(s["dev_months"]), _f(s["deadline"]), _f(s["float"])])
			"objectives":
				for o in priv[k]:
					lines.append("%s: %s of %s points" % [_objective_label(str(o["tag"])), _f(o["achieved"]), _f(o["max"])])
			"mass_dry":
				lines.append("Dry mass: %s kg" % _f(priv[k]))
			"power":
				var p: Dictionary = priv[k]
				lines.append("Power used: %s W" % _f(p["load_w"]))
				lines.append("Power made: %s W at start, %s W at end" % [_f(p["gen_bol_w"]), _f(p["gen_eol_w"])])
				lines.append("Shadow energy needed: %s Wh" % _f(p["eclipse_wh_needed"]))
				lines.append("Battery can give: %s Wh" % _f(p["battery_usable_wh"]))
				lines.append("Spare power: %s%%" % _f(float(p["margin"]) * 100.0))
			"data_generated_gb_day":
				lines.append("Data made: %s GB/day" % _f(priv[k]))
			"science":
				var sc: Dictionary = priv[k]
				lines.append("Science points: %s" % _f(sc["points"]))
				if not (sc["synergy_hits"] as Array).is_empty():
					lines.append("Teamwork bonus: " + ", ".join(PackedStringArray(sc["synergy_hits"])))
			"cost":
				var c: Dictionary = priv[k]
				lines.append("Total cost: C$%sM of C$%sM" % [_f(c["total"]), _f(c["cap"])])
				lines.append("Hardware %s, rocket %s, ground %s, running %s" % [_f(c["hardware"]), _f(c["launch"]), _f(c["ground_setup"]), _f(c["ops"])])
			"rocket_capacity":
				lines.append("Rocket can lift: %s kg" % _f(priv[k]))
			"launch_mass_margin":
				lines.append("Spare lifting room: %s%%" % _f(float(priv[k]) * 100.0))
			"downlink_gb_day":
				lines.append("Sent home: %s GB/day" % _f(priv[k]))
			"contact_min_day":
				lines.append("Talk time: %s min/day" % _f(priv[k]))
	return "\n".join(lines)


# ---------------------------------------------------------------- Fix it for me (Cadet)
func _on_fix_pressed() -> void:
	_undo = {}
	var design: Dictionary = PanelBridge.design()
	var fix: Dictionary = SimEngine.suggest_fix(Data.db, design, PanelBridge.difficulty())
	if fix.is_empty():
		_fix_label.text = "Nothing to fix. Looking good!"
		_refresh()
		return
	var owner_id: String = str(fix.get("owner_role", ""))
	if owner_id != role_id:
		var roles: Dictionary = Data.db["meta"]["roles"]
		var who: String = str((roles[owner_id] as Dictionary).get("name", owner_id)) if roles.has(owner_id) else owner_id
		_fix_label.text = "Ask %s: %s. %s" % [who, fix["label"], fix["why"]]
		_refresh()
		return
	var key: String = str(fix["key"])
	var old = design.get(key)
	if old is Array:
		old = (old as Array).duplicate()
	var new_design: Dictionary = SimEngine.apply_fix(design, fix)
	_undo = {"key": key, "value": old}
	_fix_label.text = "Done! %s. %s" % [fix["label"], fix["why"]]
	PanelBridge.submit(key, new_design[key])


func _on_undo_pressed() -> void:
	if _undo.is_empty():
		return
	var u: Dictionary = _undo
	_undo = {}
	_fix_label.text = "Undone."
	PanelBridge.submit(str(u["key"]), u["value"])



# ---------------------------------------------------------------- round 9: mission goals + team picks (everyone)
## Built from the shared design and the data file only, so it is safe on every crew laptop (no secret numbers).
func _update_team_info(design: Dictionary) -> void:
	if _goals_box == null:
		return
	var sig := str(design)
	if sig == _team_sig:
		return
	_team_sig = sig
	for c in _goals_box.get_children():
		_goals_box.remove_child(c)
		c.queue_free()
	for c in _team_box.get_children():
		_team_box.remove_child(c)
		c.queue_free()
	var orbit_name: String = str(Data.orbit(str(design.get("orbit", ""))).get("name", "no orbit yet"))
	_goals_box.add_child(_tag("MISSION GOALS", 17, GameTheme.AMBER))
	_goals_box.add_child(_small("With our instruments, in %s:" % orbit_name, GameTheme.MUTED))
	for g in ShipDoctor.goal_fill(Data.db, design):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		var l := _small("%s (%d)" % [str(g["short"]).capitalize(), int(g["weight"])], GameTheme.TEXT)
		l.custom_minimum_size = Vector2(118, 0)
		l.autowrap_mode = TextServer.AUTOWRAP_OFF
		row.add_child(l)
		var bar := ProgressBar.new()
		bar.max_value = 1.0
		bar.value = float(g["fill"])
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(0, 14)
		bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var fill_col: Color = GameTheme.GOOD if float(g["fill"]) >= 0.75 else (GameTheme.WARN if float(g["fill"]) >= 0.35 else GameTheme.BAD)
		var sb := StyleBoxFlat.new()
		sb.bg_color = fill_col
		sb.set_corner_radius_all(6)
		bar.add_theme_stylebox_override("fill", sb)
		bar.tooltip_text = "Our orbit sees %s: %s" % [g["short"], ShipDoctor.word(float(g["seen"])) if float(g["seen"]) > 0.0 else "not at all"]
		row.add_child(bar)
		_goals_box.add_child(row)
	var hints: Array = ShipDoctor.team_hints(Data.db, design)
	for h in hints:
		_goals_box.add_child(_small("- " + str(h), GameTheme.WARN))
	if hints.is_empty():
		_goals_box.add_child(_small("Tip: 2 or 3 instruments on the SAME goal fill it.", GameTheme.MUTED))
	_team_box.add_child(_tag("TEAM SHIP", 17, GameTheme.AMBER))
	var lines: Dictionary = ShipDoctor.team_lines(Data.db, design)
	for r in Protocol.ROLES:
		var row2 := HBoxContainer.new()
		row2.add_theme_constant_override("separation", 6)
		row2.add_child(CrewArt.make(r, 26))
		var t := _small(str(lines.get(r, "")), RoleGuide.color(r) if r != role_id else GameTheme.TEXT)
		t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row2.add_child(t)
		_team_box.add_child(row2)


func _small(text: String, col: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 14)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(150, 0)
	return l
