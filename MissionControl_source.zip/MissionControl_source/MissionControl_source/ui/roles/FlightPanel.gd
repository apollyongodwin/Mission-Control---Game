# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends RolePanel
## FLIGHT owns: orbit, engines (prop) and pointing (adcs).
## LEAD (round 7, role balance): FLIGHT used to pick only the orbit. Engines and pointing are flight dynamics
## (how the ship moves and aims), so they moved here from SYSTEMS. The engines you need depend on the orbit.


func _init() -> void:
	role_id = "flight"


func _make_sections(_cadet: bool) -> Array:
	var options: Array = []
	for oid in _scenario()["orbits"]:
		var o: Dictionary = Data.orbit(str(oid)).duplicate()
		var more: Array = []
		if o.has("pros"):
			more.append("Good: " + ", ".join(PackedStringArray(o["pros"])))
		if o.has("cons"):
			more.append("Watch out: " + ", ".join(PackedStringArray(o["cons"])))
		o["more"] = "\n".join(PackedStringArray(more))
		# round 9: what this orbit sees well, so FLIGHT and PAYLOAD can plan together
		var cov: Dictionary = _scenario()["orbits"][oid].get("coverage", {})
		var sees: PackedStringArray = []
		for tag in cov:
			var w: String = ShipDoctor.word(float(cov[tag]) - 0.25)
			sees.append("%s %s" % [ShipDoctor.short_goal(str(tag)), w if w != "" else "poorly"])
		o["extra"] = "Sees: " + ", ".join(sees)
		options.append(o)
	var P: Dictionary = Data.db["parts"]
	return [
		{"key": "orbit", "category": "orbit", "kind": "single", "title": "Pick your orbit", "rule": "Pick ONE", "options": options},
		{"key": "prop", "category": "prop", "kind": "single", "title": "Pick your engines", "rule": "Pick ONE (some orbits need engines!)", "options": P["prop"]},
		{"key": "adcs", "category": "adcs", "kind": "single", "title": "Pick your pointing", "rule": "Pick ONE (sharp cameras need steady aim)", "options": P["adcs"]},
	]


func _disabled_reason(def: Dictionary, opt: Dictionary) -> String:
	if str(def.get("category", "")) == "prop":
		return WhyDisabled.block_prop(opt, _orbit())
	return ""


func _warning_for(def: Dictionary, opt: Dictionary, _selected: bool) -> String:
	if str(def.get("category", "")) == "adcs":
		return WhyDisabled.warn_adcs(opt, PanelBridge.design())
	return ""
