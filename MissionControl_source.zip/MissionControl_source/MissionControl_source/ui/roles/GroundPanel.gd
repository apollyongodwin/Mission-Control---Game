# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends RolePanel
## GROUND owns: rocket, comm (antenna), stations (a list of station ids).

const ANTENNA_NAMES: Dictionary = {"uhf_omni": "Walkie-talkie", "s_band_patch": "Radio", "x_band_steer": "Science radio",
	"x_band_hga": "Super radio", "ka_band": "Turbo radio", "optical_terminal": "Laser"}


func _init() -> void:
	role_id = "ground"


func _make_sections(cadet: bool) -> Array:
	var antennas: Array = []
	for a in Data.db["parts"]["comm"]:
		var o: Dictionary = a.duplicate()
		if cadet and ANTENNA_NAMES.has(a["id"]):
			o["name"] = ANTENNA_NAMES[a["id"]]
		antennas.append(o)
	return [
		{"key": "rocket", "category": "rocket", "kind": "single", "title": "Pick your rocket", "rule": "Pick ONE", "options": Data.db["rockets"]},
		{"key": "comm", "category": "comm", "kind": "single", "title": "Pick your antenna", "rule": "Pick ONE", "options": antennas},
		{"key": "stations", "category": "stations", "kind": "multi", "title": "Pick ground stations", "rule": "Pick as many as you like", "options": Data.db["stations"]},
	]


func _disabled_reason(def: Dictionary, opt: Dictionary) -> String:
	match str(def["key"]):
		"rocket":
			return WhyDisabled.block_rocket(opt, _orbit())
		"stations":
			return WhyDisabled.block_station(opt, _orbit())
	return ""


func _warning_for(def: Dictionary, opt: Dictionary, selected: bool) -> String:
	var design: Dictionary = PanelBridge.design()
	match str(def["key"]):
		"comm":
			return WhyDisabled.warn_comm(opt, design)
		"stations":
			return WhyDisabled.warn_station(opt, design, selected)
	return ""
