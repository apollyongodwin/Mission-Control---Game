# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends RolePanel
## SYSTEMS owns: bus, panel, rtg_count, battery, obc, shield.
## LEAD (round 7, role balance): engines (prop) and pointing (adcs) moved to FLIGHT, so the Cadet autopilot is gone.
## Cadet shows 3 card groups (UX_GUIDE section 3).
## EASY TO EDIT: the packs below. Each "sets" line is what the bundle puts into the design.

const BODY_NAMES: Dictionary = {"bus_micro": "Tiny", "bus_mini": "Small", "bus_standard": "Medium", "bus_flagship": "Giant"}

const POWER_PACKS: Array = [
	{"id": "pack_small", "name": "Small power pack", "kid": "Little wings, little battery. Sips power.",
		"sets": {"panel": "si_2", "battery": "bat_300", "rtg_count": 0}},
	{"id": "pack_medium", "name": "Medium power pack", "kid": "Good wings and a good battery.",
		"sets": {"panel": "si_6", "battery": "bat_800", "rtg_count": 0}},
	{"id": "pack_large", "name": "Large power pack", "kid": "Big wings and a big battery.",
		"sets": {"panel": "si_12", "battery": "bat_2000", "rtg_count": 0}},
	{"id": "pack_mega", "name": "Mega power pack", "kid": "Huge wings and a huge battery. Heavy!",
		"sets": {"panel": "si_25", "battery": "bat_5000", "rtg_count": 0}},
]
const NUCLEAR_PACK: Dictionary = {"id": "pack_nuclear", "name": "Nuclear battery", "kid": "Space-rock heat makes power. Works far from the Sun.",
	"sets": {"panel": "no_panels", "battery": "bat_800", "rtg_count": 2}}

const BRAINS: Array = [
	{"id": "brain_basic", "name": "Basic brain", "kid": "Slow but trusted. No extra shield.",
		"sets": {"obc": "obc_basic", "shield": "shield_none"}},
	{"id": "brain_speedy", "name": "Speedy brain", "kid": "Fast and squeezes data small. Not tough.",
		"sets": {"obc": "obc_fast", "shield": "shield_none"}},
	{"id": "brain_tough", "name": "Tough brain", "kid": "Space-proof brain with a light shield.",
		"sets": {"obc": "obc_rad_hard", "shield": "shield_light"}},
	{"id": "brain_vault", "name": "Tough brain + vault", "kid": "Space-proof brain inside a heavy safe.",
		"sets": {"obc": "obc_rad_hard", "shield": "shield_vault"}},
]

var _ap_count: int = 0
var _ap_pending: bool = false


func _init() -> void:
	role_id = "systems"


func _make_sections(cadet: bool) -> Array:
	return _cadet_sections() if cadet else _engineer_sections()


# ---------------------------------------------------------------- Cadet: 3 groups
func _cadet_sections() -> Array:
	var bodies: Array = []
	for b in Data.db["parts"]["bus"]:
		var o: Dictionary = b.duplicate()
		o["name"] = BODY_NAMES.get(b["id"], b["name"])
		bodies.append(o)
	var packs: Array = []
	for p in POWER_PACKS:
		packs.append(_pack_option(p))
	if _scenario()["rtg_allowed"]:
		packs.append(_pack_option(NUCLEAR_PACK))
	var brains: Array = []
	for b in BRAINS:
		brains.append(_brain_option(b))
	return [
		{"key": "bus", "category": "bus", "kind": "single", "title": "Pick your body", "rule": "Pick ONE", "options": bodies},
		{"key": "power_pack", "category": "", "kind": "bundle", "title": "Pick your power pack", "rule": "Pick ONE", "options": packs},
		{"key": "brain", "category": "", "kind": "bundle", "title": "Pick your brain and shield", "rule": "Pick ONE", "options": brains},
	]


func _pack_option(p: Dictionary) -> Dictionary:
	var o: Dictionary = p.duplicate(true)
	var sets: Dictionary = p["sets"]
	var pnl: Dictionary = Data.part("panel", str(sets["panel"]))
	var bat: Dictionary = Data.part("battery", str(sets["battery"]))
	var n: int = int(sets["rtg_count"])
	var rtg: Dictionary = Data.db["rtg"]
	var watts: float = float(pnl["area_m2"]) * float(pnl["w_per_m2_1au"]) + n * float(rtg["w_bol"])
	var mass: float = float(pnl["mass"]) + float(bat["mass"]) + n * float(rtg["mass"])
	var cost: float = float(pnl["cost"]) + float(bat["cost"]) + n * float(rtg["cost"])
	o["blurb"] = o["kid"]
	o["stats"] = [CardStats.stat("Power", watts, CardStats.fmt(watts) + " W"),
		CardStats.stat("Weight", mass, CardStats.fmt(mass) + " kg"),
		CardStats.stat("Cost", cost, "C$" + CardStats.fmt(cost) + "M")]
	return o


func _brain_option(b: Dictionary) -> Dictionary:
	var o: Dictionary = b.duplicate(true)
	var sets: Dictionary = b["sets"]
	var obc: Dictionary = Data.part("obc", str(sets["obc"]))
	var sh: Dictionary = Data.part("shield", str(sets["shield"]))
	var tough: float = float(obc["rad_tol_krad"]) + float(sh["rad_bonus_krad"])
	var cost: float = float(obc["cost"]) + float(sh["cost"])
	o["blurb"] = o["kid"]
	o["stats"] = [CardStats.stat("Tough", tough, CardStats.fmt(tough) + " krad"),
		CardStats.stat("Memory", float(obc["storage_gb"]), CardStats.fmt(obc["storage_gb"]) + " GB"),
		CardStats.stat("Cost", cost, "C$" + CardStats.fmt(cost) + "M")]
	return o


# ---------------------------------------------------------------- Engineer: all eight choices
func _engineer_sections() -> Array:
	var out: Array = []
	var P: Dictionary = Data.db["parts"]
	for cat in ["bus", "panel", "rtg_count", "battery", "obc", "shield"]:
		if cat == "rtg_count":
			if _scenario()["rtg_allowed"]:
				out.append(_rtg_section())
			continue
		out.append({"key": cat, "category": cat, "kind": "single", "title": "Pick: " + str(SimEngine.CATEGORY_LABELS[cat]),
			"rule": "Pick ONE", "options": P[cat]})
	return out


func _rtg_section() -> Dictionary:
	var rtg: Dictionary = Data.db["rtg"]
	var options: Array = []
	for n in range(0, int(rtg["max_count"]) + 1):
		var o: Dictionary = {"id": str(n), "value": n, "blurb": str(rtg["blurb"]), "learn": str(rtg["learn"])}
		o["name"] = "No nuclear battery" if n == 0 else "%d nuclear unit%s" % [n, "" if n == 1 else "s"]
		o["stats"] = [CardStats.stat("Power", n * float(rtg["w_bol"]), CardStats.fmt(n * float(rtg["w_bol"])) + " W"),
			CardStats.stat("Weight", n * float(rtg["mass"]), CardStats.fmt(n * float(rtg["mass"])) + " kg"),
			CardStats.stat("Cost", n * float(rtg["cost"]), "C$" + CardStats.fmt(n * float(rtg["cost"])) + "M")]
		options.append(o)
	return {"key": "rtg_count", "category": "rtg_count", "kind": "single", "title": "Pick: Nuclear battery", "rule": "Pick ONE", "options": options}


func _disabled_reason(def: Dictionary, opt: Dictionary) -> String:
	if str(def.get("category", "")) == "prop":
		return WhyDisabled.block_prop(opt, _orbit())
	return ""


func _warning_for(def: Dictionary, opt: Dictionary, selected: bool) -> String:
	var design: Dictionary = PanelBridge.design()
	match str(def.get("category", "")):
		"bus":
			return "" if selected else WhyDisabled.warn_bus(opt, design)
		"adcs":
			return WhyDisabled.warn_adcs(opt, design)
		"panel":
			return WhyDisabled.warn_panel(opt, design)
	if opt.has("sets") and (opt["sets"] as Dictionary).get("panel") == "no_panels" and int((opt["sets"] as Dictionary).get("rtg_count", 0)) <= 0:
		return "No wings and no nuclear battery: no power!"
	return ""


# ---------------------------------------------------------------- Autopilot (Cadet only): adcs and prop
func _on_user_pick() -> void:
	_ap_count = 0


func _after_refresh() -> void:
	_set_chips([])   # round 7: no autopilot any more (FLIGHT picks engines and pointing)


func _run_autopilot() -> void:
	_ap_pending = false
	var design: Dictionary = PanelBridge.design()
	var res: Dictionary = SimEngine.autofill(Data.db, design, ["adcs", "prop"])
	var wanted: Dictionary = res["design"]
	var changed: bool = false
	if _ap_count < 4:
		for key in ["adcs", "prop"]:
			if str(wanted[key]) != str(design.get(key, "")):
				PanelBridge.submit(key, wanted[key])
				changed = true
	if changed:
		_ap_count += 1
		return   # the submit triggers another refresh, which shows the chips
	_ap_count = 0
	_set_chips(res["notes"])
