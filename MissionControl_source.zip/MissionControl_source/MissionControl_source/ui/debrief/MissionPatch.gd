# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name MissionPatch
extends Control
## Dev D, Part 2. Procedural mission patch drawn with _draw().
##   shape + colours = scenario; central motif = orbit path around a planet;
##   icons along the bottom = instruments flown; team name arched along the top.
## Use: var p := MissionPatch.new(); p.setup({scenario, orbit, instruments, team}); add_child(p)
## p.play_spin_in(delay) = spin-in animation. p.save_png() (await it) writes user://patches/*.png

const STYLES := {
	"bagyo_watch": {"shape": "circle", "bg": Color("0E3B5C"), "ring": Color("1F7A8C"),
		"accent": Color("FFC857"), "body": Color("2E86DE"), "detail": Color("7CE08A")},
	"moon_relay": {"shape": "hexagon", "bg": Color("1B2433"), "ring": Color("8D99AE"),
		"accent": Color("EDF2F4"), "body": Color("B8B8B8"), "detail": Color("7A7A7A")},
	"deep_probe": {"shape": "shield", "bg": Color("3A1C0F"), "ring": Color("C8742B"),
		"accent": Color("FFD7A0"), "body": Color("D9A066"), "detail": Color("A0522D")},
}
# orbit id -> [semi-major a, semi-minor b, tilt degrees, centre shift, fraction of loop drawn]
# (units are fractions of the patch radius; a + shift must stay below 0.55)
const ORBIT_STYLE := {
	"leo_sso_700": [0.40, 0.17, -80.0, 0.0, 1.0],
	"leo_dawndusk_700": [0.38, 0.12, -70.0, 0.0, 1.0],
	"leo_tropical_600": [0.44, 0.13, -20.0, 0.0, 1.0],
	"leo_low_400": [0.28, 0.26, 0.0, 0.0, 1.0],
	"geo_35786": [0.50, 0.50, 0.0, 0.0, 1.0],
	"lunar_polar_100": [0.32, 0.22, -90.0, 0.0, 1.0],
	"lunar_elfo_south": [0.40, 0.22, -90.0, 0.15, 1.0],
	"lunar_nrho": [0.42, 0.12, -90.0, 0.12, 1.0],
	"jup_flyby_direct": [0.50, 0.26, -20.0, 0.0, 0.5],
	"jup_flyby_assist": [0.50, 0.30, 20.0, 0.0, 0.65],
	"jup_orbiter_polar": [0.36, 0.14, -85.0, 0.0, 1.0],
}
const SAVE_DIR := "user://patches"

var scenario_id := "bagyo_watch"
var orbit_id := ""
var instruments: Array = []
var team_name := "Pawstronauts"
var _k := 1.0   # line-width scale so big PNGs do not look thin


func setup(info: Dictionary) -> void:
	scenario_id = str(info.get("scenario", "bagyo_watch"))
	orbit_id = str(info.get("orbit", ""))
	var ins = info.get("instruments", [])
	instruments = ins if typeof(ins) == TYPE_ARRAY else []
	team_name = str(info.get("team", "Pawstronauts"))
	queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(360, 360)
	pivot_offset = size / 2.0
	resized.connect(func(): pivot_offset = size / 2.0)


func play_spin_in(delay: float = 0.0) -> void:
	scale = Vector2.ZERO
	rotation = -TAU * 2.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(self, "scale", Vector2.ONE, 1.3).set_delay(delay).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(self, "rotation", 0.0, 1.3).set_delay(delay).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func save_png() -> String:
	var vp := SubViewport.new()
	vp.size = Vector2i(1024, 1024)
	vp.transparent_bg = true
	vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(vp)
	var copy := MissionPatch.new()
	copy.scenario_id = scenario_id
	copy.orbit_id = orbit_id
	copy.instruments = instruments.duplicate()
	copy.team_name = team_name
	copy.custom_minimum_size = Vector2(1024, 1024)
	vp.add_child(copy)
	copy.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	copy.size = Vector2(1024, 1024)   # make sure the picture is drawn at full size
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	vp.queue_free()
	if img == null or img.is_empty():
		return ""
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)
	var path := "%s/patch_%d_%d.png" % [SAVE_DIR, int(Time.get_unix_time_from_system()), Time.get_ticks_msec() % 1000]
	if img.save_png(path) != OK:
		return ""
	return path


# ---------------------------------------------------------------- drawing
func _draw() -> void:
	var st: Dictionary = STYLES.get(scenario_id, STYLES["bagyo_watch"])
	var s := minf(size.x, size.y)
	_k = maxf(s / 360.0, 1.0)
	var c := size / 2.0
	var r := s * 0.47
	var accent: Color = st["accent"]

	# border and face
	var outer := _shape(str(st["shape"]), c, r)
	var inner := _shape(str(st["shape"]), c, r * 0.93)
	draw_colored_polygon(outer, st["ring"])
	draw_colored_polygon(inner, st["bg"])
	draw_polyline(_closed(outer), accent, 3.0 * _k, true)
	draw_polyline(_closed(inner), accent, 1.5 * _k, true)

	# central motif: planet + orbit path + satellite
	var pr := r * 0.17
	draw_circle(c, pr, st["body"])
	_planet_detail(c, pr, st)
	var o: Array = ORBIT_STYLE.get(orbit_id, [0.40, 0.20, -30.0, 0.0, 1.0])
	var tilt := deg_to_rad(float(o[2]))
	var pts := PackedVector2Array()
	var steps := 64
	for i in range(steps + 1):
		var t := TAU * float(o[4]) * float(i) / float(steps)
		var p := Vector2(float(o[0]) * cos(t) + float(o[3]), float(o[1]) * sin(t)).rotated(tilt)
		pts.append(c + p * r)
	draw_polyline(pts, accent, 4.0 * _k, true)
	var sat := pts[int(steps * 0.2)]
	draw_circle(sat, r * 0.055, Color.WHITE)
	draw_arc(sat, r * 0.055, 0.0, TAU, 16, accent, 2.0 * _k)

	# team name arched along the top
	var text := team_name.strip_edges().to_upper().left(18)
	if text != "":
		_arc_text(ThemeDB.fallback_font, text, c, r * 0.66, maxi(20, int(r * 0.125)), accent)

	# instrument icons along the bottom
	var n := mini(instruments.size(), 9)
	if n > 0:
		var span := 0.30 * float(n - 1)
		for i in n:
			var ang := PI / 2.0 - span / 2.0 + 0.30 * float(i)
			var p := c + Vector2(cos(ang), sin(ang)) * r * 0.70
			_icon(icon_kind(str(instruments[i])), p, r * 0.065, accent)


func _shape(kind: String, c: Vector2, rad: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	match kind:
		"hexagon":
			for i in 6:
				var a := TAU * float(i) / 6.0
				pts.append(c + Vector2(cos(a), sin(a)) * rad)
		"shield":
			pts.append(c + Vector2(-0.88, -0.92) * rad)
			pts.append(c + Vector2(0.88, -0.92) * rad)
			pts.append(c + Vector2(0.88, 0.05) * rad)
			for i in range(1, 13):
				var t := float(i) / 12.0
				pts.append(c + _bezier(Vector2(0.88, 0.05), Vector2(0.8, 0.7), Vector2(0.0, 1.0), t) * rad)
			for i in range(1, 13):
				var t := float(i) / 12.0
				pts.append(c + _bezier(Vector2(0.0, 1.0), Vector2(-0.8, 0.7), Vector2(-0.88, 0.05), t) * rad)
		_:
			for i in 72:
				var a := TAU * float(i) / 72.0
				pts.append(c + Vector2(cos(a), sin(a)) * rad)
	return pts


func _bezier(p0: Vector2, p1: Vector2, p2: Vector2, t: float) -> Vector2:
	return p0 * (1.0 - t) * (1.0 - t) + p1 * 2.0 * (1.0 - t) * t + p2 * t * t


func _closed(pts: PackedVector2Array) -> PackedVector2Array:
	var p := PackedVector2Array(pts)
	p.append(pts[0])
	return p


func _planet_detail(c: Vector2, pr: float, st: Dictionary) -> void:
	var d: Color = st["detail"]
	match scenario_id:
		"moon_relay":
			draw_circle(c + Vector2(-pr * 0.35, -pr * 0.3), pr * 0.18, d)
			draw_circle(c + Vector2(pr * 0.3, pr * 0.1), pr * 0.25, d)
			draw_circle(c + Vector2(-pr * 0.1, pr * 0.5), pr * 0.12, d)
		"deep_probe":
			for y in [-0.45, 0.0, 0.4]:
				var yy: float = y * pr
				var half := sqrt(maxf(pr * pr - yy * yy, 0.0))
				draw_line(c + Vector2(-half, yy), c + Vector2(half, yy), d, 4.0 * _k)
		_:
			draw_circle(c + Vector2(-pr * 0.3, -pr * 0.2), pr * 0.35, d)
			draw_circle(c + Vector2(pr * 0.35, pr * 0.3), pr * 0.2, d)


func _arc_text(font: Font, text: String, c: Vector2, rad: float, fs: int, col: Color) -> void:
	var widths: Array[float] = []
	var total := 0.0
	for ch in text:
		var cw := font.get_string_size(ch, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x + 2.0
		widths.append(cw)
		total += cw
	var a := -PI / 2.0 - (total / rad) / 2.0
	for i in text.length():
		var w: float = widths[i]
		var mid := a + (w / rad) / 2.0
		var pos := c + Vector2(cos(mid), sin(mid)) * rad
		draw_set_transform(pos, mid + PI / 2.0, Vector2.ONE)
		draw_string(font, Vector2(-w / 2.0, 0.0), text[i], HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)
		a += w / rad
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


static func icon_kind(id: String) -> String:
	if id.contains("radar") or id == "sar_c" or id.contains("sounder") or id.contains("scatter"):
		return "radar"
	if id.contains("imager") or id.contains("camera") or id.contains("mapper"):
		return "camera"
	if id.contains("thermal") or id.contains("radiometer"):
		return "thermo"
	if id.contains("spec") or id.begins_with("uv_"):
		return "prism"
	if id.contains("relay") or id.contains("beacon") or id.contains("gravity") or id.contains("altimeter"):
		return "antenna"
	return "dot"


func _icon(kind: String, p: Vector2, s: float, col: Color) -> void:
	var w := 2.0 * _k
	match kind:
		"radar":
			var base := p + Vector2(0, s * 0.8)
			draw_circle(base, s * 0.2, col)
			for j in 3:
				draw_arc(base, s * (0.7 + 0.5 * float(j)), -PI * 0.85, -PI * 0.15, 10, col, w)
		"camera":
			draw_rect(Rect2(p - Vector2(s, s * 0.7), Vector2(s * 2.0, s * 1.4)), col, false, w)
			draw_circle(p, s * 0.4, col)
		"thermo":
			draw_line(p + Vector2(0, -s), p + Vector2(0, s * 0.4), col, 2.0 * w)
			draw_circle(p + Vector2(0, s * 0.7), s * 0.5, col)
		"prism":
			var tri := PackedVector2Array([p + Vector2(0, -s), p + Vector2(s, s * 0.8), p + Vector2(-s, s * 0.8)])
			draw_polyline(_closed(tri), col, w)
		"antenna":
			draw_arc(p + Vector2(0, -s * 0.2), s, 0.2, PI - 0.2, 10, col, 1.5 * w)
			draw_line(p + Vector2(0, -s * 0.2), p + Vector2(0, s), col, w)
		_:
			draw_colored_polygon(PackedVector2Array([p + Vector2(0, -s), p + Vector2(s, 0), p + Vector2(0, s), p + Vector2(-s, 0)]), col)
