# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## Debrief (Dev D). Call show_report(report, eval_result, context) with Dev A's final_report() Dictionary.
## Run this scene alone (F6) and it shows a hard-coded SAMPLE_REPORT.
## Cadet shows bars only; press N (or set show_numbers = true) for the numbers (UX rule 3).
##
## Keys read from the report (Dev A: please keep or tell me the real names):
##   breakdown {science, lifetime, budget, margins, crisis, teamwork}, total, grade,
##   medals [String], why [String], mission_lost (bool, optional)
## Keys read from eval_result: lifetime.limiting, lifetime.days  (from SimEngine.evaluate)

signal again_pressed   # the big "Again!" button: same crew, design remembered
signal menu_pressed

const BG := Color("0B1530")
const AMBER := Color("FFC857")
const TEXT := Color("E8EEF9")
const GOOD := Color("7CE08A")
const BAD := Color("FF7A6B")
const BAR_ORDER := ["science", "lifetime", "budget", "margins", "crisis", "teamwork"]
const BAR_NAMES := {
	"science": "Science", "lifetime": "Life in space", "budget": "Money saved",
	"margins": "Safety room", "crisis": "Crisis skills", "teamwork": "Teamwork",
}
const GRADE_COLORS := {
	"S": Color("FFD54A"), "A": Color("7CE08A"), "B": Color("4FB3FF"), "C": Color("FFC857"), "D": Color("FF7A6B"),
}
# kid-level text for SimEngine's lifetime "limiting" values: drag, radiation, solar_fade, battery
const LIMIT_TEXT := {
	"drag": "Thin air up high slowly pulled your ship down. A higher orbit or some fuel would help.",
	"radiation": "Space radiation wore out the computer. A tougher brain or shield would help.",
	"solar_fade": "The solar panels faded over time. Bigger panels would help.",
	"battery": "The battery wore out first. A bigger battery would help.",
}
const SAMPLE_REPORT := {
	"breakdown": {"science": 262.0, "lifetime": 120.0, "budget": 96.0, "margins": 78.0, "crisis": 110.0, "teamwork": 37.5},
	"total": 703.5, "grade": "A", "mission_lost": false,
	"medals": ["Great Minds", "Local Hero"],
	"why": [
		"Your radar saw through the storm clouds, so the typhoon was tracked all week.",
		"A debris pass came close. You had thruster fuel, so the ship dodged it.",
		"A solar flare hit. Your tough computer kept going with only a small loss.",
	],
}
const SAMPLE_EVAL := {"lifetime": {"days": 1450, "limiting": "radiation"}}

var show_numbers := false
var read_only := false          # PART 2: true = viewing an old mission (no saving, no spin, no Again button)
var can_again := true          # MERGE (Lead): false on crew laptops; only Mission Control starts "Again!"
var save_on_show := true        # PART 2: false for sample/test data
var _context: Dictionary = {}   # PART 2: optional {design, team_name, difficulty}
var _saved_path := ""
var _patch_played := false
var _report: Dictionary = {}
var _eval: Dictionary = {}
var _root: VBoxContainer


## round 6: every medal, with how to win it (pictures in assets/images/medals, made by tools/make_medals.py)
const MEDAL_INFO := {
	"frugal_flyer": ["Frugal Flyer", "Spend 3/4 of the money or less"],
	"margin_master": ["Margin Master", "Keep every safety margin full"],
	"great_minds": ["Great Minds", "Pick 2 instruments that work great together"],
	"perfect_pass": ["Perfect Pass", "Beat every crisis with no damage"],
	"silent_running": ["Silent Running", "Perfect Pass on Flight Director level"],
	"local_hero": ["Local Hero", "Bagyo Watch: tropical orbit + rain gauges"],
	"helping_paws": ["Helping Paws", "Hand 2 tokens to teammates"],
}

func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 32)
	add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	margin.add_child(scroll)
	_root = VBoxContainer.new()
	_root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_root.add_theme_constant_override("separation", 18)
	scroll.add_child(_root)
	# standalone test: if this scene was run by itself, show the sample
	if _report.is_empty() and get_tree().current_scene == self:
		save_on_show = false   # PART 2: do not save the hard-coded sample
		show_report(SAMPLE_REPORT.duplicate(true), SAMPLE_EVAL.duplicate(true))


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_N:
		show_numbers = not show_numbers
		_rebuild()


func show_report(report: Dictionary, eval_result: Dictionary = {}, context: Dictionary = {}) -> void:
	_report = report
	_eval = report.get("eval", eval_result)
	_context = context
	_patch_played = false
	_saved_path = ""
	if save_on_show and not read_only:   # PART 2: save once per mission
		_saved_path = MissionStore.save_report(_report, _eval, _full_context())
	if _root != null:
		_rebuild()


func _rebuild() -> void:
	## MERGE (Lead, UI pass): Dev D's debrief in the house style, plus the UX guide's payoff pieces:
	## grade stamp, crew reactions, NASA's four mission segments, "who used your data", real-world twin, confetti.
	for c in _root.get_children():
		c.queue_free()
	if _report.is_empty():
		return
	theme = GameTheme.build(AMBER)
	var lost: bool = _report.get("mission_lost", false)
	var grade := str(_report.get("grade", "D"))
	var maxes: Dictionary = Data.db["meta"]["constants"]["score_max"]
	var total_max := 0.0
	for k in maxes:
		total_max += float(maxes[k])
	var total := float(_report.get("total", _sum_breakdown()))
	var good_run: bool = (not lost) and grade in ["S", "A", "B"]

	# 1. hero: grade stamp, headline, score, the crew reacting
	var hero := GameTheme.panel(GameTheme.PANEL, GRADE_COLORS.get(grade, BAD) if not lost else BAD, 4, 24, 20)
	_root.add_child(hero)
	var hrow := HBoxContainer.new()
	hrow.add_theme_constant_override("separation", 24)
	hero.add_child(hrow)
	var stamp := DebriefExtras.GradeStamp.new("LOST" if lost else grade, BAD if lost else GRADE_COLORS.get(grade, TEXT), 150.0)
	hrow.add_child(stamp)
	stamp.thump.call_deferred()
	get_tree().create_timer(0.45).timeout.connect(func() -> void: Audio.play_sfx("stamp"))   # MERGE (juice)
	if lost or grade == "D":
		get_tree().create_timer(0.9).timeout.connect(func() -> void: Audio.play_sfx("sad_trombone"))
	var hv := VBoxContainer.new()
	hv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hv.alignment = BoxContainer.ALIGNMENT_CENTER
	hrow.add_child(hv)
	var no_lives: bool = bool(_report.get("out_of_lives", false))   # round 8
	if no_lives:
		hv.add_child(_label("OUT OF LIVES!", 56, BAD))
		hv.add_child(_label("Too many crisis mistakes, so Mission Control called the mission off. Read the gauges, trust the Commander's handbook, and try again!", 22, TEXT))
	elif lost:
		hv.add_child(_label("KABOOM!", 60, BAD))
		hv.add_child(_label("Rapid Unscheduled Disassembly. (Rocket engineers really call it that.) Real rockets fail too: let's find out why, then fly again!", 22, TEXT))
		if not read_only:   # MERGE (juice): the boom you came for
			get_tree().create_timer(0.15).timeout.connect(func() -> void:
				if is_inside_tree():
					Audio.play_sfx("explosion")
					Fx.explosion(self, size * Vector2(0.5, 0.25), 1.6)
					Fx.shake(_root, 22.0, 0.8))
	else:
		var headline: String = {"S": "Legendary mission!", "A": "Mission complete!", "B": "Nice mission!",
			"C": "Mission complete, with bumps.", "D": "We made it... just."}.get(grade, "Mission complete!")
		hv.add_child(_label(headline, 52, AMBER))
		hv.add_child(_label("Score: %d out of %d" % [int(round(total)), int(round(total_max))], 30, TEXT))
	var team: String = str(_pick("team_name", "Pawstronauts"))
	var sc_name: String = str(Data.scenario(str(_patch_info()["scenario"])).get("name", ""))
	hv.add_child(_label("Team %s  -  %s" % [team, sc_name], 20, GameTheme.MUTED))
	var crew := HBoxContainer.new()
	crew.add_theme_constant_override("separation", 6)
	crew.alignment = BoxContainer.ALIGNMENT_END
	for r in ["flight", "systems", "payload", "ground"]:
		var cat := CrewArt.make(r, 96, "kaboom" if lost else ("happy" if good_run else "worried"))
		cat.bob = good_run
		crew.add_child(cat)
	hrow.add_child(crew)

	# 2. NASA's four mission segments, each lit by how that part went (UX guide section 5)
	var bd: Dictionary = _report.get("breakdown", {})
	var segs := HBoxContainer.new()
	segs.add_theme_constant_override("separation", 10)
	_root.add_child(segs)
	var seg_vals := {
		"LAUNCH": 0.0 if lost else 1.0,
		"SPACE": 0.0 if lost else (float(bd.get("lifetime", 0.0)) / float(maxes["lifetime"]) + float(bd.get("crisis", 0.0)) / float(maxes["crisis"])) / 2.0,
		"GROUND": 0.0 if lost else (float(bd.get("budget", 0.0)) / float(maxes["budget"]) + float(bd.get("margins", 0.0)) / float(maxes["margins"])) / 2.0,
		"USER": 0.0 if lost else float(bd.get("science", 0.0)) / float(maxes["science"]),
	}
	for seg in seg_vals:
		var f: float = float(seg_vals[seg])
		var col: Color = GOOD if f >= 0.7 else (AMBER if f >= 0.4 else BAD)
		var chip := GameTheme.panel(Color(col, 0.15), col, 2, 16, 10)
		chip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cl := _label(("OK  " if f >= 0.7 else ("!  " if f >= 0.4 else "X  ")) + seg, 22, col)
		cl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		chip.add_child(cl)
		chip.tooltip_text = "NASA splits every mission into Launch, Space, Ground and User segments."
		segs.add_child(chip)

	# 3. two columns: score bars | who used your data + real-world twin + what limited you
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 16)
	_root.add_child(cols)
	var left := GameTheme.panel()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_child(left)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 10)
	left.add_child(lv)
	lv.add_child(_label("HOW YOU DID", 22, AMBER))
	for key in BAR_ORDER:
		lv.add_child(_bar_row(key, float(bd.get(key, 0.0)), float(maxes.get(key, 100))))
	lv.add_child(_label("Press N to show the numbers.", 16, GameTheme.MUTED))

	var right := GameTheme.panel()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_child(right)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 10)
	right.add_child(rv)
	var objs: Array = _report.get("objectives", [])
	if not lost and not objs.is_empty():
		rv.add_child(_label("WHO USED YOUR DATA", 22, AMBER))
		for o in objs:
			var u: Dictionary = DebriefExtras.USERS.get(str(o["tag"]), {})
			if u.is_empty():
				continue
			var frac: float = float(o["achieved"]) / maxf(0.001, float(o["max"]))
			var mood: String = DebriefExtras.mood_for(frac)
			var urow := HBoxContainer.new()
			urow.add_theme_constant_override("separation", 12)
			urow.add_child(DebriefExtras.UserFace.new(mood, 56.0))
			var ut := VBoxContainer.new()
			ut.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			ut.add_theme_constant_override("separation", 0)
			ut.add_child(_label(str(u["who"]), 18, GameTheme.MUTED))
			ut.add_child(_label("\"%s\"" % str(u[mood]), 21, TEXT))
			urow.add_child(ut)
			rv.add_child(urow)
	if lost:   # MERGE: the right column tells the anomaly story instead of "who used your data"
		rv.add_child(_label("ANOMALY REPORT", 22, AMBER))
		for line in _report.get("why", []):
			rv.add_child(_label("-  " + str(line), 20, TEXT))
		rv.add_child(_label("TRY THIS", 20, AMBER))
		if no_lives:
			rv.add_child(_label("Every crew member reads both gauges out loud. The Commander finds the crisis in the handbook and names ONLY those cards. Build spare margins: more tokens means you can always play the right card.", 20, TEXT))
		else:
			rv.add_child(_label("Pick a rocket with higher reliability, or keep spare budget for a second try. Cadet and Demo Mode never fail.", 20, TEXT))
	var twin: String = _real_twin()
	if twin != "" and not lost:
		rv.add_child(_label("YOUR MISSION IS MOST LIKE", 20, AMBER))
		rv.add_child(_label(twin, 20, TEXT))
	var leaks: Array = _report.get("science_leaks", [])   # round 8: "why is our science so low?"
	if not lost and not leaks.is_empty():
		var sf: float = float(_report.get("science_final", 0.0))
		rv.add_child(_label("WHY SCIENCE WAS %d / 100" % int(round(sf)), 20, AMBER))
		for l in leaks.slice(0, 3):
			rv.add_child(_label("-  " + str(l), 18, TEXT))
	var lim := str(_eval.get("lifetime", {}).get("limiting", ""))
	if LIMIT_TEXT.has(lim) and not lost:
		rv.add_child(_label("WHAT LIMITED YOUR MISSION", 20, AMBER))
		var t: String = LIMIT_TEXT[lim]
		if show_numbers and _eval.get("lifetime", {}).has("days"):
			t += "  (lasted %d days)" % int(_eval["lifetime"]["days"])
		rv.add_child(_label(t, 20, TEXT))

	# 4. medals + mission patch
	var mrow := HBoxContainer.new()
	mrow.add_theme_constant_override("separation", 16)
	_root.add_child(mrow)
	var mp := GameTheme.panel()
	mp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mrow.add_child(mp)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 10)
	mp.add_child(mv)
	var medals: Array = _report.get("medals", [])
	var won_ids: Array = _report.get("medal_ids", [])
	mv.add_child(_label("MEDALS  -  %d of %d won" % [won_ids.size(), MEDAL_INFO.size()], 22, AMBER))
	# round 6: every medal has a picture. Won ones pop in one by one; the rest wait in grey with how to win them.
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	var i := 0
	var order: Array = won_ids.duplicate()
	for mid in MEDAL_INFO:
		if not order.has(mid):
			order.append(mid)
	for mid in order:
		var won: bool = won_ids.has(mid)
		var info: Array = MEDAL_INFO.get(mid, [str(mid), ""])
		var cell := VBoxContainer.new()
		cell.custom_minimum_size = Vector2(150, 0)
		cell.add_theme_constant_override("separation", 2)
		var tex := TextureRect.new()
		var path: String = "res://assets/images/medals/%s%s.png" % [mid, "" if won else "_locked"]
		if ResourceLoader.exists(path):
			tex.texture = load(path)
		tex.custom_minimum_size = Vector2(96, 96) if won else Vector2(70, 70)
		tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tex.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		cell.add_child(tex)
		var nm := _label(str(info[0]), 18 if won else 15, AMBER if won else Color(TEXT, 0.55))
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cell.add_child(nm)
		var how := _label(str(info[1]) if not won else "WON!", 13, Color(TEXT, 0.5) if not won else GOOD)
		how.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cell.add_child(how)
		grid.add_child(cell)
		if won:
			cell.modulate.a = 0.0
			cell.scale = Vector2(0.6, 0.6)
			cell.pivot_offset = Vector2(75, 50)
			var tw := create_tween().set_parallel(true)
			tw.tween_property(cell, "modulate:a", 1.0, 0.3).set_delay(0.8 + 0.4 * i)
			tw.tween_property(cell, "scale", Vector2.ONE, 0.45).set_delay(0.8 + 0.4 * i).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			get_tree().create_timer(0.8 + 0.4 * i).timeout.connect(func() -> void: Audio.play_sfx("medal"))
			i += 1
	mv.add_child(grid)
	if not lost:
		var pp := GameTheme.panel()
		mrow.add_child(pp)
		var pv := VBoxContainer.new()
		pv.add_theme_constant_override("separation", 8)
		pp.add_child(pv)
		pv.add_child(_label("YOUR MISSION PATCH", 22, AMBER))
		var cc := CenterContainer.new()
		var patch := MissionPatch.new()
		patch.setup(_patch_info())
		cc.add_child(patch)
		pv.add_child(cc)
		if not _patch_played and not read_only:
			_patch_played = true
			patch.play_spin_in(1.2 + 0.35 * medals.size())   # the patch spins in last
		var save_btn := Button.new()
		save_btn.text = "Save patch as a picture"
		save_btn.custom_minimum_size = Vector2(0, 56)
		save_btn.add_theme_font_size_override("font_size", 20)
		pv.add_child(save_btn)
		var save_note := _label("", 18, GOOD)
		pv.add_child(save_note)
		save_btn.pressed.connect(func(): _on_save_patch(patch, save_note))

	# 5. what happened and why
	var why: Array = _report.get("why", [])
	if not why.is_empty() and not lost:
		var wp := GameTheme.panel()
		_root.add_child(wp)
		var wv := VBoxContainer.new()
		wv.add_theme_constant_override("separation", 8)
		wp.add_child(wv)
		wv.add_child(_label("WHAT HAPPENED, AND WHY", 22, AMBER))
		for line in why:
			wv.add_child(_label("-  " + str(line), 20, TEXT))

	if _saved_path != "":
		_root.add_child(_label("Saved in Past Missions.", 18, GOOD))

	# 6. buttons: Again! is the biggest (hidden when just viewing an old mission)
	if not read_only and not can_again:
		_root.add_child(_label("Mission Control can press Again! for another try with the same crew.", 22, GOOD))
	if not read_only and can_again:
		var again := Button.new()
		again.text = "Again!"
		again.custom_minimum_size = Vector2(0, 110)
		again.add_theme_font_size_override("font_size", 44)
		GameTheme.primary(again)
		again.pressed.connect(func(): again_pressed.emit())
		_root.add_child(again)
	var menu := Button.new()
	menu.text = "Back to list" if read_only else "Main menu"
	menu.custom_minimum_size = Vector2(0, 64)
	menu.add_theme_font_size_override("font_size", 24)
	menu.pressed.connect(func(): menu_pressed.emit())
	_root.add_child(menu)

	if not lost and grade in ["S", "A"] and not read_only:
		add_child(DebriefExtras.Confetti.new())   # UX guide: confetti on S and A grades
		Audio.play_sfx("confetti")
		get_tree().create_timer(0.5).timeout.connect(func() -> void: Audio.play_sfx("success"))


## UX guide section 5: "Your mission is most like ..." from the orbit's and the best instrument's real_analog.
func _real_twin() -> String:
	var d = _pick("design", {})
	if typeof(d) != TYPE_DICTIONARY:
		return ""
	var bits: Array = []
	var orb: Dictionary = Data.orbit(str(d.get("orbit", "")))
	if str(orb.get("real_analog", "")) != "":
		var oa: String = str(orb["real_analog"])
		bits.append(oa if oa.to_lower().contains("orbit") else oa + " orbit")
	var best := ""
	var best_v := 0.0
	for iid in d.get("instruments", []):
		var ins: Dictionary = Data.instrument(str(iid))
		var v := 0.0
		for t in ins.get("values", {}):
			v += float(ins["values"][t])
		if str(ins.get("real_analog", "")) != "" and v > best_v:
			best_v = v
			best = str(ins["real_analog"]) + " (" + str(ins["name"]) + ")"
	if best != "":
		bits.append(best)
	if bits.is_empty():
		return ""
	return "Inspired by: " + " + ".join(bits) + ". Real missions made similar trade-offs."


func _bar_row(key: String, val: float, mx: float) -> Control:
	var ratio := val / mx if mx > 0.0 else 0.0
	# shape word as well as the bar, never colour alone
	var mark := "OK" if ratio >= 0.7 else ("!" if ratio >= 0.4 else "X")
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var name_l := _label(str(BAR_NAMES.get(key, key)), 20, TEXT)
	name_l.custom_minimum_size = Vector2(150, 0)
	row.add_child(name_l)
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = mx
	bar.value = 0.0
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 30)
	var col: Color = GOOD if ratio >= 0.7 else (AMBER if ratio >= 0.4 else BAD)   # MERGE (UI pass)
	bar.add_theme_stylebox_override("fill", GameTheme.box(col, col, 0, 10, 2))
	bar.add_theme_stylebox_override("background", GameTheme.box(GameTheme.PANEL_HI, GameTheme.EDGE, 1, 10, 2))
	create_tween().tween_property(bar, "value", val, 0.9).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT).set_delay(0.3)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(bar)
	var mark_l := _label(mark, 24, GOOD if ratio >= 0.7 else (AMBER if ratio >= 0.4 else BAD))
	mark_l.custom_minimum_size = Vector2(48, 0)
	row.add_child(mark_l)
	if show_numbers:
		var n := _label("%d / %d" % [int(round(val)), int(round(mx))], 22, TEXT)
		n.custom_minimum_size = Vector2(130, 0)
		row.add_child(n)
	return row


func _sum_breakdown() -> float:
	var s := 0.0
	for v in _report.get("breakdown", {}).values():
		s += float(v)
	return s


func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


# ------------------------------------------------------------------ PART 2 helpers
# GUESS: where the design / team name / difficulty live. Checked in this order:
# the context passed to show_report(), then report keys, then MissionState properties.
# If the Lead names them differently, fix ONLY this function.
func _pick(key: String, fallback: Variant) -> Variant:
	if _context.has(key):
		return _context[key]
	if _report.has(key):
		return _report[key]
	var ms := get_node_or_null("/root/MissionState")
	if ms != null:
		var v = ms.get(key)
		if v != null:
			return v
	return fallback


func _full_context() -> Dictionary:
	var design = _pick("design", {})
	if typeof(design) != TYPE_DICTIONARY:
		design = {}
	return {"design": design, "team_name": str(_pick("team_name", "Pawstronauts")),
		"difficulty": str(_pick("difficulty", ""))}


func _patch_info() -> Dictionary:
	var d = _pick("design", {})
	if typeof(d) != TYPE_DICTIONARY:
		d = {}
	return {"scenario": str(d.get("scenario", "bagyo_watch")), "orbit": str(d.get("orbit", "")),
		"instruments": d.get("instruments", []), "team": str(_pick("team_name", "Pawstronauts"))}


func _on_save_patch(patch: MissionPatch, note: Label) -> void:
	note.text = "Saving..."
	var path: String = await patch.save_png()
	if not is_instance_valid(note):
		return
	if path == "":
		note.text = "Oops! Could not save the picture."
	else:
		note.text = "Saved! Find it here: " + ProjectSettings.globalize_path(path)
