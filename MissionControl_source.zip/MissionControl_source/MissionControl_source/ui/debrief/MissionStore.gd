# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name MissionStore
extends RefCounted
## Dev D, Part 2. Saves each mission as JSON in user://missions/ and lists them.

const DIR := "user://missions"


static func save_report(report: Dictionary, eval_result: Dictionary, ctx: Dictionary) -> String:
	DirAccess.make_dir_recursive_absolute(DIR)
	var design = ctx.get("design", {})
	if typeof(design) != TYPE_DICTIONARY:
		design = {}
	var rep: Dictionary = report.duplicate(true)
	rep.erase("eval")   # keep the file small; only the lifetime bit is stored below
	var life = eval_result.get("lifetime", {})
	var now := Time.get_unix_time_from_system()
	var rec := {
		"version": 1,
		"saved_unix": int(now),
		"saved_text": Time.get_datetime_string_from_system(false, true),
		"team_name": str(ctx.get("team_name", "Pawstronauts")),
		"scenario": str(design.get("scenario", "")),
		"difficulty": str(ctx.get("difficulty", "")),
		"grade": str(report.get("grade", "")),
		"total": float(report.get("total", 0.0)),
		"mission_lost": bool(report.get("mission_lost", false)),
		"design": design,
		"report": rep,
		"eval": {"lifetime": life if typeof(life) == TYPE_DICTIONARY else {}},
	}
	var path := "%s/mission_%d_%d.json" % [DIR, int(now), Time.get_ticks_msec() % 1000]
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		push_warning("MissionStore: could not write " + path)
		return ""
	f.store_string(JSON.stringify(rec, "\t"))
	f.close()
	return path


static func list_missions() -> Array:
	var out: Array = []
	if not DirAccess.dir_exists_absolute(DIR):
		return out   # no missions saved yet, nothing to list
	for file in DirAccess.get_files_at(DIR):
		if not file.ends_with(".json"):
			continue
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(DIR + "/" + file))
		if typeof(parsed) == TYPE_DICTIONARY:
			parsed["path"] = DIR + "/" + file
			out.append(parsed)
	out.sort_custom(func(a, b): return int(a.get("saved_unix", 0)) > int(b.get("saved_unix", 0)))
	return out
