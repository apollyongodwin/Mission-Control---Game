# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name DebriefExtras
extends RefCounted
## LEAD (UI pass) for Dev D's debrief: the payoff pieces from UX_GUIDE sections 5, 6 and 10.
##   GradeStamp   a big rubber-stamp grade that thumps in
##   UserFace     a happy / so-so / worried face for "who used your data"
##   Confetti     falling paper bits for S and A grades
##   USERS        the three little users per scenario (qualitative lines only: no invented statistics)

const USERS := {
	"typhoon_track": {"who": "Fisherfolk", "happy": "We saw the storm coming and stayed ashore.",
		"soso": "We got some warning, but it came late.", "sad": "The storm surprised us at sea."},
	"flood_map": {"who": "Rescuers", "happy": "Flood maps arrived early. We reached families fast.",
		"soso": "We had maps for some towns, not all.", "sad": "Clouds hid the floods. We searched blind."},
	"rain_wind": {"who": "Farmers and forecasters", "happy": "Rain and wind numbers let us prepare the fields.",
		"soso": "We guessed the rain, but not well.", "sad": "We had no rain numbers to plan with."},
	"relay_service": {"who": "Astronauts", "happy": "We could always call home.",
		"soso": "Calls dropped now and then.", "sad": "We were out of touch for days."},
	"ice_mapping": {"who": "Base planners", "happy": "Now we know where the water ice is.",
		"soso": "We found a little ice. We need more maps.", "sad": "We still do not know where the ice is."},
	"navigation": {"who": "Lander pilots", "happy": "We touched down exactly where we aimed.",
		"soso": "We landed, but a bit off target.", "sad": "Landing without a guide was scary."},
	"magnetosphere": {"who": "Space-weather team", "happy": "We mapped Jupiter's giant magnetic bubble.",
		"soso": "We saw part of the magnetic bubble.", "sad": "The magnetic bubble stays a mystery."},
	"atmosphere": {"who": "Cloud scientists", "happy": "We read the gases in Jupiter's clouds.",
		"soso": "We got a blurry look at the clouds.", "sad": "Jupiter's clouds kept their secrets."},
	"moons": {"who": "Moon hunters", "happy": "We spotted hints of oceans under the ice.",
		"soso": "We got a few moon pictures.", "sad": "We barely saw the moons."},
	"gravity": {"who": "Gravity team", "happy": "We felt Jupiter's pull and learned what is inside.",
		"soso": "Our gravity numbers are rough.", "sad": "No gravity data reached home."},
}


static func mood_for(frac: float) -> String:
	if frac >= 0.8:
		return "happy"
	if frac >= 0.4:
		return "soso"
	return "sad"


class GradeStamp extends Control:
	var grade: String = "A"
	var color: Color = Color("7CE08A")

	func _init(g: String = "A", c: Color = Color("7CE08A"), px: float = 150.0) -> void:
		grade = g
		color = c
		custom_minimum_size = Vector2(px, px)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func thump() -> void:
		pivot_offset = custom_minimum_size / 2.0
		scale = Vector2(2.2, 2.2)
		modulate.a = 0.0
		rotation = -0.35
		var tw := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		tw.tween_property(self, "scale", Vector2.ONE, 0.45).set_delay(0.25)
		tw.parallel().tween_property(self, "modulate:a", 1.0, 0.2).set_delay(0.25)
		tw.parallel().tween_property(self, "rotation", -0.12, 0.45).set_delay(0.25)

	func _draw() -> void:
		var s: float = minf(size.x, size.y)
		var c := Vector2(size.x / 2.0, size.y / 2.0)
		draw_circle(c, s * 0.48, Color(color, 0.16))
		draw_arc(c, s * 0.46, 0.0, TAU, 64, color, s * 0.05, true)
		draw_arc(c, s * 0.38, 0.0, TAU, 64, Color(color, 0.6), s * 0.015, true)
		var font: Font = get_theme_default_font()
		var fs: int = int(s * (0.55 if grade.length() == 1 else 0.24))
		var tw: Vector2 = font.get_string_size(grade, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
		draw_string(font, c + Vector2(-tw.x / 2.0, fs * 0.36), grade, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, color)


class UserFace extends Control:
	var mood: String = "happy"
	var color: Color = Color("7CE08A")

	func _init(m: String = "happy", px: float = 64.0) -> void:
		mood = m
		color = {"happy": Color("7CE08A"), "soso": Color("FFC857")}.get(m, Color("FF7A6B"))
		custom_minimum_size = Vector2(px, px)

	func _draw() -> void:
		var s: float = minf(size.x, size.y)
		var c := Vector2(size.x / 2.0, size.y / 2.0)
		var r: float = s * 0.44
		var ink := Color("0B1530")
		draw_circle(c, r, color)
		draw_circle(c + Vector2(-r * 0.35, -r * 0.2), r * 0.11, ink)
		draw_circle(c + Vector2(r * 0.35, -r * 0.2), r * 0.11, ink)
		var w: float = maxf(2.0, s * 0.05)
		match mood:
			"happy":
				draw_arc(c + Vector2(0, r * 0.05), r * 0.5, 0.25, PI - 0.25, 16, ink, w, true)
			"soso":
				draw_line(c + Vector2(-r * 0.4, r * 0.38), c + Vector2(r * 0.4, r * 0.38), ink, w, true)
			_:
				draw_arc(c + Vector2(0, r * 0.75), r * 0.42, PI + 0.4, TAU - 0.4, 16, ink, w, true)


class Confetti extends Control:
	var _bits: Array = []
	var _t: float = 0.0
	const COLORS := [Color("FFC857"), Color("4FB3FF"), Color("7CE08A"), Color("FF7A6B"), Color("F2B134"), Color("E8EEF9")]

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		var rng := RandomNumberGenerator.new()
		rng.randomize()
		for i in 140:
			_bits.append({"x": rng.randf(), "y": rng.randf_range(-1.2, -0.05), "v": rng.randf_range(0.18, 0.42),
				"sw": rng.randf_range(2.0, 6.0), "ph": rng.randf() * TAU, "c": COLORS[i % COLORS.size()], "s": rng.randf_range(6.0, 12.0)})

	func _process(delta: float) -> void:
		_t += delta
		if _t > 7.0:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var fade: float = clampf(7.0 - _t, 0.0, 1.0)
		for b in _bits:
			var y: float = (float(b["y"]) + float(b["v"]) * _t) * size.y
			if y < -20.0 or y > size.y + 20.0:
				continue
			var x: float = float(b["x"]) * size.x + sin(_t * float(b["sw"]) + float(b["ph"])) * 18.0
			var s: float = float(b["s"])
			var squash: float = absf(cos(_t * float(b["sw"]) + float(b["ph"])))
			draw_rect(Rect2(x, y, s, s * (0.35 + 0.65 * squash)), Color(b["c"], fade))
