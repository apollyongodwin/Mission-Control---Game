# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## Stand-in for the lead's MissionState. ONLY used when you test the broadcast screen alone.
## BroadcastMain creates this automatically if the real MissionState autoload does not exist.

signal design_changed
signal phase_changed(phase)
signal seats_changed
signal poll_changed

const PHASES: Array = ["LOBBY", "BRIEFING", "DESIGN", "REVIEW", "LAUNCH", "FLIGHT", "DEBRIEF"]
const ROLES: Array = ["flight", "systems", "payload", "ground"]

var phase: String = "LOBBY"
var scenario: String = "bagyo_watch"
var difficulty: String = "cadet"
var design: Dictionary = {}
var seats: Dictionary = {"flight": 0, "systems": 0, "payload": 0, "ground": 0}
var poll: Dictionary = {}
var current_event: Dictionary = {}
var report: Dictionary = {}

var _design_index: int = 1  # 0 = empty design, 1.. = bot presets


func _ready() -> void:
	_load_design()


func next_phase() -> void:
	set_phase_index(mini(PHASES.find(phase) + 1, PHASES.size() - 1))


func prev_phase() -> void:
	set_phase_index(maxi(PHASES.find(phase) - 1, 0))


func set_phase_index(i: int) -> void:
	phase = PHASES[i]
	current_event = {}
	report = {}
	if phase == "FLIGHT":
		var events: Array = Data.db["events"]
		current_event = {"title": str(events[0].get("title", "Solar Flare"))}
	elif phase == "DEBRIEF":
		report = {"total": 742, "grade": "A"}
	phase_changed.emit(phase)


func toggle_seat(role: String) -> void:
	seats[role] = 0 if int(seats[role]) > 0 else 2
	seats_changed.emit()


func cycle_poll(role: String) -> void:
	# nothing -> GO -> NO-GO -> nothing
	if not poll.has(role):
		poll[role] = {"go": true, "reason": ""}
	elif bool(poll[role]["go"]):
		poll[role] = {"go": false, "reason": "We are not sure the power margin is big enough."}
	else:
		poll.erase(role)
	poll_changed.emit()


func cycle_design() -> void:
	var presets: Array = Data.db["bot_presets"][scenario]
	_design_index = (_design_index + 1) % (presets.size() + 1)
	_load_design()
	design_changed.emit()


func cycle_scenario() -> void:
	var ids: Array = []
	for s in Data.db["scenarios"]:
		ids.append(s["id"])
	scenario = ids[(ids.find(scenario) + 1) % ids.size()]
	_design_index = 1
	_load_design()
	design_changed.emit()
	phase_changed.emit(phase)


func _load_design() -> void:
	if _design_index == 0:
		design = {"scenario": scenario}
		return
	var presets: Array = Data.db["bot_presets"][scenario]
	design = presets[_design_index - 1]["design"].duplicate(true)
	design["scenario"] = scenario
