# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Announcer
extends Node
## Mission-control voice lines. Picks lines in a fixed order (no randomness, so Demo Mode is
## always identical) and optionally speaks them with the system text-to-speech.
## Non-coders: edit the LINES below. Keep {placeholders} as they are.

signal line_said(text: String)

var voice_enabled: bool = true
var _counts: Dictionary = {}
var _voice_id: String = ""

const LINES := {
	# MERGE (Lead, writing pass): witty, but every line still teaches something true.
	"design": ["Design phase is open. Four consoles, one spacecraft, zero arguments. Probably.",
		"Crew, the design table is yours. Remember: every gram costs money to launch.",
		"Mission Control here. Build us something that fits the rocket AND the budget. No pressure."],
	"poll": ["Launch poll! All stations: GO, or NO-GO?", "Real flight directors ask every station before launch. So do we. GO or NO-GO?"],
	"go": ["{role} is GO.", "{role}: GO for launch.", "{role} says GO. Confidence level: suspiciously high."],
	"nogo": ["{role} calls NO-GO. Back to the drawing board. Smart move: holds are cheaper than explosions.",
		"{role} says NO-GO. Better a hold on the ground than a hole in the sky."],
	"countdown": ["Terminal count. Everybody hold your whiskers.", "Final countdown. Please keep paws inside the vehicle."],
	"liftoff": ["Liftoff! The rocket has cleared the tower!", "We have liftoff! That is a lot of controlled explosion."],
	"orbit": ["Orbit reached. The spacecraft is healthy and very, very far from the snack table.",
		"Spacecraft is in orbit and phoning home."],
	"anomaly": ["Uh oh. We have an anomaly.", "That did NOT look like the brochure."],
	"crisis": ["Alert! {title}. All stations, check your tokens!", "Warning: {title}. This is what margins are for!",
		"{title}! Nobody panic. Okay, panic a little. Then play a card."],
	"crisis_ok": ["Crisis averted! The spare margin you built just saved the day.", "Handled! Engineers call that 'margin'. We call it 'cat-like reflexes'."],
	"crisis_hit": ["Ouch. That one left a mark. Lesson logged.", "We took damage. Next time: a little more margin."],
	"radio": ["Radio silence! No talking. Paws on the ping wheel.", "Radio silence is in effect. Use your pings, Pawstronauts."],
	"opportunity": ["Science opportunity! Pool your tokens and grab it!", "Bonus science spotted! Who has tokens to spare?"],
	"debrief": ["Mission complete. Final grade: {grade}.", "Debrief time! The grade is... {grade}!"],
	"lost": ["KABOOM. Mission lost. Real rockets fail too: we learn, we fix, we fly again.",
		"Well. That was loud. Every failure teaches. Let's find out why."],
}


var _no_voice: bool = false

func line(key: String, vars: Dictionary = {}) -> String:
	if not LINES.has(key):
		return ""
	var variants: Array = LINES[key]
	var n: int = int(_counts.get(key, 0))
	_counts[key] = n + 1
	return str(variants[n % variants.size()]).format(vars)


## Say a ready-made line by key, or any text.
func say_key(key: String, vars: Dictionary = {}) -> String:
	var text: String = line(key, vars)
	if text != "":
		say(text)
	return text


func say(text: String) -> void:
	line_said.emit(text)
	_speak(text)


func reset_counts() -> void:
	_counts.clear()


func _speak(text: String) -> void:
	if not voice_enabled or not Audio.voice_on():   # MERGE: robot voice is OFF unless turned on in Settings
		return
	if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		return
	if _no_voice:
		return   # MERGE: looked once, found no voices (e.g. Linux without speech-dispatcher): stay quiet
	if _voice_id == "":
		var ids: PackedStringArray = DisplayServer.tts_get_voices_for_language("en")
		if ids.size() > 0:
			_voice_id = ids[0]
		else:
			var all: Array = DisplayServer.tts_get_voices()
			if all.size() > 0:
				_voice_id = str(all[0].get("id", ""))
	if _voice_id == "":
		_no_voice = true
		return
	DisplayServer.tts_speak(text, _voice_id, 70, 0.9, 1.05)
