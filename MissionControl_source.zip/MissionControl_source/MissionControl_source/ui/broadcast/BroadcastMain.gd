# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## COUNTDOWN Mission Control (broadcast) screen. DEV C, Part 1.
## Plain, big, readable content for each game phase. It reads MissionState (the lead's autoload).
## If MissionState does not exist yet, it makes a FakeMissionState so you can test it alone:
##   Right / Left = next / previous phase     1 2 3 4 = seats join / leave
##   Q W E R = launch poll answers (nothing > GO > NO-GO)     D = next design     S = next scenario
## PART 2 test keys (fake state only):  F9 = full Demo Mode   C = crisis   X = next role acts   G = ping   V = resolve crisis

# ---- what we assume about MissionState (change ONLY these names if the lead's differ) ----
# properties: phase, design, seats, difficulty, poll, current_event, report
# signals (any that exist are used): phase_changed, design_changed, seats_changed, poll_changed
const PHASE_NAMES: Array = ["LOBBY", "BRIEFING", "DESIGN", "REVIEW", "LAUNCH", "FLIGHT", "DEBRIEF"]
const STATE_SIGNALS: Array = ["phase_changed", "design_changed", "seats_changed", "poll_changed", "tokens_changed",
	"flight_status_changed", "settings_changed"]   # MERGE: the Lead's MissionState also has these two

const ROLES: Array = ["flight", "systems", "payload", "ground"]
const LIGHT_KEYS: Array = ["mass", "power", "budget", "data", "comms", "time"]
const LIGHT_NAMES: Dictionary = {"mass": "Weight", "power": "Power", "budget": "Budget", "data": "Data", "comms": "Radio", "time": "Time"}
const PART_CATEGORIES: Array = ["bus", "panel", "battery", "comm", "adcs", "obc", "shield", "prop"]
const REQUIRED_KEYS: Array = ["scenario", "orbit", "bus", "panel", "battery", "comm", "adcs", "obc", "shield", "prop", "rocket"]
const PHASE_TITLES: Dictionary = {
	"LOBBY": "MISSION CONTROL", "BRIEFING": "MISSION BRIEFING", "DESIGN": "DESIGN",
	"REVIEW": "DESIGN REVIEW", "LAUNCH": "LAUNCH", "FLIGHT": "FLIGHT", "DEBRIEF": "DEBRIEF",
}

const COL_BG := Color("#0B1530")
const COL_PANEL := Color("#142347")
const COL_AMBER := Color("#FFC24B")
const COL_TEXT := Color("#F3E9D2")
const COL_DIM := Color("#8A93B2")
const COL_GREEN := Color("#4CD964")
const COL_RED := Color("#FF5A4F")

const SIZE_TITLE: int = 72
const SIZE_BIG: int = 52
const SIZE_BODY: int = 38

@export var scale_window_to_1080p: bool = true
@export var launch_countdown_seconds: float = 6.0   # MERGE: matches PhaseMachine.LAUNCH_COUNTDOWN_SECONDS (also read from the LAUNCH payload)

var ms: Object = null
var using_fake: bool = false

var _title: Label
var _content: VBoxContainer
var _phase_shown: String = ""
var _phase_time: float = 0.0
var _countdown_label: Label = null
var _clock_label: Label = null
var _layer: BroadcastLayer = null      # Part 2: ship, orbit view, ticker, crisis overlay, launch countdown
var _margin: MarginContainer = null
var _ship_slot: Control = null
var _orbit_slot: Control = null
var _acted_count: int = 0
var _seen_acted: Dictionary = {}    # MERGE: roles already shown as "acted" for the live crisis
var _seen_pings: int = 0
var _seen_poll: Dictionary = {}


## A small drawn status icon. Uses SHAPES as well as colour:
## green circle + check, amber triangle + "!", red square + X, grey ring = not answered yet.
class BigLight extends Control:
	var state: String = "none"

	func _init(icon_size: float = 56.0) -> void:
		custom_minimum_size = Vector2(icon_size, icon_size)

	func set_state(s: String) -> void:
		state = s
		queue_redraw()

	func _draw() -> void:
		var c: Vector2 = size / 2.0
		var r: float = minf(size.x, size.y) / 2.0 - 3.0
		var dark := Color("#0B1530")
		var w: float = maxf(4.0, r * 0.14)
		match state:
			"green":
				draw_circle(c, r, Color("#4CD964"))
				draw_polyline(PackedVector2Array([c + Vector2(-r * 0.45, 0.0), c + Vector2(-r * 0.1, r * 0.35), c + Vector2(r * 0.5, -r * 0.35)]), dark, w)
			"amber":
				draw_colored_polygon(PackedVector2Array([c + Vector2(0.0, -r), c + Vector2(r, r * 0.85), c + Vector2(-r, r * 0.85)]), Color("#FFC24B"))
				draw_line(c + Vector2(0.0, -r * 0.2), c + Vector2(0.0, r * 0.3), dark, w)
				draw_circle(c + Vector2(0.0, r * 0.6), w * 0.6, dark)
			"red":
				draw_rect(Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), Color("#FF5A4F"))
				draw_line(c + Vector2(-r * 0.5, -r * 0.5), c + Vector2(r * 0.5, r * 0.5), dark, w)
				draw_line(c + Vector2(-r * 0.5, r * 0.5), c + Vector2(r * 0.5, -r * 0.5), dark, w)
			_:
				draw_arc(c, r, 0.0, TAU, 32, Color("#8A93B2"), 4.0)


func _ready() -> void:
	if scale_window_to_1080p:
		var w: Window = get_window()
		w.content_scale_size = Vector2i(1920, 1080)
		w.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
		w.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP
	_build_frame()
	_connect_state()
	_make_layer()
	_hook_live_events()
	_refresh()


func _process(delta: float) -> void:
	_phase_time += delta
	if is_instance_valid(_countdown_label):
		var t: float = launch_countdown_seconds - _phase_time
		_countdown_label.text = str(ceili(t)) if t > 0.0 else "LIFTOFF!"
	if is_instance_valid(_clock_label):
		var secs: int = int(_phase_time)
		_clock_label.text = "MISSION CLOCK   T+ %02d:%02d" % [secs / 60, secs % 60]


func _unhandled_input(event: InputEvent) -> void:
	if not using_fake:
		return
	var k := event as InputEventKey
	if k == null or not k.pressed or k.echo:
		return
	match k.keycode:
		KEY_RIGHT: ms.call("next_phase")
		KEY_LEFT: ms.call("prev_phase")
		KEY_1: ms.call("toggle_seat", "flight")
		KEY_2: ms.call("toggle_seat", "systems")
		KEY_3: ms.call("toggle_seat", "payload")
		KEY_4: ms.call("toggle_seat", "ground")
		KEY_Q: ms.call("cycle_poll", "flight")
		KEY_W: ms.call("cycle_poll", "systems")
		KEY_E: ms.call("cycle_poll", "payload")
		KEY_R: ms.call("cycle_poll", "ground")
		KEY_D: ms.call("cycle_design")
		KEY_S: ms.call("cycle_scenario")
		KEY_C:
			_acted_count = 0
			_layer.show_crisis(Data.by_id(Data.db["events"], "solar_flare"), 25.0, false)
		KEY_X:
			_layer.crisis_acted(ROLES[_acted_count % 4])
			_acted_count += 1
		KEY_G: _layer.add_ping("payload", "have_spare_data")
		KEY_V: _layer.crisis_resolved({"residual": 0.0, "line": "You had power and shielding to spare, so the flare did no harm."})


# ------------------------------------------------------------------ setup

func _build_frame() -> void:
	var bg := ColorRect.new()
	bg.color = COL_BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 50)
	margin.add_theme_constant_override("margin_bottom", 110)  # room for the Part 2 ticker
	_margin = margin
	add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 20)
	margin.add_child(column)
	_title = _label("", SIZE_TITLE, COL_AMBER)
	column.add_child(_title)
	_content = VBoxContainer.new()
	_content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_content.add_theme_constant_override("separation", 20)
	column.add_child(_content)


func _connect_state() -> void:
	ms = get_node_or_null("/root/MissionState")
	if ms == null:
		var fake_script: GDScript = load("res://ui/broadcast/FakeMissionState.gd")
		var node: Node = fake_script.new()
		add_child(node)
		ms = node
		using_fake = true
	for sig in STATE_SIGNALS:
		if ms.has_signal(sig):
			ms.connect(sig, _on_state_changed)


## MERGE: with the real autoloads, feed live crisis / poll / ping / launch events into Dev C's BroadcastLayer.
## (Dev C's fake state drove these by keyboard; the Lead's Net sends them as signals.)
func _hook_live_events() -> void:
	if using_fake:
		return
	_layer.auto_launch = false
	var net: Node = get_node_or_null("/root/Net")
	if net == null:
		return
	net.connect("crisis_event", func(ev: Dictionary, timer_s: float) -> void:
		_seen_acted = {}
		_seen_pings = 0
		_layer.show_crisis(ev, timer_s, bool(ev.get("radio_silence", false))))
	net.connect("crisis_result", func(res: Dictionary) -> void:
		_layer.crisis_resolved(res))
	net.connect("server_message_received", func(code: String, text: String) -> void:
		if code in ["nogo", "review_blocked", "seat_held", "seat_freed", "rejoined", "bot_chatter"]:
			_layer.ticker.push(text, COL_AMBER))
	net.connect("chat_received", func(role: String, text: String) -> void:   # MERGE (Part 3): crew chat on the ticker
		var who: String = _role_name(role) if role in ROLES else "MISSION CONTROL"
		_layer.ticker.push("%s: %s" % [who, text], _role_color(role) if role in ROLES else COL_AMBER)
		Audio.play_sfx("quindar_in"))
	ms.connect("flight_status_changed", _on_flight_status)
	ms.connect("poll_changed", _on_poll_live)
	ms.connect("phase_changed", _on_phase_live)


func _on_flight_status() -> void:
	var fs: Dictionary = ms.get("flight_status") if ms.get("flight_status") is Dictionary else {}
	if not bool(fs.get("active", false)):
		return
	var acted: Dictionary = fs.get("acted", {})
	for r in acted:
		if bool(acted[r]) and not _seen_acted.has(r):
			_seen_acted[r] = true
			_layer.crisis_acted(str(r))
	var pings: Array = fs.get("pings", [])
	for i in range(_seen_pings, pings.size()):
		_layer.add_ping(str(pings[i].get("role", "")), str(pings[i].get("card", "")))
	_seen_pings = pings.size()


func _on_poll_live() -> void:
	var poll: Dictionary = ms.get("poll") if ms.get("poll") is Dictionary else {}
	for r in poll:
		var st: String = str(poll[r].get("state", "pending"))
		if st != "pending" and _seen_poll.get(r, "") != st:
			_layer.announce_poll(str(r), st == "go")
		_seen_poll[r] = st


func _on_phase_live(p: String) -> void:
	if p != "REVIEW":
		_seen_poll = {}
	if p == "LAUNCH":
		var pay: Dictionary = ms.get("phase_payload") if ms.get("phase_payload") is Dictionary else {}
		var secs: float = float(pay.get("countdown_s", launch_countdown_seconds))
		var rel: float = float(pay.get("reliability", 0.95))
		var success: bool = true
		var net: Node = get_node_or_null("/root/Net")
		if net != null and net.get("phase_machine") != null:
			success = bool(net.get("phase_machine").get("_launch_success"))   # Mission Control is the host: it knows
		_layer.start_launch(rel * 100.0, secs, success)


func _make_layer() -> void:
	_layer = preload("res://ui/broadcast/BroadcastLayer.tscn").instantiate() as BroadcastLayer
	add_child(_layer)
	_layer.use_slots = true
	_layer.show_health = false
	_layer.launch_seconds = launch_countdown_seconds
	_layer.bind_state(ms as Node)


## After the screen is rebuilt, tell the layer which rectangles to draw the ship and orbit view in.
func _sync_slots() -> void:
	# MERGE fix: the screen can leave the tree between frames (back to lobby); get_tree() is null then.
	for i in 2:
		if not is_inside_tree():
			return
		await get_tree().process_frame
	if not is_inside_tree():
		return
	if _layer == null or not is_instance_valid(_layer):
		return
	_layer.clear_slots()
	for pair in [["ship", _ship_slot], ["orbit", _orbit_slot]]:
		var slot: Control = pair[1] as Control
		if slot != null and is_instance_valid(slot) and slot.is_inside_tree():
			var r: Rect2 = slot.get_global_rect()
			_layer.place_slot(str(pair[0]), Rect2(r.position - _layer.global_position, r.size))


func _on_state_changed(_a: Variant = null, _b: Variant = null) -> void:
	_refresh()


# ------------------------------------------------------------------ reading the state (all MissionState reads live here)

func _phase_name() -> String:
	var p: Variant = ms.get("phase")
	if p == null:
		return "LOBBY"
	if typeof(p) == TYPE_INT:
		return PHASE_NAMES[clampi(int(p), 0, PHASE_NAMES.size() - 1)]
	return str(p).to_upper()


func _design() -> Dictionary:
	var d: Variant = ms.get("design")
	if typeof(d) == TYPE_DICTIONARY:
		return d
	return {}


func _difficulty() -> String:
	var d: Variant = ms.get("difficulty")
	if d != null and Data.db["meta"]["difficulty"].has(str(d)):
		return str(d)
	return "engineer"


func _scenario() -> Dictionary:
	var id: String = str(_design().get("scenario", ""))
	if id == "" and ms.get("scenario") != null:
		id = str(ms.get("scenario"))
	return Data.scenario(id)


func _seats() -> Dictionary:
	var s: Variant = ms.get("seats")
	return s if s is Dictionary else {}


func _seat_taken(role: String) -> bool:
	var seats: Variant = ms.get("seats")
	if typeof(seats) != TYPE_DICTIONARY:
		return false
	var v: Variant = seats.get(role)
	match typeof(v):
		TYPE_NIL: return false
		TYPE_STRING: return v != ""
		TYPE_INT: return int(v) != 0   # MERGE: -1 = bot, -2 = held for a dropped player (both count as taken)
		TYPE_BOOL: return bool(v)
		TYPE_DICTIONARY: return not v.is_empty()
	return true


## returns {"state": "none"|"green"|"red", "reason": String}
func _poll_entry(role: String) -> Dictionary:
	var waiting := {"state": "none", "reason": ""}
	var poll: Variant = ms.get("poll")
	if typeof(poll) != TYPE_DICTIONARY or not poll.has(role) or poll[role] == null:
		return waiting
	var v: Variant = poll[role]
	if typeof(v) == TYPE_DICTIONARY:
		if v.has("state"):   # MERGE: the Lead's poll is {"state": "pending"|"go"|"nogo", "reason"}
			var st: String = str(v["state"])
			return {"state": "green" if st == "go" else ("red" if st == "nogo" else "none"), "reason": str(v.get("reason", ""))}
		return {"state": "green" if bool(v.get("go", false)) else "red", "reason": str(v.get("reason", ""))}
	return {"state": "green" if bool(v) else "red", "reason": ""}


## Runs the sim only when the design is complete and every id exists, so half-made designs never crash it.
func _evaluate(design: Dictionary) -> Dictionary:
	for key in REQUIRED_KEYS:
		if str(design.get(key, "")) == "":
			return {}
	for cat in PART_CATEGORIES:
		if Data.part(cat, str(design[cat])).is_empty():
			return {}
	if Data.orbit(str(design["orbit"])).is_empty() or Data.rocket(str(design["rocket"])).is_empty():
		return {}
	var d: Dictionary = design.duplicate(true)
	if not d.has("rtg_count"):
		d["rtg_count"] = 0
	if not d.has("stations"):
		d["stations"] = []
	if not d.has("instruments"):
		d["instruments"] = []
	return SimEngine.evaluate(Data.db, d, _difficulty())


# ------------------------------------------------------------------ drawing helpers

func _label(text: String, size: int = SIZE_BODY, color: Color = COL_TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _panel(bg: Color, border: Color = Color(0, 0, 0, 0)) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(24)
	if border.a > 0.0:
		sb.border_color = border
		sb.set_border_width_all(4)
	p.add_theme_stylebox_override("panel", sb)
	return p


func _role_color(role: String) -> Color:
	return Color(str(Data.db["meta"]["roles"][role]["color"]))


func _role_name(role: String) -> String:
	return str(Data.db["meta"]["roles"][role]["name"])


func _role_title(role: String) -> String:
	return str(Data.db["meta"]["roles"][role]["title"])


func _spacer(h: float) -> Control:
	var s := Control.new()
	s.custom_minimum_size = Vector2(0, h)
	return s


func _local_ip() -> String:
	for a in IP.get_local_addresses():
		var s: String = str(a)
		if s.count(".") == 3 and (s.begins_with("192.168.") or s.begins_with("10.") or s.begins_with("172.")):
			return s
	return "127.0.0.1"


# ------------------------------------------------------------------ refresh: rebuild the content for the current phase

func _refresh() -> void:
	var phase: String = _phase_name()
	if phase != _phase_shown:
		_phase_shown = phase
		_phase_time = 0.0
	_title.text = str(PHASE_TITLES.get(phase, phase))
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	_countdown_label = null
	_clock_label = null
	_ship_slot = null
	_orbit_slot = null
	match phase:
		"LOBBY": _build_lobby()
		"BRIEFING": _build_briefing()
		"DESIGN": _build_design()
		"REVIEW": _build_review()
		"LAUNCH": _build_launch()
		"FLIGHT": _build_flight()
		"DEBRIEF": _build_debrief()
		_: _content.add_child(_label("Unknown phase: " + phase, SIZE_BODY, COL_DIM))
	if using_fake:
		var hint := _label("TEST KEYS:  Right/Left = phase   1-4 = seats   Q W E R = launch poll   D = design   S = scenario", 24, COL_DIM)
		_content.add_child(hint)
	_sync_slots()


# ---- LOBBY
func _build_lobby() -> void:
	_content.add_child(_label("Join this mission from your laptop", SIZE_BIG, COL_TEXT))
	_content.add_child(_label("Address:  %s      Port:  7777" % _local_ip(), SIZE_BIG, COL_AMBER))
	_content.add_child(_spacer(20))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 30)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var filled: int = 0
	for role in ROLES:
		var taken: bool = _seat_taken(role)
		if taken:
			filled += 1
		row.add_child(_seat_tile(role, taken))
	_content.add_child(row)
	_content.add_child(_label("%d of 4 seats filled" % filled, SIZE_BIG, COL_DIM))


func _seat_tile(role: String, taken: bool) -> Control:
	var col: Color = _role_color(role)
	var tile: PanelContainer = _panel(col if taken else COL_PANEL, col)
	tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	tile.add_child(box)
	var text_col: Color = COL_BG if taken else COL_DIM
	box.add_child(_label(_role_name(role), SIZE_BIG, text_col))
	box.add_child(_label(_role_title(role), SIZE_BODY, text_col))
	var cat := CrewArt.make(role, 150)   # MERGE (UI pass): the crew's cat astronaut
	cat.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	cat.dimmed = not taken
	cat.bob = taken
	box.add_child(cat)
	var icon := BigLight.new(96.0)
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	icon.set_state("green" if taken else "none")
	box.add_child(icon)
	box.add_child(_label("JOINED" if taken else "WAITING...", SIZE_BIG, text_col))
	return tile


# ---- BRIEFING  (MERGE, UI pass: story on the left, the crew and their jobs on the right)
func _build_briefing() -> void:
	var sc: Dictionary = _scenario()
	if sc.is_empty():
		_content.add_child(_label("No mission chosen yet.", SIZE_BIG, COL_DIM))
		return
	var cap: int = int(round(float(sc["budget_cap"]) * float(Data.db["meta"]["difficulty"][_difficulty()]["budget_mult"])))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 40)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_content.add_child(row)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 1.3
	left.add_theme_constant_override("separation", 16)
	row.add_child(left)
	left.add_child(_label(str(sc["name"]), 96, COL_AMBER))
	left.add_child(_label(str(sc["subtitle"]), SIZE_BODY, COL_DIM))
	left.add_child(_label(str(sc["briefing"]), SIZE_BODY, COL_TEXT))
	var facts := HBoxContainer.new()
	facts.add_theme_constant_override("separation", 20)
	for f in ["Budget  %d C$M" % cap, "Deadline  %d months" % int(sc["deadline_months"])]:
		var chip: PanelContainer = _panel(COL_PANEL, COL_AMBER)
		var fl: Label = _label(f, SIZE_BODY, COL_AMBER)
		fl.autowrap_mode = TextServer.AUTOWRAP_OFF
		fl.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		chip.add_child(fl)
		facts.add_child(chip)
	left.add_child(facts)
	for t in MissionState.twist_names():   # round 8: this mission's twist
		left.add_child(_label("TWIST: %s  -  %s" % [str(t.get("name", "")).to_upper(), str(t.get("blurb", ""))], 30, Color("FF9F43")))
	var objs := HFlowContainer.new()
	objs.add_theme_constant_override("h_separation", 14)
	objs.add_theme_constant_override("v_separation", 14)
	for o in sc["objectives"]:
		var oc: PanelContainer = _panel(COL_PANEL)
		var ol: Label = _label("%s  -  %d pts" % [str(o["label"]), int(o["weight"])], 30, COL_TEXT)
		ol.autowrap_mode = TextServer.AUTOWRAP_OFF
		oc.add_child(ol)
		objs.add_child(oc)
	left.add_child(objs)
	var crew := GridContainer.new()
	crew.columns = 2
	crew.add_theme_constant_override("h_separation", 20)
	crew.add_theme_constant_override("v_separation", 20)
	crew.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(crew)
	for role in ROLES:
		var tile: PanelContainer = _panel(COL_PANEL, _role_color(role))
		tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v := VBoxContainer.new()
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		tile.add_child(v)
		var cat := CrewArt.make(role, 170)
		cat.bob = true
		cat.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		v.add_child(cat)
		var n: Label = _label(_role_name(role), SIZE_BIG, _role_color(role))
		n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(n)
		var t: Label = _label(_role_title(role), 28, COL_DIM)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(t)
		# MERGE: Mission Control can see who is ready
		var seat: int = int(_seats().get(role, 0)) if typeof(_seats().get(role, 0)) == TYPE_INT else 0
		var rd: bool = bool((ms.get("seat_ready") if ms.get("seat_ready") is Dictionary else {}).get(role, false))
		var st: Label = _label("READY!" if rd else ("AutoCrew bot" if seat == -1 else "Reading the briefing..."), 30,
			COL_GREEN if rd else COL_DIM)
		st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(st)
		crew.add_child(tile)


# ---- DESIGN  (MERGE, UI pass: four crew cards with part chips | the live ship + health lights)
func _build_design() -> void:
	var design: Dictionary = _design()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 30)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 1.15
	left.add_theme_constant_override("separation", 10)
	for role in ROLES:
		var card: PanelContainer = _panel(COL_PANEL, _role_color(role))
		(card.get_theme_stylebox("panel") as StyleBoxFlat).set_content_margin_all(12)
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 18)
		card.add_child(h)
		var cat := CrewArt.make(role, 78)
		cat.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(cat)
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		v.add_theme_constant_override("separation", 6)
		h.add_child(v)
		var name_l: Label = _label("%s  -  %s" % [_role_name(role), _role_title(role)], 26, _role_color(role))
		name_l.autowrap_mode = TextServer.AUTOWRAP_OFF
		v.add_child(name_l)
		var chips := HFlowContainer.new()
		chips.add_theme_constant_override("h_separation", 6)
		chips.add_theme_constant_override("v_separation", 6)
		var names: Array = _chosen_names(role, design)
		if names.is_empty():
			chips.add_child(_label("(nothing chosen yet)", 24, COL_DIM))
		for nm in names:
			var chip: PanelContainer = _panel(Color(_role_color(role), 0.16))
			(chip.get_theme_stylebox("panel") as StyleBoxFlat).set_content_margin_all(6)
			var cl: Label = _label(str(nm).split(" (")[0], 20, COL_TEXT)
			cl.autowrap_mode = TextServer.AUTOWRAP_OFF
			chip.add_child(cl)
			chips.add_child(chip)
		v.add_child(chips)
		left.add_child(card)
	row.add_child(left)
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 16)
	_ship_slot = Control.new()       # Part 2 draws the spaceship here
	_ship_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_ship_slot.custom_minimum_size = Vector2(0, 420)
	right.add_child(_ship_slot)
	right.add_child(_lights_row(design))
	row.add_child(right)
	_content.add_child(row)


func _content_indent(parent: Control, child: Control) -> void:
	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", 30)
	m.add_child(child)
	parent.add_child(m)


func _lights_panel(design: Dictionary) -> Control:
	var result: Dictionary = _evaluate(design)
	var lights: Dictionary = result.get("lights", {})
	var p: PanelContainer = _panel(COL_PANEL)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.size_flags_stretch_ratio = 1.0
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	p.add_child(box)
	box.add_child(_label("HEALTH CHECK", SIZE_BODY, COL_AMBER))
	for key in LIGHT_KEYS:
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 20)
		var icon := BigLight.new(56.0)
		icon.set_state(_light_state(str(lights.get(key, ""))))
		h.add_child(icon)
		h.add_child(_label(str(LIGHT_NAMES[key]), SIZE_BIG, COL_TEXT))
		box.add_child(h)
	return p


## Compact horizontal version of the health check (sits under the spaceship).
func _lights_row(design: Dictionary) -> Control:
	var result: Dictionary = _evaluate(design)
	var lights: Dictionary = result.get("lights", {})
	var p: PanelContainer = _panel(COL_PANEL)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	p.add_child(h)
	for key in LIGHT_KEYS:
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var icon := BigLight.new(56.0)
		icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		icon.set_state(_light_state(str(lights.get(key, ""))))
		v.add_child(icon)
		var l: Label = _label(str(LIGHT_NAMES[key]), 24, COL_TEXT)
		l.autowrap_mode = TextServer.AUTOWRAP_OFF   # MERGE (UI pass): "Weight" never splits into "Weig / ht"
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(l)
		h.add_child(v)
	return p


func _light_state(word: String) -> String:
	if word == "green" or word == "amber" or word == "red":
		return word
	return "none"


func _chosen_names(role: String, d: Dictionary) -> Array:
	var out: Array = []
	match role:
		"flight":
			_add_name(out, Data.orbit(str(d.get("orbit", ""))))
		"systems":
			for cat in ["bus", "panel", "battery", "adcs", "obc", "shield", "prop"]:
				_add_name(out, Data.part(cat, str(d.get(cat, ""))))
			if int(d.get("rtg_count", 0)) > 0:
				out.append("%d x nuclear battery" % int(d["rtg_count"]))
		"payload":
			for id in d.get("instruments", []):
				_add_name(out, Data.instrument(str(id)))
		"ground":
			_add_name(out, Data.rocket(str(d.get("rocket", ""))))
			_add_name(out, Data.part("comm", str(d.get("comm", ""))))
			for id in d.get("stations", []):
				_add_name(out, Data.station(str(id)))
	return out


func _add_name(out: Array, item: Dictionary) -> void:
	if not item.is_empty():
		out.append(str(item["name"]))


# ---- REVIEW
func _build_review() -> void:
	_content.add_child(_label("Is everyone ready to launch?   GO or NO-GO", SIZE_BIG, COL_TEXT))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 30)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var go_count: int = 0
	for role in ROLES:
		var entry: Dictionary = _poll_entry(role)
		if entry["state"] == "green":
			go_count += 1
		row.add_child(_poll_tile(role, entry))
	_content.add_child(row)
	var summary: String = "ALL GO - heading to launch!" if go_count == 4 else "%d of 4 GO" % go_count
	_content.add_child(_label(summary, SIZE_BIG, COL_AMBER))


func _poll_tile(role: String, entry: Dictionary) -> Control:
	var tile: PanelContainer = _panel(COL_PANEL, _role_color(role))
	tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	tile.add_child(box)
	box.add_child(_label(_role_name(role), SIZE_BIG, _role_color(role)))
	var cat := CrewArt.make(role, 130, "happy" if entry["state"] == "green" else ("worried" if entry["state"] == "red" else ""))
	cat.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(cat)
	var icon := BigLight.new(96.0)
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	icon.set_state(str(entry["state"]))
	box.add_child(icon)
	var status: String = "WAITING..."
	if entry["state"] == "green":
		status = "GO"
	elif entry["state"] == "red":
		status = "NO-GO"
	box.add_child(_label(status, SIZE_BIG, COL_TEXT))
	if str(entry["reason"]) != "":
		box.add_child(_label(str(entry["reason"]), SIZE_BODY, COL_DIM))
	return tile


# ---- LAUNCH
func _build_launch() -> void:
	if _layer != null:
		_content.add_child(_spacer(120))
		_content.add_child(_label("Launch sequence started...", SIZE_BIG, COL_DIM))
		return
	_content.add_child(_spacer(120))
	_content.add_child(_label("T-MINUS", SIZE_BIG, COL_DIM))
	_countdown_label = _label("", 240, COL_AMBER)
	_countdown_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_content.add_child(_countdown_label)


# ---- FLIGHT  (MERGE, UI pass: a clear band on top for the crisis banner, clock + ship left, big orbit right)
func _build_flight() -> void:
	_title.text = ""
	var fs: Dictionary = ms.get("flight_status") if ms.get("flight_status") is Dictionary else {}
	_content.add_child(_spacer(150))   # the crisis banner lives up here
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 30)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 0.62
	left.add_theme_constant_override("separation", 12)
	left.add_child(_label("IN FLIGHT", SIZE_BIG, COL_AMBER))
	_clock_label = _label("", SIZE_BODY, COL_TEXT)
	left.add_child(_clock_label)
	var beat: int = int(fs.get("beat", -1))
	var total: int = int(fs.get("total", -1))
	if total > 0:
		var dots := HBoxContainer.new()
		dots.add_theme_constant_override("separation", 10)
		for i in total:
			var d := BigLight.new(40.0)
			d.set_state("green" if i < beat or (i == beat and not bool(fs.get("active", false))) else ("amber" if i == beat else "none"))
			dots.add_child(d)
		left.add_child(_label("Events", 26, COL_DIM))
		left.add_child(dots)
	var ev_title: String = str(fs.get("title", "")) if bool(fs.get("active", false)) else "All quiet. Cruising."
	if not bool(fs.get("active", false)) and not (fs.get("tasks", {}) as Dictionary).is_empty():
		ev_title = "Crew doing mini-tasks!"   # round 8
	left.add_child(_label(ev_title, SIZE_BODY, COL_TEXT))
	var lives := LivesBar.new()   # round 8
	lives.heart = 26.0
	left.add_child(lives)
	_ship_slot = Control.new()
	_ship_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_ship_slot.custom_minimum_size = Vector2(0, 260)
	left.add_child(_ship_slot)
	row.add_child(left)
	_orbit_slot = Control.new()
	_orbit_slot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_orbit_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_child(_orbit_slot)
	_content.add_child(row)


# ---- DEBRIEF
func _build_debrief() -> void:
	var rep: Variant = ms.get("report")
	if rep == null:
		rep = ms.get("last_report")   # MERGE: the Lead's name
	var total: String = "-"
	var grade: String = "-"
	if typeof(rep) == TYPE_DICTIONARY:
		for k in ["total", "TOTAL", "total_score"]:
			if rep.has(k):
				total = str(int(rep[k]))
				break
		grade = str(rep.get("grade", "-"))
	_content.add_child(_spacer(60))
	if typeof(rep) == TYPE_DICTIONARY and bool(rep.get("out_of_lives", false)):   # round 8
		_content.add_child(_label("OUT OF LIVES: MISSION CALLED OFF", SIZE_BIG, Color("FF6B5E")))
	_content.add_child(_label("FINAL SCORE", SIZE_BIG, COL_DIM))
	_content.add_child(_label("%s  /  1000" % total, 160, COL_AMBER))
	_content.add_child(_label("GRADE:  %s" % grade, 120, COL_TEXT))
