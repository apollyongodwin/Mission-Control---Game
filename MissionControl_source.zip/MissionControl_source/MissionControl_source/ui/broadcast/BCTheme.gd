# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name BCTheme
extends RefCounted
## Shared colours and tiny drawing helpers for the broadcast screen (Dev C).
## Rule from UX_GUIDE: never rely on colour alone, so lights also use shapes.

const NAVY := Color(0.043, 0.078, 0.149)
const PANEL := Color(0.078, 0.133, 0.247)
const AMBER := Color(1.0, 0.69, 0.0)
const GREEN := Color(0.30, 0.85, 0.39)
const YELLOW := Color(1.0, 0.82, 0.25)
const RED := Color(1.0, 0.31, 0.31)
const WHITE := Color(0.91, 0.93, 0.97)
const DIM := Color(0.49, 0.55, 0.66)
const ROLES := ["flight", "systems", "payload", "ground"]


static func role_color(role: String) -> Color:
	var roles: Dictionary = Data.db["meta"]["roles"]
	if roles.has(role):
		return Color(str(roles[role]["color"]))
	return WHITE


static func role_name(role: String) -> String:
	var roles: Dictionary = Data.db["meta"]["roles"]
	if roles.has(role):
		return str(roles[role]["name"])
	return role.to_upper()


static func light_color(light: String) -> Color:
	match light:
		"green":
			return GREEN
		"amber":
			return YELLOW
		"red":
			return RED
	return DIM


## green = circle + tick, amber = triangle + "!", red = square + X
static func draw_light(ci: CanvasItem, c: Vector2, r: float, light: String, pulse: float = 0.0) -> void:
	var col: Color = light_color(light)
	var rr: float = r * (1.0 + 0.12 * pulse)
	var w: float = maxf(3.0, rr * 0.18)
	match light:
		"green":
			ci.draw_circle(c, rr, col)
			ci.draw_polyline(PackedVector2Array([c + Vector2(-0.45, 0.0) * rr, c + Vector2(-0.12, 0.35) * rr, c + Vector2(0.5, -0.35) * rr]), NAVY, w)
		"amber":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0.0, -1.0) * rr, c + Vector2(0.95, 0.8) * rr, c + Vector2(-0.95, 0.8) * rr]), col)
			ci.draw_line(c + Vector2(0.0, -0.3) * rr, c + Vector2(0.0, 0.25) * rr, NAVY, w)
			ci.draw_circle(c + Vector2(0.0, 0.55) * rr, maxf(2.0, rr * 0.09), NAVY)
		"red":
			ci.draw_rect(Rect2(c - Vector2(rr, rr) * 0.9, Vector2(rr, rr) * 1.8), col)
			ci.draw_line(c + Vector2(-0.45, -0.45) * rr, c + Vector2(0.45, 0.45) * rr, NAVY, w)
			ci.draw_line(c + Vector2(0.45, -0.45) * rr, c + Vector2(-0.45, 0.45) * rr, NAVY, w)
		_:
			ci.draw_circle(c, rr, DIM)
