# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name Ticker
extends Control
## Scrolling one-line message bar at the bottom of the broadcast screen.
## Use: ticker.push("SYSTEMS switched to ...", colour)
## Ticker.describe_change(old_design, new_design) turns two designs into ticker lines.

var font_size: int = 36
var speed: float = 150.0
var _items: Array = []    # each: {"text": String, "color": Color}
var _x: float = 0.0
var _flash: float = 0.0
const GAP := 90.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	_x = size.x


func push(text: String, color: Color = BCTheme.AMBER) -> void:
	_items.append({"text": text, "color": color})
	_flash = 1.0
	if _items.size() == 1:
		_x = size.x


func _width_of(text: String) -> float:
	return ThemeDB.fallback_font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x + GAP


func _process(delta: float) -> void:
	_flash = maxf(0.0, _flash - delta * 1.5)
	if _items.is_empty():
		return
	_x -= speed * delta
	var total: float = 0.0
	for it in _items:
		total += _width_of(it["text"])
	# drop old messages once they have fully scrolled off the left edge
	while _items.size() > 10 and _x + _width_of(_items[0]["text"]) < 0.0:
		_x += _width_of(_items[0]["text"])
		_items.remove_at(0)
	if _x <= -total:
		_x += maxf(total, size.x)
	queue_redraw()


func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	draw_rect(Rect2(Vector2.ZERO, size), Color(BCTheme.NAVY, 0.92))
	draw_rect(Rect2(0.0, 0.0, size.x, 4.0), Color(BCTheme.AMBER, 0.6 + 0.4 * _flash))
	if _items.is_empty():
		return
	var total: float = 0.0
	for it in _items:
		total += _width_of(it["text"])
	var base_y: float = size.y * 0.5 + float(font_size) * 0.35
	for copy in 2:
		var x: float = _x + float(copy) * maxf(total, size.x)
		for it in _items:
			draw_string(font, Vector2(x, base_y), it["text"], HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, it["color"])
			x += _width_of(it["text"])


static func _name_of(key: String, id: String) -> String:
	var item: Dictionary = {}
	match key:
		"orbit":
			item = Data.orbit(id)
		"rocket":
			item = Data.rocket(id)
		"stations":
			item = Data.station(id)
		"instruments":
			item = Data.instrument(id)
		_:
			if Data.db["parts"].has(key):
				item = Data.part(key, id)
	return str(item.get("name", id))


## Returns [{"text": String, "role": String}] describing what changed between two designs.
static func describe_change(old: Dictionary, new: Dictionary) -> Array:
	var out: Array = []
	if old.is_empty():
		return out
	var roles: Dictionary = Data.db["meta"]["roles"]
	for role in BCTheme.ROLES:
		var rname: String = str(roles[role]["name"])
		for key in roles[role]["owns_choices"]:
			if str(old.get(key)) == str(new.get(key)):
				continue
			if key == "instruments" or key == "stations":
				var a: Array = old.get(key, [])
				var b: Array = new.get(key, [])
				for id in b:
					if not a.has(id):
						out.append({"text": "%s added %s" % [rname, _name_of(key, str(id))], "role": role})
				for id in a:
					if not b.has(id):
						out.append({"text": "%s removed %s" % [rname, _name_of(key, str(id))], "role": role})
			elif key == "rtg_count":
				out.append({"text": "%s now flies %d nuclear batter%s" % [rname, int(new.get(key, 0)), "y" if int(new.get(key, 0)) == 1 else "ies"], "role": role})
			else:
				var label: String = str(SimEngine.CATEGORY_LABELS.get(key, key)).to_lower()
				out.append({"text": "%s switched %s to %s" % [rname, label, _name_of(key, str(new.get(key)))], "role": role})
	return out
