# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CrisisOverlay
extends Control
## Alarm tint, countdown ring, "who has acted" badges, Radio Silence banner and ping log.
## Public API (all called by BroadcastLayer):
##   start(event, timer_s, radio_silence)   mark_acted(role)   add_ping(role, card_id)
##   resolve(result)   set_radio_silence(on)   clear()

var _active: bool = false
var _event: Dictionary = {}
var _total: float = 1.0
var _left: float = 0.0
var _acted: Dictionary = {}
var _radio: bool = false
var _pings: Array = []     # {"role", "text", "age"}
var _result: Dictionary = {}
var _result_left: float = 0.0
var _t: float = 0.0
var cadet_soft: bool = false    # softer alarm tint (UX: never a harsh alarm in Cadet)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func start(event: Dictionary, timer_s: float, radio_silence: bool = false) -> void:
	_event = event.duplicate(true)
	_total = maxf(1.0, timer_s)
	_left = _total
	_acted.clear()
	_result = {}
	_result_left = 0.0
	_radio = radio_silence
	_active = true


func mark_acted(role: String) -> void:
	_acted[role] = true


func set_radio_silence(on: bool) -> void:
	_radio = on


func add_ping(role: String, card_id: String) -> void:
	_pings.append({"role": role, "text": card_id.replace("_", " ").to_upper(), "age": 0.0})
	if _pings.size() > 5:
		_pings.remove_at(0)


## result may contain: "line" (what happened and why), "residual" (0 = fully saved, 1 = nothing saved).
func resolve(result: Dictionary) -> void:
	_active = false
	_result = result.duplicate(true)
	_result_left = 6.0


func clear() -> void:
	_active = false
	_result = {}
	_result_left = 0.0
	_radio = false
	_pings.clear()


func is_active() -> bool:
	return _active


func _process(delta: float) -> void:
	_t += delta
	if _active:
		_left = maxf(0.0, _left - delta)
	if _result_left > 0.0:
		_result_left -= delta
	for p in _pings:
		p["age"] = float(p["age"]) + delta
	while not _pings.is_empty() and float(_pings[0]["age"]) > 12.0:
		_pings.remove_at(0)
	queue_redraw()


func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	if _active:
		var is_crisis: bool = str(_event.get("kind", "crisis")) == "crisis"
		var amp: float = 0.07 if cadet_soft else 0.16
		var tint: Color = Color(1.0, 0.1, 0.1) if is_crisis else Color(0.2, 0.9, 0.4)
		draw_rect(Rect2(Vector2.ZERO, size), Color(tint, amp * (0.5 + 0.5 * sin(_t * 5.0))))
		# title banner
		draw_rect(Rect2(0.0, 0.0, size.x, 210.0), Color(0.25, 0.0, 0.02, 0.85) if is_crisis else Color(0.0, 0.18, 0.08, 0.85))
		var prefix: String = "ALERT: " if is_crisis else "CHANCE: "
		draw_string(font, Vector2(40.0, 70.0), prefix + str(_event.get("title", "Crisis")).to_upper(), HORIZONTAL_ALIGNMENT_LEFT, size.x - 320.0, 60, BCTheme.RED if is_crisis else BCTheme.GREEN)
		draw_multiline_string(font, Vector2(40.0, 125.0), str(_event.get("flavor", "")), HORIZONTAL_ALIGNMENT_LEFT, size.x - 320.0, 36, 2, BCTheme.WHITE)
		# countdown ring
		var rc := Vector2(size.x - 120.0, 105.0)
		var frac: float = _left / _total
		draw_arc(rc, 70.0, 0.0, TAU, 48, Color(1, 1, 1, 0.2), 14.0)
		var ring_col: Color = BCTheme.GREEN if frac > 0.5 else (BCTheme.YELLOW if frac > 0.25 else BCTheme.RED)
		draw_arc(rc, 70.0, -PI * 0.5, -PI * 0.5 + TAU * frac, 48, ring_col, 14.0)
		draw_string(font, Vector2(rc.x - 60.0, rc.y + 22.0), str(int(ceil(_left))), HORIZONTAL_ALIGNMENT_CENTER, 120.0, 64, BCTheme.WHITE)
		# who has acted
		var by: float = size.y - 190.0
		var slot: float = minf(300.0, (size.x - 80.0) / 4.0)
		for i in 4:
			var role: String = BCTheme.ROLES[i]
			var cx: float = size.x * 0.5 + (float(i) - 1.5) * slot
			var col: Color = BCTheme.role_color(role)
			var done: bool = _acted.has(role)
			draw_circle(Vector2(cx - 90.0, by), 30.0, col if done else Color(col, 0.25))
			draw_arc(Vector2(cx - 90.0, by), 30.0 + (0.0 if done else 4.0 * sin(_t * 6.0)), 0.0, TAU, 24, col, 4.0)
			if done:
				draw_polyline(PackedVector2Array([Vector2(cx - 104.0, by), Vector2(cx - 94.0, by + 11.0), Vector2(cx - 76.0, by - 10.0)]), BCTheme.NAVY, 6.0)
			draw_string(font, Vector2(cx - 48.0, by + 12.0), BCTheme.role_name(role), HORIZONTAL_ALIGNMENT_LEFT, 200.0, 36, col)
	if _radio:
		var on: bool = int(_t * 2.0) % 2 == 0
		draw_rect(Rect2(size.x * 0.5 - 330.0, 220.0, 660.0, 70.0), Color(0.0, 0.0, 0.0, 0.85))
		draw_rect(Rect2(size.x * 0.5 - 330.0, 220.0, 660.0, 70.0), BCTheme.RED if on else BCTheme.WHITE, false, 4.0)
		draw_string(font, Vector2(size.x * 0.5 - 330.0, 270.0), "RADIO SILENCE", HORIZONTAL_ALIGNMENT_CENTER, 660.0, 52, BCTheme.RED if on else BCTheme.WHITE)
		var py: float = 340.0
		for p in _pings:
			draw_string(font, Vector2(40.0, py), "%s: %s" % [BCTheme.role_name(str(p["role"])), str(p["text"])], HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.5, 36, BCTheme.role_color(str(p["role"])))
			py += 46.0
	if _result_left > 0.0:
		var residual: float = float(_result.get("residual", -1.0))
		var head := "CRISIS OVER"
		var hc: Color = BCTheme.AMBER
		if residual >= 0.0 and residual <= 0.05:
			head = "CRISIS AVERTED!"
			hc = BCTheme.GREEN
		elif residual > 0.05 and residual < 0.6:
			head = "DAMAGE LIMITED"
			hc = BCTheme.YELLOW
		elif residual >= 0.6:
			head = "OOPS! WE TOOK A HIT"
			hc = BCTheme.RED
		draw_rect(Rect2(0.0, size.y * 0.5 - 150.0, size.x, 300.0), Color(0, 0, 0, 0.8))
		draw_string(font, Vector2(0.0, size.y * 0.5 - 40.0), head, HORIZONTAL_ALIGNMENT_CENTER, size.x, 96, hc)
		draw_multiline_string(font, Vector2(120.0, size.y * 0.5 + 40.0), str(_result.get("line", "")), HORIZONTAL_ALIGNMENT_CENTER, size.x - 240.0, 36, 3, BCTheme.WHITE)
