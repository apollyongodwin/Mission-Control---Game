# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name DemoMode
extends Node
## Fully deterministic scripted tour for the pitch video (no randomness, fixed timings).
## It drives a BroadcastLayer directly: build a ship, launch poll, countdown, one crisis, debrief.
## Start it with F9 or layer.play_demo().

signal finished

var _stop: bool = false


func stop() -> void:
	_stop = true


func _wait(s: float) -> bool:
	if not is_inside_tree():
		return false
	await get_tree().create_timer(s).timeout
	return not _stop and is_inside_tree()


func run(layer: BroadcastLayer) -> void:
	await _script(layer)
	layer.auto_launch = true
	finished.emit()
	queue_free()


func _script(layer: BroadcastLayer) -> void:
	layer.announcer.reset_counts()
	var preset: Dictionary = {}
	for b in Data.db["bot_presets"]["bagyo_watch"]:
		if b["name"] == "cautious":
			preset = b["design"]
	var d: Dictionary = {
		"scenario": "bagyo_watch", "orbit": "leo_sso_700", "bus": "bus_micro", "panel": "si_2", "rtg_count": 0,
		"battery": "bat_300", "comm": "uhf_omni", "adcs": "adcs_basic", "obc": "obc_basic", "shield": "shield_none",
		"prop": "prop_none", "rocket": "swift", "stations": ["iligan_gs"], "instruments": ["rain_gauge_relay"],
	}
	layer.drive_phase("DESIGN")
	layer.drive_design(d)
	if not await _wait(2.0):
		return
	for key in ["orbit", "bus", "panel", "battery", "comm", "adcs", "obc", "shield"]:
		d[key] = preset[key]
		layer.drive_design(d)
		if not await _wait(1.6):
			return
	for iid in preset["instruments"]:
		if not d["instruments"].has(iid):
			d["instruments"].append(iid)
			layer.drive_design(d)
			if not await _wait(1.6):
				return
	layer.drive_phase("REVIEW")
	if not await _wait(2.5):
		return
	for role in BCTheme.ROLES:
		layer.drive_poll(role, true)
		if not await _wait(2.0):
			return
	layer.auto_launch = false
	layer.drive_phase("LAUNCH")
	layer.start_launch(94.0, 6.0, true)
	if not await _wait(12.0):
		return
	layer.drive_phase("FLIGHT")
	if not await _wait(5.0):
		return
	var ev: Dictionary = Data.by_id(Data.db["events"], "solar_flare")
	layer.show_crisis(ev, 12.0, true)
	if not await _wait(2.0):
		return
	layer.add_ping("systems", "need_power")
	if not await _wait(2.0):
		return
	layer.crisis_acted("flight")
	layer.add_ping("flight", "on_it")
	if not await _wait(2.0):
		return
	layer.crisis_acted("systems")
	if not await _wait(2.0):
		return
	layer.crisis_resolved({"residual": 0.0, "line": "Your power margin and shielding absorbed the flare. Margins are your safety net."})
	layer.set_radio_silence(false)
	if not await _wait(8.0):
		return
	layer.drive_phase("DEBRIEF")
	layer.show_report({"grade": "A"})
	await _wait(6.0)
