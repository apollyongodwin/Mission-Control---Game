# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name OrbitView
extends Control
## Planet (or Moon, or Jupiter), the chosen orbit, a moving satellite, an eclipse shadow
## and ground-station dots that light up during passes.
## Use: orbit_view.set_design(design). Drawing is schematic, not to scale.

signal pass_started(station_id: String)
signal eclipse_changed(in_eclipse: bool)

## LEAD (round 8) REAL ORBITS. Each orbit is a real (compressed) Kepler orbit in 3D:
##   rp / ra   closest / farthest distance in planet radii (low orbits drawn a little higher so you can see them)
##   i         inclination to the equator (degrees)      raan  where the orbit crosses the equator (vs the Sun line)
##   argp      where the closest point is (90 = over the north pole, -90 = over the south pole)
##   e > 1 (hyp) for the Jupiter flybys
## Kepler timing: the satellite whips past the close point and lingers at the far point, like the real thing.
## Earth spins (with its 23.4 degree tilt), so a geostationary satellite stays over the Philippines while
## a low orbit's ground track slides under it. Eclipse = really inside the planet's shadow cylinder.
## Ground stations sit at their real latitude/longitude and only connect when the satellite is above their horizon.
## The camera: Sun to the left, north up, looking along the orbit of the planet around the Sun.
const ELEMENTS := {
	"leo_sso_700": {"rp": 1.16, "ra": 1.16, "i": 98.0, "raan": 0.0, "argp": 0.0},          # noon-midnight plane: face-on
	"leo_dawndusk_700": {"rp": 1.16, "ra": 1.16, "i": 98.0, "raan": 90.0, "argp": 0.0},    # rides the day/night line
	"leo_tropical_600": {"rp": 1.15, "ra": 1.15, "i": 20.0, "raan": -25.0, "argp": 0.0},
	"leo_low_400": {"rp": 1.10, "ra": 1.10, "i": 51.6, "raan": -40.0, "argp": 0.0},        # space-station orbit
	"geo_35786": {"rp": 6.6, "ra": 6.6, "i": 0.0, "raan": 90.0, "argp": 0.0},              # real scale: 6.6 Earth radii
	"lunar_polar_100": {"rp": 1.12, "ra": 1.12, "i": 90.0, "raan": 50.0, "argp": 0.0},
	"lunar_elfo_south": {"rp": 1.5, "ra": 5.0, "i": 60.0, "raan": 0.0, "argp": 90.0},      # far point over the SOUTH pole
	"lunar_nrho": {"rp": 1.25, "ra": 9.0, "i": 90.0, "raan": 70.0, "argp": 90.0},          # Gateway: low over north, far south
	"jup_orbiter_polar": {"rp": 1.1, "ra": 8.0, "i": 90.0, "raan": 15.0, "argp": 20.0},    # Juno-like: skims the cloud tops
	"jup_flyby_direct": {"rp": 4.0, "e": 1.8, "i": 35.0, "raan": 0.0, "argp": -90.0},   # fast: a gentle bend
	"jup_flyby_assist": {"rp": 2.6, "e": 1.35, "i": 35.0, "raan": 0.0, "argp": -90.0},  # slower arrival: a sharper bend
}
const EARTH_TILT := 23.4
const CAM_ELEV := 20.0   # the camera looks from a little above, so rings seen edge-on still look like rings
const PH_LON := 124.0   # the Philippines: the Earth starts turned so it faces us
## Real places (latitude, longitude). Visual: where each dot sits on the spinning planet.
const STATION_LATLON := {
	"iligan_gs": [8.2, 124.2], "svalbard_gs": [78.2, 15.4], "perth_gs": [-31.9, 115.9], "santiago_gs": [-33.4, -70.7],
	"hawaii_gs": [19.9, -155.6], "optical_gs": [34.4, -117.7], "dsn_like": [-35.4, 149.0], "commercial_net": [1.3, 103.8],
}
## Big land blobs (lat, lon, size in planet radii). Not a map, just enough to see the Earth turn.
const LAND := [[5.0, 20.0, 0.34], [50.0, 15.0, 0.16], [48.0, 90.0, 0.36], [20.0, 80.0, 0.16], [15.0, 103.0, 0.12],
	[-25.0, 134.0, 0.22], [45.0, -100.0, 0.32], [-15.0, -60.0, 0.26], [72.0, -40.0, 0.12], [-80.0, 0.0, 0.3],
	[-80.0, 120.0, 0.3], [-80.0, -120.0, 0.3], [62.0, 100.0, 0.25], [-2.0, 113.0, 0.08]]
const PH_ISLANDS := [[17.0, 121.0, 0.035], [14.5, 121.5, 0.03], [12.0, 123.5, 0.025], [10.5, 123.0, 0.025], [7.5, 124.5, 0.04], [9.5, 118.5, 0.02]]

var design: Dictionary = {}
var speed_mult: float = 1.0
var _orbit: Dictionary = {}
var _path := PackedVector2Array()
var _depth := PackedFloat32Array()   # MERGE (Lead): +1 = in front of the planet, -1 = behind it (3D-ish look)
var _p3 := PackedVector3Array()      # round 8: the real 3D position (planet radii) at each time step
var _spin_period_s: float = 0.0      # round 8: seconds for the planet to turn once (0 = it does not visibly turn)
var _rot0: float = 0.0
var _stars: Array = []
var _closed: bool = true
var _t: float = 0.0
var _R: float = 100.0
var _c := Vector2.ZERO
var _sat := Vector2.ZERO
var _u: float = 0.0
var _in_eclipse: bool = false
var _eclipse_on: bool = false
var _lit: Dictionary = {}
var _link_lit: bool = false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	resized.connect(_fit)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 70:
		_stars.append([Vector2(rng.randf(), rng.randf()), rng.randf_range(0.7, 2.0), rng.randf() * TAU])


func _depth_at(u: float) -> float:
	if _depth.size() < 2:
		return 1.0
	var n: int = _depth.size() - 1
	var f: float = u * float(n)
	var i: int = mini(int(f), n - 1)
	return lerpf(_depth[i], _depth[i + 1], f - float(i))


## Orbit line in pieces: only the segments on one side of the planet (front = true / back = false).
func _draw_orbit_side(front: bool) -> void:
	var seg := PackedVector2Array()
	var col: Color = Color(BCTheme.AMBER, 0.85) if front else Color(BCTheme.AMBER, 0.28)
	var w: float = 3.5 if front else 2.0
	for i in _path.size():
		var on: bool = (_depth[i] >= 0.0) == front
		if on:
			seg.append(_c + _path[i] * _R)
		elif seg.size() > 0:
			if seg.size() > 1:
				draw_polyline(seg, col, w, true)
			seg = PackedVector2Array()
	if seg.size() > 1:
		draw_polyline(seg, col, w, true)


func _draw_sat_and_trail(front: bool) -> void:
	for k in range(1, 11):
		var uu: float = fposmod(_u - float(k) * 0.012, 1.0)
		if (_depth_at(uu) >= 0.0) != front:
			continue
		var back: Vector2 = _c + _path_at(uu) * _R
		draw_circle(back, 6.0 - float(k) * 0.45, Color(1, 1, 1, (0.5 - float(k) * 0.045) * (1.0 if front else 0.5)))
	if (_depth_at(_u) >= 0.0) != front:
		return
	var dim: float = 1.0 if front else 0.55
	var body: Color = Color(1, 1, 1, 0.45 * dim) if _in_eclipse else Color(1, 1, 1, dim)
	var s: float = 1.0 if front else 0.8   # a little smaller on the far side
	draw_line(_sat + Vector2(-22.0, 0.0) * s, _sat + Vector2(22.0, 0.0) * s, Color(0.3, 0.55, 1.0, body.a), 6.0 * s)
	draw_rect(Rect2(_sat - Vector2(7.0, 7.0) * s, Vector2(14.0, 14.0) * s), body)
	if front and not _in_eclipse:
		draw_circle(_sat, 3.0 + 2.0 * sin(_t * 6.0), Color(1.0, 0.9, 0.5, 0.9))   # blinking beacon


func set_design(d: Dictionary) -> void:
	var old_orbit: String = str(design.get("orbit", ""))
	design = d.duplicate(true)
	if str(design.get("orbit", "")) != old_orbit or _path.is_empty():
		_build_path()
		_fit()


func _build_path() -> void:
	_path = PackedVector2Array()
	_depth = PackedFloat32Array()
	_p3 = PackedVector3Array()
	_orbit = Data.orbit(str(design.get("orbit", "")))
	if _orbit.is_empty():
		return
	var oid: String = str(_orbit["id"])
	var group: String = str(_orbit.get("group", "earth"))
	_eclipse_on = float(_orbit.get("eclipse_avg_frac", 0.0)) >= 0.05
	var el: Dictionary = ELEMENTS.get(oid, _guess_elements())
	var hyper: bool = el.has("e") and float(el["e"]) > 1.0
	_closed = not hyper
	var n := 240
	for k in n + 1:
		var f: float = float(k) / float(n)   # equal steps in TIME (mean anomaly), so speed follows Kepler's law
		var rv: Array = _hyper_point(el, f) if hyper else _ellipse_point(el, f)
		var pos: Vector3 = _orient(el, float(rv[0]), float(rv[1]), group)
		_p3.append(pos)
		var cam: Vector3 = _cam(pos)
		_path.append(Vector2(cam.x, -cam.y))
		_depth.append(cam.z)
	_rot0 = deg_to_rad(-90.0 - PH_LON)   # the Philippines face the camera at the start
	_spin_period_s = 0.0
	if group == "earth":
		# the Earth turns once in 1436 minutes; in this time-lapse the orbit takes _cycle_seconds()
		_spin_period_s = _cycle_seconds() * 1436.0 / maxf(1.0, float(_orbit.get("period_min", 99.0)))
		# geostationary: the orbit starts in front of the camera (raan 90), exactly above the Philippines, and the
		# Earth turns once per orbit, so it stays parked over them


func _guess_elements() -> Dictionary:
	## a modded orbit without an entry above: a plain circle sized from its range
	var r: float = {"leo": 1.2, "geo": 6.6, "lunar": 2.0, "deep": 4.0}.get(str(_orbit.get("range_class", "leo")), 1.6)
	return {"rp": r, "ra": r, "i": 30.0, "raan": 0.0, "argp": 0.0}


## Ellipse at time fraction f: returns [radius, true anomaly]. Solves Kepler's equation M = E - e sin E.
func _ellipse_point(el: Dictionary, f: float) -> Array:
	var rp: float = float(el["rp"])
	var ra: float = float(el["ra"])
	var a: float = (rp + ra) * 0.5
	var e: float = (ra - rp) / (ra + rp)
	var m: float = TAU * f
	var ea: float = m if e < 0.8 else PI
	for _i in 30:
		ea -= (ea - e * sin(ea) - m) / (1.0 - e * cos(ea))
	var nu: float = 2.0 * atan2(sqrt(1.0 + e) * sin(ea * 0.5), sqrt(1.0 - e) * cos(ea * 0.5))
	return [a * (1.0 - e * cos(ea)), nu]


## Hyperbola (flyby) at time fraction f: the visible part of the swing past the planet. M = e sinh H - H.
func _hyper_point(el: Dictionary, f: float) -> Array:
	var rp: float = float(el["rp"])
	var e: float = float(el["e"])
	var a: float = rp / (e - 1.0)
	var r_max: float = 9.0
	var h_max: float = acosh(clampf((r_max / a + 1.0) / e, 1.0, 1e6))
	var m_max: float = e * sinh(h_max) - h_max
	var m: float = lerpf(-m_max, m_max, f)
	var h: float = asinh(m / e)
	for _i in 30:
		h -= (e * sinh(h) - h - m) / (e * cosh(h) - 1.0)
	var nu: float = 2.0 * atan(sqrt((e + 1.0) / (e - 1.0)) * tanh(h * 0.5))
	return [a * (e * cosh(h) - 1.0), nu]


## Orbit plane -> 3D. y = north, x = away from the Sun (Sun is at -x), z = towards the viewer.
func _orient(el: Dictionary, r: float, nu: float, group: String) -> Vector3:
	var u: float = deg_to_rad(float(el.get("argp", 0.0))) + nu
	var om: float = deg_to_rad(float(el.get("raan", 0.0)))
	var inc: float = deg_to_rad(float(el.get("i", 0.0)))
	var node := Vector3(cos(om), 0.0, sin(om))
	var perp := Vector3(sin(om), 0.0, -cos(om))   # the prograde direction (west to east, like the Earth turns)
	var m := perp * cos(inc) + Vector3.UP * sin(inc)
	var p: Vector3 = (node * cos(u) + m * sin(u)) * r
	if group == "earth":
		p = _tilt(p)
	return p


## World -> camera (the camera is CAM_ELEV degrees above the plane, looking down a little). Shadows use world space.
func _cam(p: Vector3) -> Vector3:
	return p.rotated(Vector3.RIGHT, deg_to_rad(CAM_ELEV))


## The Earth's 23.4 degree tilt (northern summer: the north pole leans towards the Sun).
func _tilt(p: Vector3) -> Vector3:
	return p.rotated(Vector3.BACK, deg_to_rad(EARTH_TILT))


## A point on the (spinning) planet's surface, latitude/longitude in degrees -> 3D (unit sphere).
func _surface(lat: float, lon: float, group: String) -> Vector3:
	var spin: float = _rot0 + (TAU * _t / _spin_period_s if _spin_period_s > 0.0 else 0.0)
	var la: float = deg_to_rad(lat)
	var lo: float = deg_to_rad(lon) + spin
	var p := Vector3(cos(la) * cos(lo), sin(la), -cos(la) * sin(lo))   # turns west to east (prograde)
	return _tilt(p) if group == "earth" else p


## Where a surface point shows on screen, and whether it faces us (z > 0).
func _screen(p_world: Vector3) -> Vector3:
	return _cam(p_world)


func _fit() -> void:
	if _path.is_empty():
		return
	var lo := Vector2(-1.0, -1.0)
	var hi := Vector2(1.0, 1.0)
	for p in _path:
		lo = Vector2(minf(lo.x, p.x), minf(lo.y, p.y))
		hi = Vector2(maxf(hi.x, p.x), maxf(hi.y, p.y))
	var side_pad: float = 0.0 if str(_orbit.get("group", "earth")) == "earth" else 110.0
	var area := Rect2(0.0, 80.0, size.x - side_pad, size.y - 80.0 - 60.0)
	var bw: float = hi.x - lo.x
	var bh: float = hi.y - lo.y
	_R = minf(minf(area.size.x * 0.88 / bw, area.size.y * 0.86 / bh), minf(size.x, size.y) * 0.30)
	_c = area.position + area.size * 0.5 - (lo + hi) * 0.5 * _R


func _cycle_seconds() -> float:
	var period: float = float(_orbit.get("period_min", 0.0))
	if period <= 0.0:
		return 14.0
	return clampf(2.0 + period / 16.0, 6.0, 20.0)


func _path_at(u: float) -> Vector2:
	var n: int = _path.size() - 1
	var f: float = u * float(n)
	var i: int = mini(int(f), n - 1)
	return _path[i].lerp(_path[i + 1], f - float(i))


func _p3_at(u: float) -> Vector3:
	if _p3.size() < 2:
		return Vector3.ZERO
	var n: int = _p3.size() - 1
	var f: float = u * float(n)
	var i: int = mini(int(f), n - 1)
	return _p3[i].lerp(_p3[i + 1], f - float(i))


func _station_pos(sid: String) -> Vector3:
	var ll: Array = STATION_LATLON.get(sid, [0.0, 0.0])
	return _surface(float(ll[0]), float(ll[1]), "earth")


func _supports(station_id: String) -> bool:
	var st: Dictionary = Data.station(station_id)
	if st.is_empty():
		return false
	return st["ranges"].has(str(_orbit.get("range_class", "leo")))


func _process(delta: float) -> void:
	_t += delta * speed_mult
	if _path.size() > 2:
		_u = fposmod(_t / _cycle_seconds(), 1.0)
		var rel: Vector2 = _path_at(_u)
		_sat = _c + rel * _R
		var p3: Vector3 = _p3_at(_u)
		# round 8: really inside the shadow cylinder behind the planet (Sun at -x)
		var ecl: bool = _eclipse_on and p3.x > 0.0 and Vector2(p3.y, p3.z).length() < 1.0
		if ecl != _in_eclipse:
			_in_eclipse = ecl
			eclipse_changed.emit(ecl)
		_update_contacts(rel)
	queue_redraw()


func _update_contacts(rel: Vector2) -> void:
	var group: String = str(_orbit.get("group", "earth"))
	var chosen: Array = design.get("stations", [])
	var new_lit := {}
	if group == "earth":
		# round 8: a station hears the satellite only when it is above that station's horizon
		var p3: Vector3 = _p3_at(_u)
		for sid in chosen:
			var sp: Vector3 = _station_pos(str(sid))
			if _supports(str(sid)) and sp.dot(p3) >= 1.0 + 0.02:
				new_lit[sid] = true
	else:
		var earth := Vector2(size.x - 60.0, size.y * 0.5)
		var closest: Vector2 = Geometry2D.get_closest_point_to_segment(_c, _sat, earth)
		_link_lit = closest.distance_to(_c) > _R
		for sid in chosen:
			if _link_lit and _supports(str(sid)):
				new_lit[sid] = true
	for sid in new_lit:
		if not _lit.has(sid):
			pass_started.emit(str(sid))
	_lit = new_lit


func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	draw_rect(Rect2(Vector2.ZERO, size), Color(BCTheme.NAVY, 0.6))
	for st in _stars:
		draw_circle((st[0] as Vector2) * size, float(st[1]), Color(1, 1, 1, 0.25 + 0.25 * sin(_t * 1.3 + float(st[2]))))
	draw_rect(Rect2(Vector2.ZERO, size), Color(BCTheme.AMBER, 0.5), false, 3.0)
	if _path.size() < 3:
		draw_string(font, Vector2(20.0, size.y * 0.5), "No orbit chosen yet", HORIZONTAL_ALIGNMENT_CENTER, size.x - 40.0, 36, BCTheme.DIM)
		return
	var group: String = str(_orbit.get("group", "earth"))

	# sun on the left, shadow wedge on the right
	var sy: float = size.y * 0.5
	draw_circle(Vector2(34.0, sy), 20.0, Color(1.0, 0.85, 0.3))
	for k in 8:
		var dir := Vector2.RIGHT.rotated(TAU * float(k) / 8.0)
		draw_line(Vector2(34.0, sy) + dir * 26.0, Vector2(34.0, sy) + dir * 36.0, Color(1.0, 0.85, 0.3, 0.8), 3.0)
	draw_string(font, Vector2(6.0, sy + 66.0), "SUN", HORIZONTAL_ALIGNMENT_LEFT, -1, 26, BCTheme.YELLOW)
	if _eclipse_on:
		draw_rect(Rect2(_c.x, _c.y - _R, size.x - _c.x, _R * 2.0), Color(0, 0, 0, 0.35))

	# MERGE (Lead): depth order. Far half of the orbit and the satellite go BEHIND the planet.
	_draw_orbit_side(false)
	_draw_sat_and_trail(false)
	_draw_planet(group)
	_draw_orbit_side(true)

	# ground stations and links
	var contact_name := ""
	if group == "earth":
		for sid in design.get("stations", []):
			var s3: Vector3 = _screen(_station_pos(str(sid)))
			if s3.z < -0.05 and not _lit.has(sid):
				continue   # round 8: on the far side of the spinning Earth right now
			var sp: Vector2 = _c + Vector2(s3.x, -s3.y) * _R
			var lit: bool = _lit.has(sid)
			if lit:
				draw_line(sp, _sat, Color(BCTheme.GREEN, 0.85), 3.0)
				draw_arc(sp, 14.0 + 6.0 * sin(_t * 8.0), 0.0, TAU, 24, BCTheme.GREEN, 3.0)
				contact_name = str(Data.station(str(sid)).get("name", "")).split(" (")[0].replace(" [fictional]", "")
			draw_circle(sp, 9.0, BCTheme.GREEN if lit else BCTheme.DIM)
			draw_arc(sp, 9.0, 0.0, TAU, 16, BCTheme.WHITE, 2.0)
	else:
		var earth := Vector2(size.x - 60.0, size.y * 0.5)
		draw_circle(earth, 20.0, Color(0.15, 0.4, 0.8))
		draw_string(font, Vector2(earth.x - 60.0, earth.y + 56.0), "EARTH", HORIZONTAL_ALIGNMENT_CENTER, 120.0, 26, BCTheme.WHITE)
		if _link_lit and not _lit.is_empty():
			draw_line(_sat, earth, Color(BCTheme.GREEN, 0.85), 3.0)
			contact_name = "Earth link"
		else:
			draw_dashed_line(_sat, earth, Color(BCTheme.DIM, 0.6), 2.0, 8.0)

	# satellite (front side only; the far side was drawn before the planet)
	_draw_sat_and_trail(true)

	# text
	draw_string(font, Vector2(20.0, 50.0), str(_orbit.get("name", "")), HORIZONTAL_ALIGNMENT_LEFT, size.x - 40.0, 36, BCTheme.AMBER)
	var status := "In sunlight"
	var status_col: Color = BCTheme.YELLOW
	if _in_eclipse:
		status = "ECLIPSE: running on battery"
		status_col = BCTheme.RED
	elif group == "deep":
		status = "One-way signal time: %d min" % int(_orbit.get("one_way_delay_min", 0.0)) if float(_orbit.get("one_way_delay_min", 0.0)) > 0.0 else "Deep space"
		status_col = BCTheme.DIM
	draw_string(font, Vector2(20.0, size.y - 18.0), status, HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.55, 32, status_col)
	if contact_name != "":
		draw_string(font, Vector2(size.x * 0.5, size.y - 18.0), "CONTACT: " + contact_name, HORIZONTAL_ALIGNMENT_RIGHT, size.x * 0.5 - 20.0, 32, BCTheme.GREEN)


func _draw_planet(group: String) -> void:
	# MERGE (Lead): atmosphere glow first (Earth blue, Moon none, Jupiter warm haze)
	var glow: Color = {"earth": Color(0.45, 0.75, 1.0), "deep": Color(1.0, 0.8, 0.55)}.get(group, Color(0, 0, 0, 0))
	if glow.a > 0.0:
		for i in 6:
			draw_circle(_c, _R * (1.0 + 0.035 * float(6 - i)), Color(glow, 0.05))
	if group == "earth":
		draw_circle(_c, _R, Color(0.10, 0.30, 0.62))
		draw_circle(_c + Vector2(-0.25, -0.25) * _R, _R * 0.7, Color(0.16, 0.42, 0.78, 0.6))   # ocean shine
		# round 8: the land turns with the Earth (so you can SEE geostationary hovering and low orbits sliding)
		for patch in LAND:
			var p3: Vector3 = _screen(_surface(float(patch[0]), float(patch[1]), "earth"))
			if p3.z > 0.0:
				draw_circle(_c + Vector2(p3.x, -p3.y) * _R, float(patch[2]) * _R * (0.45 + 0.55 * p3.z), Color(0.2, 0.55, 0.3))
		for isl in PH_ISLANDS:   # the Philippines (Bagyo Watch!)
			var q3: Vector3 = _screen(_surface(float(isl[0]), float(isl[1]), "earth"))
			if q3.z > 0.0:
				draw_circle(_c + Vector2(q3.x, -q3.y) * _R, float(isl[2]) * _R * (0.5 + 0.5 * q3.z) + 1.0, Color(0.45, 0.8, 0.4))
		# slow drifting clouds (kept inside the disc)
		for k in 7:
			var a: float = float(k) * 0.9 + _t * 0.05
			var rr: float = (0.25 + 0.1 * float(k % 3)) * _R
			var cp: Vector2 = _c + Vector2(cos(a) * 0.62, sin(a * 1.7) * 0.55) * _R
			if cp.distance_to(_c) + rr * 0.4 < _R:
				draw_circle(cp, rr * 0.3, Color(1, 1, 1, 0.06))
		# the tilted axis, so the 23.4 degree lean is visible
		var ax: Vector3 = _screen(_tilt(Vector3.UP))
		draw_line(_c + Vector2(ax.x, -ax.y) * _R * 1.0, _c + Vector2(ax.x, -ax.y) * _R * 1.12, Color(1, 1, 1, 0.5), 2.0)
	elif group == "moon":
		draw_circle(_c, _R, Color(0.62, 0.62, 0.64))
		for cr in [[-0.35, -0.25, 0.18], [0.3, 0.2, 0.25], [-0.1, 0.55, 0.12], [0.45, -0.4, 0.1]]:
			draw_circle(_c + Vector2(cr[0], cr[1]) * _R, float(cr[2]) * _R, Color(0.48, 0.48, 0.5))
	else:
		draw_circle(_c, _R, Color(0.80, 0.62, 0.42))
		for k in range(-4, 5):
			var y: float = float(k) * 0.2 * _R
			var hw: float = sqrt(maxf(0.0, _R * _R - y * y))
			var band: Color = Color(0.65, 0.42, 0.28) if k % 2 == 0 else Color(0.92, 0.80, 0.62)
			draw_line(_c + Vector2(-hw, y), _c + Vector2(hw, y), band, _R * 0.14)
	# soft night side: a few overlapping shadow bands, so day fades into night instead of a hard edge
	for j in 6:
		# the part of the disc to the right of x = x0: an arc from -th to +th (the chord closes it)
		var th: float = acos(clampf(-0.15 + 0.06 * float(j), -0.99, 0.99))
		var night := PackedVector2Array()
		for i in 33:
			var a: float = -th + 2.0 * th * float(i) / 32.0
			night.append(_c + Vector2(cos(a), sin(a)) * _R)
		draw_colored_polygon(night, Color(0, 0, 0.05, 0.085))
	if group == "earth":   # city lights on the night side
		for cl in [[0.35, -0.2], [0.5, 0.1], [0.2, 0.35], [0.6, -0.4], [0.3, 0.6]]:
			draw_circle(_c + Vector2(cl[0], cl[1]) * _R, 2.5, Color(1.0, 0.85, 0.4, 0.7))
	draw_arc(_c, _R, 0.0, TAU, 64, Color(0.7, 0.85, 1.0, 0.8), 3.0)
