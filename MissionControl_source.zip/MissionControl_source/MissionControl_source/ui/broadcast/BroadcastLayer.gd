# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name BroadcastLayer
extends Control
## Dev C, Part 2: the "wow" layer of Mission Control. Add ONE instance of BroadcastLayer.tscn
## on top of BroadcastMain and everything below happens by itself.
##
## It watches MissionState (if that autoload exists) for design and phase changes.
## The Lead (or anything else) can also drive it directly. These calls also work from anywhere via
##   get_tree().call_group("broadcast_layer", "show_crisis", event, 25.0, false)
##
##   set_phase(phase)                    set_design(design, difficulty)
##   show_crisis(event, timer_s, radio)  crisis_acted(role)   add_ping(role, card_id)
##   crisis_resolved(result)             set_radio_silence(on)
##   announce_poll(role, go)             start_launch(reliability_pct, seconds, success)
##   show_report(report)                 say(text)   play_demo()   stop_demo()

signal sfx_requested(sfx_name: String)
signal launch_finished(success: bool)

const PHASES := ["LOBBY", "BRIEFING", "DESIGN", "REVIEW", "LAUNCH", "FLIGHT", "DEBRIEF"]
## Where each piece sits, as fractions of the screen (x, y, width, height).
## If this layer overlaps something from Part 1, change the numbers here and nowhere else.
const LAYOUT := {
	"ship_design": Rect2(0.50, 0.12, 0.48, 0.52),
	"health": Rect2(0.50, 0.65, 0.48, 0.09),
	"ship_flight": Rect2(0.02, 0.52, 0.28, 0.34),
	"orbit": Rect2(0.33, 0.10, 0.65, 0.72),
}
const TICKER_H := 64.0
const LIGHT_OWNER := {"mass": "systems", "power": "systems", "budget": "ground", "data": "payload", "comms": "ground", "time": "ground", "lifetime": "flight"}

var phase: String = ""
var design: Dictionary = {}
var difficulty: String = "engineer"
var auto_launch: bool = true    # start the countdown by itself when phase becomes LAUNCH
var ship: ShipSchematic
var orbit_view: OrbitView
var health: HealthStrip
var ticker: Ticker
var crisis: CrisisOverlay
var launch: LaunchSequence
var announcer: Announcer
var _result: Dictionary = {}
var _last_lights: Dictionary = {}
var _launch_success: bool = true
var _demo: DemoMode = null
var use_slots: bool = false     # true when BroadcastMain tells us where to draw (see place_slot)
var show_health: bool = true    # BroadcastMain has its own health panel, so it turns ours off
var launch_seconds: float = 10.0
var _slots: Dictionary = {}
var _ms: Node = null


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_to_group("broadcast_layer")
	ship = ShipSchematic.new()
	orbit_view = OrbitView.new()
	health = HealthStrip.new()
	ticker = Ticker.new()
	crisis = CrisisOverlay.new()
	launch = LaunchSequence.new()
	announcer = Announcer.new()
	for n in [ship, orbit_view, health, ticker, crisis, launch, announcer]:
		add_child(n)
	crisis.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	launch.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	announcer.line_said.connect(_on_line_said)
	launch.tick.connect(_on_tick)
	launch.liftoff.connect(_on_liftoff)
	launch.finished.connect(_on_launch_finished)
	resized.connect(_layout)
	ticker.push("MISSION CONTROL ONLINE", BCTheme.AMBER)
	set_phase("LOBBY")
	_hook_mission_state()


func _unhandled_key_input(event: InputEvent) -> void:
	# F9 toggles the deterministic Demo Mode tour
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F9:
		if _demo == null:
			play_demo()
		else:
			stop_demo()


# ---------------------------------------------------------------- MissionState hookup (optional)
func _hook_mission_state() -> void:
	bind_state(get_node_or_null("/root/MissionState"))


## Use this state object (the real MissionState or BroadcastMain's fake one). Safe to call twice.
func bind_state(node: Node) -> void:
	if node == null or node == _ms:
		return
	_ms = node
	_connect_flex(_ms, "design_changed", _pull_design)
	_connect_flex(_ms, "phase_changed", _pull_phase)
	_pull_design()
	_pull_phase()


## BroadcastMain calls this to say "draw the ship / orbit view inside this rectangle" (name: "ship" or "orbit").
func place_slot(slot_name: String, rect: Rect2) -> void:
	_slots[slot_name] = rect
	_apply_visibility()


func clear_slots() -> void:
	_slots.clear()
	_apply_visibility()


## Connects a signal to a handler that takes no arguments, whatever arguments the signal sends.
func _connect_flex(obj: Object, sig: String, handler: Callable) -> void:
	if not obj.has_signal(sig):
		return
	var argc: int = 0
	for s in obj.get_signal_list():
		if s["name"] == sig:
			argc = s["args"].size()
	if argc > 0:
		obj.connect(sig, handler.unbind(argc))
	else:
		obj.connect(sig, handler)


func _pull_design() -> void:
	var ms: Node = _ms
	if ms == null:
		return
	var d = ms.get("design")
	if typeof(d) != TYPE_DICTIONARY:
		return
	var diff = ms.get("difficulty")
	var diff_s: String = ""
	if diff != null and Data.db["meta"]["difficulty"].has(str(diff)):
		diff_s = str(diff)
	set_design(d, diff_s)


func _pull_phase() -> void:
	var ms: Node = _ms
	if ms == null:
		return
	var p = ms.get("phase")
	if typeof(p) == TYPE_INT:
		if p >= 0 and p < PHASES.size():
			set_phase(PHASES[p])
	elif p != null:
		set_phase(str(p))


# ---------------------------------------------------------------- layout
func _rect(key: String) -> Rect2:
	var r: Rect2 = LAYOUT[key]
	return Rect2(r.position.x * size.x, r.position.y * size.y, r.size.x * size.x, r.size.y * size.y)


func _layout() -> void:
	var sr: Rect2 = _rect("ship_flight" if phase == "FLIGHT" else "ship_design")
	if _slots.has("ship"):
		sr = _slots["ship"]
	ship.position = sr.position
	ship.size = sr.size
	var hr: Rect2 = _rect("health")
	health.position = hr.position
	health.size = hr.size
	var orr: Rect2 = _rect("orbit")
	if _slots.has("orbit"):
		orr = _slots["orbit"]
	orbit_view.position = orr.position
	orbit_view.size = orr.size
	ticker.position = Vector2(0.0, size.y - TICKER_H)
	ticker.size = Vector2(size.x, TICKER_H)


func _apply_visibility() -> void:
	var building: bool = phase == "DESIGN" or phase == "REVIEW" or phase == "LAUNCH"
	var flying: bool = phase == "FLIGHT"
	if use_slots:
		ship.visible = _slots.has("ship")
		orbit_view.visible = _slots.has("orbit")
	else:
		ship.visible = building or flying
		orbit_view.visible = flying
	health.visible = building and show_health and not use_slots
	ticker.visible = building or flying
	ship.show_caption = not flying
	if not flying:
		crisis.clear()
	_layout()


# ---------------------------------------------------------------- public API
func set_phase(p: String) -> void:
	p = p.to_upper()
	if p == phase:
		return
	phase = p
	_slots.clear()
	_apply_visibility()
	match p:
		"DESIGN":
			announcer.say_key("design")
		"REVIEW":
			announcer.say_key("poll")
		"LAUNCH":
			if auto_launch:
				start_launch(float(_result.get("launch_success_prob", 0.95)) * 100.0, launch_seconds, true)


func set_design(d: Dictionary, diff: String = "") -> void:
	if diff != "":
		difficulty = diff
	var old: Dictionary = design
	design = d.duplicate(true)
	ship.set_design(design)
	orbit_view.set_design(design)
	for ch in Ticker.describe_change(old, design):
		ticker.push(str(ch["text"]), BCTheme.role_color(str(ch["role"])))
		_sfx("snap")
	_update_lights()


func _update_lights() -> void:
	if not design.has("scenario") or not design.has("orbit") or str(design["orbit"]) == "":
		return
	var full: Dictionary = SimEngine._with_defaults(design)
	for cat in ["bus", "panel", "battery", "comm", "adcs", "obc", "shield", "prop"]:
		if Data.part(cat, str(full[cat])).is_empty():
			return
	if Data.orbit(str(full["orbit"])).is_empty() or Data.rocket(str(full["rocket"])).is_empty():
		return
	for iid in full["instruments"]:
		if Data.instrument(str(iid)).is_empty():
			return
	for sid in full["stations"]:
		if Data.station(str(sid)).is_empty():
			return
	var res: Dictionary = SimEngine.evaluate(Data.db, full, difficulty)
	if not res.has("lights"):
		health.set_lights({})
		return
	_result = res
	var lights: Dictionary = res["lights"]
	health.set_lights(lights)
	var all_green: bool = true
	for k in lights:
		if lights[k] != "green":
			all_green = false
		if not _last_lights.is_empty() and lights[k] == "red" and _last_lights.get(k, "") != "red":
			var who: String = str(LIGHT_OWNER.get(k, "systems"))
			ticker.push("%s: the %s light just turned red" % [BCTheme.role_name(who), str(k).to_upper()], BCTheme.RED)
			_sfx("buzz")
	if all_green and not _last_lights.is_empty():
		var was_green: bool = true
		for k in _last_lights:
			if _last_lights[k] != "green":
				was_green = false
		if not was_green:
			ticker.push("All lights green. Ready for Design Review!", BCTheme.GREEN)
			_sfx("chime")
	_last_lights = lights.duplicate()


func show_crisis(event: Dictionary, timer_s: float, radio_silence: bool = false) -> void:
	crisis.cadet_soft = difficulty == "cadet"
	crisis.start(event, timer_s, radio_silence)
	var kind: String = str(event.get("kind", "crisis"))
	if kind == "crisis":
		announcer.say_key("crisis", {"title": str(event.get("title", "Crisis"))})
		_sfx("alarm")
	else:
		announcer.say_key("opportunity")
		_sfx("chime")
	if radio_silence:
		announcer.say_key("radio")


func crisis_acted(role: String) -> void:
	crisis.mark_acted(role)
	ticker.push("%s has acted" % BCTheme.role_name(role), BCTheme.role_color(role))


func set_radio_silence(on: bool) -> void:
	crisis.set_radio_silence(on)


func add_ping(role: String, card_id: String) -> void:
	crisis.add_ping(role, card_id)
	ticker.push("PING from %s: %s" % [BCTheme.role_name(role), card_id.replace("_", " ").to_upper()], BCTheme.role_color(role))


func crisis_resolved(result: Dictionary) -> void:
	crisis.resolve(result)
	var residual: float = float(result.get("residual", 1.0))
	if residual <= 0.05:
		announcer.say_key("crisis_ok")
		_sfx("success")
	else:
		announcer.say_key("crisis_hit")
		_sfx("hit")
		Fx.shake(self, 6.0 + 20.0 * residual, 0.5)   # MERGE (juice): the broadcast rattles when the ship gets hurt
		if residual > 0.5:
			Fx.explosion(self, ship.position + ship.size / 2.0, 0.6)
	if str(result.get("line", "")) != "":
		ticker.push(str(result["line"]), BCTheme.WHITE)


func announce_poll(role: String, go: bool) -> void:
	announcer.say_key("go" if go else "nogo", {"role": BCTheme.role_name(role)})
	if not go:
		Audio.play_sfx("sad_trombone")   # MERGE (juice): wah wah wah waaah
	if go:
		_sfx("chime")


func start_launch(reliability_pct: float, seconds: float = 10.0, success: bool = true) -> void:
	_launch_success = success
	launch.start(reliability_pct, seconds, success)
	announcer.say_key("countdown")


func show_report(report: Dictionary) -> void:
	if bool(report.get("out_of_lives", false)):
		announcer.say("Out of lives. Mission Control calls it off. Regroup, re-read the handbook, and fly again!")
	elif bool(report.get("mission_lost", false)):
		announcer.say_key("lost")
	else:
		announcer.say_key("debrief", {"grade": str(report.get("grade", "?"))})


func say(text: String) -> void:
	announcer.say(text)


## Demo helpers: when BroadcastMain's FakeMissionState is bound, the demo moves the whole screen
## (Part 1 content too). With the real MissionState (or none) it only moves this layer.
func _is_fake() -> bool:
	return _ms != null and _ms.has_method("set_phase_index")


func drive_phase(p: String) -> void:
	if _is_fake():
		_ms.call("set_phase_index", PHASES.find(p))
	else:
		set_phase(p)


func drive_design(d: Dictionary) -> void:
	if _is_fake():
		_ms.set("design", d.duplicate(true))
		_ms.emit_signal("design_changed")
	else:
		set_design(d)


func drive_poll(role: String, go: bool) -> void:
	if _is_fake() and typeof(_ms.get("poll")) == TYPE_DICTIONARY:
		var pl: Dictionary = _ms.get("poll")
		pl[role] = {"go": go, "reason": ""}
		_ms.emit_signal("poll_changed")
	announce_poll(role, go)


func play_demo() -> void:
	stop_demo()
	_demo = DemoMode.new()
	add_child(_demo)
	_demo.finished.connect(_on_demo_finished.bind(_demo))
	_demo.run(self)


func _on_demo_finished(which: DemoMode) -> void:
	if _demo == which:
		_demo = null


func stop_demo() -> void:
	if _demo != null:
		_demo.stop()
		_demo = null


# ---------------------------------------------------------------- internal
func _sfx(n: String) -> void:
	sfx_requested.emit(n)
	var audio: Node = get_node_or_null("/root/Audio")
	if audio != null and audio.has_method("play_sfx"):
		audio.call("play_sfx", n)


func _on_line_said(text: String) -> void:
	ticker.push("MISSION CONTROL: " + text, BCTheme.WHITE)


func _on_tick(_n: int) -> void:
	_sfx("tick")


func _on_liftoff() -> void:
	ship.thrusting = true
	announcer.say_key("liftoff")
	_sfx("liftoff")


func _on_launch_finished(success: bool) -> void:
	ship.thrusting = false
	if not success:   # MERGE (juice): KABOOM. Big, loud, a little funny.
		Audio.play_sfx("explosion")
		Fx.flash(self, Color(1.0, 0.85, 0.5, 0.9), 0.6)
		Fx.shake(self, 30.0, 1.0)
		Fx.explosion(self, size * Vector2(0.5, 0.45), 2.0)
		ticker.push("RAPID UNSCHEDULED DISASSEMBLY. (Yes, rocket engineers really call it that.)", BCTheme.RED)
	announcer.say_key("orbit" if success else "anomaly")
	launch_finished.emit(success)
