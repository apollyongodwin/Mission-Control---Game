# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name HealthStrip
extends Control
## The row of 7 health icons (mass, power, budget, data, comms, time, lifetime).
## Only red and amber ones pulse (UX_GUIDE section 5).

const KEYS := ["mass", "power", "budget", "data", "comms", "time", "lifetime"]
const LABELS := {"mass": "MASS", "power": "POWER", "budget": "COST", "data": "DATA", "comms": "COMMS", "time": "TIME", "lifetime": "LIFE"}

var lights: Dictionary = {}
var _t: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_lights(l: Dictionary) -> void:
	lights = l.duplicate()


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	var n: int = KEYS.size()
	var slot: float = size.x / float(n)
	var r: float = minf(slot * 0.28, size.y * 0.32)
	for i in n:
		var k: String = KEYS[i]
		var state: String = str(lights.get(k, "none"))
		var c := Vector2(slot * (float(i) + 0.5), size.y * 0.38)
		var pulse: float = 0.0
		if state == "red" or state == "amber":
			pulse = 0.5 + 0.5 * sin(_t * 6.0)
		BCTheme.draw_light(self, c, r, state, pulse)
		if slot >= 90.0:
			draw_string(font, Vector2(slot * float(i), size.y - 6.0), LABELS[k], HORIZONTAL_ALIGNMENT_CENTER, slot, 24, BCTheme.WHITE)
