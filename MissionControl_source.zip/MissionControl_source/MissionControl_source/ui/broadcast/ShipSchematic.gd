# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name ShipSchematic
extends Control
## Draws the spacecraft from the design Dictionary with _draw(). Updates live.
## Use: ship.set_design(design)   (the same Dictionary shape as GAME_SPEC section 3)

var design: Dictionary = {}
var thrusting: bool = false    # set true during launch to show a flame
var show_caption: bool = true
var _pop: float = 0.0
var _t: float = 0.0

const BUS_W := [60.0, 82.0, 108.0, 138.0]
const BUS_H := [60.0, 92.0, 128.0, 168.0]
const DISH_R := {"uhf_omni": 0.0, "s_band_patch": 10.0, "x_band_steer": 16.0, "x_band_hga": 28.0, "ka_band": 34.0, "optical_terminal": 0.0}
const TAG_COLORS := [
	Color(0.95, 0.45, 0.35), Color(0.35, 0.75, 0.95), Color(0.55, 0.9, 0.45), Color(0.95, 0.8, 0.3),
	Color(0.75, 0.5, 0.95), Color(0.3, 0.9, 0.8), Color(0.95, 0.6, 0.8), Color(0.7, 0.75, 0.3),
]


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true


func set_design(d: Dictionary) -> void:
	if d.hash() != design.hash():
		_pop = 1.0
	design = d.duplicate(true)


func _process(delta: float) -> void:
	_t += delta
	_pop = maxf(0.0, _pop - delta * 2.0)
	queue_redraw()


func _idx(cat: String, id: String) -> int:
	var arr: Array = Data.db["parts"][cat]
	for i in arr.size():
		if arr[i]["id"] == id:
			return i
	return 0


func _initials(id: String) -> String:
	var bits: PackedStringArray = id.split("_")
	if bits.size() == 1:
		return id.substr(0, 2).to_upper()
	var s := ""
	for b in bits:
		if b.length() > 0 and s.length() < 2:
			s += b.substr(0, 1).to_upper()
	return s


func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	draw_rect(Rect2(Vector2.ZERO, size), Color(BCTheme.PANEL, 0.55))
	draw_rect(Rect2(Vector2.ZERO, size), Color(BCTheme.AMBER, 0.5), false, 3.0)
	if design.is_empty() or not design.has("bus"):
		draw_string(font, Vector2(20.0, size.y * 0.5), "Waiting for the design...", HORIZONTAL_ALIGNMENT_CENTER, size.x - 40.0, 36, BCTheme.DIM)
		return

	var bus_i: int = mini(_idx("bus", str(design.get("bus", "bus_mini"))), 3)
	var bw: float = BUS_W[bus_i]
	var bh: float = BUS_H[bus_i]
	var cap_h: float = 70.0 if show_caption else 0.0
	var avail_h: float = size.y - cap_h
	var s: float = minf(size.x / 720.0, avail_h / 430.0) * (1.0 + 0.07 * sin(_pop * PI))
	draw_set_transform(Vector2(size.x * 0.5, avail_h * 0.5 + 18.0 * s), 0.0, Vector2(s, s))

	# ---- solar wings (size from panel area)
	var panel: Dictionary = Data.part("panel", str(design.get("panel", "si_6")))
	var area: float = float(panel.get("area_m2", 0.0))
	if area > 0.0:
		var wlen: float = clampf(sqrt(area) * 26.0, 34.0, 235.0)
		var wh: float = clampf(sqrt(area) * 15.0, 30.0, bh * 0.9)
		var gold: bool = str(panel.get("id", "")).begins_with("mj")
		var base: Color = Color(0.85, 0.62, 0.18) if gold else Color(0.12, 0.28, 0.65)
		for side in [-1.0, 1.0]:
			var xa: float = side * (bw * 0.5 + 10.0)
			var xb: float = xa + side * wlen
			draw_line(Vector2(side * bw * 0.5, 0.0), Vector2(xa, 0.0), BCTheme.DIM, 4.0)
			var r := Rect2(minf(xa, xb), -wh * 0.5, wlen, wh)
			draw_rect(r, base)
			var cells: int = maxi(2, int(wlen / 22.0))
			for k in range(1, cells):
				var gx: float = r.position.x + wlen * float(k) / float(cells)
				draw_line(Vector2(gx, r.position.y), Vector2(gx, r.position.y + wh), Color(1, 1, 1, 0.35), 1.5)
			draw_line(Vector2(r.position.x, 0.0), Vector2(r.position.x + wlen, 0.0), Color(1, 1, 1, 0.35), 1.5)
			draw_rect(r, Color(1, 1, 1, 0.7), false, 2.0)

	# ---- RTGs (nuclear batteries) hang on booms
	var rtg_n: int = int(design.get("rtg_count", 0))
	for i in rtg_n:
		var side: float = -1.0 if i % 2 == 0 else 1.0
		var rx: float = side * (bw * 0.5 + 34.0 + float(i / 2) * 26.0)
		var ry: float = bh * 0.5 + 8.0
		draw_line(Vector2(side * bw * 0.5, ry), Vector2(rx, ry), BCTheme.DIM, 3.0)
		draw_rect(Rect2(rx - 9.0, ry, 18.0, 44.0), Color(0.3, 0.3, 0.34))
		for k in 4:
			draw_line(Vector2(rx - 13.0, ry + 8.0 + float(k) * 9.0), Vector2(rx + 13.0, ry + 8.0 + float(k) * 9.0), Color(0.6, 0.6, 0.66), 2.0)
		draw_circle(Vector2(rx, ry + 48.0), 4.0, Color(1.0, 0.5, 0.1))

	# ---- bus
	var bus_rect := Rect2(-bw * 0.5, -bh * 0.5, bw, bh)
	draw_rect(bus_rect, Color(0.62, 0.66, 0.74))
	for k in range(1, 4):
		draw_line(Vector2(bus_rect.position.x, bus_rect.position.y + bh * float(k) / 4.0), Vector2(bus_rect.end.x, bus_rect.position.y + bh * float(k) / 4.0), Color(1, 1, 1, 0.12), 1.0)
	draw_rect(bus_rect, Color(0.95, 0.95, 1.0), false, 3.0)

	# ---- shield
	var shield_id: String = str(design.get("shield", "shield_none"))
	if shield_id == "shield_light":
		draw_rect(bus_rect.grow(4.0), Color(0.8, 0.82, 0.88), false, 4.0)
	elif shield_id == "shield_vault":
		draw_rect(bus_rect.grow(8.0), Color(0.33, 0.35, 0.40), false, 11.0)
		for cx in [bus_rect.position.x - 8.0, bus_rect.end.x + 8.0]:
			for cy in [bus_rect.position.y - 8.0, bus_rect.end.y + 8.0]:
				draw_circle(Vector2(cx, cy), 3.5, Color(0.8, 0.8, 0.85))

	# ---- instruments: coloured tiles inside the bus, colour = the objective they help most
	var inst: Array = design.get("instruments", [])
	var n: int = inst.size()
	if n > 0:
		var cols: int = int(ceil(sqrt(float(n))))
		var rows: int = int(ceil(float(n) / float(cols)))
		var cell: float = minf(minf((bw - 14.0) / float(cols), (bh - 14.0) / float(rows)), 34.0)
		var gx0: float = -cell * float(cols) * 0.5
		var gy0: float = -cell * float(rows) * 0.5
		for i in n:
			var item: Dictionary = Data.instrument(str(inst[i]))
			var best_tag := ""
			var best_v: float = -1.0
			for tag in item.get("values", {}):
				if float(item["values"][tag]) > best_v:
					best_v = float(item["values"][tag])
					best_tag = str(tag)
			var col: Color = TAG_COLORS[absi(best_tag.hash()) % TAG_COLORS.size()]
			var p := Vector2(gx0 + float(i % cols) * cell, gy0 + float(i / cols) * cell)
			draw_rect(Rect2(p + Vector2(2, 2), Vector2(cell - 4.0, cell - 4.0)), col)
			draw_string(font, p + Vector2(0.0, cell * 0.66), _initials(str(inst[i])), HORIZONTAL_ALIGNMENT_CENTER, cell, int(cell * 0.42), BCTheme.NAVY)
		var slots: int = int(Data.part("bus", str(design.get("bus", ""))).get("slots", 99))
		if n > slots:
			draw_rect(bus_rect.grow(6.0), Color(BCTheme.RED, 0.5 + 0.5 * sin(_t * 8.0)), false, 4.0)

	# ---- pointing hardware (more advanced = more visible)
	var adcs_i: int = _idx("adcs", str(design.get("adcs", "adcs_basic")))
	if adcs_i == 0:
		draw_line(Vector2(-bw * 0.5, bh * 0.3), Vector2(-bw * 0.5 - 18.0, bh * 0.3), BCTheme.DIM, 3.0)
	elif adcs_i == 1:
		draw_arc(Vector2(-bw * 0.5 - 10.0, bh * 0.32), 8.0, 0.0, TAU, 16, BCTheme.WHITE, 3.0)
	else:
		draw_rect(Rect2(-bw * 0.5 + 6.0, -bh * 0.5 - 18.0, 12.0, 18.0), Color(0.25, 0.25, 0.3))
		draw_circle(Vector2(-bw * 0.5 + 12.0, -bh * 0.5 - 18.0), 4.0, Color(0.5, 0.9, 1.0))

	# ---- antenna (size from the antenna choice)
	var comm_id: String = str(design.get("comm", "x_band_steer"))
	var top: float = -bh * 0.5
	if comm_id == "uhf_omni":
		draw_line(Vector2(0.0, top), Vector2(0.0, top - 70.0), BCTheme.WHITE, 3.0)
		draw_circle(Vector2(0.0, top - 70.0), 4.0, BCTheme.AMBER)
	elif comm_id == "optical_terminal":
		draw_rect(Rect2(-9.0, top - 56.0, 18.0, 56.0), Color(0.3, 0.32, 0.38))
		draw_circle(Vector2(0.0, top - 58.0), 10.0, Color(0.4, 0.9, 1.0, 0.6 + 0.4 * sin(_t * 5.0)))
	else:
		var dr: float = float(DISH_R.get(comm_id, 16.0))
		if dr <= 10.0:
			draw_rect(Rect2(-14.0, top - 9.0, 28.0, 9.0), BCTheme.WHITE)
		else:
			var dc := Vector2(0.0, top - 22.0 - dr * 0.3)
			draw_line(Vector2(0.0, top), dc, BCTheme.DIM, 3.0)
			draw_arc(dc, dr, 0.15, PI - 0.15, 24, BCTheme.WHITE, 5.0)
			draw_line(dc, dc + Vector2(0.0, -dr * 0.9), BCTheme.DIM, 2.0)
			draw_circle(dc + Vector2(0.0, -dr * 0.9), 3.5, BCTheme.AMBER)

	# ---- thrusters (tier from the propulsion choice)
	var tier: int = int(Data.part("prop", str(design.get("prop", "prop_none"))).get("tier", 0))
	var bot: float = bh * 0.5
	var nozzle_len: float = 0.0
	var metal: Color = Color(0.45, 0.45, 0.5)
	if tier == 1:
		nozzle_len = 10.0
		for x in [-bw * 0.3, bw * 0.3]:
			draw_colored_polygon(PackedVector2Array([Vector2(x - 5.0, bot), Vector2(x + 5.0, bot), Vector2(x + 3.0, bot + 10.0), Vector2(x - 3.0, bot + 10.0)]), metal)
	elif tier == 2:
		nozzle_len = 22.0
		draw_colored_polygon(PackedVector2Array([Vector2(-9.0, bot), Vector2(9.0, bot), Vector2(13.0, bot + 22.0), Vector2(-13.0, bot + 22.0)]), metal)
	elif tier >= 3:
		nozzle_len = 34.0
		draw_colored_polygon(PackedVector2Array([Vector2(-12.0, bot), Vector2(12.0, bot), Vector2(22.0, bot + 34.0), Vector2(-22.0, bot + 34.0)]), metal)
		draw_line(Vector2(-17.0, bot + 17.0), Vector2(17.0, bot + 17.0), Color(0.7, 0.7, 0.75), 2.0)
	if thrusting:
		var fl: float = 38.0 + 14.0 * sin(_t * 40.0)
		var fw: float = 12.0 + float(tier) * 3.0
		draw_colored_polygon(PackedVector2Array([Vector2(-fw, bot + nozzle_len), Vector2(fw, bot + nozzle_len), Vector2(0.0, bot + nozzle_len + fl)]), Color(1.0, 0.6, 0.1, 0.9))

	# ---- pop ring when something changes
	if _pop > 0.0:
		draw_arc(Vector2.ZERO, 110.0 + (1.0 - _pop) * 200.0, 0.0, TAU, 48, Color(BCTheme.AMBER, _pop * 0.7), 4.0)

	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if show_caption:
		var bus_name: String = str(Data.part("bus", str(design.get("bus", ""))).get("name", ""))
		var txt: String = "%s  |  %d instrument%s" % [bus_name, n, "" if n == 1 else "s"]
		draw_string(font, Vector2(10.0, size.y - 22.0), txt, HORIZONTAL_ALIGNMENT_CENTER, size.x - 20.0, 32, BCTheme.AMBER)
