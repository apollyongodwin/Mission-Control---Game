# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name LaunchSequence
extends Control
## Launch countdown with screen shake, rocket reliability % and a rising rocket.
## Use: launch.start(reliability_pct, countdown_seconds, will_succeed)
## Signals: tick(n) every second of the count, liftoff, finished(success)

signal tick(n: int)
signal liftoff
signal finished(success: bool)

var _running: bool = false
var _t: float = 0.0
var _count: float = 10.0
var _reliability: float = 95.0
var _success: bool = true
var _last_tick: int = -1
var _lifted: bool = false
const AFTER := 5.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _exit_tree() -> void:
	_reset_shake()


func is_running() -> bool:
	return _running


func start(reliability_pct: float, countdown_s: float = 10.0, will_succeed: bool = true) -> void:
	_reliability = reliability_pct
	_count = maxf(3.0, countdown_s)
	_success = will_succeed
	_t = -_count
	_last_tick = -1
	_lifted = false
	_running = true


func stop() -> void:
	_running = false
	_reset_shake()
	queue_redraw()


func _reset_shake() -> void:
	if is_inside_tree():
		get_viewport().canvas_transform = Transform2D.IDENTITY


func _process(delta: float) -> void:
	if not _running:
		return
	_t += delta
	var secs: int = int(ceil(-_t))
	if _t < 0.0 and secs != _last_tick:
		_last_tick = secs
		tick.emit(secs)
	if _t >= 0.0 and not _lifted:
		_lifted = true
		liftoff.emit()
	# shake builds from T-3, peaks at liftoff, fades by T+3 (deterministic, no random)
	var amp: float = 0.0
	if _t > -3.0 and _t < 3.0:
		amp = 14.0 * (1.0 - absf(_t) / 3.0) + 2.0
	get_viewport().canvas_transform = Transform2D(0.0, Vector2(sin(_t * 53.0), cos(_t * 47.0)) * amp)
	if _t >= AFTER:
		_running = false
		_reset_shake()
		finished.emit(_success)
	queue_redraw()


func _draw() -> void:
	if not _running:
		return
	var font: Font = ThemeDB.fallback_font
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.6))
	var mid := Vector2(size.x * 0.5, size.y * 0.5)
	if _t < 0.0:
		draw_string(font, Vector2(0.0, mid.y + 70.0), str(int(ceil(-_t))), HORIZONTAL_ALIGNMENT_CENTER, size.x, 260, BCTheme.AMBER)
		draw_string(font, Vector2(0.0, mid.y - 190.0), "LAUNCH COUNTDOWN", HORIZONTAL_ALIGNMENT_CENTER, size.x, 48, BCTheme.WHITE)
		var bw: float = 700.0
		var bx: float = mid.x - bw * 0.5
		var by: float = mid.y + 140.0
		draw_string(font, Vector2(0.0, by - 14.0), "ROCKET RELIABILITY %d%%" % int(round(_reliability)), HORIZONTAL_ALIGNMENT_CENTER, size.x, 40, BCTheme.WHITE)
		draw_rect(Rect2(bx, by, bw, 30.0), Color(1, 1, 1, 0.2))
		draw_rect(Rect2(bx, by, bw * clampf(_reliability / 100.0, 0.0, 1.0), 30.0), BCTheme.GREEN if _reliability >= 90.0 else BCTheme.YELLOW)
	else:
		var rise: float = clampf(_t / 3.5, 0.0, 1.0)
		var ry: float = size.y * 0.8 - rise * rise * size.y * 0.9
		var rp := Vector2(mid.x, ry)
		draw_colored_polygon(PackedVector2Array([rp + Vector2(0, -90), rp + Vector2(24, -40), rp + Vector2(24, 60), rp + Vector2(-24, 60), rp + Vector2(-24, -40)]), Color(0.92, 0.94, 1.0))
		draw_colored_polygon(PackedVector2Array([rp + Vector2(-24, 60), rp + Vector2(24, 60), rp + Vector2(0, 60.0 + 70.0 + 20.0 * sin(_t * 40.0))]), Color(1.0, 0.6, 0.1, 0.95))
		if _t > 1.0:
			var ok: bool = _success
			var head: String = "LIFTOFF!" if _t < 3.0 else ("ORBIT REACHED" if ok else "ANOMALY!")
			var hc: Color = BCTheme.AMBER if _t < 3.0 else (BCTheme.GREEN if ok else BCTheme.RED)
			draw_string(font, Vector2(0.0, size.y * 0.22), head, HORIZONTAL_ALIGNMENT_CENTER, size.x, 120, hc)
