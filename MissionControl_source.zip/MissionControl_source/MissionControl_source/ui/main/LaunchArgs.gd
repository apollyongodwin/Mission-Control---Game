# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name LaunchArgs
extends RefCounted
## LEAD. Command-line shortcuts so one laptop can run the whole team (spec section 6, "Development without 5 laptops").
## In the editor: Debug > Customize Run Instances > enable "Enable Multiple Instances", 5 instances, and give each one
## "Main Run Args" like these (everything after -- is ours):
##   instance 1:  --host
##   instance 2:  --auto-join=127.0.0.1 --role=flight
##   instance 3:  --auto-join=127.0.0.1 --role=systems
##   instance 4:  --auto-join=127.0.0.1 --role=payload
##   instance 5:  --auto-join=127.0.0.1 --role=ground
## From a terminal:  godot --path . -- --auto-join=127.0.0.1 --role=systems
## Optional on the host: --scenario=moon_relay --difficulty=engineer --length=full --demo --autostart=5
##   (--autostart presses INITIATE LAUNCH by itself after that many seconds: handy for recording the demo video)
## Testing only: --shot-dir=/tmp/shots --shot-every=3  saves a screenshot every few seconds.
##               --autoplay  (crew) presses READY; (host) the Commander says GO, calls the review, answers GO and passes in every crisis.
## Only runs once per app start, so going back to the menu later behaves normally.


static func _args() -> Dictionary:
	var out := {}
	for a in OS.get_cmdline_user_args() + OS.get_cmdline_args():
		var s: String = str(a)
		if not s.begins_with("--"):
			continue
		var kv: PackedStringArray = s.trim_prefix("--").split("=", true, 1)
		out[kv[0]] = kv[1] if kv.size() > 1 else "1"
	return out


static func apply_once(from: Node) -> void:
	if Engine.has_meta("launch_args_done"):
		return
	Engine.set_meta("launch_args_done", true)
	var a: Dictionary = _args()
	if a.has("shot-dir"):
		var shooter := _Shooter.new()
		shooter.dir = str(a["shot-dir"])
		shooter.every = float(a.get("shot-every", "3"))
		from.get_tree().root.add_child.call_deferred(shooter)
	if a.has("host"):
		Engine.set_meta("lobby_mode", "host")
		Engine.set_meta("host_presets", a)
		if a.has("autoplay"):   # round 4: a Commander who marks everything OK and says GO (testing only)
			from.get_tree().root.add_child.call_deferred(_AutoCommander.new())
		from.get_tree().change_scene_to_file.call_deferred("res://ui/menu/Lobby.tscn")
	elif a.has("auto-join"):
		var role: String = str(a.get("role", ""))
		Net.joined_server.connect(func() -> void:
			if role != "":
				Net.request_seat(role)
				Net.set_seat_ready(true), CONNECT_ONE_SHOT)
		Net.join_game(str(a["auto-join"]))
		if a.has("autoplay"):
			from.get_tree().root.add_child.call_deferred(_AutoPlayer.new())
		Engine.set_meta("lobby_mode", "client")
		from.get_tree().change_scene_to_file.call_deferred("res://ui/menu/Lobby.tscn")


## Testing only: a Commander who approves everything a few seconds into the launch poll.
class _AutoCommander extends Node:
	var _t: float = 0.0

	func _process(delta: float) -> void:
		if MissionState.phase != "REVIEW" or MissionState.commander_go:
			_t = 0.0
			return
		_t += delta
		if _t > 4.0:
			Net.phase_machine.on_commander_decision(true, "")


## Testing only: saves the screen every few seconds (see --shot-dir).
class _Shooter extends Node:
	var dir: String = "/tmp"
	var every: float = 3.0
	var _t: float = 0.0
	var _n: int = 0

	func _process(delta: float) -> void:
		_t += delta
		if _t < every:
			return
		_t = 0.0
		_n += 1
		var img: Image = get_viewport().get_texture().get_image()
		if img != null:
			img.save_png("%s/%03d_%s.png" % [dir, _n, MissionState.phase.to_lower()])


## Testing only: a crew member who always agrees (see --autoplay).
class _AutoPlayer extends Node:
	func _ready() -> void:
		MissionState.phase_changed.connect(_on_phase)
		Net.server_message_received.connect(func(code: String, text: String) -> void:
			if code in ["token_ask", "token_given", "give_rejected"]:
				printerr("AUTOPLAY %s: %s" % [code, text])   # stderr: not lost when the test is killed
			if code == "token_ask":   # round 6: a teammate asked us for a token: give it
				var p: PackedStringArray = text.split("|")
				Net.give_token(p[1], p[0])
			if code == "task_start":   # round 8: finish the mini-task after a few seconds
				get_tree().create_timer(4.0).timeout.connect(func() -> void: Net.ping("@task:ok")))
		Net.crisis_event.connect(func(ev: Dictionary, _t: float) -> void:
			var kind: String = str(ev.get("kind", "crisis"))
			if kind == "crisis":   # round 6: exercise ASK (systems asks bot FLIGHT; payload asks human SYSTEMS)
				var ask: String = {"systems": "fuel", "payload": "power"}.get(MissionState.local_role, "")
				if ask != "":
					get_tree().create_timer(1.0).timeout.connect(func() -> void: Net.ping("@ask:" + ask))
			get_tree().create_timer(3.0).timeout.connect(func() -> void:
				if kind == "crisis":
					# round 8: play the card the Commander's handbook names for us (if any), like a good crew member
					var mine := ""
					for c in RoleGuide.calls(ev):
						if str(c["role"]) == MissionState.local_role:
							mine = str(c["action"])
					Net.play_action(mine if mine != "" else "pass")
					if mine != "":
						get_tree().create_timer(1.0).timeout.connect(func() -> void: Net.play_action("pass"))
				elif kind == "opportunity":
					Net.event_choice("capture")
				else:
					Net.event_choice("pass")))

	## Uses the same "cautious" preset as the AutoCrew bots for this player's own choices.
	func _pick_preset_parts() -> void:
		var role: String = MissionState.local_role
		if role == "":
			return
		for p in Data.db["bot_presets"].get(MissionState.scenario_id, []):
			if p["name"] != "cautious":
				continue
			var i := 0
			for cat in Data.db["meta"]["roles"][role]["owns_choices"]:
				if p["design"].has(cat):
					i += 1
					var c: String = str(cat)
					var v: Variant = p["design"][cat]
					get_tree().create_timer(1.0 + 0.6 * i).timeout.connect(func() -> void: Net.submit_choice(c, v))

	func _on_phase(p: String) -> void:
		match p:
			"BRIEFING":
				get_tree().create_timer(2.0).timeout.connect(func() -> void: Net.set_seat_ready(true))
			"DESIGN":
				_pick_preset_parts()
				get_tree().create_timer(4.0).timeout.connect(func() -> void: Net.send_chat("Too heavy!"))
				get_tree().create_timer(8.0).timeout.connect(func() -> void:
					if MissionState.phase == "DESIGN":
						Net.call_review())
			"REVIEW":
				get_tree().create_timer(1.5).timeout.connect(func() -> void: Net.poll_answer(true, ""))
