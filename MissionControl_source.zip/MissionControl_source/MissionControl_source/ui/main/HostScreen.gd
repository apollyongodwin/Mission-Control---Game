# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## LEAD (merge glue). What the MISSION CONTROL laptop (the host) shows after the lobby's START.
## Dev C's broadcast screen runs the whole time; at DEBRIEF Dev D's debrief slides in on top.
##   Again!     -> Net.host_again()        same crew, same design, new seed, straight to DESIGN
##   Main menu  -> back to the host lobby  (crew stays connected and seated)
##   Esc        -> abort the mission and return to the lobby (asks first)

const BROADCAST_SCENE := "res://ui/broadcast/BroadcastMain.tscn"
const DEBRIEF_SCENE := "res://ui/debrief/Debrief.tscn"
const LOBBY_SCENE := "res://ui/menu/Lobby.tscn"

var _broadcast: Control
var _console: Control = null      # LEAD (round 4): the Commander's private screen
var _peek: bool = false           # Tab: peek at the broadcast view
var _debrief: Control = null
var _confirm: ConfirmationDialog
var _saved_scale: Vector2i
var _saved_mode: int


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var w: Window = get_window()
	_saved_scale = w.content_scale_size
	_saved_mode = w.content_scale_mode
	_broadcast = (load(BROADCAST_SCENE) as PackedScene).instantiate()
	add_child(_broadcast)
	if MissionState.commander_mode:
		_console = CommanderConsole.new()
		add_child(_console)
	_confirm = ConfirmationDialog.new()
	_confirm.dialog_text = "Stop this mission and go back to the lobby?\nThe crew stays connected."
	_confirm.ok_button_text = "Back to lobby"
	_confirm.confirmed.connect(_to_lobby)
	add_child(_confirm)
	MissionState.phase_changed.connect(_apply_phase)
	Net.debrief_report.connect(func(_r: Dictionary) -> void: _apply_phase(MissionState.phase))
	_apply_phase(MissionState.phase)


func _exit_tree() -> void:
	# Dev C's broadcast switches the window to a 1920x1080 canvas; give the menus their own size back.
	var w: Window = get_window()
	if w != null:
		w.content_scale_size = _saved_scale
		w.content_scale_mode = _saved_mode


func _unhandled_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k != null and k.pressed and not k.echo and k.keycode == KEY_ESCAPE and _debrief == null:
		_confirm.popup_centered()
	if k != null and k.pressed and not k.echo and k.keycode == KEY_TAB and _console != null and _debrief == null:
		_peek = not _peek
		_apply_phase(MissionState.phase)
		get_viewport().set_input_as_handled()


func _apply_phase(p: String) -> void:
	if _console != null and p != "DEBRIEF":
		# round 4: the Commander works on the private console; the big broadcast plays the launch (Tab = peek)
		var show_broadcast: bool = p == "LAUNCH" or _peek
		_console.visible = not show_broadcast
		_broadcast.visible = show_broadcast
		get_window().content_scale_size = Vector2i(1920, 1080) if show_broadcast else _saved_scale
	if p == "DEBRIEF":
		_show_debrief()
	elif _debrief != null:
		_debrief.queue_free()
		_debrief = null
		if _console == null:
			get_window().content_scale_size = Vector2i(1920, 1080)   # back to the broadcast canvas (Again!)


func _show_debrief() -> void:
	if _debrief != null:
		return
	var rep: Dictionary = MissionState.last_report
	if rep.is_empty():
		return
	_debrief = (load(DEBRIEF_SCENE) as PackedScene).instantiate()
	# the broadcast draws on a 1920x1080 canvas; the debrief is laid out for the normal 1280x720 one
	get_window().content_scale_size = _saved_scale
	add_child(_debrief)
	_debrief.call("show_report", rep, MissionState.eval_result,
		{"design": rep.get("design", MissionState.design), "team_name": MissionState.team_name, "difficulty": MissionState.difficulty})
	_debrief.connect("again_pressed", func() -> void: Net.host_again())
	_debrief.connect("menu_pressed", _to_lobby)
	_debrief.modulate.a = 0.0
	create_tween().tween_property(_debrief, "modulate:a", 1.0, 0.6).set_delay(0.8)


func _to_lobby() -> void:
	Net.host_new_mission()
	Engine.set_meta("lobby_mode", "host")
	get_tree().change_scene_to_file(LOBBY_SCENE)
