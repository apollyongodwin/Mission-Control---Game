# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Control
## LEAD (merge glue). What a CREW laptop shows after the lobby. It follows the host's phase:
##   BRIEFING -> briefing card (READY)          DESIGN / REVIEW / LAUNCH / FLIGHT -> my role panel
##   (the panel's own overlay shows the launch poll and the crisis cards)
##   DEBRIEF  -> Dev D's debrief                LOBBY -> back to the lobby (still connected)
## If the host goes away, it returns to the main menu with a message.

const PANELS := {
	"flight": "res://ui/roles/FlightPanel.tscn",
	"systems": "res://ui/roles/SystemsPanel.tscn",
	"payload": "res://ui/roles/PayloadPanel.tscn",
	"ground": "res://ui/roles/GroundPanel.tscn",
}
const LOBBY_SCENE := "res://ui/menu/Lobby.tscn"
const MENU_SCENE := "res://ui/menu/MainMenu.tscn"
const DEBRIEF_SCENE := "res://ui/debrief/Debrief.tscn"

var _role: String = ""
var _panel: Control = null
var _brief: CrewBriefing = null
var _debrief: Control = null
var _launch: Control = null
var _toast: Label = null
var _chat: ChatDrawer = null
var _flight: CrewFlight = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_role = MissionState.local_role
	var bg := ColorRect.new()
	bg.color = GameTheme.NAVY
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	if PANELS.has(_role):
		_panel = (load(PANELS[_role]) as PackedScene).instantiate()
		add_child(_panel)
	else:
		var c := CenterContainer.new()
		c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		c.add_child(GameTheme.label("You are watching this mission. Grab a seat next time!", 30, GameTheme.AMBER, false))
		add_child(c)
	_chat = ChatDrawer.new()   # MERGE (Part 3): crew chat, always on top
	add_child(_chat)
	if _panel != null and _panel.get("chat_button") != null:   # round 8: chat button in the top bar
		_chat.use_button.call_deferred(_panel.get("chat_button"))
	_toast = GameTheme.label("", 22, GameTheme.NAVY, false)
	_toast.visible = false
	MissionState.phase_changed.connect(_apply_phase)
	Net.left_network.connect(_on_host_lost)
	Net.debrief_report.connect(func(_r: Dictionary) -> void: _apply_phase(MissionState.phase))
	Net.server_message_received.connect(_on_server_message)   # round 8: mini-tasks
	_apply_phase(MissionState.phase)


var _task: MiniTask = null


## LEAD (round 8): the host starts and stops this player's mini-task.
func _on_server_message(code: String, text: String) -> void:
	if code == "task_start":
		var p: PackedStringArray = text.split("|")
		if p.size() < 3:
			return
		if _task != null and is_instance_valid(_task):
			_task.queue_free()
		_task = MiniTask.new()
		_task.setup(p[0], p[1], float(p[2]), MissionState.difficulty)
		add_child(_task)
	elif code == "task_stop" and _task != null and is_instance_valid(_task):
		_task.stop(text)


func _apply_phase(p: String) -> void:
	if p != "FLIGHT" and _task != null and is_instance_valid(_task):
		_task.queue_free()
	if p == "LOBBY":
		Engine.set_meta("lobby_mode", "client")
		get_tree().change_scene_to_file.call_deferred(LOBBY_SCENE)
		return
	_show_brief(p == "BRIEFING")
	_show_flight(p in ["LAUNCH", "FLIGHT"])
	_show_launch(p == "LAUNCH")
	_show_debrief(p == "DEBRIEF")


## Flight view goes INSIDE the role panel, just under its overlay, so crisis cards still pop up on top.
func _show_flight(on: bool) -> void:
	if on and _flight == null and _panel != null:
		_flight = CrewFlight.new()
		_flight.setup(_role)
		_panel.add_child(_flight)
		var ov: Node = _panel.get("_overlay")
		if ov != null:
			_panel.move_child(_flight, ov.get_index())
	elif not on and _flight != null:
		_flight.queue_free()
		_flight = null


func _show_brief(on: bool) -> void:
	if on and _brief == null:
		_brief = CrewBriefing.new()
		_brief.setup(_role)
		add_child(_brief)
		move_child(_chat, -1)
	elif not on and _brief != null:
		_brief.queue_free()
		_brief = null


## A full-screen launch moment on every laptop (the broadcast has the big one).
func _show_launch(on: bool) -> void:
	if on and _launch == null:
		_launch = CrewLaunch.new()
		add_child(_launch)
	elif not on and _launch != null:
		_launch.queue_free()
		_launch = null


func _show_debrief(on: bool) -> void:
	if on and _debrief == null:
		var rep: Dictionary = MissionState.last_report
		if rep.is_empty():
			return   # the report RPC arrives right after the phase; debrief_report calls us again
		_debrief = (load(DEBRIEF_SCENE) as PackedScene).instantiate()
		_debrief.set("can_again", false)       # only Mission Control can start "Again!"
		add_child(_debrief)
		move_child(_chat, -1)
		_debrief.call("show_report", rep, {}, {"design": rep.get("design", {}), "team_name": rep.get("team_name", "")})
		_debrief.connect("menu_pressed", _on_menu)
	elif not on and _debrief != null:
		_debrief.queue_free()
		_debrief = null


func _on_menu() -> void:
	Net.leave()
	get_tree().change_scene_to_file(MENU_SCENE)


func _on_host_lost() -> void:
	Engine.set_meta("menu_notice", "Lost the connection to Mission Control.")
	get_tree().change_scene_to_file.call_deferred(MENU_SCENE)
