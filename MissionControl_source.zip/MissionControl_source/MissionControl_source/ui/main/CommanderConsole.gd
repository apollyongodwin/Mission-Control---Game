# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CommanderConsole
extends Control
## LEAD (round 4, simplified in round 5). The COMMANDER's private screen on the host laptop.
## Kid-simple: ONE big instruction line and ONE main area that changes with the phase. No tabs, no wall of numbers.
##   BRIEFING  meet your crew (who does what)
##   DESIGN    the ship lights, the one thing to fix first, and every crew pick. Tap a pick to flag it SWAP.
##   REVIEW    same, plus a big GO / NO-GO
##   FLIGHT    the Gauge Finder: tap the gauges your crew says are on ALARM; the answer appears
## Everything else (crisis list, parts, jobs) is behind the HANDBOOK button.
## The Commander never sees the crisis clock. The screen edges flash red when the crew presses HURRY and pulse red
## when the clock is nearly out. Tab = peek at the big broadcast view (HostScreen).

const STRIP := preload("res://ui/common/ResourceStrip.tscn")
const DANGER_FRACTION := 0.35

var _money: Label
var _money_bar: ProgressBar
var _clock: Label
var _ribbon: PipelineRibbon
var _say: Label                 # the one big instruction line
var _page: Control              # the main area, rebuilt per phase
var _page_kind: String = ""
var _edge: EdgeFlash
var _alert: Label
var _sig: String = ""
var _finder: GaugeFinder = null
var _flight_box: VBoxContainer = null
var _last_result: String = ""
var _crisis_kind: String = ""

var _lives: LivesBar = null
var _twist: Label = null

var _crisis_total: float = 0.0
var _crisis_left: float = 0.0
var _crisis_live: bool = false
var _danger_said: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = GameTheme.build(GameTheme.AMBER)
	MissionState.commander_present = true
	var bg := ColorRect.new()
	bg.color = GameTheme.NAVY
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	var stars := Starfield.new()
	stars.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(stars)
	_build_frame()
	_edge = EdgeFlash.new()
	_edge.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_edge)
	_alert = GameTheme.label("", 34, Color.WHITE, false)
	_alert.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_alert.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_alert.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_alert.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_alert.position.y -= 90
	_alert.add_theme_color_override("font_outline_color", Color("7A0000"))
	_alert.add_theme_constant_override("outline_size", 12)
	_alert.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_alert)
	MissionState.design_changed.connect(_refresh)
	MissionState.commander_changed.connect(_refresh)
	MissionState.seats_changed.connect(_refresh)
	MissionState.poll_changed.connect(_refresh)
	MissionState.phase_changed.connect(_on_phase)
	MissionState.clock_changed.connect(_update_clock)
	MissionState.clock_changed.connect(_refresh)
	MissionState.settings_changed.connect(_show_twist)
	MissionState.flight_status_changed.connect(_on_flight_status)
	Net.server_message_received.connect(_on_server_message)
	_show_twist()
	Net.crisis_event.connect(_on_crisis)
	Net.crisis_result.connect(_on_crisis_result)
	Net.ping_received.connect(_on_ping)
	_on_phase(MissionState.phase)


func _exit_tree() -> void:
	MissionState.commander_present = false


func _process(delta: float) -> void:
	if not _crisis_live:
		return
	_crisis_left -= delta
	if _crisis_total > 0.0 and _crisis_left <= _crisis_total * DANGER_FRACTION and _crisis_left > 0.0:
		_edge.pulse = true
		if not _danger_said:
			_danger_said = true
			_shout("HURRY! THE SHIP IS IN DANGER!", 3.0)
			Audio.play_sfx("alarm", -6.0)


# ================================================================== frame
func _build_frame() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 14)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	margin.add_child(root)

	var top := GameTheme.panel(GameTheme.PANEL, GameTheme.AMBER, 3, 18, 10)
	root.add_child(top)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 16)
	top.add_child(head)
	var names := VBoxContainer.new()
	names.add_theme_constant_override("separation", -4)
	names.add_child(GameTheme.label("COMMANDER", 30, GameTheme.AMBER, false))
	_twist = GameTheme.label("You have the handbook", 15, GameTheme.MUTED, false)   # round 8: or this mission's twist
	names.add_child(_twist)
	head.add_child(names)
	_ribbon = PipelineRibbon.new()
	_ribbon.accent = GameTheme.AMBER
	_ribbon.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(_ribbon)
	var money := VBoxContainer.new()
	money.custom_minimum_size = Vector2(220, 0)
	_money = GameTheme.label("Money", 20, GameTheme.TEXT, false)
	money.add_child(_money)
	_money_bar = ProgressBar.new()
	_money_bar.show_percentage = false
	_money_bar.custom_minimum_size = Vector2(0, 16)
	money.add_child(_money_bar)
	head.add_child(money)
	_lives = LivesBar.new()   # round 8
	_lives.heart = 14.0
	_lives.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	head.add_child(_lives)
	_clock = GameTheme.label("", 22, GameTheme.TEXT, false)   # round 7: the build clock
	_clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_clock.custom_minimum_size = Vector2(130, 0)
	head.add_child(_clock)
	var book := Button.new()
	book.text = "HANDBOOK"
	book.custom_minimum_size = Vector2(150, 56)
	book.add_theme_font_size_override("font_size", 20)
	GameTheme.primary(book)
	book.pressed.connect(_open_handbook)
	head.add_child(book)

	_say = GameTheme.label("", 24, Color("9FD4FF"))
	root.add_child(_say)

	_page = Control.new()
	_page.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(_page)


func _set_page(c: Control) -> void:
	for old in _page.get_children():
		_page.remove_child(old)
		old.queue_free()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_page.add_child(c)


# ================================================================== phases
func _on_phase(p: String) -> void:
	_ribbon.set_phase(p)
	_update_clock()
	if p != "FLIGHT":
		_crisis_live = false
		_edge.pulse = false
	_sig = ""
	match p:
		"LOBBY", "BRIEFING":
			_say.text = "Meet your crew! You will help them build a spaceship and keep it safe."
			_page_kind = "crew"
			_set_page(_crew_page())
		"DESIGN", "REVIEW":
			_page_kind = "design"
			_finder = null
		"FLIGHT":
			_page_kind = "flight"
			_build_flight_page()
		_:
			_page_kind = ""
			_say.text = ""
	_refresh()


func _refresh() -> void:
	if not is_inside_tree():
		return
	var r: Dictionary = MissionState.eval_result
	var cost: Dictionary = r.get("cost", {})
	var total: float = float(cost.get("total", 0.0))
	var cap: float = maxf(float(cost.get("cap", 1.0)), 1.0)
	var left: float = cap - total
	_money.text = ("Money left: C$%d M" % int(round(left))) if left >= 0.0 else ("OVER BUDGET by C$%d M!" % int(round(-left)))
	_money.add_theme_color_override("font_color", GameTheme.BAD if left < 0.0 else (GameTheme.WARN if left < cap * 0.1 else GameTheme.GOOD))
	_money_bar.max_value = cap
	_money_bar.value = clampf(total, 0.0, cap)
	if _page_kind == "design":
		var sig := str([MissionState.design, MissionState.commander_marks, MissionState.seats, MissionState.phase,
			MissionState.poll, MissionState.commander_go, r.get("lights", {})])
		if sig != _sig:
			_sig = sig
			_set_page(_design_page())


func _update_clock() -> void:
	var left: int = MissionState.design_left
	_clock.visible = left >= 0 and MissionState.phase == "DESIGN"
	if left > 0:
		_clock.text = "BUILD\n" + MissionState.clock_text(left)
		_clock.add_theme_color_override("font_color", GameTheme.BAD if left <= 30 else (GameTheme.WARN if left <= 60 else GameTheme.TEXT))
	else:
		_clock.text = "OVERTIME\n-C$%d M" % int(MissionState.budget_penalty)
		_clock.add_theme_color_override("font_color", GameTheme.BAD)


# ================================================================== BRIEFING: meet the crew
func _crew_page() -> Control:
	# round 9: the mission on top (name, budget, deadline, goals, twist), then the crew
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 10)
	var sc: Dictionary = Data.scenario(MissionState.scenario_id)
	var mp := GameTheme.panel(GameTheme.PANEL, GameTheme.AMBER, 2, 16, 10)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 4)
	mp.add_child(mv)
	var cap: float = float(sc.get("budget_cap", 0)) * float(Data.db["meta"]["difficulty"][MissionState.difficulty]["budget_mult"])
	mv.add_child(GameTheme.label("MISSION: %s   -   budget about C$%d M   -   deadline %d months" % [str(sc.get("name", "")).to_upper(), int(cap), int(sc.get("deadline_months", 0))], 20, GameTheme.AMBER))
	var goals: Array = []
	for o in sc.get("objectives", []):
		goals.append("%s (%d)" % [o["label"], int(o["weight"])])
	mv.add_child(GameTheme.label("Goals: " + ",  ".join(goals), 16, GameTheme.TEXT))
	for t in MissionState.twist_names():
		mv.add_child(GameTheme.label("TWIST: %s. %s" % [t.get("name", ""), t.get("blurb", "")], 16, Color("FF9F43")))
	mv.add_child(GameTheme.label("HANDBOOK > Mission shows which orbit sees which goal: help FLIGHT and PAYLOAD pick together!", 15, GameTheme.MUTED))
	page.add_child(mp)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	page.add_child(row)
	for role in Protocol.ROLES:
		var g: Dictionary = RoleGuide.guide(role)
		var col := RoleGuide.color(role)
		var pc := GameTheme.panel(Color(col, 0.10), Color(col, 0.8), 3, 18, 12)
		pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pc.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 8)
		pc.add_child(v)
		var art := CrewArt.make(role, 90)
		art.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		v.add_child(art)
		var n := GameTheme.label(str(g["name"]), 26, col, false)
		n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(n)
		v.add_child(GameTheme.label(str(g["one_line"]), 18, GameTheme.TEXT))
		v.add_child(GameTheme.label("Watches: " + " and ".join(_gauge_names(role)), 16, col))
		row.add_child(pc)
	return page


func _gauge_names(role: String) -> Array:
	var out: Array = []
	for g in RoleGuide.gauges_for(role):
		out.append(str(g["name"]).to_lower())
	return out


# ================================================================== DESIGN / REVIEW: check the picks
func _design_page() -> Control:
	var review: bool = MissionState.phase == "REVIEW"
	var r: Dictionary = MissionState.eval_result
	var msgs: Array = SimEngine.review_messages(r)
	var lights: Dictionary = r.get("lights", {})
	var bad_lights: Array = []
	for k in lights:
		if str(lights[k]) == "red":
			bad_lights.append(str(ResourceStrip.NAMES.get(k, k)))
	if review:
		_say.text = "LAUNCH VOTE: is the ship right? Say GO, or NO-GO to send the crew back to fix it."
	elif msgs.is_empty() and bad_lights.is_empty():
		_say.text = "The ship looks good! Tell the crew they can press CALL DESIGN REVIEW."
	else:
		_say.text = "Ask the crew what they picked. Tap a part to tell them to SWAP it."

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 12)
	# ---- left: ship lights + the ONE thing to fix first (+ the vote)
	var left := GameTheme.panel(GameTheme.PANEL, GameTheme.EDGE, 3, 18, 12)
	left.custom_minimum_size = Vector2(310, 0)
	body.add_child(left)
	var lscroll := ScrollContainer.new()   # round 8: never clipped, even on a small screen
	lscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(lscroll)
	var lv := VBoxContainer.new()
	lv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lv.size_flags_vertical = Control.SIZE_EXPAND_FILL
	lv.add_theme_constant_override("separation", 8)
	lscroll.add_child(lv)
	lv.add_child(GameTheme.label("THE SHIP", 20, GameTheme.AMBER, false))
	var strip := STRIP.instantiate() as ResourceStrip
	lv.add_child(strip)
	strip.set_lights(lights)
	# round 8: SPECIFIC advice (which part, which crew member, and why), from ShipDoctor
	lv.add_child(GameTheme.label("FIX THIS FIRST", 20, GameTheme.AMBER, false))
	var advice: Array = ShipDoctor.diagnose(Data.db, MissionState.design, r)
	if advice.is_empty():
		lv.add_child(GameTheme.label("Nothing! It all works.", 19, GameTheme.GOOD))
	for a in advice.slice(0, 1 if review else 2):
		var urgent: bool = not str(a["say"]).contains("yellow")
		var who := HBoxContainer.new()
		who.add_theme_constant_override("separation", 6)
		for role in (a["roles"] as Array).slice(0, 2):
			who.add_child(CrewArt.make(str(role), 30))
		var say := GameTheme.label(str(a["say"]), 17, GameTheme.BAD if urgent else GameTheme.WARN)
		say.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		who.add_child(say)
		lv.add_child(who)
		if str(a.get("why", "")) != "":
			lv.add_child(GameTheme.label(str(a["why"]), 13, GameTheme.MUTED))
	# round 8: the science forecast, so "why is our science so low?" has an answer before launch
	var sci: Dictionary = ShipDoctor.science(Data.db, MissionState.design, r)
	var sci_row := HBoxContainer.new()
	sci_row.add_theme_constant_override("separation", 8)
	sci_row.add_child(GameTheme.label("SCIENCE FORECAST", 16, GameTheme.AMBER, false))
	var sci_pts: float = float(sci.get("points", 0.0))
	sci_row.add_child(GameTheme.label("%d / 100" % int(round(sci_pts)), 18, GameTheme.GOOD if sci_pts >= 70.0 else (GameTheme.WARN if sci_pts >= 40.0 else GameTheme.BAD), false))
	lv.add_child(sci_row)
	if not (sci.get("leaks", []) as Array).is_empty():
		lv.add_child(GameTheme.label("Biggest leak: " + str(sci["leaks"][0]), 14, GameTheme.MUTED))
	if review:
		var sp := Control.new()
		sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
		lv.add_child(sp)
		lv.add_child(GameTheme.label(_vote_text(), 17, GameTheme.TEXT))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var go := Button.new()
		go.text = "GO"
		go.custom_minimum_size = Vector2(0, 70)
		go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		go.add_theme_font_size_override("font_size", 30)
		go.disabled = MissionState.commander_go or MissionState.any_swaps()
		GameTheme.paint_button(go, Color("2E8B57"), Color.WHITE)
		go.pressed.connect(_on_decide.bind(true))
		row.add_child(go)
		var nogo := Button.new()
		nogo.text = "NO-GO"
		nogo.custom_minimum_size = Vector2(0, 70)
		nogo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nogo.add_theme_font_size_override("font_size", 30)
		GameTheme.danger(nogo)
		nogo.pressed.connect(_on_decide.bind(false))
		row.add_child(nogo)
		lv.add_child(row)

	# ---- right: the four crew members and their picks (tap = SWAP flag)
	var crew := HBoxContainer.new()
	crew.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	crew.add_theme_constant_override("separation", 10)
	body.add_child(crew)
	var can_flag: bool = MissionState.phase in ["DESIGN", "REVIEW"]
	for role in Protocol.ROLES:
		crew.add_child(_crew_column(role, can_flag))
	return body


func _vote_text() -> String:
	var go := 0
	for role in Protocol.ROLES:
		if str(MissionState.poll.get(role, {}).get("state", "")) == "go":
			go += 1
	if MissionState.any_swaps():
		return "A part is still flagged SWAP: say NO-GO so the crew can fix it."
	if MissionState.commander_go:
		return "You said GO! Crew GO: %d of 4." % go
	return "Crew GO: %d of 4." % go


func _crew_column(role: String, can_flag: bool) -> Control:
	var col := RoleGuide.color(role)
	var pc := GameTheme.panel(Color(col, 0.08), Color(col, 0.8), 3, 16, 8)
	pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	pc.add_child(scroll)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 6)
	scroll.add_child(v)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 6)
	head.add_child(CrewArt.make(role, 44))
	var nv := VBoxContainer.new()
	nv.add_theme_constant_override("separation", -4)
	nv.add_child(GameTheme.label(str(RoleGuide.guide(role)["name"]), 20, col, false))
	var seat: int = int(MissionState.seats.get(role, 0))
	nv.add_child(GameTheme.label("bot" if seat == -1 else ("player" if seat > 0 else "empty"), 13, GameTheme.MUTED, false))
	head.add_child(nv)
	v.add_child(head)
	var rtg_ok: bool = bool(Data.scenario(MissionState.scenario_id).get("rtg_allowed", false))
	for cat in (Data.db["meta"]["roles"][role]["owns_choices"] as Array):
		if str(cat) == "rtg_count" and not rtg_ok:
			continue
		var val = MissionState.design.get(cat)
		if val is Array:   # round 7: one button per instrument / station, each can be flagged on its own
			var label: String = str(SimEngine.CATEGORY_LABELS.get(cat, cat))
			if (val as Array).is_empty():
				var none := GameTheme.label("%s: none yet" % label, 14, GameTheme.MUTED)
				v.add_child(none)
			for item in val:
				v.add_child(_flag_button("%s:%s" % [cat, item], label, SimEngine._item_name(Data.db, str(cat), item), can_flag))
		else:
			v.add_child(_pick_button(str(cat), col, can_flag))
	return pc


func _pick_button(cat: String, _col: Color, can_flag: bool) -> Button:
	var label: String = "Orbit" if cat == "orbit" else str(SimEngine.CATEGORY_LABELS.get(cat, cat))
	var val = MissionState.design.get(cat)
	var name_txt := str(Data.orbit(str(val)).get("name", val)) if cat == "orbit" else SimEngine._item_name(Data.db, cat, val)
	return _flag_button(cat, label, name_txt, can_flag)


## One tappable pick. key = a design category, or "instruments:<id>" for one item of a list.
func _flag_button(cat: String, label: String, name_txt: String, can_flag: bool) -> Button:
	var flagged: bool = str(MissionState.commander_marks.get(cat, "")) == "swap"
	var b := Button.new()
	b.text = ("SWAP!  " if flagged else "") + label + "\n" + name_txt
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(0, 50)
	b.add_theme_font_size_override("font_size", 14)
	b.tooltip_text = "Tap to tell the crew to swap this part. Tap again to take it back."
	b.disabled = not can_flag
	if flagged:
		GameTheme.paint_button(b, Color("C0392B"), Color.WHITE)
		b.add_theme_stylebox_override("disabled", GameTheme.bevel(Color("8E2B20"), Color("5E1C15")))
		b.add_theme_color_override("font_disabled_color", Color.WHITE)
	else:
		GameTheme.paint_button(b, GameTheme.PANEL_HI, GameTheme.TEXT)
	b.pressed.connect(_flag.bind(cat, not flagged))
	return b


func _flag(cat: String, on: bool) -> void:
	Audio.play_sfx("error" if on else "click", -4.0, 0.0)
	Net.phase_machine.on_commander_mark(cat, "swap" if on else "")


func _on_decide(go: bool) -> void:
	var reason := "" if go else "The Commander wants changes. Check what is flagged SWAP!"
	var err: String = Net.phase_machine.on_commander_decision(go, reason)
	if err != "":
		_shout(err, 2.5)
		Audio.play_sfx("error")
	else:
		Audio.play_sfx("go" if go else "buzz")
	_sig = ""
	_refresh()


# ================================================================== FLIGHT: the gauge finder
func _build_flight_page() -> void:
	_flight_box = VBoxContainer.new()
	_flight_box.add_theme_constant_override("separation", 10)
	_set_page(_flight_box)
	_show_flight_idle()


func _clear_flight_box() -> void:
	_finder = null
	if _flight_box == null:
		return
	for c in _flight_box.get_children():
		_flight_box.remove_child(c)
		c.queue_free()


func _show_flight_idle() -> void:
	_clear_flight_box()
	_say.text = "The ship is flying. When an ANOMALY hits, your crew will need you!"
	if _last_result != "":
		_flight_box.add_child(GameTheme.label(_last_result, 22, GameTheme.TEXT))
	# round 8: lives and mini-tasks, so the big empty screen tells the Commander something useful
	var lb := LivesBar.new()
	lb.heart = 26.0
	_flight_box.add_child(lb)
	_flight_box.add_child(GameTheme.label("A crisis is a MISTAKE when the crew blocks less than half of it, or plays a card that does not help. Each mistake costs a life. Only name the cards the handbook says!", 17, GameTheme.MUTED))
	var tasks: Dictionary = MissionState.flight_status.get("tasks", {})
	if not tasks.is_empty():
		_flight_box.add_child(GameTheme.label("MINI-TASKS", 20, GameTheme.AMBER, false))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		for role in Protocol.ROLES:
			if not tasks.has(role):
				continue
			var t: Dictionary = tasks[role]
			var st: String = str(t.get("state", ""))
			var col: Color = GameTheme.GOOD if st == "done" else (GameTheme.BAD if st == "failed" else GameTheme.AMBER)
			var pc := GameTheme.panel(Color(RoleGuide.color(role), 0.1), col, 2, 14, 8)
			var v := VBoxContainer.new()
			pc.add_child(v)
			v.add_child(GameTheme.label(str(RoleGuide.guide(role)["name"]), 18, RoleGuide.color(role), false))
			v.add_child(GameTheme.label(str(MiniTask.NAMES.get(str(t.get("task", "")), ["TASK"])[0]).capitalize(), 15, GameTheme.TEXT, false))
			v.add_child(GameTheme.label({"done": "DONE! +1 token", "failed": "failed", "running": "working..."}.get(st, st), 16, col, false))
			row.add_child(pc)
		_flight_box.add_child(row)
		_flight_box.add_child(GameTheme.label("Cheer them on! Every finished task gives that crew member a token for the next crisis.", 16, GameTheme.MUTED))


func _on_flight_status() -> void:
	if _page_kind == "flight" and not _crisis_live and _finder == null and MissionState.flight_status.get("tasks", {}) is Dictionary:
		var sig: String = str(MissionState.flight_status.get("tasks", {}))
		if sig != _task_sig:
			_task_sig = sig
			_show_flight_idle()


var _task_sig: String = ""


func _show_twist() -> void:
	if _twist == null:
		return
	var tw: Array = MissionState.twist_names()
	_twist.text = ("Twist: " + str(tw[0].get("name", ""))) if not tw.is_empty() else "You have the handbook"
	_twist.tooltip_text = str(tw[0].get("blurb", "")) if not tw.is_empty() else ""
	_twist.add_theme_color_override("font_color", Color("FF9F43") if not tw.is_empty() else GameTheme.MUTED)


func _on_server_message(code: String, text: String) -> void:
	match code:
		"life_lost":
			_shout(text.get_slice(".", 0), 3.0)
			_edge.flash(1.0)
		"chip_start", "chip_ok", "chip_fail", "task_round":
			_shout(text, 2.5)


func _on_crisis(event: Dictionary, timer_s: float) -> void:
	if _page_kind != "flight":
		_on_phase("FLIGHT")
	_danger_said = false
	_edge.pulse = false
	_clear_flight_box()
	_crisis_kind = str(event.get("kind", "crisis"))
	if _crisis_kind == "crisis":
		_say.text = "ANOMALY! You can't see it. Ask each crew member: \"Is anything on ALARM?\""
		_finder = GaugeFinder.new()
		_flight_box.add_child(_finder)
		Audio.play_sfx("alarm", -8.0)
		_crisis_total = timer_s
		_crisis_left = timer_s
		_crisis_live = timer_s > 0.0
	else:
		_say.text = "Good news! The crew has a choice to make. Help them decide."
		_flight_box.add_child(GameTheme.label(str(event.get("title", "")).to_upper(), 30, GameTheme.AMBER))
		_flight_box.add_child(GameTheme.label(str(event.get("flavor", "")), 20, GameTheme.TEXT))
		_crisis_live = false
		Audio.play_sfx("warp", -6.0)


func _on_crisis_result(result: Dictionary) -> void:
	_crisis_live = false
	_edge.pulse = false
	var residual: float = float(result.get("residual", 0.0))
	var title: String = str(MissionState.flight_status.get("title", ""))
	if _crisis_kind == "crisis":
		_last_result = ("Saved the ship! " if residual < 0.05 else "Ouch, the ship got hurt a little. ") + \
			("It was a %s." % title.to_upper() if title != "" else "")
		if bool(result.get("mistake", false)):   # round 8
			_last_result = "MISTAKE, -1 life: %s. It was a %s." % [str(result.get("mistake_reason", "")), title.to_upper()]
		if residual >= 0.05:
			_edge.flash(0.9)
	else:
		_last_result = "Choice made: %s." % title
	_show_flight_idle()


func _on_ping(role: String, card_id: String) -> void:
	if card_id != "@commander":
		return
	_edge.flash(1.0)
	Audio.play_sfx("buzz", -2.0)
	_shout("%s says: HURRY UP!" % str(RoleGuide.guide(role)["name"]), 2.2)


func _shout(text: String, seconds: float) -> void:
	_alert.text = text
	_alert.modulate.a = 1.0
	Fx.pop(_alert, 1.2)
	var tw := create_tween()
	tw.tween_interval(seconds)
	tw.tween_property(_alert, "modulate:a", 0.0, 0.5)


# ================================================================== HANDBOOK popup (everything else lives here)
func _open_handbook() -> void:
	var w := Window.new()
	w.title = "Commander's Handbook"
	w.size = Vector2i(1100, 640)
	w.transient = true
	w.exclusive = false
	w.close_requested.connect(w.queue_free)
	var bg := ColorRect.new()
	bg.color = GameTheme.NAVY
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	w.add_child(bg)
	var tabs := TabContainer.new()
	tabs.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tabs.theme = theme
	w.add_child(tabs)
	tabs.add_child(_scroll("Mission", CommanderHandbook.mission_section()))   # round 9
	tabs.add_child(_scroll("Crises", CommanderHandbook.crisis_section()))
	tabs.add_child(_scroll("Parts", CommanderHandbook.parts_section()))
	tabs.add_child(_scroll("Ground stations", CommanderHandbook.stations_section()))   # round 8: comms help
	tabs.add_child(_scroll("Science", CommanderHandbook.science_section()))            # round 8
	tabs.add_child(_scroll("Tips", CommanderHandbook.tips_section()))                  # round 8
	tabs.add_child(_scroll("Who does what", CommanderHandbook.jobs_section()))
	add_child(w)
	w.popup_centered()


func _scroll(title: String, content: Control) -> ScrollContainer:
	var s := ScrollContainer.new()
	s.name = title
	s.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.add_child(content)
	return s


## Red glow drawn on the four screen edges. flash() = one burst; pulse = keeps beating (danger).
class EdgeFlash extends Control:
	var amount: float = 0.0
	var pulse: bool = false:
		set(v):
			pulse = v
			queue_redraw()
	var _t: float = 0.0

	func flash(strength: float = 1.0) -> void:
		amount = maxf(amount, strength)

	func _process(delta: float) -> void:
		_t += delta
		amount = maxf(0.0, amount - delta * 0.9)
		if pulse:
			amount = maxf(amount, 0.35 + 0.35 * (0.5 + 0.5 * sin(_t * 9.0)))
		queue_redraw()

	func _draw() -> void:
		if amount <= 0.01:
			return
		var w: float = 70.0
		var red := Color(1.0, 0.1, 0.05, 0.75 * amount)
		var clear := Color(1.0, 0.1, 0.05, 0.0)
		var s := size
		_band(Rect2(0, 0, s.x, w), red, clear, true)
		_band(Rect2(0, s.y - w, s.x, w), clear, red, true)
		_band(Rect2(0, 0, w, s.y), red, clear, false)
		_band(Rect2(s.x - w, 0, w, s.y), clear, red, false)

	func _band(r: Rect2, a: Color, b: Color, vertical: bool) -> void:
		var pts := PackedVector2Array([r.position, r.position + Vector2(r.size.x, 0), r.end, r.position + Vector2(0, r.size.y)])
		var cols: PackedColorArray
		if vertical:
			cols = PackedColorArray([a, a, b, b])
		else:
			cols = PackedColorArray([a, b, b, a])
		draw_polygon(pts, cols)
