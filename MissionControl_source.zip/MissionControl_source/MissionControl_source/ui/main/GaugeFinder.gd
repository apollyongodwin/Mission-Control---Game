# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name GaugeFinder
extends VBoxContainer
## LEAD (round 5, kid-simple). The Commander's crisis lookup.
## Four crew boxes, two gauge buttons each. Tap a gauge when that crew member says "ALARM!".
## When the lit gauges match a crisis exactly, the answer appears in big words: what it is and who plays what.

var _on: Dictionary = {}         # tag -> bool (ALARM)
var _buttons: Dictionary = {}    # tag -> Button
var _answer: VBoxContainer
var _tok_labels: Dictionary = {}   # role -> Label (round 6: the Commander sees everyone's tokens)


func _ready() -> void:
	add_theme_constant_override("separation", 10)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	add_child(grid)
	for role in Protocol.ROLES:
		var col := RoleGuide.color(role)
		var pc := GameTheme.panel(Color(col, 0.10), Color(col, 0.8), 3, 16, 8)
		pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		pc.add_child(v)
		var head := HBoxContainer.new()
		head.add_theme_constant_override("separation", 6)
		head.add_child(CrewArt.make(role, 40))
		head.add_child(GameTheme.label(str(RoleGuide.guide(role)["name"]), 20, col, false))
		v.add_child(head)
		var tl := GameTheme.label("", 14, GameTheme.AMBER, false)
		v.add_child(tl)
		_tok_labels[role] = tl
		for g in RoleGuide.gauges_for(role):
			var tag: String = g["tag"]
			_on[tag] = false
			var b := Button.new()
			b.custom_minimum_size = Vector2(0, 58)
			b.add_theme_font_size_override("font_size", 16)
			b.pressed.connect(_toggle.bind(tag))
			v.add_child(b)
			_buttons[tag] = b
		grid.add_child(pc)
	var reset := Button.new()
	reset.text = "Start over"
	reset.custom_minimum_size = Vector2(200, 40)
	reset.size_flags_horizontal = Control.SIZE_SHRINK_END
	reset.pressed.connect(clear)
	add_child(reset)
	_answer = VBoxContainer.new()
	_answer.add_theme_constant_override("separation", 6)
	add_child(_answer)
	MissionState.tokens_changed.connect(_show_tokens)
	_show_tokens()
	_paint()
	_find()


func _show_tokens() -> void:
	for role in _tok_labels:
		var parts: PackedStringArray = []
		for tk in (MissionState.tokens.get(role, {}) as Dictionary):
			parts.append("%d %s" % [int(MissionState.tokens[role][tk]), CrisisPanel.token_word(str(tk))])
		(_tok_labels[role] as Label).text = "Has: " + (", ".join(parts) if not parts.is_empty() else "no tokens")


func clear() -> void:
	for t in _on:
		_on[t] = false
	_paint()
	_find()


func _toggle(tag: String) -> void:
	_on[tag] = not _on[tag]
	Audio.play_sfx("click")
	_paint()
	_find()


## Testing helper: light exactly these gauges.
func set_alarms(tags: Array) -> void:
	for t in _on:
		_on[t] = tags.has(t)
	_paint()
	_find()


func _paint() -> void:
	for role in Protocol.ROLES:
		for g in RoleGuide.gauges_for(role):
			var tag: String = g["tag"]
			var b: Button = _buttons[tag]
			b.text = "%s\n%s" % [str(g["name"]), "ALARM!" if _on[tag] else "ok"]
			if _on[tag]:
				GameTheme.paint_button(b, Color("D63031"), Color.WHITE)
			else:
				GameTheme.paint_button(b, GameTheme.PANEL_HI, GameTheme.MUTED)


func _lit() -> Array:
	var out: Array = []
	for t in _on:
		if _on[t]:
			out.append(t)
	out.sort()
	return out


func _alarm_tags(e: Dictionary) -> Array:
	var out: Array = []
	for a in RoleGuide.alarms(e):
		out.append(a["tag"])
	out.sort()
	return out


func _find() -> void:
	for c in _answer.get_children():
		_answer.remove_child(c)
		c.queue_free()
	var lit := _lit()
	if lit.is_empty():
		_answer.add_child(GameTheme.label("Ask each crew member: \"Is anything on ALARM?\" Tap what they say.", 20, Color("9FD4FF")))
		return
	var maybe: Array = []
	for e in Data.db["events"]:
		if str(e["kind"]) != "crisis":
			continue
		var tags := _alarm_tags(e)
		if tags == lit:
			_show_answer(e)
			return
		if lit.all(func(t): return tags.has(t)):
			maybe.append(str(e["title"]))
	if maybe.is_empty():
		_answer.add_child(GameTheme.label("Hmm, no crisis looks like that. Ask everyone again!", 22, GameTheme.WARN))
	else:
		_answer.add_child(GameTheme.label("Not sure yet. Ask the OTHER crew members too!", 22, GameTheme.WARN))
		_answer.add_child(GameTheme.label("Could be: " + ", ".join(maybe), 17, GameTheme.MUTED))


func _show_answer(e: Dictionary) -> void:
	Audio.play_sfx("chime", -6.0)
	var pc := GameTheme.panel(Color(0.2, 0.6, 0.3, 0.18), GameTheme.GOOD, 3, 16, 12)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	pc.add_child(v)
	v.add_child(GameTheme.label("It's a %s!" % str(e["title"]).to_upper(), 30, GameTheme.GOOD))
	for c in RoleGuide.calls(e):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		row.add_child(CrewArt.make(str(c["role"]), 44))
		var tv := VBoxContainer.new()
		tv.add_theme_constant_override("separation", -2)
		tv.add_child(GameTheme.label("Tell %s: play \"%s\"" % [RoleGuide.guide(str(c["role"]))["name"], str(c["label"])], 24,
			RoleGuide.color(str(c["role"])), false))
		var note: String = RoleGuide.cost_note(str(c["action"]))
		if note != "":
			tv.add_child(GameTheme.label("(%s: they can tap ASK)" % note, 16, GameTheme.AMBER, false))
		row.add_child(tv)
		v.add_child(row)
	_answer.add_child(pc)
