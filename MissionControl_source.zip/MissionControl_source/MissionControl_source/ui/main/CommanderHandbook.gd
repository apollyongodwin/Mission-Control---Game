# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CommanderHandbook
extends RefCounted
## LEAD (round 4, simplified in round 5). The Commander's handbook, built from the data file so it always matches
## the game. Kid words: no percentages and no big tables.
##   On screen: crisis_section(), parts_section(), jobs_section() (the HANDBOOK button on the Commander screen).
##   On paper:  as_json() -> tools/export_handbook.tscn writes handbook/handbook.json + part pictures,
##              then tools/make_handbook_pdf.py draws handbook/Commander_Handbook.pdf with illustrations.

const CRISIS_NICK := {
	"solar_flare": "The Sun sneezes", "station_outage": "Nobody's listening", "battery_cell": "Low battery",
	"debris_alert": "Incoming junk", "overheat": "Too hot!", "software_glitch": "Turn it off and on",
	"budget_cut": "Money trouble", "storage_full": "Disk full", "eclipse_season": "Long nights",
	"light_delay": "Slow messages", "radiation_belt": "Radiation zone",
}
const PART_ORDER := ["bus", "panel", "battery", "comm", "adcs", "obc", "shield", "prop"]

const TIPS := [
	"Too heavy? Pick a lighter body or fewer instruments, or a bigger rocket.",
	"Power is red? Bigger solar wings or a bigger battery.",
	"Data is red? A faster antenna or more ground stations.",
	"Lifetime is red? Add a shield or engines, or pick a gentler orbit.",
	"Money is red? Try a cheaper rocket first. It is usually the biggest price.",
	"Comms is red? A ground station must reach your orbit AND have your antenna's radio. See GROUND STATIONS.",
]

## LEAD (round 8): small tips and help (screen tab + PDF page). Plain words, one line each.
const MORE_TIPS := [
	["Crisis? Ask everyone", "\"Is anything on ALARM?\" Gauges that are not listed for a crisis must say OK."],
	["Only name the book's cards", "A card that does not help, or blocking less than half a crisis, costs a LIFE."],
	["Lives", "Cadet 3, Engineer 2, Flight Director 1. Lose them all and the mission is over."],
	["Spare = tokens", "Green lights with room to spare turn into tokens. Tokens pay for crisis cards."],
	["Watch the build clock", "After 0:00 investors take money AND FLIGHT loses time tokens. Call the review early."],
	["Budget follows the orbit", "Hard orbits (geostationary, the Moon, Jupiter orbit) come with a bigger contract."],
	["Chip in = mini-task", "On a lucky chance, ONE crew member taps CHIP IN and does a quick task. Done = reward + 1 token."],
	["Surprise tasks", "Sometimes everyone gets a task at once. Each finished task gives that player a token."],
	["Science low?", "One instrument rarely fills a goal: use two or three per goal, and make sure the data gets home."],
	["Mission twists", "Every mission rolls a twist (stormy Sun, tight money, extra life...). Read it at the briefing."],
]


# ================================================================== round 8: ground stations, science
## Can each ground station hear each kind of orbit? (plain words for the handbook)
static func stations_info() -> Array:
	var ranges := {"leo": "low orbits", "geo": "geostationary", "lunar": "the Moon", "deep": "Jupiter"}
	var out: Array = []
	for st in Data.db["stations"]:
		var reach: Array = []
		for rc in st["ranges"]:
			reach.append(str(ranges.get(rc, rc)))
		var bands: Array = []
		for b in st["bands"]:
			bands.append(str(b).to_upper())
		var price: String = "$" if float(st["ops_cost_per_year"]) <= 2.5 else ("$$" if float(st["ops_cost_per_year"]) <= 5.0 else "$$$")
		out.append({"id": st["id"], "name": str(st["name"]), "reaches": ", ".join(reach), "radios": ", ".join(bands),
			"price": price, "note": str(st.get("blurb", ""))})
	return out


## Which radio (band) each antenna uses, so the Commander can match antenna and station.
static func antennas_info() -> Array:
	var out: Array = []
	for c in Data.db["parts"]["comm"]:
		out.append({"name": str(c["name"]), "radio": str(c["band"]).to_upper()})
	return out


## Per mission: the goals and which instruments help which goal (and how much).
static func science_info() -> Array:
	var out: Array = []
	for sc in Data.db["scenarios"]:
		var goals: Array = []
		for o in sc["objectives"]:
			goals.append({"tag": o["tag"], "label": str(o["label"]), "points": int(o["weight"]), "full_at": int(o["sat"])})
		var inst: Array = []
		for i in Data.db["instruments"]:
			if str(i["scenario"]) != str(sc["id"]):
				continue
			var helps: Dictionary = {}
			for o in sc["objectives"]:
				helps[str(o["tag"])] = int(i["values"].get(o["tag"], 0))
			inst.append({"name": str(i["name"]), "helps": helps})
		out.append({"id": sc["id"], "name": str(sc["name"]), "goals": goals, "instruments": inst})
	return out


const SCIENCE_STEPS := [
	"Every mission goal is worth points. All the goals together make 100.",
	"Each instrument gives points to some goals (the table). A goal is FULL when its points reach the \"full at\" number. The orbit counts too: an orbit that sees a goal half as well needs twice the points.",
	"One instrument almost never fills a goal. Two or three instruments helping the SAME goal do.",
	"Then everything is multiplied by POWER (is there enough?), DATA (does it all get home?) and LIFE (does the ship last?). If only half the data gets home, you keep only half the science.",
	"Clouds hide the ground from cameras, cameras need sunlight, and wobbly pointing blurs fine instruments. Radar and microwave see through clouds.",
	"In flight, crises take a bite out of science and a captured lucky chance adds some.",
]


# ================================================================== data (shared by screen and paper)
static func crises() -> Array:
	var out: Array = []
	for e in Data.db["events"]:
		if str(e.get("kind", "")) == "crisis":
			out.append(e)
	out.sort_custom(func(x, y): return RoleGuide.alarms(x).size() < RoleGuide.alarms(y).size())
	return out


static func crisis_info(e: Dictionary) -> Dictionary:
	var alarms: Array = []
	for a in RoleGuide.alarms(e):
		alarms.append({"role": a["role"], "role_name": RoleGuide.guide(a["role"])["name"], "gauge": a["name"]})
	var calls: Array = []
	for c in RoleGuide.calls(e):
		calls.append({"role": c["role"], "role_name": RoleGuide.guide(c["role"])["name"], "card": c["label"], "action": c["action"],
			"note": RoleGuide.cost_note(str(c["action"]))})
	return {"id": e["id"], "title": str(e["title"]).to_upper(), "nick": CRISIS_NICK.get(str(e["id"]), ""),
		"alarms": alarms, "calls": calls, "why": str(e.get("learn", ""))}


## "$", "$$" or "$$$" and "light" / "medium" / "heavy", compared with the other parts of the same kind.
static func _tier(value: float, all: Array) -> int:
	var sorted_vals: Array = all.duplicate()
	sorted_vals.sort()
	var idx: int = sorted_vals.find(value)
	var n: int = maxi(sorted_vals.size(), 1)
	return clampi(int(float(idx) * 3.0 / float(n)), 0, 2)


static func parts_info() -> Array:
	var out: Array = []
	for cat in PART_ORDER:
		var items: Array = Data.db["parts"].get(cat, [])
		var costs: Array = []
		var masses: Array = []
		for p in items:
			costs.append(float(p.get("cost", 0)))
			masses.append(float(p.get("mass", 0)))
		var rows: Array = []
		for p in items:
			rows.append({"id": p["id"], "name": p["name"], "blurb": str(p.get("blurb", "")),
				"price": ["$", "$$", "$$$"][_tier(float(p.get("cost", 0)), costs)],
				"weight": ["light", "medium", "heavy"][_tier(float(p.get("mass", 0)), masses)]})
		var owner: String = SimEngine._owner_of(Data.db, cat)
		out.append({"cat": cat, "label": str(SimEngine.CATEGORY_LABELS.get(cat, cat)), "owner": owner,
			"owner_name": RoleGuide.guide(owner)["name"], "items": rows})
	var rk: Array = []
	var rcost: Array = []
	for r in Data.db["rockets"]:
		rcost.append(float(r["cost"]))
	for r in Data.db["rockets"]:
		rk.append({"id": r["id"], "name": r["name"], "blurb": str(r.get("blurb", "")),
			"price": ["$", "$$", "$$$"][_tier(float(r["cost"]), rcost)], "weight": "lifts %d kg" % int(r["capacity_kg"].get("leo", 0))})
	out.append({"cat": "rocket", "label": "Rocket", "owner": "ground", "owner_name": "GROUND", "items": rk})
	return out


static func cards_info() -> Array:
	var out: Array = []
	for a in Data.db["actions"]:
		var cost: PackedStringArray = []
		for k in (a["cost"] as Dictionary):
			cost.append("%d %s" % [int(a["cost"][k]), k])
		out.append({"role": a["role"], "label": a["label"], "blurb": str(a.get("blurb", "")), "cost": ", ".join(cost),
			"note": RoleGuide.cost_note(str(a["id"]))})
	return out


static func as_json() -> Dictionary:
	var jobs: Array = []
	for r in ["commander"] + Protocol.ROLES:
		var g: Dictionary = RoleGuide.guide(r).duplicate(true)
		g["role"] = r
		g["gauges"] = []
		for x in RoleGuide.gauges_for(r):
			g["gauges"].append(x["name"])
		jobs.append(g)
	var cr: Array = []
	for e in crises():
		cr.append(crisis_info(e))
	return {"jobs": jobs, "crises": cr, "parts": parts_info(), "cards": cards_info(), "tips": TIPS,
		"more_tips": MORE_TIPS, "stations": stations_info(), "antennas": antennas_info(), "science": science_info(),
		"science_steps": SCIENCE_STEPS, "twists": Data.db["meta"].get("twists", []), "version": Protocol.GAME_VERSION}


# ================================================================== on screen (HANDBOOK button)
static func crisis_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	v.add_child(GameTheme.label("Find the crisis by its ALARMS. Then tell the crew what to play.", 20, Color("9FD4FF")))
	for e in crises():
		v.add_child(crisis_card(crisis_info(e)))
	return v


static func crisis_card(info: Dictionary) -> Control:
	var pc := GameTheme.panel(Color(1, 0.4, 0.35, 0.08), Color("FF6B5E"), 2, 14, 10)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	pc.add_child(v)
	v.add_child(GameTheme.label("%s  (%s)" % [info["title"], info["nick"]], 22, Color("FF6B5E")))
	var al := HBoxContainer.new()
	al.add_theme_constant_override("separation", 8)
	al.add_child(GameTheme.label("ALARM:", 17, GameTheme.MUTED, false))
	for a in info["alarms"]:
		al.add_child(CrewArt.make(str(a["role"]), 30))
		al.add_child(GameTheme.label("%s %s" % [a["role_name"], str(a["gauge"]).to_lower()], 17, RoleGuide.color(str(a["role"])), false))
	v.add_child(al)
	for c in info["calls"]:
		v.add_child(GameTheme.label("Tell %s: play \"%s\"%s" % [c["role_name"], c["card"], ("  (" + c["note"] + ")") if c["note"] != "" else ""], 18, GameTheme.GOOD))
	return pc


static func parts_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	v.add_child(GameTheme.label("The crew sees these pictures, but no prices. $ = cheap, $$$ = pricey.", 20, Color("9FD4FF")))
	for t in TIPS:
		v.add_child(GameTheme.label("- " + t, 17, GameTheme.TEXT))
	for group in parts_info():
		var col := RoleGuide.color(str(group["owner"]))
		v.add_child(GameTheme.label("%s  (%s picks)" % [str(group["label"]).to_upper(), group["owner_name"]], 20, col))
		var flow := HFlowContainer.new()
		flow.add_theme_constant_override("h_separation", 8)
		flow.add_theme_constant_override("v_separation", 8)
		for it in group["items"]:
			var pc := GameTheme.panel(GameTheme.PANEL_HI, Color(col, 0.6), 1, 12, 8)
			pc.custom_minimum_size = Vector2(240, 0)
			var row := HBoxContainer.new()
			row.add_theme_constant_override("separation", 8)
			pc.add_child(row)
			var dat: Dictionary = {}
			for p in Data.db["parts"].get(group["cat"], Data.db["rockets"] if group["cat"] == "rocket" else []):
				if p["id"] == it["id"]:
					dat = p
			row.add_child(PartIcon.make(str(group["cat"]), dat, col, 48))
			var tv := VBoxContainer.new()
			tv.add_child(GameTheme.label(str(it["name"]), 16, GameTheme.TEXT))
			tv.add_child(GameTheme.label("%s  -  %s" % [it["price"], it["weight"]], 15, GameTheme.AMBER, false))
			tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(tv)
			flow.add_child(pc)
		v.add_child(flow)
	return v


## LEAD (round 9): the contract at a glance, plus which orbit sees which goal (so the Commander can steer FLIGHT and
## PAYLOAD together) and what budget each orbit brings.
static func mission_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	var sc: Dictionary = Data.scenario(MissionState.scenario_id)
	v.add_child(GameTheme.label(str(sc.get("name", "")).to_upper(), 26, GameTheme.AMBER))
	v.add_child(GameTheme.label(str(sc.get("briefing", "")), 17, GameTheme.TEXT))
	var cap: float = float(sc.get("budget_cap", 0)) * float(Data.db["meta"]["difficulty"][MissionState.difficulty]["budget_mult"])
	v.add_child(GameTheme.label("Budget C$%d M (changes with the orbit, below)   Deadline %d months   Lives %d" % [int(cap), int(sc.get("deadline_months", 0)),
		int(Data.db["meta"]["difficulty"][MissionState.difficulty].get("lives", 0))], 18, GameTheme.GOOD))
	for t in MissionState.twist_names():
		v.add_child(GameTheme.label("TWIST: %s. %s" % [t.get("name", ""), t.get("blurb", "")], 17, Color("FF9F43")))
	v.add_child(GameTheme.label("GOALS", 20, GameTheme.AMBER))
	for o in sc.get("objectives", []):
		v.add_child(GameTheme.label("%s  -  %d points" % [o["label"], int(o["weight"])], 17, GameTheme.TEXT))
	v.add_child(GameTheme.label("WHICH ORBIT SEES WHICH GOAL (tell FLIGHT and PAYLOAD!)", 20, GameTheme.AMBER))
	for oid in sc.get("orbits", {}):
		var oc: Dictionary = sc["orbits"][oid]
		var bits: Array = []
		for tag in oc.get("coverage", {}):
			var w: String = ShipDoctor.word(float(oc["coverage"][tag]) - 0.25)
			bits.append("%s %s" % [ShipDoctor.short_goal(str(tag)), w if w != "" else "poorly"])
		var now: bool = str(MissionState.design.get("orbit", "")) == str(oid)
		var pc := GameTheme.panel(GameTheme.PANEL_HI, GameTheme.AMBER if now else GameTheme.EDGE, 2, 12, 8)
		var tv := VBoxContainer.new()
		pc.add_child(tv)
		tv.add_child(GameTheme.label("%s%s   (budget x%.2f)" % [str(Data.orbit(str(oid)).get("name", oid)), "  <- picked now" if now else "",
			float(oc.get("budget_mult", 1.0))], 17, GameTheme.AMBER if now else GameTheme.TEXT))
		tv.add_child(GameTheme.label("Sees: " + ", ".join(bits), 15, GameTheme.MUTED))
		v.add_child(pc)
	return v


static func stations_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	v.add_child(GameTheme.label("COMMS IS RED? A station can only hear the ship if it REACHES the orbit and has the SAME RADIO as the antenna. More stations = more talking time.", 20, Color("9FD4FF")))
	var live: Array = ShipDoctor.station_status(Data.db, MissionState.design)
	for st in stations_info():
		var now: Dictionary = {}
		for l in live:
			if str(l["id"]) == str(st["id"]):
				now = l
		var ok: bool = bool(now.get("ok", false))
		var pc := GameTheme.panel(GameTheme.PANEL_HI, GameTheme.GOOD if ok else GameTheme.EDGE, 2, 12, 8)
		var tv := VBoxContainer.new()
		pc.add_child(tv)
		tv.add_child(GameTheme.label("%s   %s" % [st["name"], st["price"]], 18, GameTheme.AMBER))
		tv.add_child(GameTheme.label("Reaches: %s.   Radios: %s." % [st["reaches"], st["radios"]], 16, GameTheme.TEXT))
		tv.add_child(GameTheme.label(("RIGHT NOW: can hear your ship." if ok else "RIGHT NOW: no, %s." % str(now.get("why", "?"))), 15, GameTheme.GOOD if ok else GameTheme.MUTED))
		v.add_child(pc)
	v.add_child(GameTheme.label("ANTENNAS AND THEIR RADIO", 20, GameTheme.AMBER))
	for a in antennas_info():
		v.add_child(GameTheme.label("%s: %s" % [a["name"], a["radio"]], 16, GameTheme.TEXT))
	return v


static func science_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	v.add_child(GameTheme.label("HOW SCIENCE WORKS", 24, GameTheme.AMBER))
	var n := 1
	for line in SCIENCE_STEPS:
		v.add_child(GameTheme.label("%d. %s" % [n, line], 17, GameTheme.TEXT))
		n += 1
	var r: Dictionary = MissionState.eval_result
	if r.has("science"):
		var sci: Dictionary = ShipDoctor.science(Data.db, MissionState.design, r)
		v.add_child(GameTheme.label("YOUR SHIP RIGHT NOW: %d / 100" % int(round(float(sci["points"]))), 20, GameTheme.AMBER))
		for o in sci["objectives"]:
			v.add_child(GameTheme.label("%s: %d of %d" % [o["label"], int(round(float(o["got"]))), int(o["max"])], 16, GameTheme.TEXT))
		for l in sci["leaks"]:
			v.add_child(GameTheme.label("- " + str(l), 16, GameTheme.WARN))
	for sc in science_info():
		if str(sc["id"]) != MissionState.scenario_id:
			continue
		v.add_child(GameTheme.label("%s: WHICH INSTRUMENT HELPS WHICH GOAL" % str(sc["name"]).to_upper(), 20, GameTheme.AMBER))
		var head: Array = []
		for g in sc["goals"]:
			head.append("%s (%d pts, full at %d)" % [g["label"], g["points"], g["full_at"]])
		v.add_child(GameTheme.label("Goals: " + ";  ".join(head), 15, GameTheme.MUTED))
		for i in sc["instruments"]:
			var bits: Array = []
			for g in sc["goals"]:
				var pts: int = int(i["helps"].get(g["tag"], 0))
				if pts > 0:
					bits.append("%s +%d" % [g["label"], pts])
			v.add_child(GameTheme.label("%s:  %s" % [i["name"], ",  ".join(bits) if not bits.is_empty() else "-"], 16, GameTheme.TEXT))
	return v


static func tips_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	v.add_child(GameTheme.label("TIPS AND HELP", 24, GameTheme.AMBER))
	for t in MORE_TIPS:
		var pc := GameTheme.panel(GameTheme.PANEL_HI, GameTheme.EDGE, 1, 12, 8)
		var tv := VBoxContainer.new()
		pc.add_child(tv)
		tv.add_child(GameTheme.label(str(t[0]), 19, GameTheme.AMBER))
		tv.add_child(GameTheme.label(str(t[1]), 16, GameTheme.TEXT))
		v.add_child(pc)
	return v


static func jobs_section() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	for r in ["commander"] + Protocol.ROLES:
		v.add_child(RoleGuide.make_card(r, true))
	return v
