# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CrewBriefing
extends Control
## LEAD (merge glue). BRIEFING phase on a crew laptop: the contract, YOUR job, your secret goal, READY.
## Spec section 2: "Contract appears ... Each player gets a private goal card. Ends after 15 s or all press READY."

const CHOICE_WORDS := {
	"orbit": "the orbit", "bus": "the body", "panel": "solar wings", "rtg_count": "nuclear batteries",
	"battery": "the battery", "adcs": "pointing", "obc": "the computer", "shield": "shielding", "prop": "engines",
	"instruments": "the science instruments", "rocket": "the rocket", "comm": "the antenna", "stations": "ground stations",
}

var role_id: String = ""
var _ready_btn: Button
var _timer_label: Label
var _left: float = 15.0


func setup(role: String) -> void:
	role_id = role


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var accent: Color = GameTheme.role_color(role_id) if role_id != "" else GameTheme.AMBER
	theme = GameTheme.build(accent)
	var bg := ColorRect.new()
	bg.color = Color(GameTheme.NAVY, 0.94)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	# round 9: the card always fits the screen (it used to run off the bottom); the words scroll, READY never moves
	var center := MarginContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		center.add_theme_constant_override("margin_" + side, 40)
	for side in ["top", "bottom"]:
		center.add_theme_constant_override("margin_" + side, 22)
	add_child(center)
	var card := GameTheme.panel(GameTheme.PANEL, accent, 4, 26, 22)
	center.add_child(card)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 28)
	card.add_child(row)

	# left: the crew member
	var who := VBoxContainer.new()
	who.custom_minimum_size = Vector2(260, 0)
	who.add_theme_constant_override("separation", 10)
	row.add_child(who)
	if role_id != "":
		var info: Dictionary = Data.db["meta"]["roles"][role_id]
		var art := CrewArt.make(role_id, 170)
		art.bob = true
		art.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		who.add_child(art)
		var nm := GameTheme.label(str(info["name"]), 34, accent, false)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		who.add_child(nm)
		var tt := GameTheme.label(str(info["title"]), 20, GameTheme.TEXT)
		tt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		who.add_child(tt)
		var jb := Button.new()   # LEAD (round 4)
		jb.text = "MY JOB"
		jb.custom_minimum_size = Vector2(0, 52)
		jb.add_theme_font_size_override("font_size", 20)
		jb.pressed.connect(func() -> void: RoleGuide.popup(self, role_id))
		who.add_child(jb)

	# right: the contract
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 10)
	row.add_child(right)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(scroll)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 10)
	scroll.add_child(col)
	var sc: Dictionary = Data.scenario(MissionState.scenario_id)
	col.add_child(GameTheme.label("MISSION BRIEFING", 22, GameTheme.MUTED, false))
	col.add_child(GameTheme.label(str(sc.get("name", "Mission")), 40, GameTheme.AMBER, false))
	col.add_child(GameTheme.label(str(sc.get("briefing", "")), 19, GameTheme.TEXT))

	var goals := HFlowContainer.new()
	goals.add_theme_constant_override("h_separation", 10)
	goals.add_theme_constant_override("v_separation", 10)
	for o in sc.get("objectives", []):
		var chip := GameTheme.panel(GameTheme.PANEL_HI, GameTheme.LINE, 2, 14, 10)
		chip.add_child(GameTheme.label("%s  -  %d pts" % [str(o["label"]), int(o["weight"])], 18, GameTheme.TEXT, false))
		goals.add_child(chip)
	col.add_child(goals)
	for t in MissionState.twist_names():   # round 8: this mission's twist
		col.add_child(GameTheme.label("TWIST: %s! %s" % [str(t.get("name", "")), str(t.get("blurb", ""))], 20, Color("FF9F43")))
	var lives_n: int = int(Data.db["meta"]["difficulty"].get(MissionState.difficulty, {}).get("lives", 0))
	if lives_n > 0:
		col.add_child(GameTheme.label("LIVES: %d. A crisis mistake (a card that doesn't help, or blocking less than half) costs one." % lives_n, 17, GameTheme.MUTED))

	if role_id != "":
		var info2: Dictionary = Data.db["meta"]["roles"][role_id]
		var job := GameTheme.panel(Color(accent, 0.14), accent, 2, 16, 14)
		var jv := VBoxContainer.new()
		jv.add_theme_constant_override("separation", 6)
		job.add_child(jv)
		var picks: Array = []
		for c in info2["owns_choices"]:
			if str(c) == "rtg_count" and not bool(sc.get("rtg_allowed", false)):
				continue
			picks.append(str(CHOICE_WORDS.get(str(c), str(c))))
		jv.add_child(GameTheme.label("YOUR JOB: you choose " + _join_words(picks) + ".", 21, GameTheme.TEXT))
		var g: Dictionary = RoleGuide.guide(role_id)   # LEAD (round 4): the one-line summary + your gauges
		jv.add_child(GameTheme.label(str(g["one_line"]), 19, GameTheme.TEXT))
		if MissionState.commander_mode:
			jv.add_child(GameTheme.label("ONLY YOU SEE: " + " ".join(g["only_you"]) + "  The COMMANDER (host laptop) has the handbook: talk to them!", 18, Color("9FD4FF")))
		jv.add_child(GameTheme.label("SECRET GOAL (+12.5 teamwork points): " + str(info2["private_goal"]), 20, accent))
		col.add_child(job)
		if bool(Data.db["meta"]["difficulty"].get(MissionState.difficulty, {}).get("private_info", false)):
			col.add_child(GameTheme.label("Engineer rules: you only see YOUR numbers. Talk to your crew!", 18, GameTheme.MUTED))

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 16)
	right.add_child(bottom)
	_ready_btn = Button.new()
	_ready_btn.text = "I'M READY!"
	_ready_btn.custom_minimum_size = Vector2(300, 64)
	_ready_btn.add_theme_font_size_override("font_size", 28)
	GameTheme.primary(_ready_btn)
	_ready_btn.pressed.connect(_on_ready)
	bottom.add_child(_ready_btn)
	_timer_label = GameTheme.label("", 20, GameTheme.MUTED)
	_timer_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bottom.add_child(_timer_label)
	if role_id == "":
		_ready_btn.visible = false

	card.pivot_offset = card.size / 2.0
	card.scale = Vector2(0.92, 0.92)
	card.modulate.a = 0.0
	var tw := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(card, "scale", Vector2.ONE, 0.45)
	tw.parallel().tween_property(card, "modulate:a", 1.0, 0.3)


func _process(delta: float) -> void:
	_left = maxf(0.0, _left - delta)
	_timer_label.text = "Design starts in %d s, or when everyone is ready." % int(ceil(_left))


func _on_ready() -> void:
	PanelBridge.set_ready(true)
	_ready_btn.disabled = true
	_ready_btn.text = "READY!"


func _join_words(words: Array) -> String:
	if words.size() <= 1:
		return "".join(words)
	return ", ".join(words.slice(0, words.size() - 1)) + " and " + str(words[-1])
