# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CrewFlight
extends Control
## LEAD (Part 3). What a crew laptop shows during LAUNCH/FLIGHT between crises (the design cards are locked then).
## Your cat, the mission clock, a live orbit view (Dev C's OrbitView), YOUR tokens and what they are for,
## and the outcome of the last event. Crisis cards still pop up on top (RoleOverlay).

var role_id: String = "systems"
var _clock: Label
var _status: Label
var _last: Label
var _cat: CrewArt
var _orbit: OrbitView
var _tray: TokenTray
var _t: float = 0.0


func setup(role: String) -> void:
	role_id = role


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var accent: Color = GameTheme.role_color(role_id)
	theme = GameTheme.build(accent)
	var bg := ColorRect.new()
	bg.color = GameTheme.NAVY
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var stars := Starfield.new()
	stars.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(stars)
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + side, 16)
	add_child(m)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	m.add_child(row)

	var left := GameTheme.panel(GameTheme.PANEL, accent, 3, 22, 18)
	left.custom_minimum_size = Vector2(400, 0)
	row.add_child(left)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 12)
	left.add_child(lv)
	_cat = CrewArt.make(role_id, 150)   # round 8: smaller, so the hearts and tokens fit at 1280 x 720
	_cat.bob = true
	_cat.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	lv.add_child(_cat)
	var info: Dictionary = Data.db["meta"]["roles"][role_id]
	var nm := GameTheme.label(str(info["name"]) + "  -  " + str(info["title"]), 22, accent)
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lv.add_child(nm)
	_clock = GameTheme.label("", 30, GameTheme.AMBER)
	_clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lv.add_child(_clock)
	_status = GameTheme.label("", 20, GameTheme.TEXT)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lv.add_child(_status)
	var lives := LivesBar.new()   # round 8
	lives.heart = 16.0
	lives.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	lv.add_child(lives)
	lv.add_child(GameTheme.label("YOUR TOKENS", 18, GameTheme.AMBER))
	_tray = TokenTray.new()
	_tray.setup(role_id)
	lv.add_child(_tray)
	lv.add_child(GameTheme.label("Your ship had spare power, fuel or money left over, so you got these! In a crisis, cards cost tokens. Short? Tap ASK. A teammate short? Tap GIVE.", 16, GameTheme.MUTED))
	_last = GameTheme.label("", 17, GameTheme.TEXT)
	lv.add_child(_last)

	var right := GameTheme.panel(GameTheme.PANEL, GameTheme.EDGE, 3, 22, 4)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(right)
	_orbit = OrbitView.new()
	_orbit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_orbit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(_orbit)
	_orbit.set_design.call_deferred(MissionState.design)

	MissionState.flight_status_changed.connect(_refresh)
	Net.crisis_result.connect(func(res: Dictionary) -> void:
		_last.text = "Last event: " + Quips.for_result(res, role_id)
		_cat.set_role(role_id, Quips.mood_for(res)))
	_refresh()


func _process(delta: float) -> void:
	_t += delta
	_clock.text = "T+ %02d:%02d" % [int(_t) / 60, int(_t) % 60] if MissionState.phase == "FLIGHT" else "LAUNCH"


func _refresh() -> void:
	if not is_inside_tree():
		return
	var fs: Dictionary = MissionState.flight_status
	var beat: int = int(fs.get("beat", -1))
	var total: int = int(fs.get("total", -1))
	if bool(fs.get("active", false)):
		var t: String = str(fs.get("title", ""))
		if MissionState.commander_mode and str(fs.get("kind", "")) == "crisis":
			t = "ANOMALY! Read your gauges to the Commander"   # round 4: the crisis name is in the handbook
		_status.text = "Event %d of %d: %s" % [beat + 1, total, t]
	elif total > 0:
		_status.text = "Cruising... %d of %d events done." % [maxi(0, beat + 1), total]
	else:
		_status.text = "Reaching orbit..."
