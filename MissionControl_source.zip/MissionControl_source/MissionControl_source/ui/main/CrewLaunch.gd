# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
class_name CrewLaunch
extends Control
## LEAD (merge glue). LAUNCH phase on a crew laptop: big countdown, a rocket that shakes and lifts off,
## and the rocket's reliability shown for tension (UX guide section 6). The outcome is decided on the host;
## if the launch fails the host goes straight to DEBRIEF (mission lost), which replaces this screen.

var _secs: float = 6.0
var _left: float = 6.0
var _rel: float = 0.95
var _num: Label
var _rocket: Control
var _sub: Label
var _rocket_y: float = 0.0
var _lift: float = 0.0


class Rocket extends Control:
	var flame: float = 0.0

	func _draw() -> void:
		var w: float = size.x
		var h: float = size.y
		var cx: float = w / 2.0
		var body := Color("E8EEF9")
		var red := Color("FF7A6B")
		var navy := Color("0B1530")
		# flame
		if flame > 0.0:
			var fl: float = h * 0.25 * flame * (0.85 + randf() * 0.3)
			draw_colored_polygon(PackedVector2Array([Vector2(cx - w * 0.16, h * 0.86), Vector2(cx + w * 0.16, h * 0.86), Vector2(cx, h * 0.86 + fl)]), Color("FFC857"))
			draw_colored_polygon(PackedVector2Array([Vector2(cx - w * 0.08, h * 0.86), Vector2(cx + w * 0.08, h * 0.86), Vector2(cx, h * 0.86 + fl * 0.6)]), Color("FFF3C4"))
		# fins
		draw_colored_polygon(PackedVector2Array([Vector2(cx - w * 0.2, h * 0.6), Vector2(cx - w * 0.42, h * 0.88), Vector2(cx - w * 0.2, h * 0.84)]), red)
		draw_colored_polygon(PackedVector2Array([Vector2(cx + w * 0.2, h * 0.6), Vector2(cx + w * 0.42, h * 0.88), Vector2(cx + w * 0.2, h * 0.84)]), red)
		# body
		draw_rect(Rect2(cx - w * 0.2, h * 0.28, w * 0.4, h * 0.58), body)
		# nose
		draw_colored_polygon(PackedVector2Array([Vector2(cx - w * 0.2, h * 0.28), Vector2(cx + w * 0.2, h * 0.28), Vector2(cx, 0)]), red)
		# window with a cat ear peeking
		draw_circle(Vector2(cx, h * 0.45), w * 0.12, navy)
		draw_circle(Vector2(cx, h * 0.45), w * 0.09, Color("4FB3FF"))
		draw_colored_polygon(PackedVector2Array([Vector2(cx - w * 0.06, h * 0.47), Vector2(cx - w * 0.03, h * 0.41), Vector2(cx, h * 0.47)]), Color("F3E9D2"))


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var pay: Dictionary = MissionState.phase_payload
	_secs = float(pay.get("countdown_s", 6.0))
	_left = _secs
	_rel = float(pay.get("reliability", 0.95))
	var bg := ColorRect.new()
	bg.color = Color(GameTheme.NAVY, 0.96)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var col := VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 6)
	add_child(col)
	col.add_child(_centered(GameTheme.label("LAUNCH", 34, GameTheme.MUTED, false)))
	_num = GameTheme.label("", 160, GameTheme.AMBER, false)
	col.add_child(_centered(_num))
	_rocket = Rocket.new()
	_rocket.custom_minimum_size = Vector2(120, 220)
	col.add_child(_centered(_rocket))
	var odds: String = "Rocket reliability: %d%%" % int(round(_rel * 100.0))
	if not bool(pay.get("can_fail", true)):
		odds += "  (training mode: it always flies)"
	_sub = GameTheme.label(odds, 26, GameTheme.TEXT, false)
	col.add_child(_centered(_sub))


func _centered(c: Control) -> Control:
	var cc := CenterContainer.new()
	cc.add_child(c)
	return cc


var _last_sec: int = -1


func _process(delta: float) -> void:
	_left -= delta
	if _left > 0.0:
		var sec: int = int(ceil(_left))
		if sec != _last_sec:   # MERGE (juice): tick... tick... and a bouncy number
			_last_sec = sec
			Audio.play_sfx("tick")
			Fx.pop(_num, 1.25)
			if sec == 3:
				Audio.play_sfx("liftoff")
		_num.text = str(sec)
		var shake: float = clampf(1.0 - _left / _secs, 0.0, 1.0) * 6.0
		_rocket.position.x += randf_range(-shake, shake) * 0.3
		(_rocket as Rocket).flame = clampf(1.0 - _left / 2.0, 0.0, 1.0)
	else:
		if _num.text != "LIFTOFF!":
			Audio.play_sfx("go")
			Fx.shake(self, 14.0, 0.8)
		_num.text = "LIFTOFF!"
		(_rocket as Rocket).flame = 1.0
		_lift += delta * 900.0
		_rocket.position.y -= delta * (200.0 + _lift)
	_rocket.queue_redraw()
