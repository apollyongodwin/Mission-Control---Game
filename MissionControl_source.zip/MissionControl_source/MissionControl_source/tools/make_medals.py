# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
"""LEAD (round 6). Draws the medal pictures (no licences to track): assets/images/medals/<id>.png, 256 x 256.
Each medal = a two-colour ribbon + a shiny disc + its own emblem. Run: python3 tools/make_medals.py"""
import math, os
from PIL import Image, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "images", "medals")
os.makedirs(OUT, exist_ok=True)
S = 1024  # draw big, shrink for smooth edges

GOLD = ((255, 214, 92), (214, 150, 30), (140, 90, 10))
SILVER = ((235, 240, 250), (170, 182, 200), (95, 105, 125))
BRONZE = ((240, 170, 110), (190, 110, 55), (115, 62, 25))

MEDALS = {
    # id: (metal, ribbon colours, emblem)
    "frugal_flyer": (GOLD, ((46, 139, 87), (120, 210, 140)), "coin"),
    "margin_master": (GOLD, ((41, 98, 255), (130, 175, 255)), "shield"),
    "great_minds": (SILVER, ((156, 39, 176), (220, 150, 235)), "bulbs"),
    "perfect_pass": (GOLD, ((214, 48, 49), (255, 140, 120)), "star"),
    "silent_running": (SILVER, ((30, 30, 60), (110, 110, 160)), "hush"),
    "local_hero": (BRONZE, ((0, 56, 168), (206, 17, 38)), "sun"),
    "helping_paws": (GOLD, ((255, 140, 0), (255, 205, 120)), "paw"),
}
INK = (25, 30, 55)


def ribbon(d, cols):
    a, b = cols
    for i, (x0, x1, c) in enumerate([(300, 470, a), (470, 554, b), (554, 724, a)]):
        d.polygon([(x0, 40), (x1, 40), (x1 + (40 if i == 2 else 0) - (40 if i == 0 else 0), 470), (x0, 470)], fill=c)
    d.polygon([(300, 40), (724, 40), (690, 470), (334, 470)], outline=INK, width=10)


def disc(img, metal):
    hi, mid, lo = metal
    d = ImageDraw.Draw(img)
    cx, cy, r = 512, 640, 300
    d.ellipse((cx - r - 14, cy - r - 14, cx + r + 14, cy + r + 14), fill=INK)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=lo)
    d.ellipse((cx - r + 26, cy - r + 26, cx + r - 26, cy + r - 26), fill=mid)
    # soft top-left shine
    shine = Image.new("RGBA", img.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shine)
    sd.ellipse((cx - 240, cy - 260, cx + 120, cy + 60), fill=hi + (170,))
    shine = shine.filter(ImageFilter.GaussianBlur(60))
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).ellipse((cx - r + 26, cy - r + 26, cx + r - 26, cy + r - 26), fill=255)
    img.paste(Image.alpha_composite(img, shine), (0, 0), mask)
    d = ImageDraw.Draw(img)
    d.ellipse((cx - r + 26, cy - r + 26, cx + r - 26, cy + r - 26), outline=lo, width=12)
    # tick marks around the rim
    for k in range(36):
        a = k * math.tau / 36
        p0 = (cx + math.cos(a) * (r - 8), cy + math.sin(a) * (r - 8))
        p1 = (cx + math.cos(a) * (r - 22), cy + math.sin(a) * (r - 22))
        d.line([p0, p1], fill=hi, width=6)
    return cx, cy


def star(d, cx, cy, R, r, fill, n=5, rot=-math.pi / 2):
    pts = []
    for k in range(n * 2):
        rad = R if k % 2 == 0 else r
        a = rot + k * math.pi / n
        pts.append((cx + math.cos(a) * rad, cy + math.sin(a) * rad))
    d.polygon(pts, fill=fill, outline=INK)


def emblem(d, kind, cx, cy, metal):
    lo = metal[2]
    if kind == "coin":
        d.ellipse((cx - 120, cy - 120, cx + 120, cy + 120), fill=(255, 236, 150), outline=INK, width=14)
        d.text((cx, cy), "$", fill=INK, anchor="mm", font_size=200)
    elif kind == "shield":
        d.polygon([(cx, cy - 150), (cx + 130, cy - 95), (cx + 115, cy + 45), (cx, cy + 160), (cx - 115, cy + 45), (cx - 130, cy - 95)],
                  fill=(120, 170, 255), outline=INK, width=16)
        d.line([(cx - 60, cy), (cx - 10, cy + 55), (cx + 75, cy - 60)], fill="white", width=30, joint="curve")
    elif kind == "bulbs":
        for dx in (-85, 85):
            d.ellipse((cx + dx - 75, cy - 150, cx + dx + 75, cy), fill=(255, 240, 120), outline=INK, width=12)
            d.rectangle((cx + dx - 35, cy, cx + dx + 35, cy + 70), fill=(180, 180, 200), outline=INK, width=10)
        d.line([(cx - 20, cy - 80), (cx + 20, cy - 80)], fill=INK, width=12)
        star(d, cx, cy + 135, 45, 20, (255, 255, 255))
    elif kind == "star":
        star(d, cx, cy, 175, 75, (255, 245, 200))
        d.line([(cx - 55, cy + 5), (cx - 12, cy + 50), (cx + 65, cy - 45)], fill=(46, 139, 87), width=26, joint="curve")
    elif kind == "hush":
        d.polygon([(cx - 140, cy - 50), (cx - 70, cy - 50), (cx + 10, cy - 120), (cx + 10, cy + 120), (cx - 70, cy + 50), (cx - 140, cy + 50)],
                  fill=(230, 235, 250), outline=INK, width=12)
        d.line([(cx + 50, cy - 60), (cx + 150, cy + 60)], fill=(214, 48, 49), width=26)
        d.line([(cx + 150, cy - 60), (cx + 50, cy + 60)], fill=(214, 48, 49), width=26)
    elif kind == "sun":   # the Philippine flag's sun and stars, for a mission that helps home
        d.ellipse((cx - 70, cy - 70, cx + 70, cy + 70), fill=(252, 209, 22), outline=INK, width=10)
        for k in range(8):
            a = k * math.tau / 8
            d.line([(cx + math.cos(a) * 85, cy + math.sin(a) * 85), (cx + math.cos(a) * 150, cy + math.sin(a) * 150)], fill=(252, 209, 22), width=30)
        for a in (-math.pi / 2 - 0.9, -math.pi / 2 + 0.9, math.pi / 2):
            star(d, cx + math.cos(a) * 190, cy + math.sin(a) * 190, 34, 14, (252, 209, 22))
    elif kind == "paw":
        d.ellipse((cx - 85, cy - 10, cx + 85, cy + 130), fill=(255, 245, 235), outline=INK, width=12)
        for (dx, dy) in ((-110, -60), (-45, -125), (45, -125), (110, -60)):
            d.ellipse((cx + dx - 38, cy + dy - 45, cx + dx + 38, cy + dy + 45), fill=(255, 245, 235), outline=INK, width=10)
        d.text((cx, cy + 60), "+1", fill=(214, 120, 0), anchor="mm", font_size=90)


for mid, (metal, rib, kind) in MEDALS.items():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    ribbon(d, rib)
    cx, cy = disc(img, metal)
    emblem(ImageDraw.Draw(img), kind, cx, cy, metal)
    img = img.resize((256, 256), Image.LANCZOS)
    img.save(os.path.join(OUT, mid + ".png"))
    # a grey "locked" version for medals not won yet
    g = img.convert("LA").convert("RGBA")
    a = g.split()[3].point(lambda v: int(v * 0.45))
    g.putalpha(a)
    g.save(os.path.join(OUT, mid + "_locked.png"))
print("made", len(MEDALS), "medals")
