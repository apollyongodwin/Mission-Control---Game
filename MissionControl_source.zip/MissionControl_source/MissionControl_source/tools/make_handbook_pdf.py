# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
"""LEAD (round 5). The illustrated, kid-simple Commander's Handbook.
Input:  handbook/handbook.json + handbook/img/*.png   (made by tools/export_handbook.tscn from the live game)
        assets/images/roles/<role>.png                (the artist's cats)
Output: handbook/Commander_Handbook.pdf  (A4)
"""
import json, os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image,
                                KeepTogether)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
HB = os.path.join(ROOT, "handbook")
IMG = os.path.join(HB, "img")
CATS = os.path.join(ROOT, "assets", "images", "roles")
D = json.load(open(os.path.join(HB, "handbook.json"), encoding="utf-8"))

COL = {"commander": "#B8860B", "flight": "#D9483B", "systems": "#C98A12", "payload": "#2F6FD6", "ground": "#8A4FC9"}
NAVY = colors.HexColor("#14213D")
RED = colors.HexColor("#D63031")
GREEN = colors.HexColor("#1E8449")
W = 180 * mm

title = ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=30, leading=34, textColor=NAVY, alignment=1)
sub = ParagraphStyle("s", fontName="Helvetica", fontSize=14, leading=18, textColor=colors.HexColor("#555555"), alignment=1)
h1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=22, leading=26, textColor=NAVY, spaceAfter=6)
h2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=15, leading=19, textColor=colors.HexColor("#B8860B"), spaceBefore=6, spaceAfter=4)
big = ParagraphStyle("big", fontName="Helvetica", fontSize=13, leading=17)
body = ParagraphStyle("b", fontName="Helvetica", fontSize=11, leading=14)
hw = ParagraphStyle("hw", fontName="Helvetica-Bold", fontSize=9, leading=11, textColor=colors.white)   # round 8: table headers
small = ParagraphStyle("sm", fontName="Helvetica", fontSize=9, leading=11, textColor=colors.HexColor("#444444"))


def P(text, style=body):
    return Paragraph(text, style)


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def cat(role, size):
    p = os.path.join(CATS, role + ".png")
    return Image(p, size, size) if os.path.exists(p) else Spacer(size, size)


def pic(name, w, h=None):
    p = os.path.join(IMG, name + ".png")
    if not os.path.exists(p):
        return Spacer(w, h or w)
    if h is None:
        from reportlab.lib.utils import ImageReader
        iw, ih = ImageReader(p).getSize()
        h = w * ih / iw
    return Image(p, w, h)


def color_role(role, text, bold=True):
    t = esc(text)
    return '<font color="%s">%s%s%s</font>' % (COL.get(role, "#000000"), "<b>" if bold else "", t, "</b>" if bold else "")


def boxed(rows, col, widths, pad=6, head=True):
    t = Table(rows, colWidths=widths)
    st = [("BOX", (0, 0), (-1, -1), 1.5, col), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("LEFTPADDING", (0, 0), (-1, -1), pad), ("RIGHTPADDING", (0, 0), (-1, -1), pad),
          ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if head:
        st.append(("BACKGROUND", (0, 0), (-1, 0), col))
    t.setStyle(TableStyle(st))
    return t


def alarm_pill(role, gauge):
    """What the crew's gauge tile looks like when it says ALARM."""
    t = Table([[P('<font color="#ffffff"><b>%s</b></font><br/><font color="#ffffff" size="8">%s</font>' %
                  (esc(gauge), "!!! ALARM"), small)]], colWidths=[40 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), RED), ("BOX", (0, 0), (-1, -1), 2, colors.HexColor(COL[role])),
                           ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


story = []

# ---------------------------------------------------------------- page 1: cover + how to play
story += [Spacer(1, 6 * mm), P("MISSION CONTROL", title), P("The Commander's Handbook", sub), Spacer(1, 6 * mm)]
story.append(Table([[cat(r, 34 * mm) for r in ["flight", "systems", "payload", "ground"]]], colWidths=[45 * mm] * 4))
story += [Spacer(1, 3 * mm), P("<b>Keep this away from the crew!</b> They have the spaceship. You have the book. Nobody wins alone.", sub),
          Spacer(1, 8 * mm), P("How to play, in 3 steps", h1)]
steps = [
    ("1. BUILD", "Your crew picks parts. They <b>can't</b> see prices or if a part is right. You can! Ask each of them "
                 "what they picked. Tap a part on your screen to tell them to <b>SWAP</b> it.", "crew_design",
     "What your crew sees. The red words show a part you flagged."),
    ("2. VOTE", "When the ship looks good, the crew votes GO. Then you say GO or NO-GO. Nobody launches while a part is "
                "flagged SWAP.", None, None),
    ("3. FLY AND FIX", "Space is dangerous! When an ANOMALY hits, the crew sees gauges and a clock. You don't. Ask: "
                       "<b>\"Is anything on ALARM?\"</b> Tap their alarms on your screen (or use the crisis page in this book) "
                       "and tell them which card to play. If your screen flashes <font color='#D63031'><b>red</b></font>, hurry!",
     "crew_crisis_flight", "What FLIGHT sees in a crisis: two gauges, the clock and their cards."),
]
for head, text, img, cap in steps:
    left = [P("<b>%s</b>" % head, h2), P(text, big)]
    if img:
        right = [pic(img, 78 * mm), P(cap, small)]
        story.append(Table([[left, right]], colWidths=[100 * mm, 80 * mm], style=[("VALIGN", (0, 0), (-1, -1), "TOP")]))
    else:
        story += left
    story.append(Spacer(1, 4 * mm))
story.append(PageBreak())

# ---------------------------------------------------------------- page 2: the crew
story.append(P("Meet your crew", h1))
story.append(P("Each crew member picks different parts and watches different gauges. Get to know them!", big))
story.append(Spacer(1, 3 * mm))
for j in D["jobs"]:
    r = j["role"]
    if r == "commander":
        continue
    col = colors.HexColor(COL[r])
    text = [P(color_role(r, "%s  -  %s" % (j["name"], j["title"])), h2), P(esc(j["one_line"]), big),
            P("<b>Watches:</b> " + esc(" and ".join(j["gauges"]).lower()), body),
            P("<b>Tip for you:</b> " + esc(j["tip"]), small)]
    t = Table([[cat(r, 30 * mm), text]], colWidths=[34 * mm, 146 * mm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1.5, col), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                           ("BACKGROUND", (0, 0), (0, 0), colors.HexColor("#F4F6FB"))]))
    story += [t, Spacer(1, 4 * mm)]
story.append(PageBreak())

# ---------------------------------------------------------------- page 3: crisis finder
story.append(P("Crisis finder", h1))
story.append(P("1. Ask everyone: <b>\"Is anything on ALARM?\"</b>   2. Find the line with the <b>same</b> red alarms.   "
               "3. Read out the green words.", big))
story.append(Spacer(1, 2 * mm))
story.append(P("A crew gauge on ALARM looks like this:", body))
story.append(Table([[alarm_pill("flight", "PARTICLE COUNTER"), P("and an OK gauge is <font color='#1E8449'><b>green</b></font>. "
                                                                 "Gauges that are not listed must say OK.", body)]],
                   colWidths=[45 * mm, 135 * mm], style=[("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
story.append(Spacer(1, 3 * mm))
rows = [[P("<b>Alarms the crew reports</b>", body), P("<b>It's a...</b>", body), P("<b>Say this</b>", body)]]
for c in D["crises"]:
    alarms = Table([[cat(a["role"], 8 * mm), P(color_role(a["role"], "%s: %s" % (a["role_name"], a["gauge"].lower())), small)]
                    for a in c["alarms"]], colWidths=[9 * mm, 52 * mm],
                   style=[("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 1), ("TOPPADDING", (0, 0), (-1, -1), 1),
                          ("BOTTOMPADDING", (0, 0), (-1, -1), 1)])
    says = "<br/>".join('<font color="#1E8449"><b>Tell %s:</b></font> play "%s"%s' % (esc(x["role_name"]), esc(x["card"]),
                        ('<br/><font color="#B8860B" size="7">(%s)</font>' % esc(x["note"])) if x.get("note") else "") for x in c["calls"])
    rows.append([alarms, P("<b>%s</b><br/><font size='8' color='#666666'>%s</font>" % (esc(c["title"]), esc(c["nick"])), small), P(says, small)])
t = Table(rows, colWidths=[64 * mm, 44 * mm, 72 * mm], repeatRows=1)
t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.6, colors.HexColor("#BBBBBB")), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#FFE9A8")),
                       ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
                       ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                       ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F7FB")])]))
story.append(t)
story.append(Spacer(1, 3 * mm))
story.append(P("Two crises can share one alarm (like the Sun sneezing and the radiation zone). That is why you must ask <b>everyone</b>!", body))
story.append(PageBreak())

# ---------------------------------------------------------------- page 4: what the crew's cards look like
story.append(P("Your crew's crisis cards", h1))
story.append(P("These are the cards on your crew's screens. They don't know which one works. You do (crisis finder page)!", big))
story.append(Spacer(1, 3 * mm))
for r in ["flight", "systems", "payload", "ground"]:
    col = colors.HexColor(COL[r])
    cards = [c for c in D["cards"] if c["role"] == r]
    cells = []
    for c in cards:
        inner = [P('<font color="%s"><b>%s</b></font>' % (COL[r], esc(c["label"])), body), P(esc(c["blurb"]), small),
                 P("Costs: " + esc(c["cost"] or "nothing"), small)]
        if c.get("note"):
            inner.append(P('<font color="#B8860B"><b>%s</b></font>' % esc(c["note"]), small))
        box = Table([[inner]], colWidths=[42 * mm])
        box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1.2, col), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F8F9FD")),
                                 ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        cells.append(box)
    while len(cells) % 4:
        cells.append("")
    grid = [cells[i:i + 4] for i in range(0, len(cells), 4)]
    head = Table([[cat(r, 12 * mm), P(color_role(r, r.upper() + "'s cards"), h2)]], colWidths=[14 * mm, 166 * mm],
                 style=[("VALIGN", (0, 0), (-1, -1), "MIDDLE")])
    story.append(KeepTogether([head, Table(grid, colWidths=[45 * mm] * 4, style=[("VALIGN", (0, 0), (-1, -1), "TOP")]), Spacer(1, 3 * mm)]))
story.append(PageBreak())

# ---------------------------------------------------------------- medals (round 6)
MEDALS = [("frugal_flyer", "Frugal Flyer", "Spend 3/4 of the money or less."),
          ("margin_master", "Margin Master", "Keep every safety margin full."),
          ("great_minds", "Great Minds", "Pick 2 instruments that work great together."),
          ("perfect_pass", "Perfect Pass", "Beat every crisis with no damage."),
          ("silent_running", "Silent Running", "Perfect Pass on Flight Director level."),
          ("local_hero", "Local Hero", "Bagyo Watch: tropical orbit + rain gauges."),
          ("helping_paws", "Helping Paws", "Hand 2 tokens to teammates in a crisis.")]
MEDAL_DIR = os.path.join(ROOT, "assets", "images", "medals")
story.append(P("Medals to win", h1))
story.append(P("Medals show up at the end of every mission. Which ones can your team win?", big))
story.append(Spacer(1, 3 * mm))
cells = []
for mid, name, how in MEDALS:
    p = os.path.join(MEDAL_DIR, mid + ".png")
    img = Image(p, 26 * mm, 26 * mm) if os.path.exists(p) else Spacer(26 * mm, 26 * mm)
    cells.append(Table([[img], [P("<b>%s</b>" % name, body)], [P(how, small)]], colWidths=[42 * mm],
                       style=[("ALIGN", (0, 0), (-1, -1), "CENTER")]))
while len(cells) % 4:
    cells.append("")
story.append(Table([cells[i:i + 4] for i in range(0, len(cells), 4)], colWidths=[45 * mm] * 4,
                   style=[("VALIGN", (0, 0), (-1, -1), "TOP")]))
story.append(Spacer(1, 6 * mm))
story.append(P("Tokens", h1))
story.append(P("When the ship launches, its spare power, fuel, money and so on become <b>tokens</b>. Crisis cards cost tokens. "
               "Some cards need a <b>teammate's</b> token: the crew member taps <b>ASK</b> and the teammate taps <b>GIVE</b>. "
               "You can see everyone's tokens in the gauge finder, so you can say who should help who!", big))
story.append(PageBreak())

# ---------------------------------------------------------------- round 8: lives, mini-tasks, twists
story.append(P("Lives, mini-tasks and twists", h1))
story.append(P("<b>Lives.</b> Cadet 3, Engineer 2, Flight Director 1. A crisis is a <b>mistake</b> when the crew blocks "
               "less than half of it, or someone plays a card that does not help at all. Each mistake costs a life. "
               "No lives left = the mission is called off. So: only name the cards the crisis finder says!", big))
story.append(Spacer(1, 2 * mm))
story.append(P("<b>Mini-tasks.</b> Sometimes everyone gets a quick task at once (surprise maintenance). And on a lucky "
               "chance, the crew member who taps <b>CHIP IN</b> does a task alone: finish it and the team wins the reward. "
               "Every finished task gives that crew member 1 token.", big))
tasks = [("flight", "FLIGHT", "Asteroid field: tap the space rocks before they hit."),
         ("systems", "SYSTEMS", "Fix the wiring: match colour AND shape."),
         ("payload", "PAYLOAD", "Decode the data: read a binary number."),
         ("ground", "GROUND", "Align the antenna: trace the signal, don't touch the walls.")]
rows = [[cat(r, 12 * mm), P(color_role(r, n), body), P(t, body)] for r, n, t in tasks]
story.append(Table(rows, colWidths=[15 * mm, 30 * mm, 135 * mm], style=[("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
story.append(Spacer(1, 2 * mm))
story.append(P("<b>Mission twists.</b> Every mission rolls one surprise rule. Read it at the briefing!", big))
for t in D.get("twists", []):
    story.append(P("&bull; <b>%s</b>: %s" % (esc(t["name"]), esc(t["blurb"])), body))
story.append(Spacer(1, 2 * mm))
story.append(P("<b>The build clock.</b> When it reaches 0:00, investors take money back every few seconds AND FLIGHT "
               "loses time tokens. The budget also depends on the orbit: hard orbits come with bigger contracts.", big))
story.append(PageBreak())

# ---------------------------------------------------------------- round 8: ground stations (comms help)
story.append(P("Comms is red? Ground stations", h1))
story.append(P("A station can only hear the ship if it <b>reaches the orbit</b> AND has the <b>same radio</b> as the "
               "ship's antenna. More stations = more talking time = more data home.", big))
story.append(Spacer(1, 2 * mm))
rows = [[P("Station", hw), P("Reaches", hw), P("Radios", hw), P("Price", hw)]]
for st in D.get("stations", []):
    rows.append([P(esc(st["name"]), small), P(esc(st["reaches"]), small), P(esc(st["radios"]), small), P(st["price"], small)])
story.append(boxed(rows, colors.HexColor(COL["ground"]), [70 * mm, 55 * mm, 35 * mm, 20 * mm]))
story.append(Spacer(1, 3 * mm))
story.append(P("Antennas and their radio", h2))
rows = [[P(esc(a["name"]), small), P("<b>%s</b>" % esc(a["radio"]), small)] for a in D.get("antennas", [])]
story.append(boxed(rows, colors.HexColor(COL["ground"]), [90 * mm, 30 * mm], head=False))
story.append(Spacer(1, 3 * mm))
story.append(P("Still red? A faster antenna, a computer that squeezes data (SYSTEMS), fewer data-hungry instruments "
               "(PAYLOAD), or steadier pointing (FLIGHT) so a sharp antenna can aim.", big))
story.append(PageBreak())

# ---------------------------------------------------------------- round 8: how science works
story.append(P("How science works", h1))
for i, line in enumerate(D.get("science_steps", []), 1):
    story.append(P("<b>%d.</b> %s" % (i, esc(line)), big))
story.append(Spacer(1, 2 * mm))
for sc in D.get("science", []):
    goals = sc["goals"]
    head = [P(esc(sc["name"]), hw)] + [P("%s<br/>%d pts, full at %d" % (esc(g["label"]), g["points"], g["full_at"]), hw) for g in goals]
    rows = [head]
    for ins in sc["instruments"]:
        rows.append([P(esc(ins["name"]), small)] + [P(("+%d" % ins["helps"].get(g["tag"], 0)) if ins["helps"].get(g["tag"], 0) else "-", small) for g in goals])
    w0 = 66 * mm
    story.append(KeepTogether([P(sc["name"], h2), boxed(rows, colors.HexColor(COL["payload"]), [w0] + [(W - w0) / len(goals)] * len(goals))]))
    story.append(Spacer(1, 2 * mm))
story.append(PageBreak())

# ---------------------------------------------------------------- round 8: tips and help
story.append(P("Tips and help", h1))
for t in D.get("more_tips", []):
    story.append(P("<b>%s.</b> %s" % (esc(t[0]), esc(t[1])), big))
    story.append(Spacer(1, 1.5 * mm))
story.append(PageBreak())

# ---------------------------------------------------------------- parts pages: the pictures the crew sees
story.append(P("The parts", h1))
story.append(P("These are the same pictures your crew sees on their cards, but only <b>you</b> see the price. "
               "<b>$</b> = cheap, <b>$$$</b> = pricey.", big))
for tip in D["tips"]:
    story.append(P("&bull; " + esc(tip), body))
story.append(Spacer(1, 3 * mm))
for g in D["parts"]:
    r = g["owner"]
    col = colors.HexColor(COL.get(r, "#333333"))
    cells = []
    for it in g["items"]:
        inner = Table([[pic("part_" + it["id"], 16 * mm, 16 * mm),
                        [P("<b>%s</b>" % esc(it["name"]), small), P('<font color="#B8860B"><b>%s</b></font>  %s' % (esc(it["price"]), esc(it["weight"])), small)]]],
                      colWidths=[18 * mm, 40 * mm], style=[("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 1)])
        box = Table([[inner]], colWidths=[59 * mm])
        box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1, col)]))
        cells.append(box)
    while len(cells) % 3:
        cells.append("")
    grid = [cells[i:i + 3] for i in range(0, len(cells), 3)]
    head = P(color_role(r, "%s  (%s picks)" % (g["label"].upper(), g["owner_name"])), h2)
    story.append(KeepTogether([head, Table(grid, colWidths=[60 * mm] * 3)]))


def footer(c, doc):
    c.saveState()
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawString(15 * mm, 9 * mm, "MISSION CONTROL %s  -  Commander's Handbook  -  Team Pawstronauts" % D.get("version", ""))
    c.drawString(15 * mm, 5 * mm, "Made with AI assistance (Claude, Anthropic): see AI_DISCLOSURE.md")
    c.drawRightString(195 * mm, 9 * mm, "page %d" % doc.page)
    c.restoreState()


out = os.path.join(HB, "Commander_Handbook.pdf")
doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=12 * mm, bottomMargin=14 * mm,
                        title="Mission Control - Commander's Handbook", author="Team Pawstronauts")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print("wrote", out)
