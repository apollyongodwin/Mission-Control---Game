# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
extends Node
## LEAD (round 4, pictures added in round 5). Builds everything the printable handbook needs from the LIVE game:
##   handbook/handbook.json            crises, gauges, cards, parts, crew jobs (kid words)
##   handbook/img/part_<id>.png        the same part pictures the crew sees on their cards
##   handbook/img/crew_crisis_<role>.png   what each crew member sees in a crisis (gauges + cards)
##   handbook/img/crew_design.png      what a crew member sees while building
## Needs a screen (pictures), so run it with a window or under xvfb:
##   godot --path . res://tools/export_handbook.tscn
## then:  python3 tools/make_handbook_pdf.py   ->  handbook/Commander_Handbook.pdf

const OUT := "res://handbook"


func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT + "/img"))
	MissionState.set_difficulty("engineer")
	MissionState.set_commander_mode(true)
	var f := FileAccess.open(OUT + "/handbook.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(CommanderHandbook.as_json(), "  "))
	f.close()
	print("wrote handbook.json")
	await _part_pictures()
	await _crew_crisis_pictures()
	await _crew_design_picture()
	print("HANDBOOK EXPORT DONE")
	get_tree().quit()


func _viewport(size: Vector2i, transparent: bool) -> SubViewport:
	var vp := SubViewport.new()
	vp.size = size
	vp.transparent_bg = transparent
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	return vp


func _save(vp: SubViewport, name: String) -> void:
	for i in 6:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	vp.get_texture().get_image().save_png(ProjectSettings.globalize_path(OUT + "/img/" + name + ".png"))


func _part_pictures() -> void:
	var vp := _viewport(Vector2i(160, 160), true)
	for cat in CommanderHandbook.PART_ORDER + ["rocket"]:
		var items: Array = Data.db["rockets"] if cat == "rocket" else Data.db["parts"].get(cat, [])
		var owner: String = "ground" if cat == "rocket" else SimEngine._owner_of(Data.db, cat)
		for it in items:
			for c in vp.get_children():
				vp.remove_child(c)
				c.queue_free()
			var icon := PartIcon.make(cat, it, RoleGuide.color(owner), 156)
			icon.position = Vector2(2, 2)
			icon.size = Vector2(156, 156)
			vp.add_child(icon)
			await _save(vp, "part_" + str(it["id"]))
	vp.queue_free()
	print("wrote part pictures")


func _crew_crisis_pictures() -> void:
	MissionState.tokens = {"flight": {"fuel": 2, "time": 2}, "systems": {"power": 4}, "payload": {"data": 3}, "ground": {"budget": 3, "comms": 2}}
	var ev: Dictionary = {}
	for e in Data.db["events"]:
		if e["id"] == "solar_flare":
			ev = (e as Dictionary).duplicate(true)
	for role in Protocol.ROLES:
		var vp := _viewport(Vector2i(1280, 720), false)
		var bg := ColorRect.new()
		bg.color = GameTheme.NAVY
		bg.size = Vector2(1280, 720)
		vp.add_child(bg)
		var panel = (load("res://ui/common/CrisisPanel.tscn") as PackedScene).instantiate()
		panel.position = Vector2(20, 20)
		panel.size = Vector2(1240, 680)
		panel.theme = GameTheme.build(RoleGuide.color(role))
		vp.add_child(panel)
		panel.setup(role, RoleGuide.color(role))
		panel.show_event(ev, 25.0)
		await _save(vp, "crew_crisis_" + role)
		vp.queue_free()
	print("wrote crew crisis pictures")


func _crew_design_picture() -> void:
	var vp := _viewport(Vector2i(1280, 720), false)
	var p = (load("res://ui/roles/SystemsPanel.tscn") as PackedScene).instantiate()
	vp.add_child(p)
	MissionState.set_mark("bus", "swap")   # show what a flagged part looks like
	MissionState.set_phase("DESIGN")
	await _save(vp, "crew_design")
	MissionState.set_mark("bus", "")
	vp.queue_free()
	print("wrote crew design picture")
