# AI-assisted: written with help from Claude (Anthropic). See AI_DISCLOSURE.md and data/credits.json.
"""COUNTDOWN sound generator (Lead). Builds every sound effect and the music loop from maths, so the team owns
them outright (no licences to track). Re-run to regenerate:  python tools/make_sfx.py
Output: assets/audio/sfx/*.wav  and  assets/audio/music/*.ogg (needs ffmpeg; falls back to .wav)."""
import os, subprocess, numpy as np
from scipy.signal import butter, lfilter
from scipy.io import wavfile

SR = 44100
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
rng = np.random.default_rng(2026)


def t(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.005, r=None, shape=4.0):
    x = np.ones(n)
    na = max(1, int(SR * a)); x[:na] = np.linspace(0, 1, na)
    if r is None: x *= np.exp(-shape * np.linspace(0, 1, n))
    return x
def lp(x, f, o=2): b, a = butter(o, min(f, SR / 2 - 100) / (SR / 2)); return lfilter(b, a, x)
def hp(x, f, o=2): b, a = butter(o, f / (SR / 2), "high"); return lfilter(b, a, x)
def sine(f, d): return np.sin(2 * np.pi * np.cumsum(np.broadcast_to(f, t(d).shape)) / SR)
def square(f, d): return np.sign(sine(f, d))
def saw(f, d):
    ph = np.cumsum(np.broadcast_to(f, t(d).shape)) / SR
    return 2 * (ph % 1) - 1
def noise(d): return rng.uniform(-1, 1, len(t(d)))
def note(n): return 440.0 * 2 ** ((n - 69) / 12)
def bell(f, d, k=5.0): x = t(d); return (np.sin(2*np.pi*f*x) + .4*np.sin(2*np.pi*f*2.01*x) + .2*np.sin(2*np.pi*f*3.02*x)) * np.exp(-k*x)
def cat(*xs): return np.concatenate(xs)
def mix(*xs):
    n = max(len(x) for x in xs); out = np.zeros(n)
    for x in xs: out[:len(x)] += x
    return out
def norm(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak
def fade_out(x, d=0.02):
    n = int(SR * d); x = x.copy(); x[-n:] *= np.linspace(1, 0, n); return x


def save(name, x, peak=0.85):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    x = fade_out(norm(x, peak))
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), SR, (x * 32767).astype(np.int16))


S = {}
# --- UI
S["click"] = lp(noise(0.03), 4000) * env(len(t(0.03)), 0.001, shape=12) + 0.5 * sine(1800, 0.03) * env(len(t(0.03)), 0.001, shape=20)
S["snap"] = mix(sine(np.linspace(900, 1500, len(t(0.09))), 0.09) * env(len(t(0.09)), 0.002, shape=9), 0.4 * lp(noise(0.02), 6000))  # part picked: "pop!"
S["whoosh"] = lp(hp(noise(0.5), 300), 2500) * np.sin(np.linspace(0, np.pi, len(t(0.5)))) ** 2
S["coin"] = cat(bell(note(88), 0.07, 20), bell(note(93), 0.35, 9))
S["chime"] = mix(bell(note(88), 0.6, 6), np.pad(bell(note(95), 0.6, 6), (int(SR * .08), 0)))       # green light
S["buzz"] = lp(square(110, 0.28) * 0.6 + saw(111, 0.28) * 0.4, 900) * env(len(t(0.28)), 0.01, shape=3)  # red light (soft)
S["tick"] = sine(1000, 0.07) * env(len(t(0.07)), 0.001, shape=10)                                     # countdown
S["go"] = sine(1600, 0.35) * env(len(t(0.35)), 0.001, shape=3)                                       # zero!
# NASA's real "Quindar tones": 2525 Hz to open the mic, 2475 Hz to close it (Apollo radio). Used for chat and pings.
S["quindar"] = cat(sine(2525, 0.25), np.zeros(int(SR * 0.04)), sine(2475, 0.25)) * 0.6
S["quindar_in"] = sine(2525, 0.22) * 0.6
S["stamp"] = mix(lp(noise(0.25), 400) * env(len(t(0.25)), 0.001, shape=14), sine(np.linspace(140, 50, len(t(0.25))), 0.25) * env(len(t(0.25)), 0.001, shape=8))
S["medal"] = mix(*[np.pad(bell(note(n), 0.8, 5), (int(SR * i * .07), 0)) for i, n in enumerate([84, 88, 91, 96])])
S["confetti"] = mix(*[np.pad(lp(noise(0.05), 7000) * env(len(t(0.05)), 0.001, shape=15) * rng.uniform(.3, 1), (int(SR * rng.uniform(0, .6)), 0)) for _ in range(28)])
# --- drama
k = t(1.4); S["alarm"] = (square(np.where((k * 2.5) % 1 < .5, 660, 520), 1.4) * 0.5 + sine(np.where((k * 2.5) % 1 < .5, 660, 520), 1.4)) * 0.5
S["alarm"] = lp(S["alarm"], 3000) * env(len(k), 0.01, shape=0.8)
S["success"] = mix(*[np.pad(bell(note(n), 0.5, 5) + 0.3 * square(note(n), 0.5) * env(len(t(.5)), .005, shape=8), (int(SR * i * .1), 0)) for i, n in enumerate([72, 76, 79, 84])])
# Sad trombone: wah wah wah waaaah (for NO-GO and bad outcomes). Sawtooth through a "wah" filter with vibrato.
def wah(n0, d, vib=False):
    f = note(n0) * (1 + (0.012 * np.sin(2 * np.pi * 6 * t(d)) if vib else 0))
    x = saw(f, d); out = np.zeros_like(x); seg = 2048
    for i in range(0, len(x), seg):
        prog = i / len(x); out[i:i+seg] = lp(x[i:i+seg], 600 + 1800 * np.sin(np.pi * min(1, prog * 1.6)))
    return out * env(len(x), 0.03, shape=1.5 if not vib else 2.5)
S["sad_trombone"] = cat(wah(62, .38), wah(61, .38), wah(60, .38), wah(59, 1.3, True)) * 0.8
S["fail"] = S["sad_trombone"]
d = 3.2; S["liftoff"] = lp(noise(d), 300) * np.linspace(0.2, 1, len(t(d))) ** 1.5 + 0.6 * lp(noise(d), 1200) * np.linspace(0, 1, len(t(d))) ** 3
S["liftoff"] *= env(len(t(d)), 0.3, shape=0.4)
# Big cartoon KABOOM: crack + low thump + rumble tail + debris tinkles.
d = 2.8; e = env(len(t(d)), 0.001, shape=3.2)
boom = mix(lp(noise(d), 700) * e * 1.4 + sine(np.linspace(90, 28, len(t(d))), d) * env(len(t(d)), 0.001, shape=4) * 1.2, hp(noise(0.08), 2000) * 0.8)
debris = mix(*[np.pad(bell(rng.uniform(1500, 4000), 0.2, 18) * 0.15, (int(SR * rng.uniform(.4, 2.0)), 0)) for _ in range(14)])
S["explosion"] = mix(boom, debris)
S["hit"] = mix(lp(noise(0.6), 900) * env(len(t(0.6)), 0.001, shape=6), sine(np.linspace(120, 40, len(t(.6))), .6) * env(len(t(.6)), .001, shape=7))  # crisis damage
S["warp"] = sine(np.linspace(200, 1400, len(t(0.6))) ** 1.0, 0.6) * env(len(t(0.6)), 0.05, shape=2) * 0.5
# --- round 3 (Lead): crew sounds. A synthetic "meow" = a buzzy source through a sliding vowel filter (ee -> ow).
def meow(f0, d, bright=1.0):
    n = len(t(d)); pitch = f0 * (1 + 0.35 * np.sin(np.linspace(0, np.pi, n)) ** 1.5)
    src = saw(pitch, d) * 0.6 + square(pitch, d) * 0.2; out = np.zeros(n); seg = 512
    for i in range(0, n, seg):
        p = i / n; fc = (2600 - 1700 * p) * bright
        out[i:i+seg] = lp(src[i:i+seg], fc)
    return out * env(n, 0.04, shape=2.2)
S["meow_flight"] = meow(520, 0.42, 1.1)     # quick pilot "mrrp!"
S["meow_systems"] = meow(380, 0.55, 0.9)    # engineer: lower, chunkier
S["meow_payload"] = meow(640, 0.38, 1.2)    # scientist: high and curious
S["meow_ground"] = meow(300, 0.7, 0.8)      # director: long, calm
S["join"] = mix(bell(note(79), 0.4, 8), np.pad(bell(note(86), 0.5, 7), (int(SR * .09), 0)), np.pad(0.4 * S["quindar_in"][:int(SR*.1)], (int(SR*.0), 0)))
S["ready"] = cat(sine(note(84), 0.06) * env(len(t(0.06)), 0.002, shape=6), sine(note(91), 0.22) * env(len(t(0.22)), 0.002, shape=5))
S["unready"] = cat(sine(note(84), 0.06) * env(len(t(0.06)), 0.002, shape=6), sine(note(77), 0.2) * env(len(t(0.2)), 0.002, shape=5))
S["token"] = mix(bell(note(91), 0.25, 14), np.pad(bell(note(98), 0.3, 12), (int(SR * .05), 0)), 0.3 * lp(noise(0.04), 8000))
S["type"] = np.pad(hp(noise(0.018), 2500) * env(len(t(0.018)), 0.001, shape=20), (0, int(SR*0.03)))
S["hover"] = np.pad(sine(2200, 0.03) * env(len(t(0.03)), 0.001, shape=14) * 0.4, (0, int(SR*0.02)))
S["error"] = cat(square(220, 0.09), np.zeros(int(SR*.03)), square(196, 0.14)) * 0.3
S["review"] = mix(*[np.pad(bell(note(n), 0.4, 8), (int(SR * i * .06), 0)) for i, n in enumerate([76, 81, 88])])
S["win_sting"] = mix(*[np.pad(bell(note(n), 1.6, 2.5) + 0.25 * saw(note(n), 1.6) * env(len(t(1.6)), .01, shape=2.5), (int(SR * i * .14), 0)) for i, n in enumerate([60, 64, 67, 72, 76, 79, 84])])
S["lose_sting"] = cat(wah(55, .5), wah(54, .5), wah(53, 1.6, True)) * 0.7
for name, x in S.items():
    save(name, x, 0.9 if name in ("explosion", "liftoff") else 0.8)


# --- music: a calm "mission control lounge" loop (A minor pentatonic pads + plucks), 32 s, seamless.
def music():
    bpm = 96; beat = 60 / bpm; bars = 12; total = int(SR * beat * 4 * bars)
    out = np.zeros(total)
    chords = [[57, 60, 64], [53, 57, 60], [55, 59, 62], [52, 55, 59]]
    for b in range(bars):
        ch = chords[b % 4]; start = int(SR * beat * 4 * b); dur = beat * 4
        pad = sum(lp(saw(note(n) * (1 + 0.003 * j), dur), 900) for n in ch for j in (-1, 1)) / 6
        pad *= np.sin(np.linspace(0, np.pi, len(pad))) ** 0.6
        out[start:start + len(pad)] += pad * 0.35
        bass = sine(note(ch[0] - 12), dur) * env(len(t(dur)), 0.02, shape=1.2)
        out[start:start + len(bass)] += bass * 0.25
        scale = [69, 72, 74, 76, 79, 81]
        for s in range(8):
            if rng.random() < 0.7:
                n = scale[rng.integers(len(scale))]; p0 = start + int(SR * beat * s / 2)
                pl = bell(note(n), beat * 1.5, 4) * 0.12
                end = min(total, p0 + len(pl)); out[p0:end] += pl[:end - p0]
    # gentle radio-static bed
    out += lp(noise(total / SR), 3000)[:total] * 0.01
    return norm(out, 0.6)


def drums(total, beat, kick_pat, hat_pat, snare_pat, swing=0.0):
    out = np.zeros(total); steps = int(total / (SR * beat / 4))
    kk = sine(np.linspace(120, 45, len(t(.25))), .25) * env(len(t(.25)), .001, shape=6)
    hh = hp(noise(.05), 7000) * env(len(t(.05)), .001, shape=12) * 0.25
    sn = mix(lp(noise(.18), 5000) * env(len(t(.18)), .001, shape=8) * .5, sine(190, .18) * env(len(t(.18)), .001, shape=10) * .4)
    for s in range(steps):
        p = int(SR * beat / 4 * (s + (swing if s % 2 else 0)))
        for pat, smp in ((kick_pat, kk), (hat_pat, hh), (snare_pat, sn)):
            if pat[s % len(pat)] == "x":
                e = min(total, p + len(smp)); out[p:e] += smp[:e - p]
    return out


def groove(bpm, bars, chords, lead_scale, kick, hat, snare, pad_cut=1200, lead_p=0.55, seed=3, bass_oct=-12):
    r = np.random.default_rng(seed); beat = 60 / bpm; total = int(SR * beat * 4 * bars); out = np.zeros(total)
    for b in range(bars):
        ch = chords[b % len(chords)]; st = int(SR * beat * 4 * b); dur = beat * 4
        pad = sum(lp(saw(note(n) * (1 + 0.004 * j), dur), pad_cut) for n in ch for j in (-1, 1)) / 6
        pad *= np.sin(np.linspace(0, np.pi, len(pad))) ** 0.5
        out[st:st + len(pad)] += pad * 0.25
        for q in range(4):   # bouncy bass on every beat
            bs = lp(square(note(ch[0] + bass_oct), beat * .9), 500) * env(len(t(beat * .9)), .005, shape=3)
            p0 = st + int(SR * beat * q); e = min(total, p0 + len(bs)); out[p0:e] += bs[:e - p0] * 0.22
        for s in range(8):
            if r.random() < lead_p:
                n = lead_scale[r.integers(len(lead_scale))]; p0 = st + int(SR * beat * s / 2)
                pl = (bell(note(n), beat, 7) * .7 + .3 * square(note(n), beat) * env(len(t(beat)), .003, shape=9)) * 0.13
                e = min(total, p0 + len(pl)); out[p0:e] += pl[:e - p0]
    out += drums(total, beat, kick, hat, snare) * 0.5
    return norm(out, 0.6)


def flight_amb():
    d = 48.0; n = len(t(d)); out = np.zeros(n)
    for f, a in ((note(45), .3), (note(52), .2), (note(57), .15)):   # slow drone, breathing
        out += lp(saw(f * (1 + .002 * np.sin(2 * np.pi * .05 * t(d))), d), 600) * a * (0.7 + 0.3 * np.sin(2 * np.pi * t(d) / 12))
    beat = 60 / 72.0
    for k in range(int(d / beat)):   # soft telemetry "blip" heartbeat
        p0 = int(SR * k * beat); bl = sine(note(93 if k % 4 == 0 else 88), .05) * env(len(t(.05)), .001, shape=10) * .08
        out[p0:p0 + len(bl)] += bl[:max(0, min(len(bl), n - p0))]
    out += lp(noise(d), 2500) * 0.012
    return norm(out, 0.55)


TRACKS = {
    "lounge": music(),   # menu + lobby (the original calm loop)
    "design": groove(112, 16, [[60, 64, 67], [57, 60, 64], [65, 69, 72], [67, 71, 74]], [72, 74, 76, 79, 81, 84],
                     "x...x...x...x...", "..x...x...x...x.", "....x.......x...", seed=5),            # bouncy "build it!" tune
    "flight": flight_amb(),                                                                           # mission in space
    "crisis": groove(138, 8, [[57, 60, 64], [58, 62, 65], [57, 60, 64], [56, 59, 64]], [69, 70, 72, 75, 76],
                     "x..x..x.x..x..x.", "xxxxxxxxxxxxxxxx", "....x.......x..x", pad_cut=700, lead_p=0.75, seed=9),  # uh-oh
}
os.makedirs(os.path.join(ROOT, "music"), exist_ok=True)
for name, m in TRACKS.items():
    wav = os.path.join(ROOT, "music", name + ".wav")
    wavfile.write(wav, SR, (m * 32767).astype(np.int16))
    try:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "4", wav[:-4] + ".ogg"], check=True)
        os.remove(wav)
    except Exception as ex:
        print("ffmpeg not available, kept wav:", ex)
print("made", len(S), "sounds + music")
